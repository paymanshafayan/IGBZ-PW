import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/dashboard_provider.dart';
import '../../shared/widgets/async_state_view.dart';
import '../../shared/widgets/formatters.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final provider = context.read<DashboardProvider>();
    await provider.load();
    if (provider.data != null && mounted) {
      context.read<AuthProvider>().cacheStoreName(provider.data!.storeName);
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DashboardProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(provider.data?.storeName ?? 'داشبورد')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: AsyncStateView(
          isLoading: provider.isLoading && provider.data == null,
          error: provider.data == null ? provider.error : null,
          onRetry: _load,
          child: provider.data == null
              ? const SizedBox()
              : _DashboardBody(data: provider.data!),
        ),
      ),
    );
  }
}

class _DashboardBody extends StatelessWidget {
  final dynamic data; // DashboardData
  const _DashboardBody({required this.data});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (data.subscriptionStatus == 'PastDue' || data.subscriptionStatus == 'Suspended')
          Card(
            color: Colors.red.shade50,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber_rounded, color: Colors.red),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      data.subscriptionStatus == 'Suspended'
                          ? 'اشتراک فروشگاه شما معلق شده است. برای فعال‌سازی مجدد با پشتیبانی تماس بگیرید.'
                          : 'پرداخت اشتراک شما با تاخیر مواجه شده است.',
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _StatCard(
                title: 'سفارش‌های امروز',
                value: '${data.ordersToday}',
                icon: Icons.today_rounded,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _StatCard(
                title: 'در انتظار بررسی',
                value: '${data.pendingOrdersCount}',
                icon: Icons.pending_actions_rounded,
                highlight: data.pendingOrdersCount > 0,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _StatCard(
          title: 'فروش این ماه',
          value: Formatters.toman(data.revenueThisMonth as double),
          icon: Icons.payments_rounded,
          wide: true,
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _StatCard(
                title: 'سفارش‌های این ماه',
                value: '${data.ordersThisMonth}',
                icon: Icons.receipt_long_rounded,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _StatCard(
                title: 'تعداد محصولات',
                value: '${data.totalProducts}',
                icon: Icons.inventory_2_rounded,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('وضعیت اشتراک', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                Text('وضعیت: ${_statusLabel(data.subscriptionStatus as String)}'),
                if (data.subscriptionRenewsOnUtc != null)
                  Text('تمدید بعدی: ${Formatters.shortDate(data.subscriptionRenewsOnUtc as DateTime)}'),
              ],
            ),
          ),
        ),
      ],
    );
  }

  String _statusLabel(String status) => switch (status) {
        'Trial' => 'دورهٔ آزمایشی',
        'Active' => 'فعال',
        'PastDue' => 'پرداخت با تاخیر',
        'Suspended' => 'معلق',
        'Cancelled' => 'لغوشده',
        _ => status,
      };
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final bool wide;
  final bool highlight;

  const _StatCard({
    required this.title,
    required this.value,
    required this.icon,
    this.wide = false,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = highlight ? Colors.orange : Theme.of(context).colorScheme.primary;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                  Text(
                    value,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
