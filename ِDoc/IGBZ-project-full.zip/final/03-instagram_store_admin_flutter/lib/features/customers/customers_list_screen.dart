import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/customers_provider.dart';
import '../../shared/widgets/async_state_view.dart';
import '../../shared/widgets/formatters.dart';
import 'customer_detail_screen.dart';

class CustomersListScreen extends StatefulWidget {
  const CustomersListScreen({super.key});

  @override
  State<CustomersListScreen> createState() => _CustomersListScreenState();
}

class _CustomersListScreenState extends State<CustomersListScreen> {
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<CustomersProvider>().loadFirstPage());
    _scrollController.addListener(() {
      if (_scrollController.position.pixels > _scrollController.position.maxScrollExtent - 200) {
        context.read<CustomersProvider>().loadNextPage();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CustomersProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('مشتریان')),
      body: AsyncStateView(
        isLoading: provider.isLoading,
        error: provider.items.isEmpty ? provider.error : null,
        onRetry: provider.loadFirstPage,
        child: provider.items.isEmpty
            ? const Center(child: Text('هنوز مشتری‌ای سفارش ثبت نکرده است.'))
            : RefreshIndicator(
                onRefresh: provider.loadFirstPage,
                child: ListView.separated(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(12),
                  itemCount: provider.items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final customer = provider.items[index];
                    return Card(
                      child: ListTile(
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: customer.id)),
                        ),
                        leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                        title: Text(customer.fullName.isEmpty ? customer.email : customer.fullName),
                        subtitle: Text('${customer.orderCount} سفارش'),
                        trailing: Text(Formatters.toman(customer.totalSpent)),
                      ),
                    );
                  },
                ),
              ),
      ),
    );
  }
}
