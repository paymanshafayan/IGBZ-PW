import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/customers_provider.dart';
import '../../shared/widgets/formatters.dart';
import '../orders/order_detail_screen.dart';

class CustomerDetailScreen extends StatefulWidget {
  final int customerId;
  const CustomerDetailScreen({super.key, required this.customerId});

  @override
  State<CustomerDetailScreen> createState() => _CustomerDetailScreenState();
}

class _CustomerDetailScreenState extends State<CustomerDetailScreen> {
  CustomerDetail? _customer;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      _customer = await context.read<CustomersProvider>().loadDetail(widget.customerId);
    } catch (e) {
      _error = e.toString();
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_customer?.fullName ?? 'مشتری')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.email_outlined),
                              title: Text(_customer!.email, textDirection: TextDirection.ltr),
                            ),
                            if (_customer!.phoneNumber != null)
                              ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: const Icon(Icons.phone_outlined),
                                title: Text(_customer!.phoneNumber!, textDirection: TextDirection.ltr),
                              ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: Card(
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                children: [
                                  Text('${_customer!.orderCount}', style: Theme.of(context).textTheme.titleLarge),
                                  const Text('تعداد سفارش', style: TextStyle(color: Colors.grey, fontSize: 12)),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Card(
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                children: [
                                  Text(Formatters.toman(_customer!.totalSpent),
                                      style: Theme.of(context).textTheme.titleMedium),
                                  const Text('مجموع خرید', style: TextStyle(color: Colors.grey, fontSize: 12)),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text('سابقهٔ سفارش‌ها', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    ..._customer!.orders.map((order) => Card(
                          child: ListTile(
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: order.id)),
                            ),
                            title: Text('سفارش #${order.customOrderNumber}'),
                            subtitle: Text(Formatters.shortDate(order.createdOnUtc)),
                            trailing: Text(order.orderTotalFormatted),
                          ),
                        )),
                  ],
                ),
    );
  }
}
