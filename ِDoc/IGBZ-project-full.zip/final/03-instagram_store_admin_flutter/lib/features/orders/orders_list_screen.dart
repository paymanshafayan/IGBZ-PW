import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/order_models.dart';
import '../../core/providers/orders_provider.dart';
import '../../shared/widgets/async_state_view.dart';
import '../../shared/widgets/formatters.dart';
import 'order_detail_screen.dart';

class OrdersListScreen extends StatefulWidget {
  const OrdersListScreen({super.key});

  @override
  State<OrdersListScreen> createState() => _OrdersListScreenState();
}

class _OrdersListScreenState extends State<OrdersListScreen> {
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<OrdersProvider>().loadFirstPage());
    _scrollController.addListener(() {
      if (_scrollController.position.pixels > _scrollController.position.maxScrollExtent - 200) {
        context.read<OrdersProvider>().loadNextPage();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<OrdersProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('سفارش‌ها')),
      body: AsyncStateView(
        isLoading: provider.isLoading,
        error: provider.items.isEmpty ? provider.error : null,
        onRetry: provider.loadFirstPage,
        child: provider.items.isEmpty
            ? const Center(child: Text('هنوز سفارشی ثبت نشده است.'))
            : RefreshIndicator(
                onRefresh: provider.loadFirstPage,
                child: ListView.separated(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(12),
                  itemCount: provider.items.length + (provider.isLoadingMore ? 1 : 0),
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    if (index >= provider.items.length) {
                      return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    }
                    return _OrderTile(order: provider.items[index]);
                  },
                ),
              ),
      ),
    );
  }
}

class _OrderTile extends StatelessWidget {
  final OrderListItem order;
  const _OrderTile({required this.order});

  Color _statusColor(String status) => switch (status) {
        'Pending' => Colors.orange,
        'Processing' => Colors.blue,
        'Complete' => Colors.green,
        'Cancelled' => Colors.red,
        _ => Colors.grey,
      };

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: order.id)),
        ),
        leading: CircleAvatar(
          backgroundColor: _statusColor(order.orderStatus).withValues(alpha: 0.12),
          child: Icon(Icons.receipt_long_rounded, color: _statusColor(order.orderStatus), size: 20),
        ),
        title: Text('سفارش #${order.customOrderNumber}'),
        subtitle: Text(
          '${order.customerFullName ?? order.customerEmail ?? ''} • ${Formatters.shortDate(order.createdOnUtc)}',
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(order.orderTotalFormatted, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: _statusColor(order.orderStatus).withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                order.orderStatus,
                style: TextStyle(color: _statusColor(order.orderStatus), fontSize: 11),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
