import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/order_models.dart';
import '../../core/providers/orders_provider.dart';
import '../../core/providers/shipments_provider.dart';
import '../../shared/widgets/formatters.dart';

class OrderDetailScreen extends StatefulWidget {
  final int orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  OrderDetail? _order;
  bool _isLoading = true;
  String? _error;
  bool _isUpdatingStatus = false;

  @override
  void initState() {
    super.initState();
    _load();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => context.read<ShipmentsProvider>().loadForOrder(widget.orderId),
    );
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      _order = await context.read<OrdersProvider>().loadDetail(widget.orderId);
    } catch (e) {
      _error = e.toString();
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _changeStatus(OrderStatusOption status) async {
    setState(() => _isUpdatingStatus = true);
    final error = await context.read<OrdersProvider>().updateStatus(widget.orderId, status);
    if (!mounted) return;
    setState(() => _isUpdatingStatus = false);

    if (error == null) {
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('وضعیت سفارش به‌روزرسانی شد.')));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _createShipment() async {
    final trackingController = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('ثبت مرسوله'),
        content: TextField(
          controller: trackingController,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(labelText: 'کد رهگیری (اختیاری)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ثبت')),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    final error = await context.read<ShipmentsProvider>().createForOrder(
          widget.orderId,
          trackingNumber: trackingController.text.trim().isEmpty ? null : trackingController.text.trim(),
        );

    if (!mounted) return;
    if (error == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('مرسوله ثبت شد.')));
      _load();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final shipments = context.watch<ShipmentsProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(_order != null ? 'سفارش #${_order!.customOrderNumber}' : 'جزئیات سفارش')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_order!.customerFullName ?? _order!.customerEmail ?? 'مشتری',
                                style: Theme.of(context).textTheme.titleMedium),
                            if (_order!.customerPhone != null) Text(_order!.customerPhone!),
                            if (_order!.shippingAddressText != null) Text(_order!.shippingAddressText!),
                            const SizedBox(height: 8),
                            Text('تاریخ ثبت: ${Formatters.dateTime(_order!.createdOnUtc)}'),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('تغییر وضعیت سفارش', style: Theme.of(context).textTheme.titleSmall),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              children: OrderStatusOption.values.map((status) {
                                final isCurrent = status.apiValue == _order!.orderStatus;
                                return ChoiceChip(
                                  label: Text(status.label),
                                  selected: isCurrent,
                                  onSelected: _isUpdatingStatus ? null : (_) => _changeStatus(status),
                                );
                              }).toList(),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
                            child: Text('اقلام سفارش', style: Theme.of(context).textTheme.titleSmall),
                          ),
                          ..._order!.items.map((item) => ListTile(
                                title: Text(item.productName),
                                subtitle: Text('تعداد: ${item.quantity}'),
                                trailing: Text(Formatters.toman(item.lineTotal)),
                              )),
                          const Divider(height: 1),
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('جمع کل', style: TextStyle(fontWeight: FontWeight.bold)),
                                Text(_order!.orderTotalFormatted, style: const TextStyle(fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('مرسولات', style: Theme.of(context).textTheme.titleSmall),
                                TextButton.icon(
                                  onPressed: shipments.isCreating ? null : _createShipment,
                                  icon: const Icon(Icons.local_shipping_outlined, size: 18),
                                  label: const Text('ثبت مرسوله'),
                                ),
                              ],
                            ),
                            if (shipments.items.isEmpty)
                              const Padding(
                                padding: EdgeInsets.symmetric(vertical: 8),
                                child: Text('هنوز مرسوله‌ای ثبت نشده است.', style: TextStyle(color: Colors.grey)),
                              )
                            else
                              ...shipments.items.map((s) => ListTile(
                                    contentPadding: EdgeInsets.zero,
                                    leading: const Icon(Icons.inventory_2_outlined),
                                    title: Text(s.trackingNumber ?? 'بدون کد رهگیری'),
                                    subtitle: Text(
                                      s.shippedOnUtc != null
                                          ? 'ارسال‌شده: ${Formatters.shortDate(s.shippedOnUtc!)}'
                                          : 'در انتظار ارسال',
                                    ),
                                  )),
                          ],
                        ),
                      ),
                    ),
                    if (_order!.notes.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('یادداشت‌های داخلی', style: Theme.of(context).textTheme.titleSmall),
                              const SizedBox(height: 8),
                              ..._order!.notes.map((n) => Padding(
                                    padding: const EdgeInsets.only(bottom: 6),
                                    child: Text('• ${n.note}', style: const TextStyle(fontSize: 13)),
                                  )),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
    );
  }
}
