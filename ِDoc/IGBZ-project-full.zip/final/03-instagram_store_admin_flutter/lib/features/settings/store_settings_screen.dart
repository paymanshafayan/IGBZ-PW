import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../core/models/store_settings_model.dart';
import '../../core/providers/store_settings_provider.dart';

/// صفحهٔ «تنظیمات ظاهری فروشگاه» - عمداً شبیه صفحهٔ «ویرایش پروفایل» اینستاگرام طراحی شده
/// (آواتار دایره‌ای وسط با آیکن دوربین روی آن، دکمهٔ «ذخیره» آبی در بالا-راست، ردیف افقی
/// دایره‌های رنگی برای انتخاب رنگ - دقیقاً مثل انتخابگر رنگ Highlight/Story اینستاگرام) چون
/// کاربران هدف این اپ (فعالان کسب‌وکار اینستاگرامی) از قبل با این الگو کاملاً آشنا هستند.
class StoreSettingsScreen extends StatefulWidget {
  const StoreSettingsScreen({super.key});

  @override
  State<StoreSettingsScreen> createState() => _StoreSettingsScreenState();
}

class _StoreSettingsScreenState extends State<StoreSettingsScreen> {
  final _picker = ImagePicker();

  Uint8List? _pendingLogoBytes;
  String? _pendingLogoMimeType;
  Color? _selectedColor;
  bool _removeLogoPending = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<StoreSettingsProvider>().load());
  }

  Future<void> _pickLogo() async {
    final picked = await _picker.pickImage(source: ImageSource.gallery, maxWidth: 1024, maxHeight: 1024, imageQuality: 85);
    if (picked == null) return;

    final bytes = await picked.readAsBytes();
    final mimeType = picked.mimeType ?? (picked.path.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg');

    setState(() {
      _pendingLogoBytes = bytes;
      _pendingLogoMimeType = mimeType;
      _removeLogoPending = false;
    });
  }

  void _removeLogo() {
    setState(() {
      _pendingLogoBytes = null;
      _pendingLogoMimeType = null;
      _removeLogoPending = true;
    });
  }

  bool _hasUnsavedChanges(StoreSettingsData? current) {
    final colorChanged = _selectedColor != null && colorToHex(_selectedColor!) != current?.brandColorHex;
    return _pendingLogoBytes != null || _removeLogoPending || colorChanged;
  }

  Future<void> _save() async {
    final provider = context.read<StoreSettingsProvider>();
    final messenger = ScaffoldMessenger.of(context);
    String? failure;

    if (_pendingLogoBytes != null && _pendingLogoMimeType != null) {
      failure = await provider.updateLogo(_pendingLogoBytes!, _pendingLogoMimeType!);
    } else if (_removeLogoPending) {
      failure = await provider.removeLogo();
    }

    if (failure == null && _selectedColor != null) {
      failure = await provider.updateColor(colorToHex(_selectedColor!));
    }

    if (!mounted) return;

    if (failure != null) {
      messenger.showSnackBar(SnackBar(content: Text(failure), backgroundColor: Colors.red));
      return;
    }

    setState(() {
      _pendingLogoBytes = null;
      _pendingLogoMimeType = null;
      _removeLogoPending = false;
      _selectedColor = null;
    });

    messenger.showSnackBar(const SnackBar(content: Text('تغییرات ذخیره شد ✓'), backgroundColor: Colors.green));
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StoreSettingsProvider>();
    final current = provider.data;
    final hasChanges = _hasUnsavedChanges(current);
    final effectiveColor = _selectedColor ?? current?.brandColor ?? const Color(0xFF2F80ED);

    return Scaffold(
      appBar: AppBar(
        title: const Text('ویرایش فروشگاه'),
        actions: [
          if (provider.isSaving)
            const Padding(
              padding: EdgeInsets.only(left: 16),
              child: Center(child: SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))),
            )
          else
            TextButton(
              onPressed: hasChanges ? _save : null,
              child: Text(
                'ذخیره',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: hasChanges ? Theme.of(context).colorScheme.primary : Colors.grey,
                ),
              ),
            ),
        ],
      ),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Column(
                children: [
                  _LogoAvatar(
                    bytes: _pendingLogoBytes,
                    logoUrl: _removeLogoPending ? null : current?.logoUrl,
                    ringColor: effectiveColor,
                    onTap: _pickLogo,
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: _pickLogo,
                    child: const Text('تغییر لوگوی فروشگاه', style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                  if ((current?.logoUrl != null && !_removeLogoPending) || _pendingLogoBytes != null)
                    TextButton(
                      onPressed: _removeLogo,
                      child: const Text('حذف لوگو', style: TextStyle(color: Colors.red)),
                    ),
                  const SizedBox(height: 8),
                  const Divider(height: 40),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Icon(Icons.palette_outlined, color: Theme.of(context).colorScheme.primary),
                        const SizedBox(width: 8),
                        const Text('رنگ برند فروشگاه', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      'این رنگ در اپلیکیشن مشتریان شما به‌عنوان رنگ اصلی نمایش داده می‌شود - دقیقاً '
                      'مثل انتخاب رنگ برای استوری یا هایلایت در اینستاگرام.',
                      style: TextStyle(color: Colors.grey, fontSize: 12.5),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _ColorPaletteRow(
                    selectedColor: effectiveColor,
                    onSelected: (color) => setState(() => _selectedColor = color),
                  ),
                ],
              ),
            ),
    );
  }
}

/// آواتار دایره‌ای با حلقهٔ رنگی دور آن - همان الگوی آشنای عکس پروفایل/استوری اینستاگرام
class _LogoAvatar extends StatelessWidget {
  final Uint8List? bytes;
  final String? logoUrl;
  final Color ringColor;
  final VoidCallback onTap;

  const _LogoAvatar({required this.bytes, required this.logoUrl, required this.ringColor, required this.onTap});

  @override
  Widget build(BuildContext context) {
    ImageProvider? image;
    if (bytes != null) {
      image = MemoryImage(bytes!);
    } else if (logoUrl != null && logoUrl!.isNotEmpty) {
      image = NetworkImage(logoUrl!);
    }

    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: 108,
            height: 108,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [ringColor, ringColor.withValues(alpha: 0.4)],
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(3),
              decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
              child: CircleAvatar(
                radius: 48,
                backgroundColor: Colors.grey.shade200,
                backgroundImage: image,
                child: image == null ? Icon(Icons.storefront_rounded, size: 40, color: Colors.grey.shade500) : null,
              ),
            ),
          ),
          Positioned(
            bottom: 2,
            right: 2,
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: ringColor,
                border: Border.all(color: Colors.white, width: 2.5),
              ),
              child: const Icon(Icons.camera_alt_rounded, size: 16, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

/// ردیف افقی دایره‌های رنگی با حلقهٔ انتخاب - دقیقاً همان الگوی «انتخاب رنگ پس‌زمینه» در
/// ادیتور استوری/هایلایت اینستاگرام
class _ColorPaletteRow extends StatelessWidget {
  final Color selectedColor;
  final ValueChanged<Color> onSelected;

  const _ColorPaletteRow({required this.selectedColor, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 76,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: kBrandColorPalette.length,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (context, index) {
          final entry = kBrandColorPalette[index];
          final color = entry.value;
          final isSelected = color.toARGB32() == selectedColor.toARGB32();

          return GestureDetector(
            onTap: () => onSelected(color),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  width: 52,
                  height: 52,
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: isSelected ? Border.all(color: color, width: 2.5) : null,
                  ),
                  child: Container(
                    decoration: BoxDecoration(shape: BoxShape.circle, color: color),
                    child: isSelected ? const Icon(Icons.check_rounded, color: Colors.white) : null,
                  ),
                ),
                const SizedBox(height: 4),
                Text(entry.key, style: const TextStyle(fontSize: 11)),
              ],
            ),
          );
        },
      ),
    );
  }
}
