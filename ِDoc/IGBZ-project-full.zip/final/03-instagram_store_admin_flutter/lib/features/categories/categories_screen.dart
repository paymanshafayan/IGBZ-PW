import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/catalog_extra_models.dart';
import '../../core/providers/categories_provider.dart';
import '../../shared/widgets/async_state_view.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<CategoriesProvider>().load());
  }

  Future<void> _showForm({CategoryItem? existing}) async {
    final nameController = TextEditingController(text: existing?.name ?? '');
    final descController = TextEditingController(text: existing?.description ?? '');
    bool published = existing?.published ?? true;

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(existing == null ? 'دسته‌بندی جدید' : 'ویرایش دسته‌بندی'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameController, decoration: const InputDecoration(labelText: 'نام')),
              const SizedBox(height: 12),
              TextField(controller: descController, decoration: const InputDecoration(labelText: 'توضیح (اختیاری)')),
              const SizedBox(height: 8),
              SwitchListTile(
                value: published,
                onChanged: (v) => setDialogState(() => published = v),
                title: const Text('نمایش در فروشگاه'),
                contentPadding: EdgeInsets.zero,
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ذخیره')),
          ],
        ),
      ),
    );

    if (saved != true || nameController.text.trim().isEmpty) return;

    final request = CategoryUpsertRequest(
      name: nameController.text.trim(),
      description: descController.text.trim(),
      published: published,
    );

    final provider = context.read<CategoriesProvider>();
    final error = existing == null
        ? await provider.create(request)
        : await provider.update(existing.id, request);

    if (!mounted) return;
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _delete(CategoryItem category) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف دسته‌بندی'),
        content: Text('«${category.name}» حذف شود؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await context.read<CategoriesProvider>().delete(category.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CategoriesProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('دسته‌بندی‌ها')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showForm(),
        child: const Icon(Icons.add),
      ),
      body: AsyncStateView(
        isLoading: provider.isLoading,
        error: provider.items.isEmpty ? provider.error : null,
        onRetry: provider.load,
        child: provider.items.isEmpty
            ? const Center(child: Text('هنوز دسته‌بندی‌ای اضافه نکرده‌اید.'))
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: provider.items.length,
                itemBuilder: (context, index) {
                  final category = provider.items[index];
                  return Card(
                    child: ListTile(
                      title: Text(category.name),
                      subtitle: category.description?.isNotEmpty == true ? Text(category.description!) : null,
                      onTap: () => _showForm(existing: category),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline_rounded, color: Colors.red),
                        onPressed: () => _delete(category),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
