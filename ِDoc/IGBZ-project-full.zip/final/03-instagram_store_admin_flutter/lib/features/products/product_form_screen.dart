import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/product_models.dart';
import '../../core/providers/categories_provider.dart';
import '../../core/providers/products_provider.dart';

class ProductFormScreen extends StatefulWidget {
  final ProductListItem? product;
  const ProductFormScreen({super.key, this.product});

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _skuController;
  late final TextEditingController _priceController;
  late final TextEditingController _stockController;
  late final TextEditingController _descriptionController;
  bool _published = true;
  final Set<int> _selectedCategoryIds = {};
  bool _isSaving = false;

  bool get _isEditing => widget.product != null;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.product?.name ?? '');
    _skuController = TextEditingController(text: widget.product?.sku ?? '');
    _priceController = TextEditingController(text: widget.product?.price.toStringAsFixed(0) ?? '');
    _stockController = TextEditingController(text: widget.product?.stockQuantity.toString() ?? '0');
    _descriptionController = TextEditingController();
    _published = widget.product?.published ?? true;

    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<CategoriesProvider>().load());
  }

  @override
  void dispose() {
    _nameController.dispose();
    _skuController.dispose();
    _priceController.dispose();
    _stockController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    final request = ProductUpsertRequest(
      name: _nameController.text.trim(),
      shortDescription: _descriptionController.text.trim(),
      sku: _skuController.text.trim().isEmpty ? null : _skuController.text.trim(),
      price: double.tryParse(_priceController.text) ?? 0,
      stockQuantity: int.tryParse(_stockController.text) ?? 0,
      published: _published,
      categoryIds: _selectedCategoryIds.toList(),
    );

    final provider = context.read<ProductsProvider>();
    final error = _isEditing
        ? await provider.updateProduct(widget.product!.id, request)
        : await provider.createProduct(request);

    if (!mounted) return;
    setState(() => _isSaving = false);

    if (error == null) {
      Navigator.of(context).pop();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف محصول'),
        content: const Text('آیا مطمئن هستید؟ این عمل قابل بازگشت نیست.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final error = await context.read<ProductsProvider>().deleteProduct(widget.product!.id);
    if (!mounted) return;

    if (error == null) {
      Navigator.of(context).pop();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final categories = context.watch<CategoriesProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'ویرایش محصول' : 'محصول جدید'),
        actions: [
          if (_isEditing)
            IconButton(onPressed: _delete, icon: const Icon(Icons.delete_outline_rounded)),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'نام محصول'),
              validator: (v) => (v == null || v.isEmpty) ? 'نام محصول را وارد کنید' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _descriptionController,
              decoration: const InputDecoration(labelText: 'توضیح کوتاه'),
              maxLines: 3,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _priceController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'قیمت (تومان)'),
                    validator: (v) => (v == null || double.tryParse(v) == null) ? 'قیمت نامعتبر' : null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _stockController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'موجودی'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _skuController,
              decoration: const InputDecoration(labelText: 'کد محصول / SKU (اختیاری)'),
              textDirection: TextDirection.ltr,
            ),
            const SizedBox(height: 12),
            SwitchListTile(
              value: _published,
              onChanged: (v) => setState(() => _published = v),
              title: const Text('نمایش در فروشگاه'),
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 12),
            Text('دسته‌بندی‌ها', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            if (categories.isLoading)
              const Center(child: CircularProgressIndicator())
            else
              Wrap(
                spacing: 8,
                children: categories.items.map((c) {
                  final selected = _selectedCategoryIds.contains(c.id);
                  return FilterChip(
                    label: Text(c.name),
                    selected: selected,
                    onSelected: (v) => setState(() {
                      if (v) {
                        _selectedCategoryIds.add(c.id);
                      } else {
                        _selectedCategoryIds.remove(c.id);
                      }
                    }),
                  );
                }).toList(),
              ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isSaving ? null : _save,
              child: _isSaving
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : Text(_isEditing ? 'ذخیرهٔ تغییرات' : 'ایجاد محصول'),
            ),
          ],
        ),
      ),
    );
  }
}
