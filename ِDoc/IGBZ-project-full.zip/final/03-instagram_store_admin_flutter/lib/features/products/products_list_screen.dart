import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/product_models.dart';
import '../../core/providers/products_provider.dart';
import '../../shared/widgets/async_state_view.dart';
import '../../shared/widgets/formatters.dart';
import 'product_form_screen.dart';

class ProductsListScreen extends StatefulWidget {
  const ProductsListScreen({super.key});

  @override
  State<ProductsListScreen> createState() => _ProductsListScreenState();
}

class _ProductsListScreenState extends State<ProductsListScreen> {
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<ProductsProvider>().loadFirstPage());
    _scrollController.addListener(() {
      if (_scrollController.position.pixels > _scrollController.position.maxScrollExtent - 200) {
        context.read<ProductsProvider>().loadNextPage();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProductsProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('محصولات')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const ProductFormScreen()),
        ),
        child: const Icon(Icons.add),
      ),
      body: AsyncStateView(
        isLoading: provider.isLoading,
        error: provider.items.isEmpty ? provider.error : null,
        onRetry: provider.loadFirstPage,
        child: provider.items.isEmpty
            ? const Center(child: Text('هنوز محصولی اضافه نکرده‌اید.'))
            : RefreshIndicator(
                onRefresh: provider.loadFirstPage,
                child: ListView.separated(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(12),
                  itemCount: provider.items.length + (provider.isLoadingMore ? 1 : 0),
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    if (index >= provider.items.length) {
                      return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    }
                    return _ProductTile(product: provider.items[index]);
                  },
                ),
              ),
      ),
    );
  }
}

class _ProductTile extends StatelessWidget {
  final ProductListItem product;
  const _ProductTile({required this.product});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => ProductFormScreen(product: product)),
        ),
        leading: CircleAvatar(
          backgroundColor: product.published ? Colors.green.shade50 : Colors.grey.shade200,
          child: Icon(
            product.published ? Icons.visibility_rounded : Icons.visibility_off_rounded,
            color: product.published ? Colors.green : Colors.grey,
            size: 20,
          ),
        ),
        title: Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('موجودی: ${product.stockQuantity}${product.sku != null ? ' • ${product.sku}' : ''}'),
        trailing: Text(
          Formatters.toman(product.price),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
