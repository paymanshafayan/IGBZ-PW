import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/catalog_extra_models.dart';
import '../../core/providers/discounts_provider.dart';
import '../../shared/widgets/async_state_view.dart';

class DiscountsScreen extends StatefulWidget {
  const DiscountsScreen({super.key});

  @override
  State<DiscountsScreen> createState() => _DiscountsScreenState();
}

class _DiscountsScreenState extends State<DiscountsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<DiscountsProvider>().load());
  }

  Future<void> _showForm({DiscountItem? existing}) async {
    final nameController = TextEditingController(text: existing?.name ?? '');
    final couponController = TextEditingController(text: existing?.couponCode ?? '');
    final amountController = TextEditingController(
      text: existing == null
          ? ''
          : (existing.usePercentage ? existing.discountPercentage : existing.discountAmount).toString(),
    );
    bool usePercentage = existing?.usePercentage ?? true;

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(existing == null ? 'تخفیف جدید' : 'ویرایش تخفیف'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameController, decoration: const InputDecoration(labelText: 'عنوان تخفیف')),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: DropdownButtonFormField<bool>(
                      initialValue: usePercentage,
                      decoration: const InputDecoration(labelText: 'نوع'),
                      items: const [
                        DropdownMenuItem(value: true, child: Text('درصدی')),
                        DropdownMenuItem(value: false, child: Text('مبلغ ثابت')),
                      ],
                      onChanged: (v) => setDialogState(() => usePercentage = v ?? true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: amountController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(labelText: usePercentage ? 'درصد' : 'مبلغ (تومان)'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: couponController,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'کد تخفیف (اختیاری)'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ذخیره')),
          ],
        ),
      ),
    );

    if (saved != true || nameController.text.trim().isEmpty) return;

    final amount = double.tryParse(amountController.text) ?? 0;
    final request = DiscountUpsertRequest(
      name: nameController.text.trim(),
      usePercentage: usePercentage,
      discountPercentage: usePercentage ? amount : 0,
      discountAmount: usePercentage ? 0 : amount,
      couponCode: couponController.text.trim().isEmpty ? null : couponController.text.trim(),
    );

    final provider = context.read<DiscountsProvider>();
    final error = existing == null
        ? await provider.create(request)
        : await provider.update(existing.id, request);

    if (!mounted) return;
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _delete(DiscountItem discount) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف تخفیف'),
        content: Text('«${discount.name}» حذف شود؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await context.read<DiscountsProvider>().delete(discount.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DiscountsProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('تخفیف‌ها')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showForm(),
        child: const Icon(Icons.add),
      ),
      body: AsyncStateView(
        isLoading: provider.isLoading,
        error: provider.items.isEmpty ? provider.error : null,
        onRetry: provider.load,
        child: provider.items.isEmpty
            ? const Center(child: Text('هنوز تخفیفی تعریف نکرده‌اید.'))
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: provider.items.length,
                itemBuilder: (context, index) {
                  final discount = provider.items[index];
                  final valueLabel =
                      discount.usePercentage ? '٪${discount.discountPercentage}' : '${discount.discountAmount} تومان';
                  return Card(
                    child: ListTile(
                      onTap: () => _showForm(existing: discount),
                      leading: const Icon(Icons.local_offer_outlined),
                      title: Text(discount.name),
                      subtitle: discount.couponCode != null
                          ? Text('کد: ${discount.couponCode}', textDirection: TextDirection.ltr)
                          : null,
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(valueLabel, style: const TextStyle(fontWeight: FontWeight.bold)),
                          IconButton(
                            icon: const Icon(Icons.delete_outline_rounded, color: Colors.red),
                            onPressed: () => _delete(discount),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
