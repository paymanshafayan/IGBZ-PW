import 'package:intl/intl.dart';
import 'package:shamsi_date/shamsi_date.dart';

class Formatters {
  Formatters._();

  static final _numberFormat = NumberFormat.decimalPattern('en');

  static String toman(double amount) => '${_numberFormat.format(amount)} تومان';

  static String shortDate(DateTime utc) {
    final local = utc.toLocal();
    final jalali = Jalali.fromDateTime(local);
    return '${jalali.year}/${jalali.month.toString().padLeft(2, '0')}/${jalali.day.toString().padLeft(2, '0')}';
  }

  static String dateTime(DateTime utc) {
    final local = utc.toLocal();
    final jalali = Jalali.fromDateTime(local);
    final time = '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
    return '${jalali.year}/${jalali.month.toString().padLeft(2, '0')}/${jalali.day.toString().padLeft(2, '0')} - $time';
  }
}
