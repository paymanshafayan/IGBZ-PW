import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../api/api_models.dart';
import '../models/catalog_extra_models.dart';
import '../models/order_models.dart';

class CustomerDetail extends CustomerListItem {
  final List<OrderListItem> orders;

  CustomerDetail({
    required super.id,
    required super.email,
    required super.fullName,
    super.phoneNumber,
    required super.orderCount,
    required super.totalSpent,
    super.lastOrderOnUtc,
    required this.orders,
  });

  factory CustomerDetail.fromJson(Map<String, dynamic> json) => CustomerDetail(
        id: json['id'] as int,
        email: json['email'] as String? ?? '',
        fullName: json['fullName'] as String? ?? '',
        phoneNumber: json['phoneNumber'] as String?,
        orderCount: json['orderCount'] as int? ?? 0,
        totalSpent: (json['totalSpent'] as num?)?.toDouble() ?? 0,
        lastOrderOnUtc:
            json['lastOrderOnUtc'] == null ? null : DateTime.parse(json['lastOrderOnUtc'] as String),
        orders: (json['orders'] as List? ?? [])
            .map((e) => OrderListItem.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

class CustomersProvider extends ChangeNotifier {
  final List<CustomerListItem> items = [];
  bool isLoading = false;
  bool isLoadingMore = false;
  String? error;
  int _pageIndex = 0;
  bool _hasMore = true;

  Future<void> loadFirstPage() async {
    _pageIndex = 0;
    _hasMore = true;
    items.clear();
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      final page = await ApiClient.instance.get<PagedResult<CustomerListItem>>(
        '/AdminCustomers',
        query: {'pageIndex': _pageIndex, 'pageSize': 30},
        fromJson: (json) => PagedResult.fromJson(json as Map<String, dynamic>, CustomerListItem.fromJson),
      );
      items.addAll(page.items);
      _hasMore = page.hasNextPage;
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadNextPage() async {
    if (!_hasMore || isLoadingMore) return;
    isLoadingMore = true;
    notifyListeners();

    try {
      _pageIndex++;
      final page = await ApiClient.instance.get<PagedResult<CustomerListItem>>(
        '/AdminCustomers',
        query: {'pageIndex': _pageIndex, 'pageSize': 30},
        fromJson: (json) => PagedResult.fromJson(json as Map<String, dynamic>, CustomerListItem.fromJson),
      );
      items.addAll(page.items);
      _hasMore = page.hasNextPage;
    } catch (e) {
      error = e.toString();
    } finally {
      isLoadingMore = false;
      notifyListeners();
    }
  }

  Future<CustomerDetail> loadDetail(int customerId) {
    return ApiClient.instance.get<CustomerDetail>(
      '/AdminCustomers/$customerId',
      fromJson: (json) => CustomerDetail.fromJson(json as Map<String, dynamic>),
    );
  }
}
