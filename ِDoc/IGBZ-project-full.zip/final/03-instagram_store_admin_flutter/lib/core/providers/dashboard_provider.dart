import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../models/dashboard_model.dart';

class DashboardProvider extends ChangeNotifier {
  DashboardData? data;
  bool isLoading = false;
  String? error;

  Future<void> load() async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      data = await ApiClient.instance.get<DashboardData>(
        '/AdminDashboard',
        fromJson: (json) => DashboardData.fromJson(json as Map<String, dynamic>),
      );
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
