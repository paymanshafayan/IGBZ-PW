import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../api/api_models.dart';
import '../models/order_models.dart';

class OrdersProvider extends ChangeNotifier {
  final List<OrderListItem> items = [];
  bool isLoading = false;
  bool isLoadingMore = false;
  String? error;
  int _pageIndex = 0;
  bool _hasMore = true;

  Future<void> loadFirstPage() async {
    _pageIndex = 0;
    _hasMore = true;
    items.clear();
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      final page = await ApiClient.instance.get<PagedResult<OrderListItem>>(
        '/AdminOrders',
        query: {'pageIndex': _pageIndex, 'pageSize': 20},
        fromJson: (json) => PagedResult.fromJson(json as Map<String, dynamic>, OrderListItem.fromJson),
      );
      items.addAll(page.items);
      _hasMore = page.hasNextPage;
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadNextPage() async {
    if (!_hasMore || isLoadingMore) return;
    isLoadingMore = true;
    notifyListeners();

    try {
      _pageIndex++;
      final page = await ApiClient.instance.get<PagedResult<OrderListItem>>(
        '/AdminOrders',
        query: {'pageIndex': _pageIndex, 'pageSize': 20},
        fromJson: (json) => PagedResult.fromJson(json as Map<String, dynamic>, OrderListItem.fromJson),
      );
      items.addAll(page.items);
      _hasMore = page.hasNextPage;
    } catch (e) {
      error = e.toString();
    } finally {
      isLoadingMore = false;
      notifyListeners();
    }
  }

  Future<OrderDetail> loadDetail(int orderId) {
    return ApiClient.instance.get<OrderDetail>(
      '/AdminOrders/$orderId',
      fromJson: (json) => OrderDetail.fromJson(json as Map<String, dynamic>),
    );
  }

  Future<String?> updateStatus(int orderId, OrderStatusOption status, {String? adminNote}) async {
    try {
      await ApiClient.instance.put<void>(
        '/AdminOrders/$orderId/status',
        data: {'orderStatus': status.apiValue, 'adminNote': adminNote},
        fromJson: (_) {},
      );
      await loadFirstPage();
      return null;
    } catch (e) {
      return e.toString();
    }
  }
}
