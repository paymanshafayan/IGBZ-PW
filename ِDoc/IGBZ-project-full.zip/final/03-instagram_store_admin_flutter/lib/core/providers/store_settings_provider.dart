import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../models/store_settings_model.dart';

class StoreSettingsProvider extends ChangeNotifier {
  StoreSettingsData? data;
  bool isLoading = false;
  bool isSaving = false;
  String? error;

  Future<void> load() async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      data = await ApiClient.instance.get<StoreSettingsData>(
        '/AdminStoreSettings',
        fromJson: (json) => StoreSettingsData.fromJson(json as Map<String, dynamic>),
      );
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  /// رنگ برند را عوض می‌کند. لوگو دست‌نخورده می‌ماند (بک‌اند فقط فیلدهای غیر-null را اعمال می‌کند).
  Future<String?> updateColor(String hexColor) async {
    return _save({'brandColorHex': hexColor});
  }

  /// لوگو را با فایل تازه جایگزین می‌کند. رنگ برند دست‌نخورده می‌ماند.
  Future<String?> updateLogo(Uint8List bytes, String mimeType) async {
    return _save({
      'logoBase64': base64Encode(bytes),
      'logoMimeType': mimeType,
    });
  }

  Future<String?> removeLogo() async {
    return _save({'removeLogo': true});
  }

  Future<String?> _save(Map<String, dynamic> body) async {
    isSaving = true;
    error = null;
    notifyListeners();

    try {
      data = await ApiClient.instance.put<StoreSettingsData>(
        '/AdminStoreSettings',
        data: body,
        fromJson: (json) => StoreSettingsData.fromJson(json as Map<String, dynamic>),
      );
      isSaving = false;
      notifyListeners();
      return null;
    } catch (e) {
      isSaving = false;
      notifyListeners();
      return e.toString();
    }
  }
}
