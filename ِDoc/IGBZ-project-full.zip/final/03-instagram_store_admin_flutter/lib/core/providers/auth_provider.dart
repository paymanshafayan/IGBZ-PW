import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../api/secure_storage_service.dart';
import '../models/auth_models.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

/// وضعیت ورود/نشست کاربر (صاحب فروشگاه). این تنها Provider ای است که تعیین می‌کند کدام صفحه
/// (Login یا Dashboard) در ابتدای اجرای اپ نمایش داده شود.
class AuthProvider extends ChangeNotifier {
  AuthProvider() {
    ApiClient.instance.onSessionExpired = _handleSessionExpired;
    _restoreSession();
  }

  AuthStatus _status = AuthStatus.unknown;
  AuthStatus get status => _status;

  String? _storeName;
  String? get storeName => _storeName;

  bool _isBusy = false;
  bool get isBusy => _isBusy;

  String? _lastError;
  String? get lastError => _lastError;

  Future<void> _restoreSession() async {
    final hasSession = await SecureStorageService.instance.hasSession;
    _status = hasSession ? AuthStatus.authenticated : AuthStatus.unauthenticated;
    _storeName = await SecureStorageService.instance.storeName;
    notifyListeners();
  }

  void _handleSessionExpired() {
    _status = AuthStatus.unauthenticated;
    notifyListeners();
  }

  Future<bool> login({required String email, required String password}) async {
    _isBusy = true;
    _lastError = null;
    notifyListeners();

    try {
      final token = await ApiClient.instance.post<TokenResponse>(
        '/auth/merchant-login',
        data: {'email': email, 'password': password},
        fromJson: (json) => TokenResponse.fromJson(json as Map<String, dynamic>),
      );

      if (token.ownedStoreId == null) {
        _lastError = 'این حساب مالک هیچ فروشگاهی نیست.';
        return false;
      }

      await SecureStorageService.instance.saveSession(
        accessToken: token.accessToken,
        refreshToken: token.refreshToken,
        accessTokenExpiresOnUtc: token.accessTokenExpiresOnUtc,
        storeId: token.ownedStoreId!,
      );

      _status = AuthStatus.authenticated;
      return true;
    } catch (e) {
      _lastError = e.toString();
      return false;
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  /// وقتی از صفحهٔ Dashboard اسم واقعی فروشگاه را گرفتیم، برای نمایش سریع‌تر در دفعات بعد
  /// (بدون نیاز به صبر کردن برای لود شدن Dashboard) آن را کش می‌کنیم.
  Future<void> cacheStoreName(String name) async {
    _storeName = name;
    final storeId = await SecureStorageService.instance.storeId;
    final accessToken = await SecureStorageService.instance.accessToken;
    final refreshToken = await SecureStorageService.instance.refreshToken;
    if (storeId == null || accessToken == null || refreshToken == null) return;

    await SecureStorageService.instance.saveSession(
      accessToken: accessToken,
      refreshToken: refreshToken,
      accessTokenExpiresOnUtc: DateTime.now().add(const Duration(days: 1)), // فقط برای رفرش این فیلد بی‌اثر است
      storeId: storeId,
      storeName: name,
    );
    notifyListeners();
  }

  Future<void> logout() async {
    await SecureStorageService.instance.clear();
    _status = AuthStatus.unauthenticated;
    notifyListeners();
  }
}
