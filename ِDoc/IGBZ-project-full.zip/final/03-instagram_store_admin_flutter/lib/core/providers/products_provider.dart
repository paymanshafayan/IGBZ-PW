import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../api/api_models.dart';
import '../models/product_models.dart';

class ProductsProvider extends ChangeNotifier {
  final List<ProductListItem> items = [];
  bool isLoading = false;
  bool isLoadingMore = false;
  String? error;
  int _pageIndex = 0;
  bool _hasMore = true;

  Future<void> loadFirstPage() async {
    _pageIndex = 0;
    _hasMore = true;
    items.clear();
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      final page = await ApiClient.instance.get<PagedResult<ProductListItem>>(
        '/AdminProducts',
        query: {'pageIndex': _pageIndex, 'pageSize': 20},
        fromJson: (json) => PagedResult.fromJson(
          json as Map<String, dynamic>,
          ProductListItem.fromJson,
        ),
      );
      items.addAll(page.items);
      _hasMore = page.hasNextPage;
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadNextPage() async {
    if (!_hasMore || isLoadingMore) return;
    isLoadingMore = true;
    notifyListeners();

    try {
      _pageIndex++;
      final page = await ApiClient.instance.get<PagedResult<ProductListItem>>(
        '/AdminProducts',
        query: {'pageIndex': _pageIndex, 'pageSize': 20},
        fromJson: (json) => PagedResult.fromJson(
          json as Map<String, dynamic>,
          ProductListItem.fromJson,
        ),
      );
      items.addAll(page.items);
      _hasMore = page.hasNextPage;
    } catch (e) {
      error = e.toString();
    } finally {
      isLoadingMore = false;
      notifyListeners();
    }
  }

  Future<String?> createProduct(ProductUpsertRequest request) async {
    try {
      await ApiClient.instance.post<void>(
        '/AdminProducts',
        data: request.toJson(),
        fromJson: (_) {},
      );
      await loadFirstPage();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<String?> updateProduct(int id, ProductUpsertRequest request) async {
    try {
      await ApiClient.instance.put<void>(
        '/AdminProducts/$id',
        data: request.toJson(),
        fromJson: (_) {},
      );
      await loadFirstPage();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<String?> deleteProduct(int id) async {
    try {
      await ApiClient.instance.delete<void>('/AdminProducts/$id', fromJson: (_) {});
      items.removeWhere((p) => p.id == id);
      notifyListeners();
      return null;
    } catch (e) {
      return e.toString();
    }
  }
}
