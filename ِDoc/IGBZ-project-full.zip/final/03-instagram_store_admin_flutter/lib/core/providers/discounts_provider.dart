import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../models/catalog_extra_models.dart';

class DiscountsProvider extends ChangeNotifier {
  final List<DiscountItem> items = [];
  bool isLoading = false;
  String? error;

  Future<void> load() async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      final result = await ApiClient.instance.get<List<DiscountItem>>(
        '/AdminDiscounts',
        fromJson: (json) =>
            (json as List).map((e) => DiscountItem.fromJson(e as Map<String, dynamic>)).toList(),
      );
      items
        ..clear()
        ..addAll(result);
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> create(DiscountUpsertRequest request) async {
    try {
      await ApiClient.instance.post<void>('/AdminDiscounts', data: request.toJson(), fromJson: (_) {});
      await load();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<String?> update(int id, DiscountUpsertRequest request) async {
    try {
      await ApiClient.instance.put<void>('/AdminDiscounts/$id', data: request.toJson(), fromJson: (_) {});
      await load();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<String?> delete(int id) async {
    try {
      await ApiClient.instance.delete<void>('/AdminDiscounts/$id', fromJson: (_) {});
      items.removeWhere((d) => d.id == id);
      notifyListeners();
      return null;
    } catch (e) {
      return e.toString();
    }
  }
}
