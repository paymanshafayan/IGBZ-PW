import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../api/api_models.dart';
import '../models/catalog_extra_models.dart';

class CategoriesProvider extends ChangeNotifier {
  final List<CategoryItem> items = [];
  bool isLoading = false;
  String? error;

  Future<void> load() async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      final page = await ApiClient.instance.get<PagedResult<CategoryItem>>(
        '/AdminCategories',
        query: {'pageIndex': 0, 'pageSize': 200},
        fromJson: (json) => PagedResult.fromJson(json as Map<String, dynamic>, CategoryItem.fromJson),
      );
      items
        ..clear()
        ..addAll(page.items);
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> create(CategoryUpsertRequest request) async {
    try {
      await ApiClient.instance.post<void>('/AdminCategories', data: request.toJson(), fromJson: (_) {});
      await load();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<String?> update(int id, CategoryUpsertRequest request) async {
    try {
      await ApiClient.instance.put<void>('/AdminCategories/$id', data: request.toJson(), fromJson: (_) {});
      await load();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<String?> delete(int id) async {
    try {
      await ApiClient.instance.delete<void>('/AdminCategories/$id', fromJson: (_) {});
      items.removeWhere((c) => c.id == id);
      notifyListeners();
      return null;
    } catch (e) {
      return e.toString();
    }
  }
}
