import 'package:flutter/foundation.dart';
import '../api/api_client.dart';
import '../models/catalog_extra_models.dart';

class ShipmentsProvider extends ChangeNotifier {
  final List<Shipment> items = [];
  bool isLoading = false;
  bool isCreating = false;
  String? error;

  Future<void> loadForOrder(int orderId) async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      final result = await ApiClient.instance.get<List<Shipment>>(
        '/AdminShipments/order/$orderId',
        fromJson: (json) => (json as List).map((e) => Shipment.fromJson(e as Map<String, dynamic>)).toList(),
      );
      items
        ..clear()
        ..addAll(result);
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> createForOrder(int orderId, {String? trackingNumber}) async {
    isCreating = true;
    notifyListeners();

    try {
      await ApiClient.instance.post<void>(
        '/AdminShipments/order/$orderId',
        data: {'trackingNumber': trackingNumber, 'items': null},
        fromJson: (_) {},
      );
      await loadForOrder(orderId);
      return null;
    } catch (e) {
      return e.toString();
    } finally {
      isCreating = false;
      notifyListeners();
    }
  }
}
