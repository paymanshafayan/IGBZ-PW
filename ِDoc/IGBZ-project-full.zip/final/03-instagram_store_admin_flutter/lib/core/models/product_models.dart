class ProductListItem {
  final int id;
  final String name;
  final String? sku;
  final double price;
  final int stockQuantity;
  final bool published;

  ProductListItem({
    required this.id,
    required this.name,
    this.sku,
    required this.price,
    required this.stockQuantity,
    required this.published,
  });

  factory ProductListItem.fromJson(Map<String, dynamic> json) => ProductListItem(
        id: json['id'] as int,
        name: json['name'] as String? ?? '',
        sku: json['sku'] as String?,
        price: (json['price'] as num?)?.toDouble() ?? 0,
        stockQuantity: json['stockQuantity'] as int? ?? 0,
        published: json['published'] as bool? ?? false,
      );
}

/// برای ارسال Create/Update به سرور
class ProductUpsertRequest {
  final String name;
  final String? shortDescription;
  final String? fullDescription;
  final String? sku;
  final double price;
  final double? oldPrice;
  final int stockQuantity;
  final bool published;
  final List<int> categoryIds;

  ProductUpsertRequest({
    required this.name,
    this.shortDescription,
    this.fullDescription,
    this.sku,
    required this.price,
    this.oldPrice,
    required this.stockQuantity,
    this.published = true,
    this.categoryIds = const [],
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'shortDescription': shortDescription,
        'fullDescription': fullDescription,
        'sku': sku,
        'price': price,
        'oldPrice': oldPrice,
        'stockQuantity': stockQuantity,
        'published': published,
        'categoryIds': categoryIds,
      };
}
