class TokenResponse {
  final String accessToken;
  final String refreshToken;
  final DateTime accessTokenExpiresOnUtc;
  final int customerId;
  final int? ownedStoreId;

  TokenResponse({
    required this.accessToken,
    required this.refreshToken,
    required this.accessTokenExpiresOnUtc,
    required this.customerId,
    this.ownedStoreId,
  });

  factory TokenResponse.fromJson(Map<String, dynamic> json) => TokenResponse(
        accessToken: json['accessToken'] as String,
        refreshToken: json['refreshToken'] as String,
        accessTokenExpiresOnUtc: DateTime.parse(json['accessTokenExpiresOnUtc'] as String),
        customerId: json['customerId'] as int,
        ownedStoreId: json['ownedStoreId'] as int?,
      );
}
