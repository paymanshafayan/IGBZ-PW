// ==================== Categories ====================

class CategoryItem {
  final int id;
  final String name;
  final String? description;
  final bool published;
  final int displayOrder;
  final int parentCategoryId;

  CategoryItem({
    required this.id,
    required this.name,
    this.description,
    required this.published,
    required this.displayOrder,
    required this.parentCategoryId,
  });

  factory CategoryItem.fromJson(Map<String, dynamic> json) => CategoryItem(
        id: json['id'] as int,
        name: json['name'] as String? ?? '',
        description: json['description'] as String?,
        published: json['published'] as bool? ?? false,
        displayOrder: json['displayOrder'] as int? ?? 0,
        parentCategoryId: json['parentCategoryId'] as int? ?? 0,
      );
}

class CategoryUpsertRequest {
  final String name;
  final String? description;
  final bool published;
  final int displayOrder;
  final int parentCategoryId;

  CategoryUpsertRequest({
    required this.name,
    this.description,
    this.published = true,
    this.displayOrder = 0,
    this.parentCategoryId = 0,
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'description': description,
        'published': published,
        'displayOrder': displayOrder,
        'parentCategoryId': parentCategoryId,
      };
}

// ==================== Customers ====================

class CustomerListItem {
  final int id;
  final String email;
  final String fullName;
  final String? phoneNumber;
  final int orderCount;
  final double totalSpent;
  final DateTime? lastOrderOnUtc;

  CustomerListItem({
    required this.id,
    required this.email,
    required this.fullName,
    this.phoneNumber,
    required this.orderCount,
    required this.totalSpent,
    this.lastOrderOnUtc,
  });

  factory CustomerListItem.fromJson(Map<String, dynamic> json) => CustomerListItem(
        id: json['id'] as int,
        email: json['email'] as String? ?? '',
        fullName: json['fullName'] as String? ?? '',
        phoneNumber: json['phoneNumber'] as String?,
        orderCount: json['orderCount'] as int? ?? 0,
        totalSpent: (json['totalSpent'] as num?)?.toDouble() ?? 0,
        lastOrderOnUtc:
            json['lastOrderOnUtc'] == null ? null : DateTime.parse(json['lastOrderOnUtc'] as String),
      );
}

// ==================== Shipments ====================

class ShipmentItem {
  final int productId;
  final String? productName;
  final int quantity;

  ShipmentItem({required this.productId, this.productName, required this.quantity});

  factory ShipmentItem.fromJson(Map<String, dynamic> json) => ShipmentItem(
        productId: json['productId'] as int? ?? 0,
        productName: json['productName'] as String?,
        quantity: json['quantity'] as int? ?? 0,
      );
}

class Shipment {
  final int id;
  final String? trackingNumber;
  final String? trackingUrl;
  final DateTime? shippedOnUtc;
  final DateTime? deliveredOnUtc;
  final List<ShipmentItem> items;

  Shipment({
    required this.id,
    this.trackingNumber,
    this.trackingUrl,
    this.shippedOnUtc,
    this.deliveredOnUtc,
    this.items = const [],
  });

  factory Shipment.fromJson(Map<String, dynamic> json) => Shipment(
        id: json['id'] as int,
        trackingNumber: json['trackingNumber'] as String?,
        trackingUrl: json['trackingUrl'] as String?,
        shippedOnUtc: json['shippedOnUtc'] == null ? null : DateTime.parse(json['shippedOnUtc'] as String),
        deliveredOnUtc:
            json['deliveredOnUtc'] == null ? null : DateTime.parse(json['deliveredOnUtc'] as String),
        items: (json['items'] as List? ?? [])
            .map((e) => ShipmentItem.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

// ==================== Discounts ====================

class DiscountItem {
  final int id;
  final String name;
  final String discountType;
  final double discountPercentage;
  final double discountAmount;
  final bool usePercentage;
  final String? couponCode;
  final DateTime? startDateUtc;
  final DateTime? endDateUtc;

  DiscountItem({
    required this.id,
    required this.name,
    required this.discountType,
    required this.discountPercentage,
    required this.discountAmount,
    required this.usePercentage,
    this.couponCode,
    this.startDateUtc,
    this.endDateUtc,
  });

  factory DiscountItem.fromJson(Map<String, dynamic> json) => DiscountItem(
        id: json['id'] as int,
        name: json['name'] as String? ?? '',
        discountType: json['discountType'] as String? ?? '',
        discountPercentage: (json['discountPercentage'] as num?)?.toDouble() ?? 0,
        discountAmount: (json['discountAmount'] as num?)?.toDouble() ?? 0,
        usePercentage: json['usePercentage'] as bool? ?? false,
        couponCode: json['couponCode'] as String?,
        startDateUtc: json['startDateUtc'] == null ? null : DateTime.parse(json['startDateUtc'] as String),
        endDateUtc: json['endDateUtc'] == null ? null : DateTime.parse(json['endDateUtc'] as String),
      );
}

class DiscountUpsertRequest {
  final String name;
  final bool usePercentage;
  final double discountPercentage;
  final double discountAmount;
  final String? couponCode;
  final DateTime? startDateUtc;
  final DateTime? endDateUtc;
  final String discountType;

  DiscountUpsertRequest({
    required this.name,
    required this.usePercentage,
    this.discountPercentage = 0,
    this.discountAmount = 0,
    this.couponCode,
    this.startDateUtc,
    this.endDateUtc,
    this.discountType = 'AssignedToOrderTotal',
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'usePercentage': usePercentage,
        'discountPercentage': discountPercentage,
        'discountAmount': discountAmount,
        'couponCode': couponCode,
        'startDateUtc': startDateUtc?.toIso8601String(),
        'endDateUtc': endDateUtc?.toIso8601String(),
        'discountType': discountType,
      };
}
