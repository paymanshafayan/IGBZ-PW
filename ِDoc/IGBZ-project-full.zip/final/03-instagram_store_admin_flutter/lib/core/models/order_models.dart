class OrderListItem {
  final int id;
  final String customOrderNumber;
  final DateTime createdOnUtc;
  final double orderTotal;
  final String orderTotalFormatted;
  final String orderStatus;
  final String paymentStatus;
  final String shippingStatus;
  final int? customerId;
  final String? customerEmail;
  final String? customerFullName;

  OrderListItem({
    required this.id,
    required this.customOrderNumber,
    required this.createdOnUtc,
    required this.orderTotal,
    required this.orderTotalFormatted,
    required this.orderStatus,
    required this.paymentStatus,
    required this.shippingStatus,
    this.customerId,
    this.customerEmail,
    this.customerFullName,
  });

  factory OrderListItem.fromJson(Map<String, dynamic> json) => OrderListItem(
        id: json['id'] as int,
        customOrderNumber: json['customOrderNumber'] as String? ?? '',
        createdOnUtc: DateTime.parse(json['createdOnUtc'] as String),
        orderTotal: (json['orderTotal'] as num?)?.toDouble() ?? 0,
        orderTotalFormatted: json['orderTotalFormatted'] as String? ?? '',
        orderStatus: json['orderStatus'] as String? ?? '',
        paymentStatus: json['paymentStatus'] as String? ?? '',
        shippingStatus: json['shippingStatus'] as String? ?? '',
        customerId: json['customerId'] as int?,
        customerEmail: json['customerEmail'] as String?,
        customerFullName: json['customerFullName'] as String?,
      );
}

class OrderItemLine {
  final int productId;
  final String productName;
  final int quantity;
  final double unitPrice;
  final double lineTotal;

  OrderItemLine({
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.unitPrice,
    required this.lineTotal,
  });

  factory OrderItemLine.fromJson(Map<String, dynamic> json) => OrderItemLine(
        productId: json['productId'] as int? ?? 0,
        productName: json['productName'] as String? ?? '',
        quantity: json['quantity'] as int? ?? 0,
        unitPrice: (json['unitPrice'] as num?)?.toDouble() ?? 0,
        lineTotal: (json['lineTotal'] as num?)?.toDouble() ?? 0,
      );
}

class OrderNoteItem {
  final String note;
  final DateTime createdOnUtc;

  OrderNoteItem({required this.note, required this.createdOnUtc});

  factory OrderNoteItem.fromJson(Map<String, dynamic> json) => OrderNoteItem(
        note: json['note'] as String? ?? '',
        createdOnUtc: DateTime.parse(json['createdOnUtc'] as String),
      );
}

class OrderDetail extends OrderListItem {
  final String? shippingAddressText;
  final String? customerPhone;
  final List<OrderItemLine> items;
  final List<OrderNoteItem> notes;

  OrderDetail({
    required super.id,
    required super.customOrderNumber,
    required super.createdOnUtc,
    required super.orderTotal,
    required super.orderTotalFormatted,
    required super.orderStatus,
    required super.paymentStatus,
    required super.shippingStatus,
    super.customerId,
    super.customerEmail,
    super.customerFullName,
    this.shippingAddressText,
    this.customerPhone,
    this.items = const [],
    this.notes = const [],
  });

  factory OrderDetail.fromJson(Map<String, dynamic> json) => OrderDetail(
        id: json['id'] as int,
        customOrderNumber: json['customOrderNumber'] as String? ?? '',
        createdOnUtc: DateTime.parse(json['createdOnUtc'] as String),
        orderTotal: (json['orderTotal'] as num?)?.toDouble() ?? 0,
        orderTotalFormatted: json['orderTotalFormatted'] as String? ?? '',
        orderStatus: json['orderStatus'] as String? ?? '',
        paymentStatus: json['paymentStatus'] as String? ?? '',
        shippingStatus: json['shippingStatus'] as String? ?? '',
        customerId: json['customerId'] as int?,
        customerEmail: json['customerEmail'] as String?,
        customerFullName: json['customerFullName'] as String?,
        shippingAddressText: json['shippingAddressText'] as String?,
        customerPhone: json['customerPhone'] as String?,
        items: (json['items'] as List? ?? [])
            .map((e) => OrderItemLine.fromJson(e as Map<String, dynamic>))
            .toList(),
        notes: (json['notes'] as List? ?? [])
            .map((e) => OrderNoteItem.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

/// وضعیت‌های معتبر سفارش - باید دقیقاً با enum OrderStatus سمت سرور یکی باشد
enum OrderStatusOption { pending, processing, complete, cancelled }

extension OrderStatusOptionX on OrderStatusOption {
  String get apiValue => switch (this) {
        OrderStatusOption.pending => 'Pending',
        OrderStatusOption.processing => 'Processing',
        OrderStatusOption.complete => 'Complete',
        OrderStatusOption.cancelled => 'Cancelled',
      };

  String get label => switch (this) {
        OrderStatusOption.pending => 'در انتظار',
        OrderStatusOption.processing => 'در حال پردازش',
        OrderStatusOption.complete => 'تکمیل‌شده',
        OrderStatusOption.cancelled => 'لغوشده',
      };
}
