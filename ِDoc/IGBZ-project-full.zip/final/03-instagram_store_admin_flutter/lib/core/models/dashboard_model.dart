class DashboardData {
  final String storeName;
  final int totalProducts;
  final int ordersToday;
  final int ordersThisMonth;
  final double revenueToday;
  final double revenueThisMonth;
  final String revenueThisMonthFormatted;
  final int pendingOrdersCount;
  final String subscriptionStatus;
  final DateTime? subscriptionRenewsOnUtc;

  DashboardData({
    required this.storeName,
    required this.totalProducts,
    required this.ordersToday,
    required this.ordersThisMonth,
    required this.revenueToday,
    required this.revenueThisMonth,
    required this.revenueThisMonthFormatted,
    required this.pendingOrdersCount,
    required this.subscriptionStatus,
    this.subscriptionRenewsOnUtc,
  });

  factory DashboardData.fromJson(Map<String, dynamic> json) => DashboardData(
        storeName: json['storeName'] as String? ?? '',
        totalProducts: json['totalProducts'] as int? ?? 0,
        ordersToday: json['ordersToday'] as int? ?? 0,
        ordersThisMonth: json['ordersThisMonth'] as int? ?? 0,
        revenueToday: (json['revenueToday'] as num?)?.toDouble() ?? 0,
        revenueThisMonth: (json['revenueThisMonth'] as num?)?.toDouble() ?? 0,
        revenueThisMonthFormatted: json['revenueThisMonthFormatted'] as String? ?? '',
        pendingOrdersCount: json['pendingOrdersCount'] as int? ?? 0,
        subscriptionStatus: json['subscriptionStatus'] as String? ?? '',
        subscriptionRenewsOnUtc: json['subscriptionRenewsOnUtc'] == null
            ? null
            : DateTime.parse(json['subscriptionRenewsOnUtc'] as String),
      );
}
