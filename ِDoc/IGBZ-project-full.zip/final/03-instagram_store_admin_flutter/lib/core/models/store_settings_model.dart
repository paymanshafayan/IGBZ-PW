import 'package:flutter/material.dart';

class StoreSettingsData {
  final String? brandColorHex;
  final String? logoUrl;

  const StoreSettingsData({this.brandColorHex, this.logoUrl});

  factory StoreSettingsData.fromJson(Map<String, dynamic> json) => StoreSettingsData(
        brandColorHex: json['brandColorHex'] as String?,
        logoUrl: json['logoUrl'] as String?,
      );

  Color? get brandColor {
    if (brandColorHex == null || brandColorHex!.isEmpty) return null;
    var hex = brandColorHex!.trim().replaceFirst('#', '');
    if (hex.length == 6) hex = 'FF$hex';
    final value = int.tryParse(hex, radix: 16);
    return value != null ? Color(value) : null;
  }
}

/// پالت رنگ‌های پیشنهادی برای برند فروشگاه - همان مجموعه‌ای که اپ مشتریان هم برای تم خودش
/// پیشنهاد می‌دهد، تا رنگ انتخابی صاحب فروشگاه در هر دو اپ یکسان به‌نظر برسد.
const List<MapEntry<String, Color>> kBrandColorPalette = [
  MapEntry('آبی', Color(0xFF2F80ED)),
  MapEntry('نیلی', Color(0xFF3F51B5)),
  MapEntry('بنفش', Color(0xFF8E44AD)),
  MapEntry('فیروزه‌ای', Color(0xFF009688)),
  MapEntry('سبز', Color(0xFF27AE60)),
  MapEntry('نارنجی', Color(0xFFF2994A)),
  MapEntry('قرمز', Color(0xFFEB5757)),
  MapEntry('صورتی', Color(0xFFE91E63)),
];

String colorToHex(Color color) =>
    '#${color.toARGB32().toRadixString(16).padLeft(8, '0').substring(2).toUpperCase()}';
