import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// نگه‌داری اطلاعات نشست (Session) روی دستگاه: توکن‌های JWT و شناسهٔ فروشگاهی که این حساب
/// مالکش است. این کلاس تنها منبع حقیقت برای "این دستگاه به کدام فروشگاه وصل است" است.
class SecureStorageService {
  SecureStorageService._();
  static final SecureStorageService instance = SecureStorageService._();

  final _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _kAccessToken = 'access_token';
  static const _kRefreshToken = 'refresh_token';
  static const _kAccessTokenExpiresOnUtc = 'access_token_expires_on_utc';
  static const _kStoreId = 'owned_store_id';
  static const _kStoreName = 'owned_store_name';

  Future<void> saveSession({
    required String accessToken,
    required String refreshToken,
    required DateTime accessTokenExpiresOnUtc,
    required int storeId,
    String? storeName,
  }) async {
    await Future.wait([
      _storage.write(key: _kAccessToken, value: accessToken),
      _storage.write(key: _kRefreshToken, value: refreshToken),
      _storage.write(
        key: _kAccessTokenExpiresOnUtc,
        value: accessTokenExpiresOnUtc.toIso8601String(),
      ),
      _storage.write(key: _kStoreId, value: storeId.toString()),
      if (storeName != null) _storage.write(key: _kStoreName, value: storeName),
    ]);
  }

  Future<void> updateTokens({
    required String accessToken,
    required String refreshToken,
    required DateTime accessTokenExpiresOnUtc,
  }) async {
    await Future.wait([
      _storage.write(key: _kAccessToken, value: accessToken),
      _storage.write(key: _kRefreshToken, value: refreshToken),
      _storage.write(
        key: _kAccessTokenExpiresOnUtc,
        value: accessTokenExpiresOnUtc.toIso8601String(),
      ),
    ]);
  }

  Future<String?> get accessToken => _storage.read(key: _kAccessToken);
  Future<String?> get refreshToken => _storage.read(key: _kRefreshToken);
  Future<String?> get storeName => _storage.read(key: _kStoreName);

  Future<int?> get storeId async {
    final raw = await _storage.read(key: _kStoreId);
    return raw == null ? null : int.tryParse(raw);
  }

  Future<bool> get hasSession async =>
      (await accessToken) != null && (await storeId) != null;

  Future<void> clear() => _storage.deleteAll();
}
