/// دقیقاً منطبق با Nop.Plugin.Api.DTOs.Common.ApiResponse<T> در بک‌اند
class ApiResponse<T> {
  final bool success;
  final String? message;
  final T? data;
  final List<String> errors;

  ApiResponse({
    required this.success,
    this.message,
    this.data,
    this.errors = const [],
  });

  factory ApiResponse.fromJson(
    Map<String, dynamic> json,
    T Function(dynamic json) fromJsonT,
  ) {
    return ApiResponse<T>(
      success: json['success'] as bool? ?? false,
      message: json['message'] as String?,
      data: json['data'] == null ? null : fromJsonT(json['data']),
      errors: (json['errors'] as List?)?.map((e) => e.toString()).toList() ?? const [],
    );
  }
}

/// دقیقاً منطبق با Nop.Plugin.Api.DTOs.Common.PagedResultDto<T>
class PagedResult<T> {
  final List<T> items;
  final int pageIndex;
  final int pageSize;
  final int totalCount;
  final int totalPages;

  PagedResult({
    required this.items,
    required this.pageIndex,
    required this.pageSize,
    required this.totalCount,
    required this.totalPages,
  });

  bool get hasNextPage => pageIndex + 1 < totalPages;

  factory PagedResult.fromJson(
    Map<String, dynamic> json,
    T Function(Map<String, dynamic> json) itemFromJson,
  ) {
    return PagedResult<T>(
      items: (json['items'] as List? ?? [])
          .map((e) => itemFromJson(e as Map<String, dynamic>))
          .toList(),
      pageIndex: json['pageIndex'] as int? ?? 0,
      pageSize: json['pageSize'] as int? ?? 0,
      totalCount: json['totalCount'] as int? ?? 0,
      totalPages: json['totalPages'] as int? ?? 0,
    );
  }
}

/// خطای یکپارچه برای نمایش پیام مناسب کاربر، صرف‌نظر از این‌که خطا از شبکه بوده یا از سرور
class ApiException implements Exception {
  final String message;
  final int? statusCode;

  ApiException(this.message, {this.statusCode});

  @override
  String toString() => message;
}
