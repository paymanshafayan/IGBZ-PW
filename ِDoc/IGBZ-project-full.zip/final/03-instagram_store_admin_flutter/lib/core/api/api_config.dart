/// تنظیمات پایه‌ی اتصال به Nop.Plugin.Api
///
/// نکته: baseUrl آدرس *مشترک* API برای همهٔ فروشگاه‌هاست (طبق تصمیم گرفته‌شده: یک آدرس API
/// مشترک + شناسایی فروشگاه با هدر X-Store-Id، نه با زیردامنهٔ جدا). این آدرس را قبل از انتشار
/// واقعی، به دامنهٔ سرور خودتان تغییر بدهید.
class ApiConfig {
  ApiConfig._();

  /// در توسعه از یک flavor/build config جدا بخوانید؛ فعلاً یک مقدار پیش‌فرض ساده است.
  static const String baseUrl = 'https://api.yourmainsite.com';

  static const String apiPrefix = '/api/v1';

  /// دقیقاً باید با MultiTenantStoreContext.StoreIdHeaderName در پلاگین nopCommerce یکی باشد
  static const String storeIdHeaderName = 'X-Store-Id';

  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 20);
}
