import 'dart:async';
import 'package:dio/dio.dart';
import 'api_config.dart';
import 'api_models.dart';
import 'secure_storage_service.dart';

/// پوششی روی Dio که:
///  - هدر Authorization (Bearer) و X-Store-Id را خودکار به هر درخواست اضافه می‌کند
///  - اگر پاسخ 401 بگیرد، یک‌بار تلاش می‌کند توکن را Refresh کند و درخواست را دوباره بفرستد
///  - اگر Refresh هم شکست بخورد، نشست را پاک می‌کند و AuthProvider (از طریق onSessionExpired)
///    کاربر را به صفحهٔ ورود برمی‌گرداند
class ApiClient {
  ApiClient._internal() {
    _dio = Dio(BaseOptions(
      baseUrl: '${ApiConfig.baseUrl}${ApiConfig.apiPrefix}',
      connectTimeout: ApiConfig.connectTimeout,
      receiveTimeout: ApiConfig.receiveTimeout,
      contentType: 'application/json',
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await SecureStorageService.instance.accessToken;
        final storeId = await SecureStorageService.instance.storeId;

        if (token != null) {
          options.headers['Authorization'] = 'Bearer $token';
        }
        if (storeId != null) {
          options.headers[ApiConfig.storeIdHeaderName] = storeId.toString();
        }

        handler.next(options);
      },
      onError: (error, handler) async {
        final isUnauthorized = error.response?.statusCode == 401;
        final isAuthEndpoint = error.requestOptions.path.contains('/auth/');

        if (isUnauthorized && !isAuthEndpoint) {
          try {
            final retryResponse = await _handle401AndRetry(error.requestOptions);
            return handler.resolve(retryResponse);
          } catch (_) {
            onSessionExpired?.call();
          }
        }

        handler.next(error);
      },
    ));
  }

  static final ApiClient instance = ApiClient._internal();
  late final Dio _dio;

  /// AuthProvider این را ست می‌کند تا وقتی Refresh هم شکست خورد، کاربر خودکار خارج شود
  void Function()? onSessionExpired;

  bool _isRefreshing = false;
  final List<Completer<void>> _refreshWaiters = [];

  Future<Response> _handle401AndRetry(RequestOptions failedRequest) async {
    if (_isRefreshing) {
      // یک درخواست دیگر همین حالا دارد Refresh می‌کند - منتظر می‌مانیم و بعد دوباره تلاش می‌کنیم
      final completer = Completer<void>();
      _refreshWaiters.add(completer);
      await completer.future;
      return _dio.fetch(failedRequest);
    }

    _isRefreshing = true;
    try {
      final refreshToken = await SecureStorageService.instance.refreshToken;
      if (refreshToken == null) throw ApiException('نشست منقضی شده است.');

      final response = await _dio.post('/auth/refresh-token', data: {
        'refreshToken': refreshToken,
        // NOTE: بک‌اند accessToken قبلی را هم برای Rotation می‌خواهد؛ اگر لازم شد اینجا اضافه کنید
      });

      final body = ApiResponse<Map<String, dynamic>>.fromJson(
        response.data as Map<String, dynamic>,
        (json) => json as Map<String, dynamic>,
      );

      if (!body.success || body.data == null) {
        throw ApiException(body.message ?? 'Refresh Token نامعتبر است.');
      }

      await SecureStorageService.instance.updateTokens(
        accessToken: body.data!['accessToken'] as String,
        refreshToken: body.data!['refreshToken'] as String,
        accessTokenExpiresOnUtc: DateTime.parse(body.data!['accessTokenExpiresOnUtc'] as String),
      );

      for (final waiter in _refreshWaiters) {
        waiter.complete();
      }
      _refreshWaiters.clear();

      return _dio.fetch(failedRequest);
    } catch (e) {
      for (final waiter in _refreshWaiters) {
        waiter.completeError(e);
      }
      _refreshWaiters.clear();
      await SecureStorageService.instance.clear();
      rethrow;
    } finally {
      _isRefreshing = false;
    }
  }

  /// درخواست GET که پاسخش مستقیم یک شیء T است (نه لیست صفحه‌بندی‌شده)
  Future<T> get<T>(
    String path, {
    Map<String, dynamic>? query,
    required T Function(dynamic json) fromJson,
  }) async {
    return _send(() => _dio.get(path, queryParameters: query), fromJson);
  }

  Future<T> post<T>(
    String path, {
    Object? data,
    required T Function(dynamic json) fromJson,
  }) async {
    return _send(() => _dio.post(path, data: data), fromJson);
  }

  Future<T> put<T>(
    String path, {
    Object? data,
    required T Function(dynamic json) fromJson,
  }) async {
    return _send(() => _dio.put(path, data: data), fromJson);
  }

  Future<T> delete<T>(
    String path, {
    required T Function(dynamic json) fromJson,
  }) async {
    return _send(() => _dio.delete(path), fromJson);
  }

  Future<T> _send<T>(
    Future<Response> Function() request,
    T Function(dynamic json) fromJson,
  ) async {
    try {
      final response = await request();
      final envelope = ApiResponse<dynamic>.fromJson(
        response.data as Map<String, dynamic>,
        (json) => json,
      );

      if (!envelope.success) {
        throw ApiException(envelope.message ?? 'خطایی رخ داد.', statusCode: response.statusCode);
      }

      return fromJson(envelope.data);
    } on DioException catch (e) {
      final serverMessage = _tryExtractServerMessage(e);
      throw ApiException(
        serverMessage ?? _friendlyMessageFor(e),
        statusCode: e.response?.statusCode,
      );
    }
  }

  String? _tryExtractServerMessage(DioException e) {
    final data = e.response?.data;
    if (data is Map<String, dynamic> && data['message'] is String) {
      return data['message'] as String;
    }
    return null;
  }

  String _friendlyMessageFor(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
      case DioExceptionType.sendTimeout:
        return 'اتصال به سرور برقرار نشد. اینترنت خود را بررسی کنید.';
      case DioExceptionType.connectionError:
        return 'خطا در اتصال به اینترنت.';
      default:
        return 'خطایی در ارتباط با سرور رخ داد.';
    }
  }
}
