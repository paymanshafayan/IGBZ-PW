# اپلیکیشن ادمین فروشگاه (Flutter) — فاز ۴

اپلیکیشن مدیریت فروشگاه برای صاحبان کسب‌وکار، متصل به `Nop.Plugin.Api` (اندپوینت‌های `Admin*`).

## معماری کلیدی

- **یک آدرس API مشترک برای همهٔ فروشگاه‌ها**، نه زیردامنهٔ جدا. تشخیص فروشگاه با هدر
  `X-Store-Id` انجام می‌شود که `ApiClient` (در `lib/core/api/api_client.dart`) به‌صورت خودکار
  از `SecureStorageService` می‌خواند و به هر درخواست اضافه می‌کند.
- **ورود (`/auth/merchant-login`)**: مسیر مخصوص این اپ - نیازی به دانستن `storeId` از قبل ندارد؛
  فقط ایمیل/رمز عبور می‌گیرد و در پاسخ `ownedStoreId` را برمی‌گرداند. اپ همان لحظه این مقدار را
  در `SecureStorageService` ذخیره می‌کند و از آن به بعد در هر درخواست می‌فرستد.
- **Refresh Token خودکار**: اگر یک درخواست ۴۰۱ بگیرد، `ApiClient` خودش یک‌بار تلاش می‌کند توکن
  را تازه کند و درخواست را دوباره بفرستد؛ اگر آن هم شکست بخورد، `AuthProvider` کاربر را به
  صفحهٔ ورود برمی‌گرداند.

## راه‌اندازی

1. Flutter SDK (پایدار، حداقل 3.19) نصب باشد.
2. `flutter pub get`
3. آدرس واقعی بک‌اند را در `lib/core/api/api_config.dart` (مقدار `baseUrl`) تنظیم کنید.
4. فونت وزیرمتن (Vazirmatn) را دانلود و دو فایل `Vazirmatn-Regular.ttf` و `Vazirmatn-Bold.ttf`
   را در `assets/fonts/` قرار دهید (به‌خاطر حجم، فایل باینری فونت در این تحویل قرار داده نشده).
5. `flutter run`

## نگاشت مستقیم روی اندپوینت‌های بک‌اند

| صفحه | Endpoint |
|---|---|
| ورود | `POST /auth/merchant-login` |
| داشبورد | `GET /AdminDashboard` |
| محصولات | `GET/POST/PUT/DELETE /AdminProducts` |
| سفارش‌ها | `GET /AdminOrders`, `GET /AdminOrders/{id}`, `PUT /AdminOrders/{id}/status` |
| دسته‌بندی‌ها | `GET/POST/PUT/DELETE /AdminCategories` |
| مشتریان | `GET /AdminCustomers`, `GET /AdminCustomers/{id}` (فقط‌خواندنی) |
| مرسولات | `GET /AdminShipments/order/{orderId}`, `POST /AdminShipments/order/{orderId}` |
| تخفیف‌ها | `GET/POST/PUT/DELETE /AdminDiscounts` |

## نکات و محدودیت‌های شناخته‌شده (قبل از انتشار واقعی بررسی کنید)

- **آپلود تصویر محصول** پیاده‌سازی نشده - فرم محصول فعلاً فقط فیلدهای متنی/عددی دارد. برای
  افزودن تصویر، هم به یک اندپوینت آپلود در بک‌اند (فعلاً وجود ندارد) و هم به `image_picker` +
  `multipart request` در این اپ نیاز است.
- **دسته‌بندی‌ها به‌صورت تخت (Flat) نمایش داده می‌شوند**، نه به‌صورت درختی/تودرتو - برای اکثر
  فروشگاه‌های کوچک کافی است، اما برای فروشگاه‌های با دسته‌بندی چندسطحی باید UI درختی اضافه شود.
- **صفحه‌بندی مشتریان/سفارش‌ها** ساده (Infinite Scroll) است، بدون فیلتر/جستجوی پیشرفته.
- **اعلان Push** (سفارش جدید و غیره) پیاده‌سازی نشده - نیاز به Firebase Cloud Messaging یا
  مشابه، به‌علاوهٔ یک Endpoint در بک‌اند برای ثبت FCM Token هر دستگاه.
- **آدرس کامل مشتری در جزئیات سفارش** فعلاً فقط شناسهٔ آدرس را نشان می‌دهد
  (`ShippingAddressText` در `AdminOrdersController.GetOrderDetail` یک NOTE برای تکمیل دارد).
- تمام رنگ/تایپوگرافی در `lib/core/theme/app_theme.dart` است - قبل از انتشار با هویت بصری
  نهایی سایت مادر (طبق سند پیشنهادی محتوا/قالب) هماهنگ کنید.

## ساختار پوشه‌ها

```
lib/
├── core/
│   ├── api/          # ApiClient، SecureStorageService، مدل‌های عمومی پاسخ
│   ├── models/        # مدل‌های Dart منطبق با DTOهای بک‌اند
│   ├── providers/      # ChangeNotifier هر فیچر (Auth، Dashboard، Products، ...)
│   └── theme/
├── features/
│   ├── auth/           # صفحهٔ ورود
│   ├── dashboard/
│   ├── products/       # لیست + فرم ایجاد/ویرایش
│   ├── orders/         # لیست + جزئیات (شامل تغییر وضعیت و ثبت مرسوله)
│   ├── categories/
│   ├── customers/      # فقط‌خواندنی
│   ├── discounts/
│   ├── more/            # منوی «بیشتر» + خروج از حساب
│   └── home_shell.dart  # Bottom Navigation اصلی
└── main.dart / app.dart
```
