# پروژهٔ پلتفرم فروشگاه‌ساز اینستاگرامی — اسنپ‌شات کامل پروژه

این زیپ، کل پروژه با آخرین تغییرات تا این لحظه است (نه دیف/تغییرات جزئی). چهار بخش:

| پوشه | چیست | وضعیت |
|---|---|---|
| `01-Nop.Plugin.Misc.MultiTenantStores` | پلاگین هستهٔ فروشگاه‌ساز nopCommerce (جداسازی چندفروشگاهی + تشخیص فروشگاه) | فاز ۱ کامل + افزودهٔ تشخیص فروشگاه |
| `02-Nop.Plugin.Api` | Web API مشترک بین اپ ادمین و اپ مشتریان | فاز ۴ + محصولات دیجیتال + تشخیص فروشگاه + برندینگ |
| `03-instagram_store_admin_flutter` | اپ ادمین فروشگاه (صاحب کسب‌وکار) | فاز ۴ + صفحهٔ برندینگ (لوگو/رنگ، سبک اینستاگرام) |
| `04-nopcommerce_flutter_app_customers` | اپ مشتریان فروشگاه‌ها (فاز ۳) | تشخیص خودکار فروشگاه + پشتیبانی محصولات دیجیتال |

سند مرجع معماری کامل (`ARCHITECTURE.md`) در Project Knowledge شماست و همچنان معتبر است؛ این زیپ
فقط کد است، نه آن سند.

## تغییرات اعمال‌شده تا این لحظه (خلاصه)

1. **محصولات دیجیتال (فاز ۷)** — `DownloadController` + DTOهای دانلود در `02-Nop.Plugin.Api`،
   و فیلد `IsDownload` روی `ProductDto`.
2. **تشخیص خودکار فروشگاه برای اپ مشترک مشتریان** —
   - `01-Nop.Plugin.Misc.MultiTenantStores`: جدول `AppPhoneStoreLink`، صفحهٔ عمومی «دریافت اپ»
     (`StoreDownloadController`)، فیلدهای برندینگ روی `TenantStoreSubscription`
   - `02-Nop.Plugin.Api`: `StoreController` (`/store/resolve`, `/store/{id}/config`)
   - `04-nopcommerce_flutter_app_customers`: صفحهٔ `StoreDetectionScreen`، تزریق خودکار هدر
     `X-Store-Id`، اعمال رنگ برند به‌عنوان تم
3. **UI ادمین برندینگ (سبک اینستاگرام)** —
   - `02-Nop.Plugin.Api`: `AdminStoreSettingsController`
   - `03-instagram_store_admin_flutter`: صفحهٔ «ویرایش فروشگاه» (آواتار لوگو با حلقهٔ رنگی +
     پالت انتخاب رنگ، دقیقاً مثل ویرایش پروفایل/انتخاب رنگ استوری اینستاگرام)

## نکات فنی مهم قبل از Build

- ترتیب Build: اول `01-Nop.Plugin.Misc.MultiTenantStores`، بعد `02-Nop.Plugin.Api` (چون یک
  `ProjectReference` یک‌طرفه به پلاگین اول دارد).
- مایگریشن جدید (`AppStoreDetectionAndBrandingMigration`) از نوع `Update` است؛ فقط با ری‌استارت
  سایت بعد از دیپلوی پلاگین اجرا می‌شود، نیازی به نصب مجدد نیست.
- امضای چند متد هستهٔ nopCommerce (`IPictureService.InsertPictureAsync` و مواردی که قبلاً با
  کامنت `NOTE` علامت‌گذاری شده بودند) را قبل از build نهایی با نسخهٔ نصب‌شدهٔ 4.90 خودتان چک کنید.
- لینک‌های App Store/Google Play/APK در `StoreDownloadModel.cs` هنوز Placeholder هستند.
- در `03-instagram_store_admin_flutter` و `04-nopcommerce_flutter_app_customers`، بعد از کپی
  فایل‌ها حتماً `flutter pub get` بزنید (اولی برای `image_picker` تازه‌اضافه‌شده).

## موارد باز شناخته‌شده (برای گفتگوهای بعدی)
- اعمال رنگ برند روی خود Storefront وب‌سایت فروشگاه (فعلاً فقط در اپ مشتریان اعمال می‌شود)
- Deep Link / Deferred Deep Linking برای ورود مستقیم به اپ بدون تایپ شماره (بخش ۵ سند معماری، مورد اختیاری)
- درگاه پرداخت (فاز ۶) و دستیار اینستاگرام (فاز ۵) هنوز شروع نشده‌اند
