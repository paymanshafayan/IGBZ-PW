# Nop.Plugin.Api — پلاگین Web API حرفه‌ای برای nopCommerce 4.90

این پلاگین یک REST API کامل روی nopCommerce می‌سازد که برای اتصال اپلیکیشن **Flutter** (یا هر کلاینت موبایل/وب دیگری) طراحی شده. احراز هویت با **JWT (Access Token کوتاه‌مدت + Refresh Token بلندمدت با چرخش خودکار/rotation)** انجام می‌شود که استاندارد صنعتی برای اپ‌های موبایل استیت‌لس است.

## ⚠️ نکته مهم قبل از استفاده (نسخه 4.90)
این پلاگین برای **nopCommerce 4.90 (.NET 9)** تنظیم شده است — این نسخه نیازمند Visual Studio 2022 (v17.12+)، .NET 9 SDK و ASP.NET Core Runtime 9 است. کد بر پایه معماری شناخته‌شده‌ی لایه‌سرویس nopCommerce (`Nop.Services`، DI مبتنی بر `INopStartup`، FluentMigrator) نوشته شده، اما **در این محیط امکان کامپایل مستقیم در برابر سورس واقعی 4.90 وجود ندارد** (بدون دسترسی شبکه به سالوشن و NuGet). نکات لازم:

1. پلاگین را داخل مسیر `src/Plugins/Nop.Plugin.Api` سالوشن نصب‌شده‌ی 4.90 خودتان قرار دهید و به Solution اضافه کنید (Add Existing Project).
2. یک بار **Build** بگیرید. نسخه‌ی 4.90 قابلیت‌های جدیدی مثل **چند لیست علاقه‌مندی (Multiple Wishlists)**، Quote/RFQ، Mega Menu و ابزارهای AI اضافه کرده که ممکن است امضای برخی متدهای مرتبط با Wishlist را کمی تغییر داده باشد (مثلاً افزودن پارامتر `wishlistId`). اگر خطای کامپایل روی این متدها گرفتید، با IntelliSense امضای دقیق را تطبیق دهید — منطق کلی درست است.
3. کلید `JwtSecretKey` به‌صورت خودکار و تصادفی هنگام نصب پلاگین تولید می‌شود (در دیتابیس، جدول `Setting`) — می‌توانید بعداً از پنل ادمین تغییرش دهید.

## 📦 نصب
1. پروژه را در `src/Plugins/Nop.Plugin.Api` کپی کنید.
2. آن را به `NopCommerce.sln` اضافه کنید (Add Existing Project).
3. در پروژه‌ی `Nop.Web` رفرنس این پروژه را اضافه کنید (یا صرفاً از طریق build خروجی در `Plugins` کپی می‌شود، طبق تنظیم `OutDir` در csproj).
4. برنامه را اجرا کنید و از پنل ادمین: **Configuration > Local Plugins** پلاگین «Web API (REST + JWT)» را Install کنید.
5. مستندات Swagger در آدرس زیر در دسترس است:
   ```
   https://yourstore.com/api/docs
   ```

## 🔑 احراز هویت (جریان کامل برای Flutter)

```
POST /api/v1/auth/register     ثبت‌نام
POST /api/v1/auth/login        ورود -> { accessToken, refreshToken, accessTokenExpiresOnUtc }
POST /api/v1/auth/refresh-token  تمدید accessToken با refreshToken
POST /api/v1/auth/logout        خروج (ابطال refresh token)
POST /api/v1/auth/change-password
POST /api/v1/auth/forgot-password
POST /api/v1/auth/reset-password
```

**الگوی پیشنهادی در Flutter:** توکن‌ها را در `flutter_secure_storage` نگه دارید و با یک `Interceptor` در `Dio`، هنگام دریافت خطای 401، خودکار `refresh-token` را صدا بزنید و درخواست را دوباره ارسال کنید. تمام endpointهای محافظت‌شده هدر زیر را می‌خواهند:
```
Authorization: Bearer {accessToken}
```

## ✅ فاز ۱ (این تحویل) — پیاده‌سازی‌شده

| ماژول | Endpoint ها |
|---|---|
| **زیرساخت** | JWT auth scheme، Swagger، جدول RefreshToken، تنظیمات پلاگین در ادمین |
| **Auth** | register, login, refresh-token, logout, change-password, forgot/reset-password |
| **Customer** | GET/PUT profile، GET/POST/PUT/DELETE addresses |
| **Catalog** | GET categories (+detail), GET manufacturers (+detail), GET products (search/filter/pagination), GET product detail, GET/POST product reviews |
| **Cart** | GET/POST/PUT/DELETE سبد خرید، خالی‌کردن سبد، GET/POST Wishlist |

همه پاسخ‌ها با فرمت یکسان برمی‌گردند تا پارس در Flutter ساده باشد:
```json
{ "success": true, "message": "...", "data": { ... }, "errors": [] }
```

## ✅ فاز ۲ (این تحویل) — پیاده‌سازی‌شده

| ماژول | Endpoint ها |
|---|---|
| **Checkout** | `GET /api/v1/checkout/summary` (خلاصه مبالغ)، `GET /shipping-methods`، `POST /shipping-methods/select`، `GET /payment-methods`، `POST /payment-methods/select`، `POST /place-order` |
| **Order** | `GET /api/v1/order` (لیست سفارش‌ها با صفحه‌بندی)، `GET /{id}` (جزئیات کامل)، `POST /{id}/cancel`، `POST /{id}/return-request` (درخواست مرجوعی) |

### جریان کامل خرید در Flutter (پیشنهادی)
```
1) GET  /api/v1/cart                         -> نمایش سبد خرید
2) GET  /api/v1/customer/addresses            -> انتخاب/افزودن آدرس
3) GET  /api/v1/checkout/shipping-methods?shippingAddressId=X   -> لیست روش‌های ارسال
4) POST /api/v1/checkout/shipping-methods/select                -> ذخیره انتخاب
5) GET  /api/v1/checkout/payment-methods                        -> لیست روش‌های پرداخت
6) POST /api/v1/checkout/payment-methods/select                 -> ذخیره انتخاب
7) GET  /api/v1/checkout/summary                                -> نمایش مبلغ نهایی برای تأیید کاربر
8) POST /api/v1/checkout/place-order                             -> ثبت نهایی سفارش
9) اگر PaymentMethod آنلاین بود (مثل درگاه پرداخت) → کاربر به صفحه درگاه هدایت می‌شود (فاز ۳)
10) GET /api/v1/order/{id}                                        -> پیگیری وضعیت سفارش
```

## ✅ فاز ۳ (این تحویل) — پیاده‌سازی‌شده

| ماژول | Endpoint ها |
|---|---|
| **Payment** | `GET /api/v1/payment/order/{orderId}/status` (نیاز به JWT)، `POST /api/v1/payment/webhook` (سرور-به-سرور، با هدر `X-Webhook-Secret`)، `POST /api/v1/payment/order/{orderId}/confirm-client` (نمایش وضعیت پس از بازگشت از درگاه) |
| **Shipping** | `GET /api/v1/shipping/countries`، `GET /api/v1/shipping/countries/{id}/states`، `GET /api/v1/shipping/order/{orderId}/tracking` (نیاز به JWT) |

### 🔗 نحوه اتصال یک درگاه پرداخت ایرانی (مثل زرین‌پال) به این API
یکپارچه‌سازی واقعی یک درگاه باید به‌صورت یک **پلاگین Payment جدای nopCommerce** (مثلاً `Nop.Plugin.Payments.Zarinpal`) نوشته شود، چون nopCommerce فرآیند redirect/return را از طریق `IPaymentMethod` مدیریت می‌کند. جریان پیشنهادی برای اپ فلاتر:

```
1) POST /api/v1/checkout/place-order          -> سفارش با PaymentStatus=Pending ساخته می‌شود
2) اپ فلاتر با استفاده از OrderId/OrderGuid یک WebView به صفحه درگاه پرداخت باز می‌کند
   (آدرس درگاه را پلاگین Payment اختصاصی شما، بر اساس مبلغ سفارش، از API درگاه می‌گیرد)
3) کاربر پرداخت را در درگاه انجام می‌دهد
4) درگاه پرداخت کاربر را به Return URL هدایت می‌کند (که در اپ با Deep Link گرفته می‌شود)
5) همزمان، درگاه یا پلاگین Payment شما باید POST به:
      /api/v1/payment/webhook
      Header: X-Webhook-Secret: <PaymentWebhookSecretKey از پنل ادمین>
      Body: { "orderGuid": "...", "isSuccess": true, "gatewayTransactionId": "...", "paidAmount": 150000 }
   این تنها منبع معتبر برای تغییر وضعیت پرداخت است (امنیت بالاتر از تکیه بر کلاینت).
6) اپ فلاتر بعد از بازگشت از WebView، GET /api/v1/payment/order/{orderId}/status را صدا می‌زند
   تا وضعیت نهایی (Paid/Pending/Failed) را به کاربر نشان دهد.
```

کلید `PaymentWebhookSecretKey` هنگام نصب پلاگین به‌صورت تصادفی تولید می‌شود و از مسیر **Configuration > Local Plugins > Web API** در پنل ادمین قابل مشاهده/تغییر است.

## ✅ فاز ۴ (این تحویل) — پیاده‌سازی‌شده

| ماژول | Endpoint ها |
|---|---|
| **CMS** | `GET /api/v1/cms/topics`، `GET /api/v1/cms/topics/{systemName}` (صفحات ثابت مثل درباره‌ما/قوانین) |
| **Blog** | `GET /api/v1/blog` (لیست+صفحه‌بندی+فیلتر تگ)، `GET /{id}`، `POST /{id}/comments` (نیاز به JWT) |
| **News** | `GET /api/v1/news` (لیست+صفحه‌بندی)، `GET /{id}`، `POST /{id}/comments` (نیاز به JWT) |
| **Forum** | `GET /api/v1/forum/groups`، `GET /forums/{id}`، `GET /forums/{id}/topics`، `GET /topics/{id}` (با پست‌ها)، `POST /topics` (ایجاد تاپیک، نیاز به JWT)، `POST /topics/{id}/posts` (پاسخ، نیاز به JWT) |

همه اندپوینت‌های خواندنی این فاز عمومی (`AllowAnonymous`) هستند و فقط عملیات نوشتن (کامنت/پست/تاپیک جدید) نیاز به توکن JWT دارند.

## ✅ فاز ۵ (این تحویل) — پیاده‌سازی‌شده

| ماژول | Endpoint ها |
|---|---|
| **Vendor** | `GET /api/v1/vendor` (لیست فروشندگان)، `GET /{id}` (پروفایل)، `GET /{id}/products` (محصولات فروشنده، صفحه‌بندی‌شده) |

مناسب سناریوی بازارگاه (Marketplace) که در آن چند فروشنده روی یک فروشگاه nopCommerce محصول می‌فروشند.

## ✅ فاز ۶ (این تحویل) — سخت‌سازی امنیتی

| قابلیت | توضیح |
|---|---|
| **Rate Limiting** | سیاست `AuthPolicy` (حداکثر ۵ درخواست در دقیقه) روی کل `AuthController` (لاگین، ثبت‌نام، فراموشی رمز) برای جلوگیری از حملات Brute-force؛ در صورت عبور از سقف، پاسخ `429 Too Many Requests` برمی‌گردد. |
| **هش‌کردن Refresh Token** | مقدار Refresh Token دیگر به‌صورت متن ساده در دیتابیس ذخیره نمی‌شود؛ فقط هش SHA-256 آن نگه‌داری می‌شود. اگر دیتابیس افشا شود، مهاجم نمی‌تواند از رکوردها برای جعل نشست استفاده کند. |
| **اعتبارسنجی ورودی (FluentValidation)** | یک `ApiValidationFilter` سراسری، پیش از اجرای هر اکشن، اگر برای نوع DTO ورودی یک Validator ثبت شده باشد آن را خودکار اجرا می‌کند (`LoginRequestDto`, `RegisterRequestDto`, `ChangePasswordRequestDto`, `AddToCartRequestDto`, `UpdateCartItemDto`, `PlaceOrderRequestDto`). نیازی به نوشتن `if (!ModelState.IsValid)` تکراری در هر اکشن نیست. |
| **مدیریت خطای سراسری** | `ApiExceptionFilterAttribute` هر Exception مدیریت‌نشده را در جدول Log فروشگاه (از طریق `ILogger` خود nopCommerce) ثبت می‌کند و به‌جای صفحه خطای HTML، پاسخ JSON استاندارد (`500` + پیام کلی، بدون افشای جزئیات داخلی در Production) برمی‌گرداند. |

### افزودن Validator جدید برای یک DTO دیگر
کافیست یک کلاس مثل زیر در پوشه `Validators` اضافه کنید؛ چون `AddValidatorsFromAssemblyContaining` در `NopStartup` همه Validatorهای این اسمبلی را خودکار پیدا و ثبت می‌کند:
```csharp
public class MyDtoValidator : AbstractValidator<MyDto>
{
    public MyDtoValidator()
    {
        RuleFor(x => x.SomeField).NotEmpty();
    }
}
```

## 🎉 جمع‌بندی — همه فازهای توافق‌شده تکمیل شدند
پلاگین اکنون شامل: زیرساخت JWT، Auth، Customer، Catalog، Cart، Checkout، Order، Payment، Shipping، CMS، Blog، News، Forum، Vendor و سخت‌سازی امنیتی (Rate limiting، هش Refresh Token، FluentValidation، لاگ‌گیری خطا) است.

### پیشنهادهای اختیاری برای ادامه (در صورت نیاز، در گفتگوی جدید بخواهید)
- نوشتن یک پلاگین Payment واقعی برای درگاه مدنظر شما (زرین‌پال/IDPay/...) که به Webhook این API متصل شود.
- افزودن Push Notification (Firebase) برای اطلاع‌رسانی تغییر وضعیت سفارش به اپ فلاتر.
- افزودن تست‌های Integration (xUnit + WebApplicationFactory) برای اطمینان از صحت اندپوینت‌ها پس از هر تغییر.
- افزودن پشتیبانی از چند زبان/چند ارز در پاسخ‌های API (بر اساس هدر `Accept-Language` یا `X-Store-Currency`).

## ✅ فاز ۷ — محصولات دیجیتال/دانلودی (ویدئو، صدا، کتاب الکترونیک)

| Endpoint | توضیح |
|---|---|
| `GET /api/v1/download/my-products` | لیست همه محصولات دیجیتالی خریداری‌شده توسط کاربر جاری (از همهٔ سفارش‌ها)، همراه با نوع رسانه، وضعیت مجاز بودن دانلود و تعداد دانلود باقی‌مانده |
| `GET /api/v1/download/license/{orderItemId}` | متن قرارداد/توافق‌نامهٔ استفاده (اگر محصول `HasUserAgreement=true` داشته باشد) |
| `POST /api/v1/download/license/{orderItemId}/accept` | پذیرش قرارداد - پیش‌نیاز دانلود برای محصولات دارای توافق‌نامه |
| `GET /api/v1/download/file/{orderItemId}` | دانلود فایل اصلی (استریم باینری مستقیم) |
| `GET /api/v1/download/sample/{productId}` | دانلود فایل نمونه، بدون نیاز به خرید (Anonymous) |

منطق و قوانین دسترسی دقیقاً همان چیزی است که در پلاگین API عمومی (نسخهٔ ارسالی شما) پیاده‌سازی
شده بود؛ چیزی که اینجا اضافه/تفاوت دارد فقط این است که این کنترلر مثل بقیهٔ کنترلرهای این پلاگین
به‌صورت خودکار زیر چتر امنیتی چندفروشگاهی (`ApiStoreGateFilter` + `ApiCrossStoreGuardFilter`) قرار
می‌گیرد - نیازی به هیچ تغییری در خود `DownloadController` نبود چون آن دو فیلتر Global هستند.
همچنین فیلد `IsDownload` به `ProductDto` (نتیجهٔ `GET /catalog/products/{id}`) اضافه شد تا اپ
بتواند تشخیص دهد یک محصول دیجیتال است یا فیزیکی.

## ✅ فاز ۳ (تکمیل اپ مشتریان) — تشخیص خودکار فروشگاه برای اپ مشترک

اپ مشتریان یک باینری واحد است که بین همهٔ فروشگاه‌های پلتفرم مشترک است؛ این دو Endpoint (هر دو
`AllowAnonymous` و معاف از الزام هدر `X-Store-Id` - چون دقیقاً همین‌ها آن هدر را برای بقیهٔ
درخواست‌ها فراهم می‌کنند) این تشخیص را ممکن می‌کنند:

| Endpoint | توضیح |
|---|---|
| `POST /api/v1/store/resolve` | ورودی `{ phoneNumber }` - همان شماره‌ای که کاربر قبلاً در صفحهٔ دانلود اپ روی سایت فروشگاهش وارد کرده. خروجی `{ found, storeId }`. فروشگاه Suspended/Cancelled به‌عمد `found:false` برمی‌گرداند. |
| `GET /api/v1/store/{storeId}/config` | برندینگ فروشگاه برای اپ: `{ storeId, name, domain, logoUrl, brandColorHex }` |

**نکتهٔ مهم دربارهٔ منبع دادهٔ `resolve`:** این Endpoint خودش چیزی ذخیره نمی‌کند؛ فقط جدول
`AppPhoneStoreLink` (در پلاگین `Nop.Plugin.Misc.MultiTenantStores`) را می‌خواند. آن جدول توسط
یک صفحهٔ عمومی جدید در همان پلاگین پر می‌شود: `StoreDownloadController` (مسیر پیش‌فرض `/storedownload`
یا هر مسیر دیگری که در `RouteConfig`/attribute routing خودتان به آن بدهید) - همان صفحه‌ای که طبق
تصمیم بخش ۵ سند معماری، قبل از نمایش لینک‌های دانلود از کاربر شماره موبایل می‌گیرد. جزئیات کامل
در README پلاگین `Nop.Plugin.Misc.MultiTenantStores`.

**برندینگ (`logoUrl`/`brandColorHex`):** این دو فیلد روی خود `TenantStoreSubscription` ذخیره
می‌شوند (ستون‌های تازه‌اضافه‌شدهٔ `LogoPictureId`/`BrandColorHex`) - فعلاً هیچ UI ادمینی برای
تنظیم آن‌ها ساخته نشده؛ ساده‌ترین راه، ست‌کردن مستقیم این دو ستون در دیتابیس یا افزودن یک فرم کوچک
به کنترلر ادمین موجود (`TenantSettingsController` یا معادل) در یک تحویل بعدی است.

## ⚠️ نکات فنی فاز ۲ و ۳
- در `PlaceOrder`، اگر `PaymentMethodSystemName` مربوط به یک درگاه پرداخت آنلاین (Redirection) باشد، معمولاً باید کاربر بعد از ثبت سفارش به صفحه درگاه هدایت شود؛ منطق دقیق آن به پلاگین Payment اختصاصی درگاه بستگی دارد (بخش «نحوه اتصال درگاه» در بالا را ببینید).
- متد `CancelOrderAsync`، `MarkOrderAsPaidAsync`، `CanMarkOrderAsPaid` و امضای دقیق برخی متدهای `IOrderTotalCalculationService`/`IShipmentService` (که چند خروجی/تاپل برمی‌گردانند یا پارامتر اضافه دارند) ممکن است در 4.90 نسبت به آنچه اینجا فرض شده جزئی تفاوت داشته باشد؛ در صورت خطای کامپایل با IntelliSense تطبیق دهید — منطق کلی و ترتیب فراخوانی‌ها درست است.
- Webhook با یک کلید مخفی ساده (`X-Webhook-Secret`) محافظت شده که برای شروع کافی است؛ برای Production توصیه می‌شود امضای HMAC مخصوص درگاه خودتان (اگر ارائه می‌دهد) را هم اضافه کنید.

## ساختار فایل‌ها (فاز ۱)
```
Nop.Plugin.Api/
├── Nop.Plugin.Api.csproj
├── plugin.json
├── ApiPlugin.cs
├── Domain/
│   ├── ApiSettings.cs
│   └── ApiRefreshToken.cs
├── Data/
│   ├── ApiRefreshTokenBuilder.cs
│   └── Migrations/SchemaMigration.cs
├── Services/
│   ├── IJwtTokenService.cs / JwtTokenService.cs
│   └── IRefreshTokenService.cs / RefreshTokenService.cs
├── Infrastructure/
│   └── NopStartup.cs   (JWT + Swagger + DI)
├── Controllers/
│   ├── BaseNopApiController.cs
│   ├── AuthController.cs
│   ├── CustomerController.cs
│   ├── CatalogController.cs
│   └── ShoppingCartController.cs
└── DTOs/ (Common, Auth, Customer, Catalog, Cart)
```

برای ادامه (فاز ۲: Checkout/Order) کافیست در همین گفتگو بگویید **«فاز بعدی رو بساز»**.
