using System.Threading.Tasks;
using Nop.Core.Events;
using Nop.Plugin.Api.Domain;
using Nop.Plugin.Misc.MultiTenantStores.Domain;
using Nop.Services.Configuration;
using Nop.Services.Events;

namespace Nop.Plugin.Api.Events
{
    /// <summary>
    /// NOTE: nopCommerce's generic repository publishes EntityUpdatedEvent&lt;T&gt; automatically
    /// for ANY entity on Update, including TenantStoreSubscription (defined in the
    /// Nop.Plugin.Misc.MultiTenantStores plugin) - no direct call/coupling needed from that
    /// plugin into this one, only this one-way project reference. Verify this generic event
    /// still fires the same way in your installed nopCommerce version.
    ///
    /// Reconciles the per-store "EnableApi" override every time a subscription record changes:
    /// Suspended/Cancelled -> API access for that store's app users is cut off; anything else ->
    /// restored. Runs in addition to (not instead of) TenantProvisioningService.SuspendAsync
    /// already disabling the store's domain binding/admin access on the web side.
    /// </summary>
    public class TenantSubscriptionApiGateConsumer : IConsumer<EntityUpdatedEvent<TenantStoreSubscription>>
    {
        private readonly ISettingService _settingService;

        public TenantSubscriptionApiGateConsumer(ISettingService settingService)
        {
            _settingService = settingService;
        }

        public async Task HandleEventAsync(EntityUpdatedEvent<TenantStoreSubscription> eventMessage)
        {
            var subscription = eventMessage?.Entity;
            if (subscription == null || subscription.StoreId <= 0)
                return;

            var apiSettings = await _settingService.LoadSettingAsync<ApiSettings>(subscription.StoreId);
            var shouldBeEnabled = subscription.Status != TenantSubscriptionStatus.Suspended
                                   && subscription.Status != TenantSubscriptionStatus.Cancelled;

            if (apiSettings.EnableApi == shouldBeEnabled)
                return; // already in sync, avoid a pointless write

            apiSettings.EnableApi = shouldBeEnabled;
            await _settingService.SaveSettingAsync(apiSettings, x => x.EnableApi, subscription.StoreId);
        }
    }
}
