using FluentMigrator.Builders.Create.Table;
using Nop.Data.Mapping.Builders;
using Nop.Plugin.Api.Domain;

namespace Nop.Plugin.Api.Data
{
    public class ApiRefreshTokenBuilder : NopEntityBuilder<ApiRefreshToken>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table
                .WithColumn(nameof(ApiRefreshToken.CustomerId)).AsInt32().ForeignKey("Customer", "Id").NotNullable()
                .WithColumn(nameof(ApiRefreshToken.Token)).AsString(450).NotNullable()
                .WithColumn(nameof(ApiRefreshToken.DeviceId)).AsString(200).Nullable();
        }
    }
}
