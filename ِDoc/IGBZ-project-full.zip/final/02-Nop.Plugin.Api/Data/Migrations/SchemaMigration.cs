using FluentMigrator;
using Nop.Data.Migrations;
using Nop.Plugin.Api.Domain;

namespace Nop.Plugin.Api.Data.Migrations
{
    [NopMigration("2026-07-19 00:00:00", "Nop.Plugin.Api base schema", MigrationProcessType.Installation)]
    public class SchemaMigration : AutoReversingMigration
    {
        protected readonly IMigrationManager _migrationManager;

        public SchemaMigration()
        {
        }

        public override void Up()
        {
            Create.TableFor<ApiRefreshToken>();
        }
    }
}
