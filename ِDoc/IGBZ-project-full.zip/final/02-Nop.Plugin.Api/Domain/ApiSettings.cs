using Nop.Core.Configuration;

namespace Nop.Plugin.Api.Domain
{
    public class ApiSettings : ISettings
    {
        /// <summary>فعال یا غیرفعال بودن کل API</summary>
        public bool EnableApi { get; set; }

        /// <summary>کلید مخفی برای امضای توکن JWT (باید طولانی و تصادفی باشد)</summary>
        public string JwtSecretKey { get; set; }

        /// <summary>Issuer توکن JWT</summary>
        public string JwtIssuer { get; set; }

        /// <summary>Audience توکن JWT</summary>
        public string JwtAudience { get; set; }

        /// <summary>مدت اعتبار Access Token بر حسب دقیقه</summary>
        public int AccessTokenExpirationMinutes { get; set; }

        /// <summary>مدت اعتبار Refresh Token بر حسب روز</summary>
        public int RefreshTokenExpirationDays { get; set; }

        /// <summary>آیا ثبت‌نام مشتری جدید از طریق API مجاز است</summary>
        public bool AllowRegistrationViaApi { get; set; }

        /// <summary>حداکثر مجاز اندازه صفحه در pagination</summary>
        public int MaxPageSize { get; set; }

        /// <summary>اندازه پیش‌فرض صفحه در pagination</summary>
        public int DefaultPageSize { get; set; }

        /// <summary>کلید مخفی برای اعتبارسنجی درخواست‌های Webhook درگاه‌های پرداخت (سرور-به-سرور، بدون JWT کاربر)</summary>
        public string PaymentWebhookSecretKey { get; set; }
    }
}
