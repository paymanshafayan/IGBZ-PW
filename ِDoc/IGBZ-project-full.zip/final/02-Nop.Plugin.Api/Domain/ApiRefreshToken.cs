using System;
using Nop.Core;

namespace Nop.Plugin.Api.Domain
{
    /// <summary>
    /// موجودیت نگهداری Refresh Token های صادرشده برای کاربران API (مثلاً اپ فلاتر)
    /// </summary>
    public class ApiRefreshToken : BaseEntity
    {
        /// <summary>شناسه مشتری (Customer) صاحب توکن</summary>
        public int CustomerId { get; set; }

        /// <summary>مقدار توکن (هش‌شده ذخیره می‌شود در پیاده‌سازی نهایی توصیه می‌شود)</summary>
        public string Token { get; set; }

        /// <summary>تاریخ ایجاد</summary>
        public DateTime CreatedOnUtc { get; set; }

        /// <summary>تاریخ انقضا</summary>
        public DateTime ExpiresOnUtc { get; set; }

        /// <summary>آیا ابطال شده است (مثلاً بعد از logout یا refresh)</summary>
        public bool IsRevoked { get; set; }

        /// <summary>شناسه دستگاه/کلاینت (اختیاری - برای مدیریت چند دستگاه در اپ موبایل)</summary>
        public string DeviceId { get; set; }
    }
}
