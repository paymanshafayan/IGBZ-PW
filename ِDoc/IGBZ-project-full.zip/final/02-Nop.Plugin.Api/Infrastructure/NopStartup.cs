using System;
using System.Text;
using FluentValidation;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Nop.Core.Infrastructure;
using Nop.Plugin.Api.Domain;
using Nop.Web.Framework.Infrastructure.Extensions;

namespace Nop.Plugin.Api.Infrastructure
{
    /// <summary>
    /// این کلاس هنگام راه‌اندازی برنامه nopCommerce به‌صورت خودکار توسط هسته nopCommerce فراخوانی می‌شود
    /// و Authentication Scheme جدید "ApiJwtBearer" را (در کنار سیستم کوکی پیش‌فرض ادمین/سایت) اضافه می‌کند.
    /// </summary>
    public class NopStartup : INopStartup
    {
        public int Order => 3000; // بعد از راه‌اندازی هسته اصلی nopCommerce اجرا شود

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // تنظیمات JWT را در زمان راه‌اندازی از دیتابیس نمی‌توان خواند (چون DB هنوز آماده نیست)
            // بنابراین یک کلید موقت هنگام bootstrap استفاده می‌شود و خود Handler توکن‌ها را با
            // کلید واقعی (خوانده‌شده از ApiSettings در دیتابیس) در IJwtTokenService صادر/اعتبارسنجی می‌کند.
            // برای ولیدیشن در میان‌افزار AspNet از یک SecurityKeyProvider سفارشی استفاده می‌کنیم.

            services.AddHttpContextAccessor();

            // ثبت سرویس‌های اختصاصی پلاگین
            services.AddScoped<Nop.Plugin.Api.Services.IJwtTokenService, Nop.Plugin.Api.Services.JwtTokenService>();
            services.AddScoped<Nop.Plugin.Api.Services.IRefreshTokenService, Nop.Plugin.Api.Services.RefreshTokenService>();

            // ثبت خودکار همه‌ی Validatorهای FluentValidation موجود در این اسمبلی (فاز ۶ - سخت‌سازی امنیتی)
            services.AddValidatorsFromAssemblyContaining<Nop.Plugin.Api.Validators.LoginRequestValidator>();

            // اعمال فیلترهای گلوبال: مدیریت خطا + اعتبارسنجی خودکار ورودی (فاز ۶)
            // + جداسازی چندفروشگاهی (Multi-Tenant): این دو فیلتر با هم‌کاری پلاگین
            //   Nop.Plugin.Misc.MultiTenantStores تضمین می‌کنند که یک درخواست API همیشه هدر
            //   X-Store-Id معتبر داشته باشد، فروشگاه مقصد Suspend نشده باشد، و حساب کاربری
            //   لاگین‌شده واقعاً متعلق به همان فروشگاه باشد - نه فقط در لحظهٔ لاگین، بلکه در
            //   تمام درخواست‌های بعدی هم.
            services.Configure<Microsoft.AspNetCore.Mvc.MvcOptions>(options =>
            {
                options.Filters.Add<Nop.Plugin.Api.Filters.ApiExceptionFilterAttribute>();
                options.Filters.Add<Nop.Plugin.Api.Filters.ApiValidationFilter>();
                options.Filters.Add<Nop.Plugin.Api.Filters.ApiStoreGateFilter>();
                options.Filters.Add<Nop.Plugin.Api.Filters.ApiCrossStoreGuardFilter>();
            });

            // محدودسازی نرخ درخواست (Rate Limiting) روی اندپوینت‌های حساس احراز هویت
            // برای جلوگیری از حملات Brute-force روی لاگین/ثبت‌نام/فراموشی رمز عبور (فاز ۶)
            services.AddRateLimiter(options =>
            {
                options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

                options.AddFixedWindowLimiter("AuthPolicy", opt =>
                {
                    opt.PermitLimit = 5;                       // حداکثر ۵ درخواست
                    opt.Window = TimeSpan.FromMinutes(1);       // در هر ۱ دقیقه
                    opt.QueueLimit = 0;
                    opt.QueueProcessingOrder = System.Threading.RateLimiting.QueueProcessingOrder.OldestFirst;
                });

                options.OnRejected = async (context, cancellationToken) =>
                {
                    context.HttpContext.Response.ContentType = "application/json";
                    await context.HttpContext.Response.WriteAsync(
                        "{\"success\":false,\"message\":\"تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً کمی صبر کنید.\"}",
                        cancellationToken);
                };
            });

            services.AddAuthentication(options =>
                {
                    // اسکیم پیش‌فرض nopCommerce دست‌نخورده باقی می‌ماند؛ فقط یک اسکیم اضافه برای API ثبت می‌شود
                })
                .AddJwtBearer("ApiJwtBearer", options =>
                {
                    options.RequireHttpsMetadata = false; // در Production حتماً true و پشت HTTPS
                    options.SaveToken = true;
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ClockSkew = TimeSpan.FromSeconds(30),
                        IssuerSigningKeyResolver = (token, securityToken, kid, parameters) =>
                        {
                            // کلید امضا از تنظیمات دیتابیس (ApiSettings) در زمان اجرا خوانده می‌شود
                            var settingService = EngineContext.Current.Resolve<Nop.Services.Configuration.ISettingService>();
                            var apiSettings = settingService.LoadSettingAsync<ApiSettings>().Result;
                            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(apiSettings.JwtSecretKey));
                            return new[] { (SecurityKey)key };
                        },
                        ValidIssuer = "NopCommerceApi",
                        ValidAudience = "NopCommerceApiClient"
                    };

                    options.Events = new JwtBearerEvents
                    {
                        OnAuthenticationFailed = context =>
                        {
                            context.NoResult();
                            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                            context.Response.ContentType = "application/json";
                            return context.Response.WriteAsync("{\"success\":false,\"message\":\"توکن نامعتبر یا منقضی شده است.\"}");
                        },
                        OnChallenge = context =>
                        {
                            context.HandleResponse();
                            if (!context.Response.HasStarted)
                            {
                                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                                context.Response.ContentType = "application/json";
                                return context.Response.WriteAsync("{\"success\":false,\"message\":\"دسترسی غیرمجاز. توکن ارسال نشده یا نامعتبر است.\"}");
                            }
                            return System.Threading.Tasks.Task.CompletedTask;
                        }
                    };
                });

            services.AddAuthorization(options =>
            {
                options.AddPolicy("ApiUser", policy =>
                {
                    policy.AuthenticationSchemes.Add("ApiJwtBearer");
                    policy.RequireAuthenticatedUser();
                });
            });

            // Swagger برای مستندسازی و تست API
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("nop-api", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "nopCommerce Web API",
                    Version = "v1",
                    Description = "REST API کامل برای nopCommerce - مناسب اتصال اپلیکیشن‌های موبایل (Flutter) و وب"
                });

                c.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                {
                    Description = "توکن JWT را با فرمت زیر وارد کنید: Bearer {token}",
                    Name = "Authorization",
                    In = Microsoft.OpenApi.Models.ParameterLocation.Header,
                    Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });

                c.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
                {
                    {
                        new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                        {
                            Reference = new Microsoft.OpenApi.Models.OpenApiReference
                            {
                                Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        Array.Empty<string>()
                    }
                });
            });
        }

        public void Configure(IApplicationBuilder application)
        {
            application.UseRateLimiter();

            application.UseSwagger(c => c.RouteTemplate = "api/docs/{documentName}/swagger.json");
            application.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/api/docs/nop-api/swagger.json", "nopCommerce Web API v1");
                c.RoutePrefix = "api/docs";
            });
        }
    }
}
