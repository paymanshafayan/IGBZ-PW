using FluentValidation;
using Nop.Plugin.Api.DTOs.Store;

namespace Nop.Plugin.Api.Validators
{
    public class ResolveStoreRequestValidator : AbstractValidator<ResolveStoreRequestDto>
    {
        public ResolveStoreRequestValidator()
        {
            RuleFor(x => x.PhoneNumber).NotEmpty().WithMessage("شماره موبایل الزامی است.");
        }
    }
}
