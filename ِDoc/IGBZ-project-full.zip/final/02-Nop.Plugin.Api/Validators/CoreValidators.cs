using FluentValidation;
using Nop.Plugin.Api.DTOs.Auth;
using Nop.Plugin.Api.DTOs.Cart;
using Nop.Plugin.Api.DTOs.Checkout;

namespace Nop.Plugin.Api.Validators
{
    public class LoginRequestValidator : AbstractValidator<LoginRequestDto>
    {
        public LoginRequestValidator()
        {
            RuleFor(x => x.Email).NotEmpty().WithMessage("ایمیل الزامی است.").EmailAddress().WithMessage("فرمت ایمیل صحیح نیست.");
            RuleFor(x => x.Password).NotEmpty().WithMessage("رمز عبور الزامی است.");
        }
    }

    public class RegisterRequestValidator : AbstractValidator<RegisterRequestDto>
    {
        public RegisterRequestValidator()
        {
            RuleFor(x => x.FirstName).NotEmpty().WithMessage("نام الزامی است.").MaximumLength(100);
            RuleFor(x => x.LastName).NotEmpty().WithMessage("نام خانوادگی الزامی است.").MaximumLength(100);
            RuleFor(x => x.Email).NotEmpty().EmailAddress().WithMessage("ایمیل معتبر وارد کنید.");
            RuleFor(x => x.Password)
                .NotEmpty().WithMessage("رمز عبور الزامی است.")
                .MinimumLength(6).WithMessage("رمز عبور باید حداقل ۶ کاراکتر باشد.")
                .Matches("[A-Za-z]").WithMessage("رمز عبور باید حداقل شامل یک حرف باشد.")
                .Matches("[0-9]").WithMessage("رمز عبور باید حداقل شامل یک عدد باشد.");
        }
    }

    public class ChangePasswordRequestValidator : AbstractValidator<ChangePasswordRequestDto>
    {
        public ChangePasswordRequestValidator()
        {
            RuleFor(x => x.OldPassword).NotEmpty().WithMessage("رمز عبور فعلی الزامی است.");
            RuleFor(x => x.NewPassword)
                .NotEmpty().MinimumLength(6).WithMessage("رمز عبور جدید باید حداقل ۶ کاراکتر باشد.")
                .NotEqual(x => x.OldPassword).WithMessage("رمز عبور جدید نباید با رمز فعلی یکسان باشد.");
        }
    }

    public class AddToCartRequestValidator : AbstractValidator<AddToCartRequestDto>
    {
        public AddToCartRequestValidator()
        {
            RuleFor(x => x.ProductId).GreaterThan(0).WithMessage("شناسه محصول نامعتبر است.");
            RuleFor(x => x.Quantity).GreaterThan(0).WithMessage("تعداد باید بزرگ‌تر از صفر باشد.")
                .LessThanOrEqualTo(1000).WithMessage("تعداد درخواستی بیش از حد مجاز است.");
        }
    }

    public class UpdateCartItemValidator : AbstractValidator<UpdateCartItemDto>
    {
        public UpdateCartItemValidator()
        {
            RuleFor(x => x.Quantity).GreaterThanOrEqualTo(0).WithMessage("تعداد نامعتبر است.")
                .LessThanOrEqualTo(1000).WithMessage("تعداد درخواستی بیش از حد مجاز است.");
        }
    }

    public class PlaceOrderRequestValidator : AbstractValidator<PlaceOrderRequestDto>
    {
        public PlaceOrderRequestValidator()
        {
            RuleFor(x => x.BillingAddressId).GreaterThan(0).WithMessage("آدرس صورتحساب باید انتخاب شود.");
            RuleFor(x => x.PaymentMethodSystemName).NotEmpty().WithMessage("روش پرداخت باید انتخاب شود.");
        }
    }
}
