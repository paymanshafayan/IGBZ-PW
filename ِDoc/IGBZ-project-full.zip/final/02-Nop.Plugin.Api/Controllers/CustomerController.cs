using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core.Domain.Common;
using Nop.Plugin.Api.DTOs.Customer;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Directory;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>مدیریت پروفایل و آدرس‌های مشتری لاگین‌شده</summary>
    public class CustomerController : AuthorizedApiController
    {
        private readonly ICustomerService _customerService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IAddressService _addressService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ICustomerAttributeParser _customerAttributeParser;

        public CustomerController(
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            IAddressService addressService,
            ICountryService countryService,
            IStateProvinceService stateProvinceService)
        {
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
            _addressService = addressService;
            _countryService = countryService;
            _stateProvinceService = stateProvinceService;
        }

        /// <summary>دریافت اطلاعات پروفایل کاربر جاری</summary>
        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile()
        {
            var customer = await GetCurrentApiCustomerAsync();
            if (customer == null)
                return NotFoundResult("کاربر یافت نشد.");

            var dto = await MapCustomerAsync(customer);
            return Ok(dto);
        }

        /// <summary>ویرایش اطلاعات پروفایل کاربر جاری</summary>
        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateCustomerDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            if (customer == null)
                return NotFoundResult("کاربر یافت نشد.");

            await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.FirstNameAttribute, request.FirstName);
            await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.LastNameAttribute, request.LastName);
            if (request.PhoneNumber != null)
                await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.PhoneAttribute, request.PhoneNumber);
            if (request.DateOfBirth.HasValue)
                await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.DateOfBirthAttribute, request.DateOfBirth.Value);
            if (request.Gender != null)
                await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.GenderAttribute, request.Gender);

            await _customerService.UpdateCustomerAsync(customer);

            var dto = await MapCustomerAsync(customer);
            return Ok(dto, "پروفایل با موفقیت به‌روزرسانی شد.");
        }

        /// <summary>لیست آدرس‌های کاربر جاری</summary>
        [HttpGet("addresses")]
        public async Task<IActionResult> GetAddresses()
        {
            var customer = await GetCurrentApiCustomerAsync();
            var addresses = await _customerService.GetAddressesByCustomerIdAsync(customer.Id);

            var result = new List<CustomerAddressDto>();
            foreach (var address in addresses)
                result.Add(await MapAddressAsync(address, customer));

            return Ok(result);
        }

        /// <summary>افزودن آدرس جدید برای کاربر جاری</summary>
        [HttpPost("addresses")]
        public async Task<IActionResult> AddAddress([FromBody] CustomerAddressDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();

            var address = new Address
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Company = request.Company,
                CountryId = request.CountryId,
                StateProvinceId = request.StateProvinceId,
                City = request.City,
                County = request.County,
                Address1 = request.Address1,
                Address2 = request.Address2,
                ZipPostalCode = request.ZipPostalCode,
                PhoneNumber = request.PhoneNumber,
                FaxNumber = request.FaxNumber,
                CreatedOnUtc = System.DateTime.UtcNow
            };

            await _addressService.InsertAddressAsync(address);
            await _customerService.InsertCustomerAddressAsync(customer, address);

            if (request.IsDefaultBilling)
            {
                customer.BillingAddressId = address.Id;
                await _customerService.UpdateCustomerAsync(customer);
            }
            if (request.IsDefaultShipping)
            {
                customer.ShippingAddressId = address.Id;
                await _customerService.UpdateCustomerAsync(customer);
            }

            var dto = await MapAddressAsync(address, customer);
            return Ok(dto, "آدرس با موفقیت اضافه شد.");
        }

        /// <summary>ویرایش آدرس کاربر جاری</summary>
        [HttpPut("addresses/{addressId:int}")]
        public async Task<IActionResult> UpdateAddress(int addressId, [FromBody] CustomerAddressDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var address = await _addressService.GetAddressByIdAsync(addressId);
            if (address == null || !(await _customerService.GetAddressesByCustomerIdAsync(customer.Id)).Any(a => a.Id == addressId))
                return NotFoundResult("آدرس یافت نشد.");

            address.FirstName = request.FirstName;
            address.LastName = request.LastName;
            address.Email = request.Email;
            address.Company = request.Company;
            address.CountryId = request.CountryId;
            address.StateProvinceId = request.StateProvinceId;
            address.City = request.City;
            address.County = request.County;
            address.Address1 = request.Address1;
            address.Address2 = request.Address2;
            address.ZipPostalCode = request.ZipPostalCode;
            address.PhoneNumber = request.PhoneNumber;
            address.FaxNumber = request.FaxNumber;

            await _addressService.UpdateAddressAsync(address);

            if (request.IsDefaultBilling)
            {
                customer.BillingAddressId = address.Id;
                await _customerService.UpdateCustomerAsync(customer);
            }
            if (request.IsDefaultShipping)
            {
                customer.ShippingAddressId = address.Id;
                await _customerService.UpdateCustomerAsync(customer);
            }

            var dto = await MapAddressAsync(address, customer);
            return Ok(dto, "آدرس با موفقیت ویرایش شد.");
        }

        /// <summary>حذف آدرس کاربر جاری</summary>
        [HttpDelete("addresses/{addressId:int}")]
        public async Task<IActionResult> DeleteAddress(int addressId)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var address = await _addressService.GetAddressByIdAsync(addressId);
            if (address == null || !(await _customerService.GetAddressesByCustomerIdAsync(customer.Id)).Any(a => a.Id == addressId))
                return NotFoundResult("آدرس یافت نشد.");

            await _customerService.RemoveCustomerAddressAsync(customer, address);
            await _addressService.DeleteAddressAsync(address);

            return Ok<object>(null, "آدرس با موفقیت حذف شد.");
        }

        private async Task<CustomerDto> MapCustomerAsync(Nop.Core.Domain.Customers.Customer customer)
        {
            var roles = await _customerService.GetCustomerRolesAsync(customer);
            return new CustomerDto
            {
                Id = customer.Id,
                Email = customer.Email,
                FirstName = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.FirstNameAttribute),
                LastName = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.LastNameAttribute),
                PhoneNumber = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.PhoneAttribute),
                Gender = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.GenderAttribute),
                DateOfBirth = await _genericAttributeService.GetAttributeAsync<System.DateTime?>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.DateOfBirthAttribute),
                IsActive = customer.Active,
                CreatedOnUtc = customer.CreatedOnUtc,
                Roles = roles.Select(r => r.SystemName).ToList()
            };
        }

        private async Task<CustomerAddressDto> MapAddressAsync(Address address, Nop.Core.Domain.Customers.Customer customer)
        {
            var country = address.CountryId.HasValue ? await _countryService.GetCountryByAddressAsync(address) : null;
            var state = address.StateProvinceId.HasValue ? await _stateProvinceService.GetStateProvinceByAddressAsync(address) : null;

            return new CustomerAddressDto
            {
                Id = address.Id,
                FirstName = address.FirstName,
                LastName = address.LastName,
                Email = address.Email,
                Company = address.Company,
                CountryId = address.CountryId,
                CountryName = country?.Name,
                StateProvinceId = address.StateProvinceId,
                StateProvinceName = state?.Name,
                City = address.City,
                County = address.County,
                Address1 = address.Address1,
                Address2 = address.Address2,
                ZipPostalCode = address.ZipPostalCode,
                PhoneNumber = address.PhoneNumber,
                FaxNumber = address.FaxNumber,
                IsDefaultBilling = customer.BillingAddressId == address.Id,
                IsDefaultShipping = customer.ShippingAddressId == address.Id
            };
        }
    }
}
