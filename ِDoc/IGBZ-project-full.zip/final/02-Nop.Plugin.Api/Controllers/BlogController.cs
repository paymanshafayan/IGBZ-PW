using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Api.DTOs.Blog;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Services.Blogs;
using Nop.Services.Customers;
using Nop.Services.Seo;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>وبلاگ فروشگاه: لیست پست‌ها، جزئیات و کامنت‌گذاری</summary>
    [AllowAnonymous]
    public class BlogController : BaseNopApiController
    {
        private readonly IBlogService _blogService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly ICustomerService _customerService;
        private readonly IStoreContext _storeContext;

        public BlogController(IBlogService blogService, IUrlRecordService urlRecordService,
            ICustomerService customerService, IStoreContext storeContext)
        {
            _blogService = blogService;
            _urlRecordService = urlRecordService;
            _customerService = customerService;
            _storeContext = storeContext;
        }

        /// <summary>لیست پست‌های وبلاگ با صفحه‌بندی</summary>
        [HttpGet("")]
        public async Task<IActionResult> GetPosts([FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 10, [FromQuery] string tag = null)
        {
            var store = await _storeContext.GetCurrentStoreAsync();

            var posts = string.IsNullOrEmpty(tag)
                ? await _blogService.GetAllBlogPostsAsync(store.Id, pageIndex: pageIndex, pageSize: pageSize)
                : await _blogService.GetAllBlogPostsByTagAsync(store.Id, tag: tag, pageIndex: pageIndex, pageSize: pageSize);

            var items = new List<BlogPostListItemDto>();
            foreach (var post in posts)
                items.Add(await MapListItemAsync(post));

            var result = new PagedResultDto<BlogPostListItemDto>
            {
                Items = items,
                PageIndex = posts.PageIndex,
                PageSize = posts.PageSize,
                TotalCount = posts.TotalCount,
                TotalPages = posts.TotalPages
            };

            return Ok(result);
        }

        /// <summary>جزئیات یک پست وبلاگ به همراه کامنت‌ها</summary>
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetPost(int id)
        {
            var post = await _blogService.GetBlogPostByIdAsync(id);
            if (post == null || !post.Published)
                return NotFoundResult("پست وبلاگ یافت نشد.");

            var listItem = await MapListItemAsync(post);
            var comments = await _blogService.GetBlogCommentsByBlogPostIdAsync(post.Id);

            var commentDtos = new List<BlogCommentDto>();
            foreach (var comment in comments)
            {
                var customer = await _customerService.GetCustomerByIdAsync(comment.CustomerId);
                commentDtos.Add(new BlogCommentDto
                {
                    Id = comment.Id,
                    CustomerName = customer != null ? await _customerService.GetCustomerFullNameAsync(customer) : "کاربر",
                    CommentText = comment.CommentText,
                    CreatedOnUtc = comment.CreatedOnUtc
                });
            }

            return Ok(new BlogPostDto
            {
                Id = listItem.Id,
                Title = listItem.Title,
                Body = listItem.Body,
                SeName = listItem.SeName,
                StartDateUtc = listItem.StartDateUtc,
                CreatedOnUtc = listItem.CreatedOnUtc,
                CommentCount = commentDtos.Count,
                Tags = listItem.Tags,
                Comments = commentDtos
            });
        }

        /// <summary>ثبت کامنت جدید روی یک پست وبلاگ (نیاز به احراز هویت)</summary>
        [HttpPost("{id:int}/comments")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> AddComment(int id, [FromBody] AddBlogCommentRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            if (customer == null)
                return Fail("کاربر یافت نشد.", 401);

            var post = await _blogService.GetBlogPostByIdAsync(id);
            if (post == null)
                return NotFoundResult("پست وبلاگ یافت نشد.");

            var store = await _storeContext.GetCurrentStoreAsync();
            var comment = new Nop.Core.Domain.Blogs.BlogComment
            {
                BlogPostId = post.Id,
                CustomerId = customer.Id,
                CommentText = request.CommentText,
                StoreId = store.Id,
                CreatedOnUtc = DateTime.UtcNow
            };

            await _blogService.InsertBlogCommentAsync(comment);

            return Ok<object>(null, "نظر شما با موفقیت ثبت شد.");
        }

        private async Task<BlogPostListItemDto> MapListItemAsync(Nop.Core.Domain.Blogs.BlogPost post)
        {
            var comments = await _blogService.GetBlogCommentsByBlogPostIdAsync(post.Id);
            return new BlogPostListItemDto
            {
                Id = post.Id,
                Title = post.Title,
                Body = post.Body,
                SeName = await _urlRecordService.GetSeNameAsync(post),
                StartDateUtc = post.StartDateUtc,
                CreatedOnUtc = post.CreatedOnUtc,
                CommentCount = comments.Count,
                Tags = string.IsNullOrEmpty(post.Tags)
                    ? new List<string>()
                    : post.Tags.Split(',').Select(t => t.Trim()).Where(t => !string.IsNullOrEmpty(t)).ToList()
            };
        }
    }
}
