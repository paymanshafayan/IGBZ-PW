using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Api.DTOs.Store;
using Nop.Plugin.Misc.MultiTenantStores.Domain;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Media;
using Nop.Services.Stores;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>
    /// Backs the shared customer app's first-run "which store am I?" flow (see
    /// ARCHITECTURE.md section 5 and <see cref="Nop.Plugin.Misc.MultiTenantStores.Domain.AppPhoneStoreLink"/>).
    /// Both endpoints are anonymous on purpose: the app calls them before it has any
    /// storeId/JWT at all, and the normal X-Store-Id header requirement
    /// (<c>ApiStoreGateFilter</c>) does not apply to <c>/api/v1/store/*</c> - see NopStartup.
    /// </summary>
    [AllowAnonymous]
    public class StoreController : BaseNopApiController
    {
        private readonly IAppPhoneStoreLinkService _appPhoneStoreLinkService;
        private readonly ITenantProvisioningService _tenantProvisioningService;
        private readonly IStoreDomainMappingService _storeDomainMappingService;
        private readonly IStoreService _storeService;
        private readonly IPictureService _pictureService;

        public StoreController(
            IAppPhoneStoreLinkService appPhoneStoreLinkService,
            ITenantProvisioningService tenantProvisioningService,
            IStoreDomainMappingService storeDomainMappingService,
            IStoreService storeService,
            IPictureService pictureService)
        {
            _appPhoneStoreLinkService = appPhoneStoreLinkService;
            _tenantProvisioningService = tenantProvisioningService;
            _storeDomainMappingService = storeDomainMappingService;
            _storeService = storeService;
            _pictureService = pictureService;
        }

        /// <summary>
        /// Called once, on the app's very first launch, with the phone number the person just
        /// typed in. Looks it up against the rows created by the storefront "get the app" page
        /// (StoreDownloadController) and returns which store it belongs to, if any.
        /// A suspended/cancelled store's subscription is treated as "not found" - the app
        /// should not silently onboard into a shop that isn't actually live.
        /// </summary>
        [HttpPost("resolve")]
        public async Task<IActionResult> Resolve([FromBody] ResolveStoreRequestDto request)
        {
            var storeId = await _appPhoneStoreLinkService.ResolveStoreIdAsync(request.PhoneNumber);
            if (storeId == null)
                return Ok(new ResolveStoreResultDto { Found = false }, "شماره موبایل با هیچ فروشگاهی مرتبط نیست.");

            var subscription = await _tenantProvisioningService.GetByStoreIdAsync(storeId.Value);
            if (subscription != null && subscription.Status is TenantSubscriptionStatus.Suspended or TenantSubscriptionStatus.Cancelled)
                return Ok(new ResolveStoreResultDto { Found = false }, "این فروشگاه در حال حاضر فعال نیست.");

            return Ok(new ResolveStoreResultDto { Found = true, StoreId = storeId.Value }, "فروشگاه شناسایی شد.");
        }

        /// <summary>
        /// Called right after Resolve succeeds (and cached locally after that) to fetch the
        /// branding the app should apply: store name, logo, and brand color.
        /// </summary>
        [HttpGet("{storeId:int}/config")]
        public async Task<IActionResult> GetConfig(int storeId)
        {
            var store = await _storeService.GetStoreByIdAsync(storeId);
            if (store == null)
                return NotFoundResult("فروشگاهی با این شناسه یافت نشد.");

            var subscription = await _tenantProvisioningService.GetByStoreIdAsync(storeId);

            string logoUrl = null;
            if (subscription?.LogoPictureId is > 0)
            {
                var picture = await _pictureService.GetPictureByIdAsync(subscription.LogoPictureId.Value);
                if (picture != null)
                    (logoUrl, _) = await _pictureService.GetPictureUrlAsync(picture);
            }

            var domains = await _storeDomainMappingService.GetByStoreIdAsync(storeId);
            var primaryDomain = domains.FirstOrDefault(d => d.Enabled && d.IsPrimary) ?? domains.FirstOrDefault(d => d.Enabled);

            return Ok(new StoreConfigDto
            {
                StoreId = store.Id,
                Name = store.Name,
                Domain = primaryDomain?.Domain ?? store.Url,
                LogoUrl = logoUrl,
                BrandColorHex = subscription?.BrandColorHex
            });
        }
    }
}
