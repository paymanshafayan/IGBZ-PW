using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Services.Customers;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>
    /// کنترلر پایه‌ی همه کنترلرهای API. آدرس پایه: /api/v1/[controller-name]
    /// </summary>
    [ApiController]
    [Route("api/v1/[controller]")]
    [Produces("application/json")]
    public abstract class BaseNopApiController : ControllerBase
    {
        protected IWorkContext WorkContext => HttpContext.RequestServices.GetService(typeof(IWorkContext)) as IWorkContext;
        protected ICustomerService CustomerServiceHelper => HttpContext.RequestServices.GetService(typeof(ICustomerService)) as ICustomerService;

        /// <summary>مشتری در حال درخواست را بر اساس claim موجود در توکن JWT برمی‌گرداند</summary>
        protected async Task<Customer> GetCurrentApiCustomerAsync()
        {
            var customerIdClaim = User?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(customerIdClaim) || !int.TryParse(customerIdClaim, out var customerId))
                return null;

            return await CustomerServiceHelper.GetCustomerByIdAsync(customerId);
        }

        protected int GetCurrentApiCustomerId()
        {
            var customerIdClaim = User?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(customerIdClaim, out var customerId) ? customerId : 0;
        }

        protected IActionResult Ok<T>(T data, string message = null) => base.Ok(ApiResponse<T>.Ok(data, message));

        protected IActionResult Fail(string message, int statusCode = 400)
        {
            var result = ApiResponse<object>.Fail(message);
            return StatusCode(statusCode, result);
        }

        protected IActionResult NotFoundResult(string message = "مورد درخواستی یافت نشد.")
            => Fail(message, 404);
    }

    /// <summary>کنترلر پایه برای اندپوینت‌هایی که نیاز به احراز هویت JWT دارند</summary>
    [Authorize(AuthenticationSchemes = "ApiJwtBearer", Policy = "ApiUser")]
    public abstract class AuthorizedApiController : BaseNopApiController
    {
    }
}
