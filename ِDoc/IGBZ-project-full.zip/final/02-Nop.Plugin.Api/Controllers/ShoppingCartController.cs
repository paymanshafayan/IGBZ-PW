using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Api.DTOs.Cart;
using Nop.Services.Catalog;
using Nop.Services.Media;
using Nop.Services.Orders;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>مدیریت سبد خرید و لیست علاقه‌مندی‌های کاربر لاگین‌شده</summary>
    public class ShoppingCartController : AuthorizedApiController
    {
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IProductService _productService;
        private readonly IProductAttributeParser _productAttributeParser;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly IPictureService _pictureService;
        private readonly IStoreContext _storeContext;

        public ShoppingCartController(
            IShoppingCartService shoppingCartService,
            IProductService productService,
            IProductAttributeParser productAttributeParser,
            IPriceCalculationService priceCalculationService,
            IPriceFormatter priceFormatter,
            IOrderTotalCalculationService orderTotalCalculationService,
            IPictureService pictureService,
            IStoreContext storeContext)
        {
            _shoppingCartService = shoppingCartService;
            _productService = productService;
            _productAttributeParser = productAttributeParser;
            _priceCalculationService = priceCalculationService;
            _priceFormatter = priceFormatter;
            _orderTotalCalculationService = orderTotalCalculationService;
            _pictureService = pictureService;
            _storeContext = storeContext;
        }

        /// <summary>دریافت سبد خرید فعلی کاربر</summary>
        [HttpGet("")]
        public async Task<IActionResult> GetCart()
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var cartItems = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);

            return Ok(await MapCartAsync(cartItems));
        }

        /// <summary>افزودن محصول به سبد خرید</summary>
        [HttpPost("items")]
        public async Task<IActionResult> AddItem([FromBody] AddToCartRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var product = await _productService.GetProductByIdAsync(request.ProductId);
            if (product == null)
                return NotFoundResult("محصول یافت نشد.");

            var attributesXml = string.Empty; // در صورت وجود ویژگی‌های محصول، باید با ProductAttributeParser ساخته شود

            var warnings = await _shoppingCartService.AddToCartAsync(
                customer, product, ShoppingCartType.ShoppingCart, store.Id,
                attributesXml, 0M, null, null, request.Quantity);

            if (warnings.Any())
                return Fail(string.Join(" | ", warnings));

            var cartItems = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);
            return Ok(await MapCartAsync(cartItems), "محصول به سبد خرید اضافه شد.");
        }

        /// <summary>ویرایش تعداد یک قلم سبد خرید</summary>
        [HttpPut("items/{itemId:int}")]
        public async Task<IActionResult> UpdateItem(int itemId, [FromBody] UpdateCartItemDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var cartItems = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);
            var item = cartItems.FirstOrDefault(i => i.Id == itemId);
            if (item == null)
                return NotFoundResult("قلم سبد خرید یافت نشد.");

            var warnings = await _shoppingCartService.UpdateShoppingCartItemAsync(
                customer, itemId, item.AttributesXml, item.CustomerEnteredPrice, request.Quantity, true);

            if (warnings.Any())
                return Fail(string.Join(" | ", warnings));

            cartItems = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);
            return Ok(await MapCartAsync(cartItems), "سبد خرید به‌روزرسانی شد.");
        }

        /// <summary>حذف یک قلم از سبد خرید</summary>
        [HttpDelete("items/{itemId:int}")]
        public async Task<IActionResult> RemoveItem(int itemId)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var cartItems = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);
            var item = cartItems.FirstOrDefault(i => i.Id == itemId);
            if (item == null)
                return NotFoundResult("قلم سبد خرید یافت نشد.");

            await _shoppingCartService.DeleteShoppingCartItemAsync(item);

            cartItems = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);
            return Ok(await MapCartAsync(cartItems), "قلم مورد نظر از سبد خرید حذف شد.");
        }

        /// <summary>خالی کردن کامل سبد خرید</summary>
        [HttpDelete("")]
        public async Task<IActionResult> ClearCart()
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var cartItems = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);
            foreach (var item in cartItems)
                await _shoppingCartService.DeleteShoppingCartItemAsync(item);

            return Ok<object>(null, "سبد خرید خالی شد.");
        }

        /// <summary>لیست علاقه‌مندی‌ها (Wishlist)</summary>
        [HttpGet("/api/v1/wishlist")]
        public async Task<IActionResult> GetWishlist()
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var items = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.Wishlist, store.Id);

            var result = new List<WishlistItemDto>();
            foreach (var item in items)
            {
                var product = await _productService.GetProductByIdAsync(item.ProductId);
                var (price, _) = await _priceCalculationService.GetFinalPriceAsync(product, customer);
                result.Add(new WishlistItemDto
                {
                    Id = item.Id,
                    ProductId = product.Id,
                    ProductName = product.Name,
                    Quantity = item.Quantity,
                    UnitPrice = price,
                    IsInStock = await _productService.GetTotalStockQuantityAsync(product) > 0
                });
            }

            return Ok(result);
        }

        /// <summary>افزودن محصول به لیست علاقه‌مندی‌ها</summary>
        [HttpPost("/api/v1/wishlist/items")]
        public async Task<IActionResult> AddToWishlist([FromBody] AddToCartRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var product = await _productService.GetProductByIdAsync(request.ProductId);
            if (product == null)
                return NotFoundResult("محصول یافت نشد.");

            var warnings = await _shoppingCartService.AddToCartAsync(
                customer, product, ShoppingCartType.Wishlist, store.Id, string.Empty, 0M, null, null, request.Quantity);

            if (warnings.Any())
                return Fail(string.Join(" | ", warnings));

            return Ok<object>(null, "محصول به لیست علاقه‌مندی‌ها اضافه شد.");
        }

        private async Task<ShoppingCartDto> MapCartAsync(IList<ShoppingCartItem> cartItems)
        {
            var result = new ShoppingCartDto();
            foreach (var item in cartItems)
            {
                var product = await _productService.GetProductByIdAsync(item.ProductId);
                var (unitPrice, _) = await _priceCalculationService.GetUnitPriceAsync(item, true);
                var (subTotal, _, _) = await _priceCalculationService.GetSubTotalAsync(item, true);

                var picture = (await _productService.GetProductPicturesByProductIdAsync(product.Id)).FirstOrDefault();
                var pictureEntity = picture != null ? await _pictureService.GetPictureByIdAsync(picture.PictureId) : null;
                var (pictureUrl, _) = pictureEntity != null ? await _pictureService.GetPictureUrlAsync(pictureEntity) : (string.Empty, null);

                result.Items.Add(new ShoppingCartItemDto
                {
                    Id = item.Id,
                    ProductId = product.Id,
                    ProductName = product.Name,
                    PictureUrl = pictureUrl,
                    Quantity = item.Quantity,
                    UnitPrice = unitPrice,
                    UnitPriceFormatted = await _priceFormatter.FormatPriceAsync(unitPrice),
                    SubTotal = subTotal,
                    SubTotalFormatted = await _priceFormatter.FormatPriceAsync(subTotal)
                });
            }

            result.TotalItemsCount = result.Items.Sum(i => i.Quantity);
            result.SubTotal = result.Items.Sum(i => i.SubTotal);
            result.SubTotalFormatted = await _priceFormatter.FormatPriceAsync(result.SubTotal);

            var totals = await _orderTotalCalculationService.GetShoppingCartTotalAsync(cartItems);
            if (totals.appliedDiscounts != null)
                result.AppliedDiscountCodes = totals.appliedDiscounts.Select(d => d.CouponCode).Where(c => !string.IsNullOrEmpty(c)).ToList();
            result.Total = totals.shoppingCartTotal;
            if (totals.shoppingCartTotal.HasValue)
                result.TotalFormatted = await _priceFormatter.FormatPriceAsync(totals.shoppingCartTotal.Value);

            return result;
        }
    }
}
