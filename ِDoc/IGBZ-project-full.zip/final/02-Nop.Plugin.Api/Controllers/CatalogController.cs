using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Plugin.Api.DTOs.Catalog;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Media;
using Nop.Services.Seo;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>اندپوینت‌های عمومی کاتالوگ (دسته‌بندی، تولیدکننده، محصول) - بدون نیاز به احراز هویت</summary>
    [AllowAnonymous]
    public class CatalogController : BaseNopApiController
    {
        private readonly ICategoryService _categoryService;
        private readonly IManufacturerService _manufacturerService;
        private readonly IProductService _productService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IPictureService _pictureService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly ISpecificationAttributeService _specificationAttributeService;
        private readonly IProductAttributeService _productAttributeService;
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly ISettingService _settingService;

        public CatalogController(
            ICategoryService categoryService,
            IManufacturerService manufacturerService,
            IProductService productService,
            IPriceCalculationService priceCalculationService,
            IPriceFormatter priceFormatter,
            IPictureService pictureService,
            IUrlRecordService urlRecordService,
            ISpecificationAttributeService specificationAttributeService,
            IProductAttributeService productAttributeService,
            IWorkContext workContext,
            IStoreContext storeContext,
            ISettingService settingService)
        {
            _categoryService = categoryService;
            _manufacturerService = manufacturerService;
            _productService = productService;
            _priceCalculationService = priceCalculationService;
            _priceFormatter = priceFormatter;
            _pictureService = pictureService;
            _urlRecordService = urlRecordService;
            _specificationAttributeService = specificationAttributeService;
            _productAttributeService = productAttributeService;
            _workContext = workContext;
            _storeContext = storeContext;
            _settingService = settingService;
        }

        // ---------------- دسته‌بندی‌ها ----------------

        /// <summary>لیست دسته‌بندی‌ها (درختی از سطح ریشه یا زیرمجموعه یک دسته)</summary>
        [HttpGet("categories")]
        public async Task<IActionResult> GetCategories([FromQuery] int parentCategoryId = 0)
        {
            var store = await _storeContext.GetCurrentStoreAsync();
            var categories = await _categoryService.GetAllCategoriesByParentCategoryIdAsync(parentCategoryId, storeId: store.Id);

            var result = new List<CategoryDto>();
            foreach (var category in categories)
                result.Add(await MapCategoryAsync(category));

            return Ok(result);
        }

        /// <summary>جزئیات یک دسته‌بندی</summary>
        [HttpGet("categories/{id:int}")]
        public async Task<IActionResult> GetCategory(int id)
        {
            var category = await _categoryService.GetCategoryByIdAsync(id);
            if (category == null || category.Deleted)
                return NotFoundResult("دسته‌بندی یافت نشد.");

            return Ok(await MapCategoryAsync(category));
        }

        // ---------------- تولیدکننده‌ها ----------------

        /// <summary>لیست تولیدکننده‌ها/برندها</summary>
        [HttpGet("manufacturers")]
        public async Task<IActionResult> GetManufacturers([FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 50)
        {
            var manufacturers = await _manufacturerService.GetAllManufacturersAsync(pageIndex: pageIndex, pageSize: pageSize);
            var result = new List<ManufacturerDto>();
            foreach (var m in manufacturers)
                result.Add(await MapManufacturerAsync(m));

            return Ok(result);
        }

        /// <summary>جزئیات یک تولیدکننده</summary>
        [HttpGet("manufacturers/{id:int}")]
        public async Task<IActionResult> GetManufacturer(int id)
        {
            var manufacturer = await _manufacturerService.GetManufacturerByIdAsync(id);
            if (manufacturer == null || manufacturer.Deleted)
                return NotFoundResult("تولیدکننده یافت نشد.");

            return Ok(await MapManufacturerAsync(manufacturer));
        }

        // ---------------- محصولات ----------------

        /// <summary>جستجو و فیلتر محصولات با صفحه‌بندی</summary>
        [HttpGet("products")]
        public async Task<IActionResult> SearchProducts([FromQuery] ProductSearchRequestDto request)
        {
            var apiSettings = await _settingService.LoadSettingAsync<Nop.Plugin.Api.Domain.ApiSettings>();
            var pageSize = request.PageSize > 0 ? Math.Min(request.PageSize, apiSettings.MaxPageSize) : apiSettings.DefaultPageSize;
            var store = await _storeContext.GetCurrentStoreAsync();

            var orderBy = ProductSortingEnum.Position;
            switch (request.OrderBy)
            {
                case "NameAsc": orderBy = ProductSortingEnum.NameAsc; break;
                case "NameDesc": orderBy = ProductSortingEnum.NameDesc; break;
                case "PriceAsc": orderBy = ProductSortingEnum.PriceAsc; break;
                case "PriceDesc": orderBy = ProductSortingEnum.PriceDesc; break;
                case "CreatedOnDesc": orderBy = ProductSortingEnum.CreatedOn; break;
            }

            var products = await _productService.SearchProductsAsync(
                pageIndex: request.PageIndex,
                pageSize: pageSize,
                categoryIds: request.CategoryId.HasValue ? new List<int> { request.CategoryId.Value } : null,
                manufacturerIds: request.ManufacturerId.HasValue ? new List<int> { request.ManufacturerId.Value } : null,
                storeId: store.Id,
                keywords: request.Keyword,
                priceMin: request.PriceFrom,
                priceMax: request.PriceTo,
                orderBy: orderBy,
                visibleIndividuallyOnly: true);

            var items = new List<ProductListItemDto>();
            foreach (var product in products)
                items.Add(await MapProductListItemAsync(product));

            var result = new PagedResultDto<ProductListItemDto>
            {
                Items = items,
                PageIndex = products.PageIndex,
                PageSize = products.PageSize,
                TotalCount = products.TotalCount,
                TotalPages = products.TotalPages
            };

            return Ok(result);
        }

        /// <summary>جزئیات کامل یک محصول</summary>
        [HttpGet("products/{id:int}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null || product.Deleted || !product.Published)
                return NotFoundResult("محصول یافت نشد.");

            return Ok(await MapProductDetailsAsync(product));
        }

        /// <summary>لیست نظرات یک محصول</summary>
        [HttpGet("products/{id:int}/reviews")]
        public async Task<IActionResult> GetProductReviews(int id, [FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 20)
        {
            var reviews = await _productService.GetAllProductReviewsAsync(
                approved: true, productId: id, pageIndex: pageIndex, pageSize: pageSize);

            var result = new List<ProductReviewDto>();
            foreach (var review in reviews)
            {
                result.Add(new ProductReviewDto
                {
                    Id = review.Id,
                    CustomerName = "کاربر",
                    Title = review.Title,
                    ReviewText = review.ReviewText,
                    Rating = review.Rating,
                    CreatedOnUtc = review.CreatedOnUtc
                });
            }

            return Ok(result);
        }

        /// <summary>ثبت نظر برای یک محصول (نیاز به احراز هویت)</summary>
        [HttpPost("products/{id:int}/reviews")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> AddProductReview(int id, [FromBody] AddProductReviewRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            if (customer == null)
                return Fail("کاربر یافت نشد.", 401);

            var product = await _productService.GetProductByIdAsync(id);
            if (product == null)
                return NotFoundResult("محصول یافت نشد.");

            var store = await _storeContext.GetCurrentStoreAsync();
            var review = new ProductReview
            {
                ProductId = product.Id,
                CustomerId = customer.Id,
                Title = request.Title,
                ReviewText = request.ReviewText,
                Rating = Math.Clamp(request.Rating, 1, 5),
                IsApproved = false, // بر اساس تنظیمات فروشگاه می‌تواند نیاز به تأیید ادمین داشته باشد
                StoreId = store.Id,
                CreatedOnUtc = DateTime.UtcNow
            };

            await _productService.InsertProductReviewAsync(review);

            return Ok<object>(null, "نظر شما ثبت شد و پس از تأیید نمایش داده می‌شود.");
        }

        // ---------------- متدهای کمکی نگاشت ----------------

        private async Task<CategoryDto> MapCategoryAsync(Category category)
        {
            var picture = await _pictureService.GetPictureByIdAsync(category.PictureId);
            var (pictureUrl, _) = picture != null ? await _pictureService.GetPictureUrlAsync(picture) : (string.Empty, null);

            return new CategoryDto
            {
                Id = category.Id,
                Name = category.Name,
                Description = category.Description,
                PictureUrl = pictureUrl,
                ParentCategoryId = category.ParentCategoryId == 0 ? null : category.ParentCategoryId,
                SeName = await _urlRecordService.GetSeNameAsync(category),
                DisplayOrder = category.DisplayOrder,
                ProductCount = 0
            };
        }

        private async Task<ManufacturerDto> MapManufacturerAsync(Manufacturer manufacturer)
        {
            var picture = await _pictureService.GetPictureByIdAsync(manufacturer.PictureId);
            var (pictureUrl, _) = picture != null ? await _pictureService.GetPictureUrlAsync(picture) : (string.Empty, null);

            return new ManufacturerDto
            {
                Id = manufacturer.Id,
                Name = manufacturer.Name,
                Description = manufacturer.Description,
                PictureUrl = pictureUrl,
                SeName = await _urlRecordService.GetSeNameAsync(manufacturer)
            };
        }

        private async Task<ProductListItemDto> MapProductListItemAsync(Product product)
        {
            var customer = await _workContext.GetCurrentCustomerAsync();
            var (price, _) = await _priceCalculationService.GetFinalPriceAsync(product, customer);
            var picture = (await _productService.GetProductPicturesByProductIdAsync(product.Id)).FirstOrDefault();
            var pictureEntity = picture != null ? await _pictureService.GetPictureByIdAsync(picture.PictureId) : null;
            var (pictureUrl, _) = pictureEntity != null ? await _pictureService.GetPictureUrlAsync(pictureEntity) : (string.Empty, null);

            return new ProductListItemDto
            {
                Id = product.Id,
                Name = product.Name,
                ShortDescription = product.ShortDescription,
                SeName = await _urlRecordService.GetSeNameAsync(product),
                PictureUrl = pictureUrl,
                Price = price,
                PriceFormatted = await _priceFormatter.FormatPriceAsync(price),
                IsInStock = await _productService.GetTotalStockQuantityAsync(product) > 0 || product.ManageInventoryMethod == ManageInventoryMethod.DontManageStock,
                RatingAverage = product.ApprovedRatingSum > 0 && product.ApprovedTotalReviews > 0
                    ? (double)product.ApprovedRatingSum / product.ApprovedTotalReviews : null,
                TotalReviews = product.ApprovedTotalReviews
            };
        }

        private async Task<ProductDto> MapProductDetailsAsync(Product product)
        {
            var listItem = await MapProductListItemAsync(product);
            var pictures = await _productService.GetProductPicturesByProductIdAsync(product.Id);

            var pictureUrls = new List<string>();
            foreach (var pp in pictures)
            {
                var pic = await _pictureService.GetPictureByIdAsync(pp.PictureId);
                if (pic == null) continue;
                var (url, _) = await _pictureService.GetPictureUrlAsync(pic);
                pictureUrls.Add(url);
            }

            var categoryMappings = await _categoryService.GetProductCategoriesByProductIdAsync(product.Id);
            var categories = new List<CategoryDto>();
            foreach (var mapping in categoryMappings)
            {
                var cat = await _categoryService.GetCategoryByIdAsync(mapping.CategoryId);
                if (cat != null) categories.Add(await MapCategoryAsync(cat));
            }

            ManufacturerDto manufacturerDto = null;
            var manufacturerMappings = await _manufacturerService.GetProductManufacturersByProductIdAsync(product.Id);
            var firstManufacturer = manufacturerMappings.FirstOrDefault();
            if (firstManufacturer != null)
            {
                var manufacturer = await _manufacturerService.GetManufacturerByIdAsync(firstManufacturer.ManufacturerId);
                if (manufacturer != null) manufacturerDto = await MapManufacturerAsync(manufacturer);
            }

            var specAttributes = await _specificationAttributeService.GetProductSpecificationAttributesAsync(product.Id, showOnProductPage: true);
            var specs = new List<ProductSpecificationDto>();
            foreach (var spec in specAttributes)
            {
                specs.Add(new ProductSpecificationDto
                {
                    GroupName = string.Empty,
                    AttributeName = string.Empty,
                    ValueText = await _specificationAttributeService.GetSpecificationAttributeOptionNameAsync(spec)
                });
            }

            return new ProductDto
            {
                Id = listItem.Id,
                Name = listItem.Name,
                ShortDescription = listItem.ShortDescription,
                SeName = listItem.SeName,
                PictureUrl = listItem.PictureUrl,
                Price = listItem.Price,
                PriceFormatted = listItem.PriceFormatted,
                IsInStock = listItem.IsInStock,
                RatingAverage = listItem.RatingAverage,
                TotalReviews = listItem.TotalReviews,
                FullDescription = product.FullDescription,
                Sku = product.Sku,
                PictureUrls = pictureUrls,
                Categories = categories,
                Manufacturer = manufacturerDto,
                Specifications = specs,
                CallForPrice = product.CallForPrice,
                StockQuantity = await _productService.GetTotalStockQuantityAsync(product),
                IsDownload = product.IsDownload
            };
        }
    }
}
