using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Plugin.Api.DTOs.Order;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Media;
using Nop.Services.Orders;
using Nop.Services.Shipping;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>مدیریت سفارش‌های کاربر لاگین‌شده</summary>
    public class OrderController : AuthorizedApiController
    {
        private readonly IOrderService _orderService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IProductService _productService;
        private readonly IPictureService _pictureService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IAddressService _addressService;
        private readonly IShipmentService _shipmentService;
        private readonly IReturnRequestService _returnRequestService;
        private readonly Nop.Core.IStoreContext _storeContext;
        private readonly Nop.Services.Localization.ILocalizationService _localizationService;

        public OrderController(
            IOrderService orderService,
            IOrderProcessingService orderProcessingService,
            IProductService productService,
            IPictureService pictureService,
            IPriceFormatter priceFormatter,
            IAddressService addressService,
            IShipmentService shipmentService,
            IReturnRequestService returnRequestService,
            IStoreContext storeContext,
            Nop.Services.Localization.ILocalizationService localizationService)
        {
            _orderService = orderService;
            _orderProcessingService = orderProcessingService;
            _productService = productService;
            _pictureService = pictureService;
            _priceFormatter = priceFormatter;
            _addressService = addressService;
            _shipmentService = shipmentService;
            _returnRequestService = returnRequestService;
            _storeContext = storeContext;
            _localizationService = localizationService;
        }

        /// <summary>لیست سفارش‌های کاربر جاری (صفحه‌بندی‌شده)</summary>
        [HttpGet("")]
        public async Task<IActionResult> GetOrders([FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 20)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();

            var orders = await _orderService.SearchOrdersAsync(
                storeId: store.Id, customerId: customer.Id,
                pageIndex: pageIndex, pageSize: pageSize);

            var items = new List<OrderListItemDto>();
            foreach (var order in orders)
                items.Add(await MapOrderListItemAsync(order));

            var result = new PagedResultDto<OrderListItemDto>
            {
                Items = items,
                PageIndex = orders.PageIndex,
                PageSize = orders.PageSize,
                TotalCount = orders.TotalCount,
                TotalPages = orders.TotalPages
            };

            return Ok(result);
        }

        /// <summary>جزئیات کامل یک سفارش (فقط برای مالک سفارش)</summary>
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetOrder(int id)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null || order.CustomerId != customer.Id)
                return NotFoundResult("سفارش یافت نشد.");

            return Ok(await MapOrderDetailsAsync(order));
        }

        /// <summary>لغو سفارش (در صورتی که هنوز پردازش/ارسال نشده باشد)</summary>
        [HttpPost("{id:int}/cancel")]
        public async Task<IActionResult> CancelOrder(int id)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null || order.CustomerId != customer.Id)
                return NotFoundResult("سفارش یافت نشد.");

            if (order.OrderStatus == OrderStatus.Cancelled)
                return Fail("این سفارش قبلاً لغو شده است.");

            if (order.ShippingStatusId != (int)ShippingStatus.NotYetShipped && order.ShippingStatusId != (int)ShippingStatus.ShippingNotRequired)
                return Fail("امکان لغو سفارشی که ارسال شده وجود ندارد. لطفاً درخواست مرجوعی ثبت کنید.");

            await _orderProcessingService.CancelOrderAsync(order, true);

            return Ok<object>(null, "سفارش با موفقیت لغو شد.");
        }

        /// <summary>ثبت درخواست مرجوعی برای یک یا چند قلم سفارش</summary>
        [HttpPost("{id:int}/return-request")]
        public async Task<IActionResult> CreateReturnRequest(int id, [FromBody] CreateReturnRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null || order.CustomerId != customer.Id)
                return NotFoundResult("سفارش یافت نشد.");

            if (request.Items == null || !request.Items.Any())
                return Fail("حداقل یک قلم برای مرجوعی باید مشخص شود.");

            var createdRequests = new List<ReturnRequestDto>();
            foreach (var item in request.Items)
            {
                var orderItem = await _orderService.GetOrderItemByIdAsync(item.OrderItemId);
                if (orderItem == null || orderItem.OrderId != order.Id)
                    continue;

                var returnRequest = new Nop.Core.Domain.Orders.ReturnRequest
                {
                    CustomerId = customer.Id,
                    OrderItemId = orderItem.Id,
                    Quantity = item.Quantity,
                    ReasonForReturn = item.ReasonForReturn,
                    RequestedAction = item.RequestedAction,
                    CustomerComments = request.CustomerComments,
                    StaffNotes = string.Empty,
                    ReturnRequestStatus = ReturnRequestStatus.Pending,
                    CreatedOnUtc = DateTime.UtcNow,
                    UpdatedOnUtc = DateTime.UtcNow
                };

                await _returnRequestService.InsertReturnRequestAsync(returnRequest);

                createdRequests.Add(new ReturnRequestDto
                {
                    Id = returnRequest.Id,
                    OrderId = order.Id,
                    ReturnStatus = returnRequest.ReturnRequestStatus.ToString(),
                    CreatedOnUtc = returnRequest.CreatedOnUtc
                });
            }

            if (!createdRequests.Any())
                return Fail("هیچ‌کدام از اقلام ارسالی معتبر نبودند.");

            return Ok(createdRequests, "درخواست مرجوعی با موفقیت ثبت شد و در انتظار بررسی است.");
        }

        // ---------------- متدهای کمکی نگاشت ----------------

        private async Task<OrderListItemDto> MapOrderListItemAsync(Order order)
        {
            var items = await _orderService.GetOrderItemsAsync(order.Id);
            return new OrderListItemDto
            {
                Id = order.Id,
                CustomOrderNumber = order.CustomOrderNumber,
                CreatedOnUtc = order.CreatedOnUtc,
                OrderTotal = order.OrderTotal,
                OrderTotalFormatted = await _priceFormatter.FormatPriceAsync(order.OrderTotal),
                OrderStatus = order.OrderStatus.ToString(),
                PaymentStatus = order.PaymentStatus.ToString(),
                ShippingStatus = order.ShippingStatus.ToString(),
                TotalItems = items.Sum(i => i.Quantity)
            };
        }

        private async Task<OrderDto> MapOrderDetailsAsync(Order order)
        {
            var listItem = await MapOrderListItemAsync(order);
            var orderItems = await _orderService.GetOrderItemsAsync(order.Id);

            var itemDtos = new List<OrderItemDto>();
            foreach (var item in orderItems)
            {
                var product = await _productService.GetProductByIdAsync(item.ProductId);
                var picture = (await _productService.GetProductPicturesByProductIdAsync(item.ProductId)).FirstOrDefault();
                var pictureEntity = picture != null ? await _pictureService.GetPictureByIdAsync(picture.PictureId) : null;
                var (pictureUrl, _) = pictureEntity != null ? await _pictureService.GetPictureUrlAsync(pictureEntity) : (string.Empty, null);

                itemDtos.Add(new OrderItemDto
                {
                    Id = item.Id,
                    ProductId = item.ProductId,
                    ProductName = product?.Name,
                    PictureUrl = pictureUrl,
                    Quantity = item.Quantity,
                    UnitPrice = item.UnitPriceInclTax,
                    UnitPriceFormatted = await _priceFormatter.FormatPriceAsync(item.UnitPriceInclTax),
                    SubTotal = item.PriceInclTax,
                    SubTotalFormatted = await _priceFormatter.FormatPriceAsync(item.PriceInclTax)
                });
            }

            var billingAddress = order.BillingAddressId > 0 ? await _addressService.GetAddressByIdAsync(order.BillingAddressId) : null;
            var shippingAddress = order.ShippingAddressId.HasValue ? await _addressService.GetAddressByIdAsync(order.ShippingAddressId.Value) : null;
            var notes = await _orderService.GetOrderNotesByOrderIdAsync(order.Id, displayToCustomer: true);

            return new OrderDto
            {
                Id = listItem.Id,
                CustomOrderNumber = listItem.CustomOrderNumber,
                CreatedOnUtc = listItem.CreatedOnUtc,
                OrderTotal = listItem.OrderTotal,
                OrderTotalFormatted = listItem.OrderTotalFormatted,
                OrderStatus = listItem.OrderStatus,
                PaymentStatus = listItem.PaymentStatus,
                ShippingStatus = listItem.ShippingStatus,
                TotalItems = listItem.TotalItems,
                BillingAddress = FormatAddress(billingAddress),
                ShippingAddress = FormatAddress(shippingAddress),
                ShippingMethod = order.ShippingMethod,
                PaymentMethod = order.PaymentMethodSystemName,
                SubTotal = order.OrderSubtotalInclTax,
                ShippingTotal = order.OrderShippingInclTax,
                TaxTotal = order.OrderTax,
                DiscountAmount = order.OrderDiscount,
                CustomerComment = order.CustomerOrderComment,
                Items = itemDtos,
                CanCancel = order.OrderStatus != OrderStatus.Cancelled &&
                    (order.ShippingStatusId == (int)ShippingStatus.NotYetShipped || order.ShippingStatusId == (int)ShippingStatus.ShippingNotRequired),
                CanReturnItems = order.OrderStatus == OrderStatus.Complete,
                CanRePay = order.PaymentStatus == Nop.Core.Domain.Payments.PaymentStatus.Pending,
                Notes = notes.Select(n => new OrderNoteDto { Note = n.Note, CreatedOnUtc = n.CreatedOnUtc }).ToList()
            };
        }

        private static string FormatAddress(Nop.Core.Domain.Common.Address address)
        {
            if (address == null) return null;
            return $"{address.FirstName} {address.LastName}, {address.City}, {address.Address1}, {address.ZipPostalCode}";
        }
    }
}
