using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Forums;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Plugin.Api.DTOs.Forum;
using Nop.Services.Customers;
using Nop.Services.Forums;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>فروم گفتگوی فروشگاه: گروه‌ها، فروم‌ها، تاپیک‌ها و پاسخ‌ها</summary>
    [AllowAnonymous]
    public class ForumController : BaseNopApiController
    {
        private readonly IForumService _forumService;
        private readonly ICustomerService _customerService;
        private readonly IStoreContext _storeContext;

        public ForumController(IForumService forumService, ICustomerService customerService, IStoreContext storeContext)
        {
            _forumService = forumService;
            _customerService = customerService;
            _storeContext = storeContext;
        }

        /// <summary>لیست گروه‌های فروم به همراه فروم‌های هر گروه</summary>
        [HttpGet("groups")]
        public async Task<IActionResult> GetForumGroups()
        {
            var store = await _storeContext.GetCurrentStoreAsync();
            var groups = await _forumService.GetAllForumGroupsAsync(store.Id);

            var result = new List<ForumGroupDto>();
            foreach (var group in groups)
            {
                var forums = await _forumService.GetForumsByGroupIdAsync(group.Id);
                result.Add(new ForumGroupDto
                {
                    Id = group.Id,
                    Name = group.Name,
                    Forums = forums.Select(MapForum).ToList()
                });
            }

            return Ok(result);
        }

        /// <summary>جزئیات یک فروم</summary>
        [HttpGet("forums/{id:int}")]
        public async Task<IActionResult> GetForum(int id)
        {
            var forum = await _forumService.GetForumByIdAsync(id);
            if (forum == null)
                return NotFoundResult("فروم یافت نشد.");

            return Ok(MapForum(forum));
        }

        /// <summary>لیست تاپیک‌های یک فروم با صفحه‌بندی</summary>
        [HttpGet("forums/{id:int}/topics")]
        public async Task<IActionResult> GetTopics(int id, [FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 20)
        {
            var topics = await _forumService.GetAllTopicsAsync(forumId: id, pageIndex: pageIndex, pageSize: pageSize);

            var items = new List<ForumTopicListItemDto>();
            foreach (var topic in topics)
                items.Add(await MapTopicListItemAsync(topic));

            var result = new PagedResultDto<ForumTopicListItemDto>
            {
                Items = items,
                PageIndex = topics.PageIndex,
                PageSize = topics.PageSize,
                TotalCount = topics.TotalCount,
                TotalPages = topics.TotalPages
            };

            return Ok(result);
        }

        /// <summary>جزئیات یک تاپیک به همراه پست‌ها (با صفحه‌بندی)</summary>
        [HttpGet("topics/{id:int}")]
        public async Task<IActionResult> GetTopic(int id, [FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 20)
        {
            var topic = await _forumService.GetTopicByIdAsync(id);
            if (topic == null)
                return NotFoundResult("تاپیک یافت نشد.");

            topic.Views += 1;
            await _forumService.UpdateForumTopicAsync(topic);

            var listItem = await MapTopicListItemAsync(topic);
            var posts = await _forumService.GetAllPostsAsync(forumTopicId: id, pageIndex: pageIndex, pageSize: pageSize, ascSort: true);

            var postDtos = new List<ForumPostDto>();
            foreach (var post in posts)
            {
                var customer = await _customerService.GetCustomerByIdAsync(post.CustomerId);
                postDtos.Add(new ForumPostDto
                {
                    Id = post.Id,
                    CustomerName = customer != null ? await _customerService.GetCustomerFullNameAsync(customer) : "کاربر",
                    Text = post.Text,
                    CreatedOnUtc = post.CreatedOnUtc
                });
            }

            return Ok(new ForumTopicDto
            {
                Id = listItem.Id,
                Subject = listItem.Subject,
                CustomerName = listItem.CustomerName,
                NumReplies = listItem.NumReplies,
                Views = listItem.Views,
                CreatedOnUtc = listItem.CreatedOnUtc,
                IsLocked = listItem.IsLocked,
                IsPinned = listItem.IsPinned,
                Posts = postDtos
            });
        }

        /// <summary>ایجاد تاپیک جدید در یک فروم (نیاز به احراز هویت)</summary>
        [HttpPost("topics")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> CreateTopic([FromBody] CreateForumTopicRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            if (customer == null)
                return Fail("کاربر یافت نشد.", 401);

            var forum = await _forumService.GetForumByIdAsync(request.ForumId);
            if (forum == null)
                return NotFoundResult("فروم یافت نشد.");

            var topicType = Enum.TryParse<ForumTopicType>(request.TopicType, true, out var parsedType)
                ? parsedType : ForumTopicType.Normal;

            var topic = new ForumTopic
            {
                ForumId = forum.Id,
                CustomerId = customer.Id,
                TopicTypeId = (int)topicType,
                Subject = request.Subject,
                Views = 0,
                NumPosts = 1,
                CreatedOnUtc = DateTime.UtcNow,
                UpdatedOnUtc = DateTime.UtcNow
            };

            await _forumService.InsertTopicAsync(topic, sendNotifications: true);

            var firstPost = new ForumPost
            {
                TopicId = topic.Id,
                CustomerId = customer.Id,
                Text = request.Text,
                CreatedOnUtc = DateTime.UtcNow,
                UpdatedOnUtc = DateTime.UtcNow
            };
            await _forumService.InsertPostAsync(firstPost, sendNotifications: false);

            return Ok(await MapTopicListItemAsync(topic), "تاپیک با موفقیت ایجاد شد.");
        }

        /// <summary>ارسال پاسخ جدید در یک تاپیک (نیاز به احراز هویت)</summary>
        [HttpPost("topics/{id:int}/posts")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> CreatePost(int id, [FromBody] CreateForumPostRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            if (customer == null)
                return Fail("کاربر یافت نشد.", 401);

            var topic = await _forumService.GetTopicByIdAsync(id);
            if (topic == null)
                return NotFoundResult("تاپیک یافت نشد.");

            if (topic.TopicTypeId == (int)ForumTopicType.Normal && topic.Locked)
                return Fail("این تاپیک بسته شده و امکان ارسال پاسخ جدید وجود ندارد.");

            var post = new ForumPost
            {
                TopicId = topic.Id,
                CustomerId = customer.Id,
                Text = request.Text,
                CreatedOnUtc = DateTime.UtcNow,
                UpdatedOnUtc = DateTime.UtcNow
            };

            await _forumService.InsertPostAsync(post, sendNotifications: true);

            return Ok<object>(null, "پاسخ شما با موفقیت ثبت شد.");
        }

        // ---------------- کمکی ----------------

        private static ForumDto MapForum(Nop.Core.Domain.Forums.Forum forum) => new ForumDto
        {
            Id = forum.Id,
            Name = forum.Name,
            Description = forum.Description,
            NumTopics = forum.NumTopics,
            NumPosts = forum.NumPosts,
            LastPostTime = forum.LastPostTime
        };

        private async Task<ForumTopicListItemDto> MapTopicListItemAsync(ForumTopic topic)
        {
            var customer = await _customerService.GetCustomerByIdAsync(topic.CustomerId);
            return new ForumTopicListItemDto
            {
                Id = topic.Id,
                Subject = topic.Subject,
                CustomerName = customer != null ? await _customerService.GetCustomerFullNameAsync(customer) : "کاربر",
                NumReplies = topic.NumPosts > 0 ? topic.NumPosts - 1 : 0,
                Views = topic.Views,
                CreatedOnUtc = topic.CreatedOnUtc,
                IsLocked = topic.Locked,
                IsPinned = topic.TopicTypeId == (int)ForumTopicType.Sticky || topic.TopicTypeId == (int)ForumTopicType.Announcement
            };
        }
    }
}
