using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Api.DTOs.Cms;
using Nop.Services.Seo;
using Nop.Services.Topics;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>صفحات ثابت (Topics) مثل "درباره ما"، "قوانین و مقررات" و ...</summary>
    [AllowAnonymous]
    public class CmsController : BaseNopApiController
    {
        private readonly ITopicService _topicService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly IStoreContext _storeContext;

        public CmsController(ITopicService topicService, IUrlRecordService urlRecordService, IStoreContext storeContext)
        {
            _topicService = topicService;
            _urlRecordService = urlRecordService;
            _storeContext = storeContext;
        }

        /// <summary>لیست صفحات ثابتی که در منو/فوتر قابل نمایش هستند</summary>
        [HttpGet("topics")]
        public async Task<IActionResult> GetTopics()
        {
            var store = await _storeContext.GetCurrentStoreAsync();
            var topics = await _topicService.GetAllTopicsAsync(store.Id, onlyIncludedInTopMenu: false);

            var result = new List<TopicDto>();
            foreach (var topic in topics.Where(t => t.Published))
                result.Add(await MapTopicAsync(topic));

            return Ok(result);
        }

        /// <summary>جزئیات یک صفحه ثابت بر اساس نام سیستمی (مثل "AboutUs")</summary>
        [HttpGet("topics/{systemName}")]
        public async Task<IActionResult> GetTopicBySystemName(string systemName)
        {
            var store = await _storeContext.GetCurrentStoreAsync();
            var topic = await _topicService.GetTopicBySystemNameAsync(systemName, store.Id);
            if (topic == null || !topic.Published)
                return NotFoundResult("صفحه یافت نشد.");

            return Ok(await MapTopicAsync(topic));
        }

        private async Task<TopicDto> MapTopicAsync(Nop.Core.Domain.Topics.Topic topic)
        {
            return new TopicDto
            {
                Id = topic.Id,
                SystemName = topic.SystemName,
                Title = topic.Title,
                Body = topic.Body,
                SeName = await _urlRecordService.GetSeNameAsync(topic),
                MetaTitle = topic.MetaTitle,
                MetaDescription = topic.MetaDescription,
                MetaKeywords = topic.MetaKeywords
            };
        }
    }
}
