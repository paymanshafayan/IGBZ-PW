using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core.Domain.Payments;
using Nop.Plugin.Api.Domain;
using Nop.Plugin.Api.DTOs.Payment;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Orders;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>
    /// اندپوینت‌های پرداخت: پیگیری وضعیت پرداخت توسط کاربر (JWT) و دریافت Webhook از درگاه پرداخت (سرور-به-سرور).
    /// یکپارچه‌سازی واقعی درگاه (مثل زرین‌پال/IDPay) معمولاً به‌صورت یک پلاگین جدای Payment در nopCommerce نوشته می‌شود؛
    /// اندپوینت webhook این کنترلر نقطه‌ی اتصال آن پلاگین (یا سرویس بیرونی) به این Web API است.
    /// </summary>
    public class PaymentController : BaseNopApiController
    {
        private readonly IOrderService _orderService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly ISettingService _settingService;

        public PaymentController(
            IOrderService orderService,
            IOrderProcessingService orderProcessingService,
            IPriceFormatter priceFormatter,
            ISettingService settingService)
        {
            _orderService = orderService;
            _orderProcessingService = orderProcessingService;
            _priceFormatter = priceFormatter;
            _settingService = settingService;
        }

        /// <summary>وضعیت پرداخت یک سفارش متعلق به کاربر جاری</summary>
        [HttpGet("order/{orderId:int}/status")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> GetPaymentStatus(int orderId)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var order = await _orderService.GetOrderByIdAsync(orderId);
            if (order == null || order.CustomerId != customer.Id)
                return NotFoundResult("سفارش یافت نشد.");

            return Ok(new PaymentStatusDto
            {
                OrderId = order.Id,
                CustomOrderNumber = order.CustomOrderNumber,
                OrderStatus = order.OrderStatus.ToString(),
                PaymentStatus = order.PaymentStatus.ToString(),
                IsPaid = order.PaymentStatus == PaymentStatus.Paid || order.PaymentStatus == PaymentStatus.Authorized,
                OrderTotal = order.OrderTotal,
                OrderTotalFormatted = await _priceFormatter.FormatPriceAsync(order.OrderTotal),
                PaymentMethod = order.PaymentMethodSystemName
            });
        }

        /// <summary>
        /// Webhook درگاه پرداخت. باید هدر <c>X-Webhook-Secret</c> برابر مقدار تنظیم‌شده در پنل ادمین
        /// (Configuration > Local Plugins > Web API > Payment Webhook Secret) باشد.
        /// این اندپوینت با JWT کاربر محافظت نمی‌شود چون فراخوان آن سرور درگاه پرداخت است، نه اپ کاربر.
        /// </summary>
        [HttpPost("webhook")]
        [AllowAnonymous]
        public async Task<IActionResult> Webhook([FromBody] PaymentWebhookRequestDto request, [FromHeader(Name = "X-Webhook-Secret")] string webhookSecret)
        {
            var apiSettings = await _settingService.LoadSettingAsync<ApiSettings>();
            if (string.IsNullOrEmpty(webhookSecret) || webhookSecret != apiSettings.PaymentWebhookSecretKey)
                return Fail("دسترسی غیرمجاز به Webhook.", 401);

            var order = await _orderService.GetOrderByGuidAsync(request.OrderGuid);
            if (order == null)
                return NotFoundResult("سفارشی با این شناسه یافت نشد.");

            if (request.IsSuccess)
            {
                if (!string.IsNullOrEmpty(request.GatewayTransactionId))
                    order.CaptureTransactionId = request.GatewayTransactionId;

                await _orderService.UpdateOrderAsync(order);

                if (_orderProcessingService.CanMarkOrderAsPaid(order))
                    await _orderProcessingService.MarkOrderAsPaidAsync(order);

                await _orderService.InsertOrderNoteAsync(new Nop.Core.Domain.Orders.OrderNote
                {
                    OrderId = order.Id,
                    Note = $"پرداخت با موفقیت از طریق درگاه تأیید شد. کد پیگیری: {request.GatewayReferenceId}",
                    DisplayToCustomer = true,
                    CreatedOnUtc = DateTime.UtcNow
                });
            }
            else
            {
                await _orderService.InsertOrderNoteAsync(new Nop.Core.Domain.Orders.OrderNote
                {
                    OrderId = order.Id,
                    Note = $"پرداخت ناموفق بود. دلیل: {request.FailureReason}",
                    DisplayToCustomer = true,
                    CreatedOnUtc = DateTime.UtcNow
                });
            }

            return Ok<object>(null, "Webhook با موفقیت پردازش شد.");
        }

        /// <summary>
        /// تأیید سمت کلاینت پس از بازگشت از درگاه (برای زمانی که هنوز webhook سمت سرور نرسیده است).
        /// این اندپوینت فقط وضعیت را از سفارش می‌خواند و آن را تغییر نمی‌دهد؛ منبع حقیقت همیشه Webhook/تایید سرور است.
        /// </summary>
        [HttpPost("order/{orderId:int}/confirm-client")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> ConfirmClientReturn(int orderId, [FromBody] ConfirmClientPaymentRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var order = await _orderService.GetOrderByIdAsync(orderId);
            if (order == null || order.CustomerId != customer.Id)
                return NotFoundResult("سفارش یافت نشد.");

            return Ok(new PaymentStatusDto
            {
                OrderId = order.Id,
                CustomOrderNumber = order.CustomOrderNumber,
                OrderStatus = order.OrderStatus.ToString(),
                PaymentStatus = order.PaymentStatus.ToString(),
                IsPaid = order.PaymentStatus == PaymentStatus.Paid || order.PaymentStatus == PaymentStatus.Authorized,
                OrderTotal = order.OrderTotal,
                OrderTotalFormatted = await _priceFormatter.FormatPriceAsync(order.OrderTotal),
                PaymentMethod = order.PaymentMethodSystemName
            }, order.PaymentStatus == PaymentStatus.Paid
                ? "پرداخت تأیید شده است."
                : "پرداخت هنوز نهایی نشده؛ لطفاً کمی صبر کنید تا تأیید سرور دریافت شود.");
        }
    }
}
