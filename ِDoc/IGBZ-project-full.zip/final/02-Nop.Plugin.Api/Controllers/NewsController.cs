using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Plugin.Api.DTOs.News;
using Nop.Services.Customers;
using Nop.Services.News;
using Nop.Services.Seo;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>اخبار فروشگاه: لیست، جزئیات و کامنت‌گذاری</summary>
    [AllowAnonymous]
    public class NewsController : BaseNopApiController
    {
        private readonly INewsService _newsService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly ICustomerService _customerService;
        private readonly IStoreContext _storeContext;

        public NewsController(INewsService newsService, IUrlRecordService urlRecordService,
            ICustomerService customerService, IStoreContext storeContext)
        {
            _newsService = newsService;
            _urlRecordService = urlRecordService;
            _customerService = customerService;
            _storeContext = storeContext;
        }

        /// <summary>لیست اخبار با صفحه‌بندی</summary>
        [HttpGet("")]
        public async Task<IActionResult> GetNews([FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 10)
        {
            var store = await _storeContext.GetCurrentStoreAsync();
            var news = await _newsService.GetAllNewsAsync(store.Id, pageIndex: pageIndex, pageSize: pageSize);

            var items = new List<NewsItemListDto>();
            foreach (var item in news)
                items.Add(await MapListItemAsync(item));

            var result = new PagedResultDto<NewsItemListDto>
            {
                Items = items,
                PageIndex = news.PageIndex,
                PageSize = news.PageSize,
                TotalCount = news.TotalCount,
                TotalPages = news.TotalPages
            };

            return Ok(result);
        }

        /// <summary>جزئیات یک خبر به همراه کامنت‌ها</summary>
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetNewsItem(int id)
        {
            var item = await _newsService.GetNewsByIdAsync(id);
            if (item == null || !item.Published)
                return NotFoundResult("خبر یافت نشد.");

            var listItem = await MapListItemAsync(item);
            var comments = await _newsService.GetNewsCommentsByNewsItemIdAsync(item.Id);

            var commentDtos = new List<NewsCommentDto>();
            foreach (var comment in comments)
            {
                var customer = await _customerService.GetCustomerByIdAsync(comment.CustomerId);
                commentDtos.Add(new NewsCommentDto
                {
                    Id = comment.Id,
                    CustomerName = customer != null ? await _customerService.GetCustomerFullNameAsync(customer) : "کاربر",
                    Title = comment.CommentTitle,
                    CommentText = comment.CommentText,
                    CreatedOnUtc = comment.CreatedOnUtc
                });
            }

            return Ok(new NewsItemDto
            {
                Id = listItem.Id,
                Title = listItem.Title,
                Short = listItem.Short,
                Full = item.Full,
                SeName = listItem.SeName,
                CreatedOnUtc = listItem.CreatedOnUtc,
                CommentCount = commentDtos.Count,
                Comments = commentDtos
            });
        }

        /// <summary>ثبت کامنت جدید روی یک خبر (نیاز به احراز هویت)</summary>
        [HttpPost("{id:int}/comments")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> AddComment(int id, [FromBody] AddNewsCommentRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            if (customer == null)
                return Fail("کاربر یافت نشد.", 401);

            var item = await _newsService.GetNewsByIdAsync(id);
            if (item == null)
                return NotFoundResult("خبر یافت نشد.");

            var store = await _storeContext.GetCurrentStoreAsync();
            var comment = new Nop.Core.Domain.News.NewsComment
            {
                NewsItemId = item.Id,
                CustomerId = customer.Id,
                CommentTitle = request.Title,
                CommentText = request.CommentText,
                StoreId = store.Id,
                CreatedOnUtc = DateTime.UtcNow
            };

            await _newsService.InsertNewsCommentAsync(comment);

            return Ok<object>(null, "نظر شما با موفقیت ثبت شد.");
        }

        private async Task<NewsItemListDto> MapListItemAsync(Nop.Core.Domain.News.NewsItem item)
        {
            var comments = await _newsService.GetNewsCommentsByNewsItemIdAsync(item.Id);
            return new NewsItemListDto
            {
                Id = item.Id,
                Title = item.Title,
                Short = item.Short,
                SeName = await _urlRecordService.GetSeNameAsync(item),
                CreatedOnUtc = item.CreatedOnUtc,
                CommentCount = comments.Count
            };
        }
    }
}
