using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Api.DTOs.Admin;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Customers;
using Nop.Services.Orders;

namespace Nop.Plugin.Api.Controllers.Admin
{
    /// <summary>مدیریت سفارش‌های فروشگاه از اپلیکیشن ادمین (همهٔ سفارش‌های فروشگاه، نه فقط یک مشتری)</summary>
    public class AdminOrdersController : AuthorizedTenantOwnerApiController
    {
        private readonly IOrderService _orderService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly ICustomerService _customerServiceForOrders;
        private readonly Nop.Services.Catalog.IProductService _productServiceForOrders;

        public AdminOrdersController(
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService,
            IOrderService orderService,
            IOrderProcessingService orderProcessingService,
            Nop.Services.Catalog.IProductService productService)
            : base(storeContext, customerService, tenantProvisioningService)
        {
            _orderService = orderService;
            _orderProcessingService = orderProcessingService;
            _customerServiceForOrders = customerService;
            _productServiceForOrders = productService;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetOrders([FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 50)
        {
            var orders = await _orderService.SearchOrdersAsync(
                storeId: CurrentOwnedStoreId, pageIndex: pageIndex, pageSize: pageSize);

            var items = new System.Collections.Generic.List<AdminOrderListItemDto>();
            foreach (var order in orders)
            {
                var customer = await _customerServiceForOrders.GetCustomerByIdAsync(order.CustomerId);

                items.Add(new AdminOrderListItemDto
                {
                    Id = order.Id,
                    CustomOrderNumber = order.CustomOrderNumber,
                    CreatedOnUtc = order.CreatedOnUtc,
                    OrderTotal = order.OrderTotal,
                    OrderTotalFormatted = order.OrderTotal.ToString("N0"),
                    OrderStatus = ((OrderStatus)order.OrderStatusId).ToString(),
                    PaymentStatus = ((Nop.Core.Domain.Payments.PaymentStatus)order.PaymentStatusId).ToString(),
                    ShippingStatus = ((ShippingStatus)order.ShippingStatusId).ToString(),
                    CustomerId = order.CustomerId,
                    CustomerEmail = customer?.Email,
                    CustomerFullName = customer?.Username
                });
            }

            return Ok(new PagedResultDto<AdminOrderListItemDto>
            {
                Items = items,
                PageIndex = orders.PageIndex,
                PageSize = orders.PageSize,
                TotalCount = orders.TotalCount,
                TotalPages = orders.TotalPages
            });
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetOrderDetail(int id)
        {
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null || order.StoreId != CurrentOwnedStoreId)
                return NotFoundResult("سفارش یافت نشد.");

            var customer = await _customerServiceForOrders.GetCustomerByIdAsync(order.CustomerId);
            var orderItems = await _orderService.GetOrderItemsAsync(order.Id);
            var orderNotes = await _orderService.GetOrderNotesByOrderIdAsync(order.Id);

            var dto = new AdminOrderDetailDto
            {
                Id = order.Id,
                CustomOrderNumber = order.CustomOrderNumber,
                CreatedOnUtc = order.CreatedOnUtc,
                OrderTotal = order.OrderTotal,
                OrderTotalFormatted = order.OrderTotal.ToString("N0"),
                OrderStatus = ((OrderStatus)order.OrderStatusId).ToString(),
                PaymentStatus = ((Nop.Core.Domain.Payments.PaymentStatus)order.PaymentStatusId).ToString(),
                ShippingStatus = ((ShippingStatus)order.ShippingStatusId).ToString(),
                CustomerId = order.CustomerId,
                CustomerEmail = customer?.Email,
                CustomerFullName = customer?.Username,
                ShippingAddressText = order.ShippingAddressId.HasValue
                    ? $"آدرس ثبت‌شده #{order.ShippingAddressId}" // NOTE: برای متن کامل آدرس، IAddressService.GetAddressByIdAsync را صدا بزنید و فرمت کنید
                    : null,
                Items = orderItems.Select(oi => new AdminOrderItemDto
                {
                    ProductId = oi.ProductId,
                    Quantity = oi.Quantity,
                    UnitPrice = oi.UnitPriceInclTax,
                    LineTotal = oi.PriceInclTax
                }).ToList(),
                Notes = orderNotes
                    .Where(n => !n.DisplayToCustomer) // یادداشت‌های داخلی صاحب فروشگاه
                    .OrderByDescending(n => n.CreatedOnUtc)
                    .Select(n => new AdminOrderNoteDto
                    {
                        Note = n.Note,
                        DisplayToCustomer = n.DisplayToCustomer,
                        CreatedOnUtc = n.CreatedOnUtc
                    }).ToList()
            };

            // NOTE: برای نام واقعی محصول در هر ردیف، IProductService.GetProductByIdAsync را برای
            // هر ProductId صدا بزنید (حذف شد تا این اکشن ساده بماند - قبل از استفادهٔ واقعی اضافه کنید)
            foreach (var item in dto.Items)
            {
                var product = await _productServiceForOrders.GetProductByIdAsync(item.ProductId);
                item.ProductName = product?.Name ?? $"#{item.ProductId}";
            }

            return Ok(dto);
        }

        /// <summary>NOTE: verify IOrderProcessingService.SetOrderStatusAsync's exact signature against your nopCommerce 4.90 build.</summary>
        [HttpPut("{id:int}/status")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] AdminOrderStatusUpdateRequestDto request)
        {
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null || order.StoreId != CurrentOwnedStoreId)
                return NotFoundResult("سفارش یافت نشد.");

            if (!Enum.TryParse<OrderStatus>(request.OrderStatus, true, out var newStatus))
                return Fail("وضعیت سفارش نامعتبر است.");

            await _orderProcessingService.SetOrderStatusAsync(order, newStatus, notifyCustomer: true);

            if (!string.IsNullOrWhiteSpace(request.AdminNote))
            {
                await _orderService.InsertOrderNoteAsync(new OrderNote
                {
                    OrderId = order.Id,
                    Note = request.AdminNote,
                    DisplayToCustomer = false,
                    CreatedOnUtc = DateTime.UtcNow
                });
            }

            return Ok<object>(null, "وضعیت سفارش به‌روزرسانی شد.");
        }
    }
}
