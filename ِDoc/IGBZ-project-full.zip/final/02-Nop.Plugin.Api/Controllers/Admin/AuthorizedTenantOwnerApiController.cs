using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Filters;
using Nop.Core;
using Nop.Plugin.Misc.MultiTenantStores;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Customers;

namespace Nop.Plugin.Api.Controllers.Admin
{
    /// <summary>
    /// Base for every endpoint meant for the store-owner ("admin") mobile app (Phase 4).
    ///
    /// A controller implementing IAsyncActionFilter is automatically invoked as a filter for its
    /// own actions by ASP.NET Core MVC - no separate attribute/class needed. This runs in
    /// addition to (not instead of) the global ApiStoreGateFilter/ApiCrossStoreGuardFilter, and
    /// adds the piece those two don't check: that the caller specifically holds the "Tenant
    /// Store Owners" role (a regular customer of the store must never reach these endpoints,
    /// even though ApiCrossStoreGuardFilter would otherwise let them address their own store's
    /// context via HomeStoreId).
    /// </summary>
    public abstract class AuthorizedTenantOwnerApiController : AuthorizedApiController, IAsyncActionFilter
    {
        private readonly IStoreContext _storeContext;
        private readonly ICustomerService _customerService;
        private readonly ITenantProvisioningService _tenantProvisioningService;

        protected AuthorizedTenantOwnerApiController(
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService)
        {
            _storeContext = storeContext;
            _customerService = customerService;
            _tenantProvisioningService = tenantProvisioningService;
        }

        /// <summary>Store id the caller owns - set right before the action runs, safe to use inside it</summary>
        protected int CurrentOwnedStoreId { get; private set; }

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var customer = await GetCurrentApiCustomerAsync();
            if (customer == null)
            {
                context.Result = Fail("کاربر معتبر نیست.", 401);
                return;
            }

            var ownerRole = await _customerService.GetCustomerRoleBySystemNameAsync(MultiTenantStoresDefaults.TenantStoreOwnerRoleSystemName);
            var roleIds = await _customerService.GetCustomerRoleIdsAsync(customer, showHidden: true);
            if (ownerRole == null || !roleIds.Contains(ownerRole.Id))
            {
                context.Result = Fail("شما دسترسی مدیریت فروشگاه ندارید.", 403);
                return;
            }

            var ownedStoreId = await _tenantProvisioningService.GetOwnedStoreIdAsync(customer);
            var currentStore = await _storeContext.GetCurrentStoreAsync();

            if (ownedStoreId == null || ownedStoreId.Value != currentStore.Id)
            {
                context.Result = Fail("این فروشگاه متعلق به شما نیست.", 403);
                return;
            }

            CurrentOwnedStoreId = ownedStoreId.Value;
            await next();
        }
    }
}
