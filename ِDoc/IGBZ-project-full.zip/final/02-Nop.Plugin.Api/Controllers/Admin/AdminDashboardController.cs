using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Api.DTOs.Admin;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Orders;

namespace Nop.Plugin.Api.Controllers.Admin
{
    /// <summary>صفحهٔ اول اپلیکیشن ادمین فروشگاه: خلاصهٔ وضعیت</summary>
    public class AdminDashboardController : AuthorizedTenantOwnerApiController
    {
        private readonly IStoreService _storeService;
        private readonly IProductService _productService;
        private readonly IOrderService _orderService;
        private readonly ITenantProvisioningService _tenantProvisioningService;

        public AdminDashboardController(
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService,
            IStoreService storeService,
            IProductService productService,
            IOrderService orderService)
            : base(storeContext, customerService, tenantProvisioningService)
        {
            _storeService = storeService;
            _productService = productService;
            _orderService = orderService;
            _tenantProvisioningService = tenantProvisioningService;
        }

        /// <summary>
        /// NOTE: parameter names on IOrderService.SearchOrdersAsync / IProductService.SearchProductsAsync
        /// (createdFromUtc, osIds, storeId, pageSize, ...) are based on the widely-stable nopCommerce
        /// signature but should be checked against your exact 4.90 build if this fails to compile.
        /// </summary>
        [HttpGet("")]
        public async Task<IActionResult> Get()
        {
            var store = await _storeService.GetStoreByIdAsync(CurrentOwnedStoreId);
            var subscription = await _tenantProvisioningService.GetByStoreIdAsync(CurrentOwnedStoreId);

            var now = DateTime.UtcNow;
            var startOfToday = now.Date;
            var startOfMonth = new DateTime(now.Year, now.Month, 1);

            var ordersThisMonth = await _orderService.SearchOrdersAsync(
                storeId: CurrentOwnedStoreId, createdFromUtc: startOfMonth, pageSize: int.MaxValue);
            var ordersToday = ordersThisMonth.Where(o => o.CreatedOnUtc >= startOfToday).ToList();

            var pendingOrders = await _orderService.SearchOrdersAsync(
                storeId: CurrentOwnedStoreId, osIds: new System.Collections.Generic.List<int> { (int)Nop.Core.Domain.Orders.OrderStatus.Pending }, pageSize: int.MaxValue);

            var allProducts = await _productService.SearchProductsAsync(storeId: CurrentOwnedStoreId, pageSize: int.MaxValue);

            var revenueThisMonth = ordersThisMonth.Sum(o => o.OrderTotal);

            var dto = new AdminDashboardDto
            {
                StoreName = store?.Name,
                TotalProducts = allProducts.TotalCount,
                OrdersToday = ordersToday.Count,
                OrdersThisMonth = ordersThisMonth.TotalCount,
                RevenueToday = ordersToday.Sum(o => o.OrderTotal),
                RevenueThisMonth = revenueThisMonth,
                RevenueThisMonthFormatted = revenueThisMonth.ToString("N0"),
                PendingOrdersCount = pendingOrders.TotalCount,
                SubscriptionStatus = subscription?.Status.ToString(),
                SubscriptionRenewsOnUtc = subscription?.CurrentPeriodEndUtc
            };

            return Ok(dto);
        }
    }
}
