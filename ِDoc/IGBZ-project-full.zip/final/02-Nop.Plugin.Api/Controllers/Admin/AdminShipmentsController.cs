using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Shipping;
using Nop.Plugin.Api.DTOs.Admin;
using Nop.Plugin.Api.DTOs.Shipping;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Customers;
using Nop.Services.Orders;
using Nop.Services.Shipping;

namespace Nop.Plugin.Api.Controllers.Admin
{
    /// <summary>
    /// مدیریت مرسولات (Shipment) سفارش‌های همین فروشگاه از اپلیکیشن ادمین.
    ///
    /// NOTE: امضای دقیق IShipmentService.InsertShipmentAsync و این‌که آیا ShipmentItems را
    /// خودش هنگام Insert ذخیره می‌کند یا باید جداگانه InsertShipmentItemAsync صدا زد، بین
    /// نسخه‌های nopCommerce کمی فرق داشته - قبل از تکیه کردن با نسخهٔ 4.90 خودتان تطبیق دهید
    /// (کنترلر هستهٔ Areas/Admin/Controllers/ShipmentController.cs خود nopCommerce بهترین مرجع است).
    /// </summary>
    public class AdminShipmentsController : AuthorizedTenantOwnerApiController
    {
        private readonly IOrderService _orderService;
        private readonly IShipmentService _shipmentService;
        private readonly IOrderProcessingService _orderProcessingService;

        public AdminShipmentsController(
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService,
            IOrderService orderService,
            IShipmentService shipmentService,
            IOrderProcessingService orderProcessingService)
            : base(storeContext, customerService, tenantProvisioningService)
        {
            _orderService = orderService;
            _shipmentService = shipmentService;
            _orderProcessingService = orderProcessingService;
        }

        [HttpGet("order/{orderId:int}")]
        public async Task<IActionResult> GetShipmentsForOrder(int orderId)
        {
            var order = await _orderService.GetOrderByIdAsync(orderId);
            if (order == null || order.StoreId != CurrentOwnedStoreId)
                return NotFoundResult("سفارش یافت نشد.");

            var shipments = await _shipmentService.GetShipmentsByOrderIdAsync(orderId);

            var result = new List<ShipmentDto>();
            foreach (var shipment in shipments)
            {
                var shipmentItems = await _shipmentService.GetShipmentItemsByShipmentIdAsync(shipment.Id);
                var items = new List<ShipmentItemDto>();

                foreach (var shipmentItem in shipmentItems)
                {
                    var orderItem = await _orderService.GetOrderItemByIdAsync(shipmentItem.OrderItemId);
                    items.Add(new ShipmentItemDto
                    {
                        ProductId = orderItem?.ProductId ?? 0,
                        Quantity = shipmentItem.Quantity
                    });
                }

                result.Add(new ShipmentDto
                {
                    Id = shipment.Id,
                    TrackingNumber = shipment.TrackingNumber,
                    ShippedOnUtc = shipment.ShippedDateUtc,
                    DeliveredOnUtc = shipment.DeliveryDateUtc,
                    Items = items
                });
            }

            return Ok(result);
        }

        [HttpPost("order/{orderId:int}")]
        public async Task<IActionResult> CreateShipment(int orderId, [FromBody] AdminShipmentCreateRequestDto request)
        {
            var order = await _orderService.GetOrderByIdAsync(orderId);
            if (order == null || order.StoreId != CurrentOwnedStoreId)
                return NotFoundResult("سفارش یافت نشد.");

            var orderItems = await _orderService.GetOrderItemsAsync(orderId);

            var shipment = new Shipment
            {
                OrderId = orderId,
                TrackingNumber = request.TrackingNumber,
                TotalWeight = null,
                CreatedOnUtc = System.DateTime.UtcNow
            };

            await _shipmentService.InsertShipmentAsync(shipment);

            var linesToShip = request.Items != null && request.Items.Count > 0
                ? request.Items
                : orderItems.Select(oi => new AdminShipmentItemRequestDto { OrderItemId = oi.Id, Quantity = oi.Quantity }).ToList();

            foreach (var line in linesToShip)
            {
                var orderItem = orderItems.FirstOrDefault(oi => oi.Id == line.OrderItemId);
                if (orderItem == null)
                    continue;

                await _shipmentService.InsertShipmentItemAsync(new ShipmentItem
                {
                    ShipmentId = shipment.Id,
                    OrderItemId = orderItem.Id,
                    Quantity = line.Quantity > 0 ? line.Quantity : orderItem.Quantity
                });
            }

            await _orderProcessingService.ShipAsync(shipment, notifyCustomer: true);

            return Ok(new { shipment.Id }, "مرسوله با موفقیت ثبت شد.");
        }
    }
}
