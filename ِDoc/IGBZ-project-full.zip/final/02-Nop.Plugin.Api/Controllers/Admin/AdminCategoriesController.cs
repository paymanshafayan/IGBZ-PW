using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Plugin.Api.DTOs.Admin;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Catalog;
using Nop.Services.Customers;
using Nop.Services.Seo;
using Nop.Services.Stores;

namespace Nop.Plugin.Api.Controllers.Admin
{
    /// <summary>
    /// مدیریت دسته‌بندی‌های فروشگاه از اپلیکیشن ادمین. همان الگوی AdminProductsController:
    /// Insert معمولی صدا زده می‌شود و CategoryStoreIsolationConsumer (پلاگین فروشگاه‌ساز) با
    /// شنیدن EntityInsertedEvent&lt;Category&gt; آن را خودکار به فروشگاه جاری محدود می‌کند.
    /// </summary>
    public class AdminCategoriesController : AuthorizedTenantOwnerApiController
    {
        private readonly ICategoryService _categoryService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly IStoreMappingService _storeMappingService;

        public AdminCategoriesController(
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService,
            ICategoryService categoryService,
            IUrlRecordService urlRecordService,
            IStoreMappingService storeMappingService)
            : base(storeContext, customerService, tenantProvisioningService)
        {
            _categoryService = categoryService;
            _urlRecordService = urlRecordService;
            _storeMappingService = storeMappingService;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetCategories([FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 100)
        {
            // NOTE: GetAllCategoriesAsync doesn't take a storeId filter by itself in every
            // nopCommerce version - we fetch then filter by the store mapping this merchant
            // owns, same defense-in-depth approach as AdminProductsController.
            var allCategories = await _categoryService.GetAllCategoriesAsync(showHidden: true, pageIndex: pageIndex, pageSize: pageSize);

            var mine = new System.Collections.Generic.List<AdminCategoryDto>();
            foreach (var category in allCategories)
            {
                if (!await BelongsToMyStoreAsync(category))
                    continue;

                mine.Add(new AdminCategoryDto
                {
                    Id = category.Id,
                    Name = category.Name,
                    Description = category.Description,
                    Published = category.Published,
                    DisplayOrder = category.DisplayOrder,
                    ParentCategoryId = category.ParentCategoryId
                });
            }

            return Ok(new PagedResultDto<AdminCategoryDto>
            {
                Items = mine,
                PageIndex = allCategories.PageIndex,
                PageSize = allCategories.PageSize,
                TotalCount = mine.Count,
                TotalPages = allCategories.TotalPages
            });
        }

        [HttpPost("")]
        public async Task<IActionResult> CreateCategory([FromBody] AdminCategoryUpsertRequestDto request)
        {
            var category = new Category
            {
                Name = request.Name,
                Description = request.Description,
                Published = request.Published,
                DisplayOrder = request.DisplayOrder,
                ParentCategoryId = request.ParentCategoryId,
                CreatedOnUtc = System.DateTime.UtcNow,
                UpdatedOnUtc = System.DateTime.UtcNow
            };

            // triggers EntityInsertedEvent<Category> -> CategoryStoreIsolationConsumer store-limits it
            await _categoryService.InsertCategoryAsync(category);

            await _urlRecordService.SaveSlugAsync(category, await _urlRecordService.ValidateSeNameAsync(category, string.Empty, category.Name, true), 0);

            return Ok(new { category.Id }, "دسته‌بندی با موفقیت ایجاد شد.");
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateCategory(int id, [FromBody] AdminCategoryUpsertRequestDto request)
        {
            var category = await _categoryService.GetCategoryByIdAsync(id);
            if (category == null || !await BelongsToMyStoreAsync(category))
                return NotFoundResult("دسته‌بندی یافت نشد.");

            category.Name = request.Name;
            category.Description = request.Description;
            category.Published = request.Published;
            category.DisplayOrder = request.DisplayOrder;
            category.ParentCategoryId = request.ParentCategoryId;
            category.UpdatedOnUtc = System.DateTime.UtcNow;

            await _categoryService.UpdateCategoryAsync(category);

            return Ok<object>(null, "دسته‌بندی با موفقیت ویرایش شد.");
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var category = await _categoryService.GetCategoryByIdAsync(id);
            if (category == null || !await BelongsToMyStoreAsync(category))
                return NotFoundResult("دسته‌بندی یافت نشد.");

            await _categoryService.DeleteCategoryAsync(category);

            return Ok<object>(null, "دسته‌بندی حذف شد.");
        }

        private async Task<bool> BelongsToMyStoreAsync(Category category)
        {
            if (!category.LimitedToStores)
                return false;

            return await _storeMappingService.AuthorizeAsync(category, CurrentOwnedStoreId);
        }
    }
}
