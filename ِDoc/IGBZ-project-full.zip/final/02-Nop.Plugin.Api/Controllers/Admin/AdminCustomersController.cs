using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Api.DTOs.Admin;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Plugin.Api.DTOs.Order;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Orders;

namespace Nop.Plugin.Api.Controllers.Admin
{
    /// <summary>
    /// نمای فقط-خواندنی مشتریانی که حداقل یک سفارش در همین فروشگاه ثبت کرده‌اند.
    ///
    /// عمداً هیچ اندپوینت Create/Delete اینجا نیست: حساب مشتری یک موجودیت سراسری nopCommerce
    /// است (نه مختص یک Store)، پس این اپ فقط اجازهٔ دیدن سابقهٔ خرید را می‌دهد، نه مدیریت خود
    /// حساب - جلوگیری از خطر این‌که یک صاحب فروشگاه حساب مشتریِ فروشگاه دیگری را ببیند/دستکاری کند.
    /// </summary>
    public class AdminCustomersController : AuthorizedTenantOwnerApiController
    {
        private readonly IOrderService _orderService;
        private readonly ICustomerService _customerServiceForCustomers;
        private readonly IGenericAttributeService _genericAttributeService;

        public AdminCustomersController(
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService,
            IOrderService orderService,
            IGenericAttributeService genericAttributeService)
            : base(storeContext, customerService, tenantProvisioningService)
        {
            _orderService = orderService;
            _customerServiceForCustomers = customerService;
            _genericAttributeService = genericAttributeService;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetCustomers([FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 50)
        {
            // همهٔ سفارش‌های این فروشگاه را می‌گیریم و بر اساس مشتری گروه‌بندی می‌کنیم - برای
            // تعداد متوسط سفارش هر فروشگاه (نه یک مارکت‌پلیس بزرگ) کفایت می‌کند؛ اگر حجم سفارش‌ها
            // خیلی بالا رفت، این را با یک Query تجمیعی مستقیم در دیتابیس جایگزین کنید.
            var allOrders = await _orderService.SearchOrdersAsync(storeId: CurrentOwnedStoreId, pageSize: int.MaxValue);

            var grouped = allOrders
                .GroupBy(o => o.CustomerId)
                .OrderByDescending(g => g.Max(o => o.CreatedOnUtc))
                .Skip(pageIndex * pageSize)
                .Take(pageSize)
                .ToList();

            var items = new List<AdminCustomerListItemDto>();
            foreach (var group in grouped)
            {
                var customer = await _customerServiceForCustomers.GetCustomerByIdAsync(group.Key);
                if (customer == null)
                    continue;

                var firstName = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.FirstNameAttribute);
                var lastName = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.LastNameAttribute);
                var phone = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.PhoneAttribute);

                items.Add(new AdminCustomerListItemDto
                {
                    Id = customer.Id,
                    Email = customer.Email,
                    FullName = $"{firstName} {lastName}".Trim(),
                    PhoneNumber = phone,
                    OrderCount = group.Count(),
                    TotalSpent = group.Sum(o => o.OrderTotal),
                    LastOrderOnUtc = group.Max(o => (System.DateTime?)o.CreatedOnUtc)
                });
            }

            return Ok(new PagedResultDto<AdminCustomerListItemDto>
            {
                Items = items,
                PageIndex = pageIndex,
                PageSize = pageSize,
                TotalCount = allOrders.Select(o => o.CustomerId).Distinct().Count(),
                TotalPages = (int)System.Math.Ceiling(allOrders.Select(o => o.CustomerId).Distinct().Count() / (double)pageSize)
            });
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetCustomerDetail(int id)
        {
            var customer = await _customerServiceForCustomers.GetCustomerByIdAsync(id);
            if (customer == null)
                return NotFoundResult("مشتری یافت نشد.");

            // دفاع اصلی: فقط سفارش‌های همین مشتری در همین فروشگاه را می‌بینیم؛ اگر این مشتری
            // هرگز در این فروشگاه سفارشی ثبت نکرده باشد، از دید این اپ اصلاً وجود ندارد
            var orders = await _orderService.SearchOrdersAsync(storeId: CurrentOwnedStoreId, customerId: id, pageSize: int.MaxValue);
            if (orders.TotalCount == 0)
                return NotFoundResult("این مشتری سفارشی در فروشگاه شما ثبت نکرده است.");

            var firstName = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.FirstNameAttribute);
            var lastName = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.LastNameAttribute);
            var phone = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.PhoneAttribute);

            var dto = new AdminCustomerDetailDto
            {
                Id = customer.Id,
                Email = customer.Email,
                FullName = $"{firstName} {lastName}".Trim(),
                PhoneNumber = phone,
                OrderCount = orders.TotalCount,
                TotalSpent = orders.Sum(o => o.OrderTotal),
                LastOrderOnUtc = orders.Max(o => (System.DateTime?)o.CreatedOnUtc),
                Orders = orders.Select(o => new OrderListItemDto
                {
                    Id = o.Id,
                    CustomOrderNumber = o.CustomOrderNumber,
                    CreatedOnUtc = o.CreatedOnUtc,
                    OrderTotal = o.OrderTotal,
                    OrderTotalFormatted = o.OrderTotal.ToString("N0"),
                    OrderStatus = ((Nop.Core.Domain.Orders.OrderStatus)o.OrderStatusId).ToString(),
                    PaymentStatus = ((Nop.Core.Domain.Payments.PaymentStatus)o.PaymentStatusId).ToString(),
                    ShippingStatus = ((Nop.Core.Domain.Shipping.ShippingStatus)o.ShippingStatusId).ToString()
                }).ToList()
            };

            return Ok(dto);
        }
    }
}
