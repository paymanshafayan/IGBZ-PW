using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Discounts;
using Nop.Plugin.Api.DTOs.Admin;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Discounts;

namespace Nop.Plugin.Api.Controllers.Admin
{
    /// <summary>
    /// مدیریت تخفیف‌های فروشگاه از اپلیکیشن ادمین.
    ///
    /// برخلاف Product/Category/Manufacturer، موجودیت هستهٔ Discount در nopCommerce مکانیزم
    /// استاندارد Store Mapping (LimitedToStores) را ندارد - یعنی یک Discount به‌طور پیش‌فرض
    /// سراسری است. برای جلوگیری از نشت بین فروشگاه‌ها، مالکیت هر Discount با یک Generic
    /// Attribute اختصاصی (DiscountOwnerStoreIdKey) ردیابی می‌شود: هر Discount ساخته‌شده از این
    /// کنترلر بلافاصله به فروشگاه سازنده‌اش برچسب می‌خورد، و هر GET/PUT/DELETE این برچسب را
    /// چک می‌کند. NOTE: قبل از استفادهٔ واقعی، در نسخهٔ 4.90 خودتان بررسی کنید که آیا
    /// Discount این‌بین Store Mapping بومی گرفته یا نه - اگر گرفته، به‌جای این روش دستی از
    /// همان مکانیزم استاندارد (IStoreMappingService) استفاده کنید.
    /// </summary>
    public class AdminDiscountsController : AuthorizedTenantOwnerApiController
    {
        private const string DiscountOwnerStoreIdKey = "Api.Merchant.DiscountOwnerStoreId";

        private readonly IDiscountService _discountService;
        private readonly IGenericAttributeService _genericAttributeService;

        public AdminDiscountsController(
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService,
            IDiscountService discountService,
            IGenericAttributeService genericAttributeService)
            : base(storeContext, customerService, tenantProvisioningService)
        {
            _discountService = discountService;
            _genericAttributeService = genericAttributeService;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetDiscounts()
        {
            var allDiscounts = await _discountService.GetAllDiscountsAsync(showHidden: true);

            var mine = new List<AdminDiscountDto>();
            foreach (var discount in allDiscounts)
            {
                if (!await BelongsToMyStoreAsync(discount))
                    continue;

                mine.Add(ToDto(discount));
            }

            return Ok(mine);
        }

        [HttpPost("")]
        public async Task<IActionResult> CreateDiscount([FromBody] AdminDiscountUpsertRequestDto request)
        {
            if (!System.Enum.TryParse<DiscountType>(request.DiscountType, true, out var discountType))
                discountType = DiscountType.AssignedToOrderTotal;

            var discount = new Discount
            {
                Name = request.Name,
                DiscountTypeId = (int)discountType,
                UsePercentage = request.UsePercentage,
                DiscountPercentage = request.DiscountPercentage,
                DiscountAmount = request.DiscountAmount,
                CouponCode = request.CouponCode,
                RequiresCouponCode = !string.IsNullOrWhiteSpace(request.CouponCode),
                StartDateUtc = request.StartDateUtc,
                EndDateUtc = request.EndDateUtc
            };

            await _discountService.InsertDiscountAsync(discount);
            await _genericAttributeService.SaveAttributeAsync(discount, DiscountOwnerStoreIdKey, CurrentOwnedStoreId);

            return Ok(new { discount.Id }, "تخفیف با موفقیت ایجاد شد.");
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateDiscount(int id, [FromBody] AdminDiscountUpsertRequestDto request)
        {
            var discount = await _discountService.GetDiscountByIdAsync(id);
            if (discount == null || !await BelongsToMyStoreAsync(discount))
                return NotFoundResult("تخفیف یافت نشد.");

            discount.Name = request.Name;
            discount.UsePercentage = request.UsePercentage;
            discount.DiscountPercentage = request.DiscountPercentage;
            discount.DiscountAmount = request.DiscountAmount;
            discount.CouponCode = request.CouponCode;
            discount.RequiresCouponCode = !string.IsNullOrWhiteSpace(request.CouponCode);
            discount.StartDateUtc = request.StartDateUtc;
            discount.EndDateUtc = request.EndDateUtc;

            await _discountService.UpdateDiscountAsync(discount);

            return Ok<object>(null, "تخفیف با موفقیت ویرایش شد.");
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteDiscount(int id)
        {
            var discount = await _discountService.GetDiscountByIdAsync(id);
            if (discount == null || !await BelongsToMyStoreAsync(discount))
                return NotFoundResult("تخفیف یافت نشد.");

            await _discountService.DeleteDiscountAsync(discount);

            return Ok<object>(null, "تخفیف حذف شد.");
        }

        private async Task<bool> BelongsToMyStoreAsync(Discount discount)
        {
            var ownerStoreId = await _genericAttributeService.GetAttributeAsync<int?>(discount, DiscountOwnerStoreIdKey);
            return ownerStoreId.HasValue && ownerStoreId.Value == CurrentOwnedStoreId;
        }

        private static AdminDiscountDto ToDto(Discount discount) => new()
        {
            Id = discount.Id,
            Name = discount.Name,
            DiscountType = ((DiscountType)discount.DiscountTypeId).ToString(),
            DiscountPercentage = discount.DiscountPercentage,
            DiscountAmount = discount.DiscountAmount,
            UsePercentage = discount.UsePercentage,
            CouponCode = discount.CouponCode,
            StartDateUtc = discount.StartDateUtc,
            EndDateUtc = discount.EndDateUtc
        };
    }
}
