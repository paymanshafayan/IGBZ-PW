using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Api.DTOs.Admin;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Customers;
using Nop.Services.Media;

namespace Nop.Plugin.Api.Controllers.Admin
{
    /// <summary>
    /// Lets a store owner set the branding (logo + a single accent color) their store's
    /// customers see - both on their own storefront theme (if you wire ApiSettings/ThemeSettings
    /// to read from it - not done here) and, more immediately, in the shared customer app
    /// (GET /api/v1/store/{storeId}/config reads exactly these two fields off
    /// TenantStoreSubscription). Scoped to the caller's own store by AuthorizedTenantOwnerApiController.
    /// </summary>
    public class AdminStoreSettingsController : AuthorizedTenantOwnerApiController
    {
        private readonly ITenantProvisioningService _tenantProvisioningService;
        private readonly IPictureService _pictureService;

        public AdminStoreSettingsController(
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService,
            IPictureService pictureService)
            : base(storeContext, customerService, tenantProvisioningService)
        {
            _tenantProvisioningService = tenantProvisioningService;
            _pictureService = pictureService;
        }

        [HttpGet("")]
        public async Task<IActionResult> Get()
        {
            var subscription = await _tenantProvisioningService.GetByStoreIdAsync(CurrentOwnedStoreId);

            string logoUrl = null;
            if (subscription?.LogoPictureId is > 0)
            {
                var picture = await _pictureService.GetPictureByIdAsync(subscription.LogoPictureId.Value);
                if (picture != null)
                    (logoUrl, _) = await _pictureService.GetPictureUrlAsync(picture);
            }

            return Ok(new AdminStoreSettingsDto
            {
                BrandColorHex = subscription?.BrandColorHex,
                LogoUrl = logoUrl
            });
        }

        /// <summary>
        /// NOTE: IPictureService.InsertPictureAsync/UpdatePictureAsync/DeletePictureAsync
        /// signatures (parameter names/order, whether a seo-filename or alt-text argument is
        /// required) can differ a little across nopCommerce point releases - check with
        /// IntelliSense against your installed 4.90 build if this doesn't compile as-is; the
        /// overall logic (decode base64 -> upsert Picture -> store its Id) is correct.
        /// </summary>
        [HttpPut("")]
        public async Task<IActionResult> Update([FromBody] UpdateAdminStoreSettingsRequestDto request)
        {
            var subscription = await _tenantProvisioningService.GetByStoreIdAsync(CurrentOwnedStoreId);
            if (subscription == null)
                return Fail("اطلاعات اشتراک این فروشگاه یافت نشد.", 404);

            if (!string.IsNullOrWhiteSpace(request.BrandColorHex))
            {
                var hex = request.BrandColorHex.Trim();
                if (!System.Text.RegularExpressions.Regex.IsMatch(hex, "^#[0-9A-Fa-f]{6}$"))
                    return Fail("رنگ باید به‌صورت هگز و مثل #2F80ED باشد.");

                subscription.BrandColorHex = hex;
            }

            if (request.RemoveLogo)
            {
                if (subscription.LogoPictureId is > 0)
                {
                    var existing = await _pictureService.GetPictureByIdAsync(subscription.LogoPictureId.Value);
                    if (existing != null)
                        await _pictureService.DeletePictureAsync(existing);
                }

                subscription.LogoPictureId = null;
            }
            else if (!string.IsNullOrEmpty(request.LogoBase64))
            {
                if (string.IsNullOrEmpty(request.LogoMimeType))
                    return Fail("نوع فایل تصویر (LogoMimeType) الزامی است.");

                byte[] bytes;
                try
                {
                    bytes = Convert.FromBase64String(request.LogoBase64);
                }
                catch (FormatException)
                {
                    return Fail("تصویر ارسالی معتبر نیست.");
                }

                // بیش از حد بزرگ نباشد (~5MB) - از پر شدن دیتابیس با فایل‌های حجیم جلوگیری می‌کند
                if (bytes.Length > 5 * 1024 * 1024)
                    return Fail("حجم تصویر لوگو نباید بیشتر از ۵ مگابایت باشد.");

                if (subscription.LogoPictureId is > 0)
                {
                    var existing = await _pictureService.GetPictureByIdAsync(subscription.LogoPictureId.Value);
                    if (existing != null)
                        await _pictureService.DeletePictureAsync(existing);
                }

                var seoName = $"store-{CurrentOwnedStoreId}-logo";
                var picture = await _pictureService.InsertPictureAsync(bytes, request.LogoMimeType, seoName);
                subscription.LogoPictureId = picture.Id;
            }

            await _tenantProvisioningService.UpdateAsync(subscription);

            return await Get();
        }
    }
}
