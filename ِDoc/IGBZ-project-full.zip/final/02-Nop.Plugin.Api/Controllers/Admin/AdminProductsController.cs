using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Plugin.Api.DTOs.Admin;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Catalog;
using Nop.Services.Customers;
using Nop.Services.Seo;

namespace Nop.Plugin.Api.Controllers.Admin
{
    /// <summary>
    /// مدیریت محصولات فروشگاه از اپلیکیشن ادمین.
    ///
    /// عمداً محصولات را با یک StoreId مشخص از بدنهٔ درخواست نمی‌سازد: Insert معمولی صدا زده
    /// می‌شود و ProductStoreIsolationConsumer (پلاگین Nop.Plugin.Misc.MultiTenantStores) با
    /// شنیدن EntityInsertedEvent&lt;Product&gt;، بر اساس همان X-Store-Id هدر جاری، محصول را
    /// خودکار به فروشگاه صاحبش محدود می‌کند - این کنترلر فقط باید مطمئن شود IStoreContext در
    /// لحظهٔ Insert به فروشگاه درست resolve شده، که چون AuthorizedTenantOwnerApiController آن
    /// را از قبل تایید کرده، تضمین‌شده است.
    /// </summary>
    public class AdminProductsController : AuthorizedTenantOwnerApiController
    {
        private readonly IProductService _productService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly IProductCategoryService _productCategoryService;
        private readonly Nop.Services.Stores.IStoreMappingService _storeMappingService;

        public AdminProductsController(
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService,
            IProductService productService,
            IUrlRecordService urlRecordService,
            IProductCategoryService productCategoryService,
            Nop.Services.Stores.IStoreMappingService storeMappingService)
            : base(storeContext, customerService, tenantProvisioningService)
        {
            _productService = productService;
            _urlRecordService = urlRecordService;
            _productCategoryService = productCategoryService;
            _storeMappingService = storeMappingService;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetProducts([FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 50)
        {
            var products = await _productService.SearchProductsAsync(
                storeId: CurrentOwnedStoreId, pageIndex: pageIndex, pageSize: pageSize, showHidden: true);

            var items = products.Select(p => new AdminProductListItemDto
            {
                Id = p.Id,
                Name = p.Name,
                Sku = p.Sku,
                Price = p.Price,
                StockQuantity = p.StockQuantity,
                Published = p.Published
            }).ToList();

            return Ok(new PagedResultDto<AdminProductListItemDto>
            {
                Items = items,
                PageIndex = products.PageIndex,
                PageSize = products.PageSize,
                TotalCount = products.TotalCount,
                TotalPages = products.TotalPages
            });
        }

        [HttpPost("")]
        public async Task<IActionResult> CreateProduct([FromBody] AdminProductUpsertRequestDto request)
        {
            var product = new Product
            {
                Name = request.Name,
                ShortDescription = request.ShortDescription,
                FullDescription = request.FullDescription,
                Sku = request.Sku,
                Price = request.Price,
                OldPrice = request.OldPrice ?? 0,
                StockQuantity = request.StockQuantity,
                Published = request.Published,
                ProductType = ProductType.SimpleProduct,
                VisibleIndividually = true,
                CreatedOnUtc = System.DateTime.UtcNow,
                UpdatedOnUtc = System.DateTime.UtcNow
            };

            // triggers EntityInsertedEvent<Product> -> ProductStoreIsolationConsumer store-limits it
            await _productService.InsertProductAsync(product);

            await _urlRecordService.SaveSlugAsync(product, await _urlRecordService.ValidateSeNameAsync(product, string.Empty, product.Name, true), 0);

            foreach (var categoryId in request.CategoryIds ?? new List<int>())
            {
                await _productCategoryService.InsertProductCategoryAsync(new ProductCategory
                {
                    ProductId = product.Id,
                    CategoryId = categoryId,
                    IsFeaturedProduct = false,
                    DisplayOrder = 0
                });
            }

            return Ok(new { product.Id }, "محصول با موفقیت ایجاد شد.");
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] AdminProductUpsertRequestDto request)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null || !await BelongsToMyStoreAsync(product))
                return NotFoundResult("محصول یافت نشد.");

            product.Name = request.Name;
            product.ShortDescription = request.ShortDescription;
            product.FullDescription = request.FullDescription;
            product.Sku = request.Sku;
            product.Price = request.Price;
            product.OldPrice = request.OldPrice ?? 0;
            product.StockQuantity = request.StockQuantity;
            product.Published = request.Published;
            product.UpdatedOnUtc = System.DateTime.UtcNow;

            await _productService.UpdateProductAsync(product);

            return Ok<object>(null, "محصول با موفقیت ویرایش شد.");
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null || !await BelongsToMyStoreAsync(product))
                return NotFoundResult("محصول یافت نشد.");

            await _productService.DeleteProductAsync(product);

            return Ok<object>(null, "محصول حذف شد.");
        }

        /// <summary>
        /// دفاع دوم (Defense-in-depth): حتی اگر یک شناسهٔ محصول از فروشگاه دیگری حدس زده شود،
        /// این متد با چک کردن نگاشت واقعی Store-to-Product (که ProductStoreIsolationConsumer
        /// هنگام ساخت محصول ثبت کرده) از ویرایش/حذف آن جلوگیری می‌کند.
        /// </summary>
        private async Task<bool> BelongsToMyStoreAsync(Product product)
        {
            if (!product.LimitedToStores)
                return false; // محصولات سراسری/پلتفرم هرگز از این اپ قابل ویرایش نیستند

            return await _storeMappingService.AuthorizeAsync(product, CurrentOwnedStoreId);
        }
    }
}
