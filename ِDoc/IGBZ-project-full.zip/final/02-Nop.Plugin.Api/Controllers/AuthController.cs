using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Plugin.Api.Domain;
using Nop.Plugin.Api.DTOs.Auth;
using Nop.Plugin.Api.Services;
using Nop.Plugin.Misc.MultiTenantStores;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Messages;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>
    /// اندپوینت‌های احراز هویت مناسب اپلیکیشن موبایل/فلاتر (JWT: Access + Refresh Token)
    /// </summary>
    [EnableRateLimiting("AuthPolicy")]
    public class AuthController : BaseNopApiController
    {
        private readonly ICustomerService _customerService;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ISettingService _settingService;
        private readonly IJwtTokenService _jwtTokenService;
        private readonly IRefreshTokenService _refreshTokenService;
        private readonly IWorkflowMessageService _workflowMessageService;
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly ITenantProvisioningService _tenantProvisioningService;

        public AuthController(
            ICustomerService customerService,
            ICustomerRegistrationService customerRegistrationService,
            IGenericAttributeService genericAttributeService,
            ISettingService settingService,
            IJwtTokenService jwtTokenService,
            IRefreshTokenService refreshTokenService,
            IWorkflowMessageService workflowMessageService,
            IWorkContext workContext,
            IStoreContext storeContext,
            ITenantProvisioningService tenantProvisioningService)
        {
            _customerService = customerService;
            _customerRegistrationService = customerRegistrationService;
            _genericAttributeService = genericAttributeService;
            _settingService = settingService;
            _jwtTokenService = jwtTokenService;
            _refreshTokenService = refreshTokenService;
            _workflowMessageService = workflowMessageService;
            _workContext = workContext;
            _storeContext = storeContext;
            _tenantProvisioningService = tenantProvisioningService;
        }

        /// <summary>ثبت‌نام مشتری جدید</summary>
        [HttpPost("register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] RegisterRequestDto request)
        {
            var apiSettings = await _settingService.LoadSettingAsync<ApiSettings>();
            if (!apiSettings.AllowRegistrationViaApi)
                return Fail("ثبت‌نام از طریق API غیرفعال است.", 403);

            if (!ModelState.IsValid)
                return Fail("اطلاعات ارسالی نامعتبر است.");

            var existing = await _customerService.GetCustomerByEmailAsync(request.Email);
            if (existing != null)
                return Fail("این ایمیل قبلاً ثبت شده است.", 409);

            // resolved via the X-Store-Id header on /api requests (see MultiTenantStoreContext) -
            // this is the store the customer is actually signing up for
            var currentStore = await _storeContext.GetCurrentStoreAsync();

            var customer = new Customer
            {
                CustomerGuid = Guid.NewGuid(),
                Email = request.Email,
                Username = request.Email,
                Active = true,
                CreatedOnUtc = DateTime.UtcNow,
                LastActivityDateUtc = DateTime.UtcNow,
                RegisteredInStoreId = currentStore.Id
            };

            await _customerService.InsertCustomerAsync(customer);

            var registrationResult = await _customerRegistrationService.RegisterCustomerAsync(new CustomerRegistrationRequest(
                customer, request.Email, request.Email, request.Password,
                PasswordFormat.Hashed, customer.RegisteredInStoreId, true));

            if (!registrationResult.Success)
                return Fail(string.Join(" | ", registrationResult.Errors));

            await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.FirstNameAttribute, request.FirstName);
            await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.LastNameAttribute, request.LastName);
            if (!string.IsNullOrEmpty(request.PhoneNumber))
                await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.PhoneAttribute, request.PhoneNumber);

            // Defensive/idempotent: stamp the "home store" ourselves too, in addition to
            // CustomerRegisteredEventConsumer (in case that event isn't published by this
            // nopCommerce version's RegisterCustomerAsync - see NOTE in that consumer).
            var existingHomeStore = await _genericAttributeService.GetAttributeAsync<int?>(customer, MultiTenantStoresDefaults.HomeStoreIdAttributeKey);
            if (existingHomeStore is not > 0)
                await _genericAttributeService.SaveAttributeAsync(customer, MultiTenantStoresDefaults.HomeStoreIdAttributeKey, currentStore.Id);

            // افزودن به نقش "Registered"
            var registeredRole = await _customerService.GetCustomerRoleBySystemNameAsync(NopCustomerDefaults.RegisteredRoleName);
            if (registeredRole != null && !await _customerService.IsRegisteredAsync(customer))
            {
                await _customerService.AddCustomerRoleMappingAsync(new CustomerCustomerRoleMapping
                {
                    CustomerId = customer.Id,
                    CustomerRoleId = registeredRole.Id
                });
            }

            var tokenResult = await IssueTokensAsync(customer, null);
            return Ok(tokenResult, "ثبت‌نام با موفقیت انجام شد.");
        }

        /// <summary>ورود کاربر و دریافت Access/Refresh Token</summary>
        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto request)
        {
            if (!ModelState.IsValid)
                return Fail("اطلاعات ورود نامعتبر است.");

            var result = await _customerRegistrationService.ValidateCustomerAsync(request.Email, request.Password);
            if (result != CustomerLoginResults.Successful)
            {
                var message = result switch
                {
                    CustomerLoginResults.CustomerNotExist => "کاربری با این مشخصات یافت نشد.",
                    CustomerLoginResults.WrongPassword => "رمز عبور اشتباه است.",
                    CustomerLoginResults.NotActive => "حساب کاربری فعال نشده است.",
                    CustomerLoginResults.Deleted => "این حساب کاربری حذف شده است.",
                    CustomerLoginResults.NotRegistered => "این حساب ثبت‌نام نشده است.",
                    CustomerLoginResults.LockedOut => "حساب کاربری به دلیل تلاش‌های ناموفق مسدود شده است.",
                    _ => "ورود ناموفق بود."
                };
                return Fail(message, 401);
            }

            var customer = await _customerService.GetCustomerByEmailAsync(request.Email);

            // CRITICAL tenant-isolation check: this account must belong to (or own) the store
            // the request is for (identified by the X-Store-Id header) - otherwise a customer
            // of store A could log into store B's app with the exact same credentials.
            if (!await BelongsToCurrentStoreAsync(customer))
                return Fail("این حساب متعلق به فروشگاه دیگری است.", 403);

            var tokenResult = await IssueTokensAsync(customer, request.DeviceId);
            return Ok(tokenResult, "ورود با موفقیت انجام شد.");
        }

        /// <summary>
        /// ورود مخصوص اپلیکیشن ادمین فروشگاه (Flutter). بر خلاف /auth/login معمولی، این مسیر
        /// نیازمند هدر X-Store-Id نیست (چون خودِ اپ ادمین در همان اولین اجرا هنوز نمی‌داند صاحب
        /// کدام فروشگاه است - این Endpoint دقیقاً همان را در اختیارش می‌گذارد) و به‌جای بررسی
        /// "آیا این حساب متعلق به فروشگاه X است"، بررسی می‌کند "آیا این حساب اصلاً صاحب یک
        /// فروشگاه است یا نه". از این پس اپ، OwnedStoreId برگشتی را ذخیره و به‌عنوان X-Store-Id
        /// در همهٔ درخواست‌های بعدی (شامل توابع Admin/*) می‌فرستد.
        /// </summary>
        [HttpPost("merchant-login")]
        [AllowAnonymous]
        public async Task<IActionResult> MerchantLogin([FromBody] LoginRequestDto request)
        {
            if (!ModelState.IsValid)
                return Fail("اطلاعات ورود نامعتبر است.");

            var result = await _customerRegistrationService.ValidateCustomerAsync(request.Email, request.Password);
            if (result != CustomerLoginResults.Successful)
                return Fail("ایمیل یا رمز عبور اشتباه است.", 401);

            var customer = await _customerService.GetCustomerByEmailAsync(request.Email);

            var ownedStoreId = await _tenantProvisioningService.GetOwnedStoreIdAsync(customer);
            if (ownedStoreId == null)
                return Fail("این حساب مالک هیچ فروشگاهی نیست. اپلیکیشن ادمین فقط برای صاحبان فروشگاه است.", 403);

            var tokenResult = await IssueTokensAsync(customer, request.DeviceId);
            return Ok(tokenResult, "ورود با موفقیت انجام شد.");
        }

        /// <summary>دریافت Access Token جدید با استفاده از Refresh Token معتبر</summary>
        [HttpPost("refresh-token")]
        [AllowAnonymous]
        public async Task<IActionResult> RefreshToken([FromBody] RefreshTokenRequestDto request)
        {
            var storedToken = await _refreshTokenService.GetByTokenValueAsync(request.RefreshToken);
            if (storedToken == null || storedToken.ExpiresOnUtc < DateTime.UtcNow)
                return Fail("Refresh Token نامعتبر یا منقضی‌شده است.", 401);

            var customer = await _customerService.GetCustomerByIdAsync(storedToken.CustomerId);
            if (customer == null || !customer.Active || customer.Deleted)
                return Fail("حساب کاربری معتبر نیست.", 401);

            // same isolation check as Login - a refresh token must not be usable to keep a
            // session alive on a store this account does not belong to
            if (!await BelongsToCurrentStoreAsync(customer))
            {
                await _refreshTokenService.RevokeAsync(storedToken);
                return Fail("این حساب متعلق به فروشگاه دیگری است.", 403);
            }

            // ابطال توکن قبلی و صدور زوج جدید (rotation) برای امنیت بالاتر
            await _refreshTokenService.RevokeAsync(storedToken);
            var tokenResult = await IssueTokensAsync(customer, storedToken.DeviceId);
            return Ok(tokenResult, "توکن با موفقیت تمدید شد.");
        }

        /// <summary>خروج از حساب کاربری (ابطال Refresh Token فعلی یا همه دستگاه‌ها)</summary>
        [HttpPost("logout")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> Logout([FromBody] RefreshTokenRequestDto request, [FromQuery] bool allDevices = false)
        {
            var customerId = GetCurrentApiCustomerId();
            if (allDevices)
            {
                await _refreshTokenService.RevokeAllForCustomerAsync(customerId);
            }
            else if (!string.IsNullOrEmpty(request?.RefreshToken))
            {
                var storedToken = await _refreshTokenService.GetByTokenValueAsync(request.RefreshToken);
                await _refreshTokenService.RevokeAsync(storedToken);
            }

            return Ok<object>(null, "خروج با موفقیت انجام شد.");
        }

        /// <summary>تغییر رمز عبور توسط کاربر لاگین‌شده</summary>
        [HttpPost("change-password")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            if (customer == null)
                return Fail("کاربر یافت نشد.", 401);

            var result = await _customerRegistrationService.ChangePasswordAsync(new ChangePasswordRequest(
                customer.Email, true, PasswordFormat.Hashed, request.NewPassword, request.OldPassword));

            if (!result.Success)
                return Fail(string.Join(" | ", result.Errors));

            await _refreshTokenService.RevokeAllForCustomerAsync(customer.Id);
            return Ok<object>(null, "رمز عبور با موفقیت تغییر کرد. لطفاً دوباره وارد شوید.");
        }

        /// <summary>درخواست بازیابی رمز عبور (ایمیل حاوی لینک بازیابی ارسال می‌شود)</summary>
        [HttpPost("forgot-password")]
        [AllowAnonymous]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordRequestDto request)
        {
            var customer = await _customerService.GetCustomerByEmailAsync(request.Email);
            if (customer == null)
                // به دلایل امنیتی همیشه پیام موفقیت‌آمیز برمی‌گردانیم تا از افشای وجود ایمیل جلوگیری شود
                return Ok<object>(null, "در صورت وجود این ایمیل در سیستم، لینک بازیابی رمز عبور ارسال شد.");

            var token = Guid.NewGuid().ToString();
            await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.PasswordRecoveryTokenAttribute, token);
            await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.PasswordRecoveryTokenDateGeneratedAttribute, DateTime.UtcNow);

            await _workflowMessageService.SendCustomerPasswordRecoveryMessageAsync(customer, (await _workContext.GetWorkingLanguageAsync()).Id);

            return Ok<object>(null, "در صورت وجود این ایمیل در سیستم، لینک بازیابی رمز عبور ارسال شد.");
        }

        /// <summary>تکمیل بازیابی رمز عبور با استفاده از توکن ارسال‌شده در ایمیل</summary>
        [HttpPost("reset-password")]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequestDto request)
        {
            var customer = await _customerService.GetCustomerByEmailAsync(request.Email);
            if (customer == null)
                return Fail("درخواست نامعتبر است.", 400);

            var savedToken = await _genericAttributeService.GetAttributeAsync<string>(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.PasswordRecoveryTokenAttribute);
            if (string.IsNullOrEmpty(savedToken) || savedToken != request.Token)
                return Fail("توکن بازیابی نامعتبر است.", 400);

            var result = await _customerRegistrationService.ChangePasswordAsync(new ChangePasswordRequest(
                request.Email, false, PasswordFormat.Hashed, request.NewPassword));

            if (!result.Success)
                return Fail(string.Join(" | ", result.Errors));

            await _genericAttributeService.SaveAttributeAsync(customer, Nop.Core.Domain.Customers.NopCustomerDefaults.PasswordRecoveryTokenAttribute, string.Empty);
            await _refreshTokenService.RevokeAllForCustomerAsync(customer.Id);

            return Ok<object>(null, "رمز عبور با موفقیت بازیابی شد.");
        }

        /// <summary>
        /// Mirrors CrossStoreCustomerGuardFilter's rule from the storefront plugin: a customer
        /// may use the store they registered on (HomeStoreId), or a store they own (tenant
        /// owner checking their own shop's app). Customers with no HomeStoreId recorded yet
        /// (e.g. accounts created before this plugin was installed) are allowed through -
        /// fail-open on that specific edge case, exactly like the storefront filter does.
        /// </summary>
        private async Task<bool> BelongsToCurrentStoreAsync(Customer customer)
        {
            if (customer == null)
                return false;

            var currentStore = await _storeContext.GetCurrentStoreAsync();

            var homeStoreId = await _genericAttributeService.GetAttributeAsync<int?>(customer, MultiTenantStoresDefaults.HomeStoreIdAttributeKey);
            if (homeStoreId is not > 0)
                return true;

            if (homeStoreId.Value == currentStore.Id)
                return true;

            var ownedStoreId = await _tenantProvisioningService.GetOwnedStoreIdAsync(customer);
            return ownedStoreId.HasValue && ownedStoreId.Value == currentStore.Id;
        }

        private async Task<TokenResponseDto> IssueTokensAsync(Customer customer, string deviceId)
        {
            var apiSettings = await _settingService.LoadSettingAsync<ApiSettings>();
            var accessToken = await _jwtTokenService.GenerateAccessTokenAsync(customer);
            var refreshTokenValue = _jwtTokenService.GenerateRefreshTokenValue();

            await _refreshTokenService.CreateRefreshTokenAsync(customer.Id, refreshTokenValue, apiSettings.RefreshTokenExpirationDays, deviceId);

            // مهم برای اپ ادمین (Flutter): این‌طوری اپ همان لحظهٔ ورود می‌فهمد این حساب مالک کدام
            // فروشگاه است و از همان لحظه هدر X-Store-Id درست را برای بقیهٔ درخواست‌ها می‌فرستد،
            // بدون نیاز به یک Endpoint جداگانه یا حدس زدن.
            var ownedStoreId = await _tenantProvisioningService.GetOwnedStoreIdAsync(customer);

            return new TokenResponseDto
            {
                AccessToken = accessToken,
                RefreshToken = refreshTokenValue,
                AccessTokenExpiresOnUtc = DateTime.UtcNow.AddMinutes(apiSettings.AccessTokenExpirationMinutes),
                CustomerId = customer.Id,
                OwnedStoreId = ownedStoreId
            };
        }
    }
}
