using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Plugin.Api.DTOs.Checkout;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Directory;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Shipping;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>اندپوینت‌های فرآیند تسویه‌حساب (checkout) - نیاز به احراز هویت دارد</summary>
    public class CheckoutController : AuthorizedApiController
    {
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IShippingService _shippingService;
        private readonly IPaymentService _paymentService;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IAddressService _addressService;
        private readonly ICustomerService _customerService;
        private readonly Nop.Services.Catalog.IPriceFormatter _priceFormatter;
        private readonly IStoreContext _storeContext;

        public CheckoutController(
            IShoppingCartService shoppingCartService,
            IShippingService shippingService,
            IPaymentService paymentService,
            IOrderTotalCalculationService orderTotalCalculationService,
            IOrderProcessingService orderProcessingService,
            IGenericAttributeService genericAttributeService,
            IAddressService addressService,
            ICustomerService customerService,
            Nop.Services.Catalog.IPriceFormatter priceFormatter,
            IStoreContext storeContext)
        {
            _shoppingCartService = shoppingCartService;
            _shippingService = shippingService;
            _paymentService = paymentService;
            _orderTotalCalculationService = orderTotalCalculationService;
            _orderProcessingService = orderProcessingService;
            _genericAttributeService = genericAttributeService;
            _addressService = addressService;
            _customerService = customerService;
            _priceFormatter = priceFormatter;
            _storeContext = storeContext;
        }

        /// <summary>خلاصه مبالغ سبد خرید (جمع جزء، مالیات، تخفیف، مجموع کل)</summary>
        [HttpGet("summary")]
        public async Task<IActionResult> GetSummary()
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var cart = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);

            if (!cart.Any())
                return Fail("سبد خرید خالی است.");

            var subTotalResult = await _orderTotalCalculationService.GetShoppingCartSubTotalAsync(cart, false);
            var (shippingTotal, _, _) = await _orderTotalCalculationService.GetShoppingCartShippingTotalAsync(cart);
            var (taxTotal, _) = await _orderTotalCalculationService.GetTaxTotalAsync(cart, false);
            var totals = await _orderTotalCalculationService.GetShoppingCartTotalAsync(cart);

            var requiresShipping = await _shoppingCartService.ShoppingCartRequiresShippingAsync(cart);

            var dto = new CheckoutSummaryDto
            {
                SubTotal = subTotalResult.subTotalWithoutDiscount,
                SubTotalFormatted = await _priceFormatter.FormatPriceAsync(subTotalResult.subTotalWithoutDiscount, true, false),
                ShippingTotal = shippingTotal,
                ShippingTotalFormatted = shippingTotal.HasValue ? await _priceFormatter.FormatShippingPriceAsync(shippingTotal.Value, true) : null,
                TaxTotal = taxTotal,
                TaxTotalFormatted = await _priceFormatter.FormatPriceAsync(taxTotal, true, false),
                DiscountAmount = totals.discountAmount,
                DiscountAmountFormatted = await _priceFormatter.FormatPriceAsync(totals.discountAmount, true, false),
                Total = totals.shoppingCartTotal,
                TotalFormatted = totals.shoppingCartTotal.HasValue ? await _priceFormatter.FormatPriceAsync(totals.shoppingCartTotal.Value) : null,
                RequiresShipping = requiresShipping,
                AppliedDiscountCodes = totals.appliedDiscounts?.Select(d => d.CouponCode).Where(c => !string.IsNullOrEmpty(c)).ToList() ?? new List<string>()
            };

            return Ok(dto);
        }

        /// <summary>لیست روش‌های ارسال موجود بر اساس آدرس ارسال انتخابی</summary>
        [HttpGet("shipping-methods")]
        public async Task<IActionResult> GetShippingMethods([FromQuery] int shippingAddressId)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var cart = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);

            var address = await _addressService.GetAddressByIdAsync(shippingAddressId);
            if (address == null)
                return NotFoundResult("آدرس ارسال یافت نشد.");

            var response = await _shippingService.GetShippingOptionsAsync(cart, address, customer, storeId: store.Id);
            if (!response.Success)
                return Fail(string.Join(" | ", response.Errors));

            var result = new List<ShippingOptionDto>();
            foreach (var option in response.ShippingOptions)
            {
                result.Add(new ShippingOptionDto
                {
                    Name = option.Name,
                    Description = option.Description,
                    Rate = option.Rate,
                    RateFormatted = await _priceFormatter.FormatShippingPriceAsync(option.Rate, true),
                    ShippingRateComputationMethodSystemName = option.ShippingRateComputationMethodSystemName
                });
            }

            return Ok(result);
        }

        /// <summary>ذخیره روش ارسال انتخاب‌شده برای سفارش بعدی</summary>
        [HttpPost("shipping-methods/select")]
        public async Task<IActionResult> SelectShippingMethod([FromBody] SelectShippingOptionRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var cart = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);
            var address = await _customerService.GetCustomerShippingAddressAsync(customer);

            var response = await _shippingService.GetShippingOptionsAsync(cart, address, customer, request.ShippingRateComputationMethodSystemName, store.Id);
            var selected = response.ShippingOptions.FirstOrDefault(o => o.Name == request.ShippingOptionName);
            if (selected == null)
                return Fail("روش ارسال انتخابی معتبر نیست.");

            await _genericAttributeService.SaveAttributeAsync(customer, NopCustomerDefaults.SelectedShippingOptionAttribute, selected, store.Id);

            return Ok<object>(null, "روش ارسال ذخیره شد.");
        }

        /// <summary>لیست روش‌های پرداخت فعال</summary>
        [HttpGet("payment-methods")]
        public async Task<IActionResult> GetPaymentMethods()
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var cart = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);

            var filterByCountryId = 0;
            var paymentMethods = await _paymentService.LoadActivePaymentMethodsAsync(customer, store.Id, filterByCountryId);

            var result = new List<PaymentMethodDto>();
            foreach (var pm in paymentMethods)
            {
                result.Add(new PaymentMethodDto
                {
                    SystemName = pm.PluginDescriptor.SystemName,
                    FriendlyName = pm.PluginDescriptor.FriendlyName,
                    Description = await pm.GetPaymentMethodDescriptionAsync()
                });
            }

            return Ok(result);
        }

        /// <summary>ذخیره روش پرداخت انتخاب‌شده برای سفارش بعدی</summary>
        [HttpPost("payment-methods/select")]
        public async Task<IActionResult> SelectPaymentMethod([FromBody] SelectPaymentMethodRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();

            await _genericAttributeService.SaveAttributeAsync(customer, NopCustomerDefaults.SelectedPaymentMethodAttribute, request.PaymentMethodSystemName, store.Id);

            return Ok<object>(null, "روش پرداخت ذخیره شد.");
        }

        /// <summary>ثبت نهایی سفارش - نقطه پایانی فرآیند checkout</summary>
        [HttpPost("place-order")]
        public async Task<IActionResult> PlaceOrder([FromBody] PlaceOrderRequestDto request)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var cart = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, store.Id);

            if (!cart.Any())
                return Fail("سبد خرید خالی است.");

            var billingAddress = await _addressService.GetAddressByIdAsync(request.BillingAddressId);
            if (billingAddress == null)
                return Fail("آدرس صورتحساب معتبر نیست.");

            customer.BillingAddressId = billingAddress.Id;

            var requiresShipping = await _shoppingCartService.ShoppingCartRequiresShippingAsync(cart);
            if (requiresShipping)
            {
                if (!request.ShippingAddressId.HasValue)
                    return Fail("آدرس ارسال الزامی است.");

                var shippingAddress = await _addressService.GetAddressByIdAsync(request.ShippingAddressId.Value);
                if (shippingAddress == null)
                    return Fail("آدرس ارسال معتبر نیست.");

                customer.ShippingAddressId = shippingAddress.Id;

                if (!string.IsNullOrEmpty(request.ShippingOptionName))
                {
                    var shippingResponse = await _shippingService.GetShippingOptionsAsync(cart, shippingAddress, customer, request.ShippingRateComputationMethodSystemName, store.Id);
                    var selectedOption = shippingResponse.ShippingOptions.FirstOrDefault(o => o.Name == request.ShippingOptionName);
                    if (selectedOption != null)
                        await _genericAttributeService.SaveAttributeAsync(customer, NopCustomerDefaults.SelectedShippingOptionAttribute, selectedOption, store.Id);
                }
            }

            await _customerService.UpdateCustomerAsync(customer);

            if (!string.IsNullOrEmpty(request.PaymentMethodSystemName))
                await _genericAttributeService.SaveAttributeAsync(customer, NopCustomerDefaults.SelectedPaymentMethodAttribute, request.PaymentMethodSystemName, store.Id);

            if (!string.IsNullOrEmpty(request.CustomerComment))
                await _genericAttributeService.SaveAttributeAsync(customer, "checkout.custom.comment", request.CustomerComment);

            var processPaymentRequest = new ProcessPaymentRequest
            {
                StoreId = store.Id,
                CustomerId = customer.Id,
                PaymentMethodSystemName = request.PaymentMethodSystemName,
                OrderGuid = Guid.NewGuid()
            };

            var placeOrderResult = await _orderProcessingService.PlaceOrderAsync(processPaymentRequest);

            var resultDto = new DTOs.Checkout.PlaceOrderResultDto
            {
                Success = placeOrderResult.Success,
                Errors = placeOrderResult.Errors?.ToList() ?? new List<string>()
            };

            if (!placeOrderResult.Success)
                return Ok(resultDto, "ثبت سفارش با خطا مواجه شد.");

            var order = placeOrderResult.PlacedOrder;
            resultDto.OrderId = order.Id;
            resultDto.CustomOrderNumber = order.CustomOrderNumber;
            resultDto.OrderTotal = order.OrderTotal;
            resultDto.OrderTotalFormatted = await _priceFormatter.FormatPriceAsync(order.OrderTotal);

            return Ok(resultDto, "سفارش با موفقیت ثبت شد.");
        }
    }
}
