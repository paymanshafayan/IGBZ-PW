using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Api.DTOs.Shipping;
using Nop.Services.Directory;
using Nop.Services.Orders;
using Nop.Services.Shipping;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>اطلاعات کشور/استان (برای فرم‌های آدرس) و رهگیری مرسوله سفارش‌ها</summary>
    [AllowAnonymous]
    public class ShippingController : BaseNopApiController
    {
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly IOrderService _orderService;
        private readonly IShipmentService _shipmentService;

        public ShippingController(
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            IOrderService orderService,
            IShipmentService shipmentService)
        {
            _countryService = countryService;
            _stateProvinceService = stateProvinceService;
            _orderService = orderService;
            _shipmentService = shipmentService;
        }

        /// <summary>لیست کشورهای فعال (برای فرم آدرس در فلاتر)</summary>
        [HttpGet("countries")]
        public async Task<IActionResult> GetCountries()
        {
            var countries = await _countryService.GetAllCountriesAsync();
            var result = countries.Select(c => new CountryDto
            {
                Id = c.Id,
                Name = c.Name,
                TwoLetterIsoCode = c.TwoLetterIsoCode,
                ThreeLetterIsoCode = c.ThreeLetterIsoCode,
                AllowsBilling = c.AllowsBilling,
                AllowsShipping = c.AllowsShipping
            }).ToList();

            return Ok(result);
        }

        /// <summary>لیست استان‌های یک کشور</summary>
        [HttpGet("countries/{countryId:int}/states")]
        public async Task<IActionResult> GetStates(int countryId)
        {
            var states = await _stateProvinceService.GetStateProvincesByCountryIdAsync(countryId);
            var result = states.Select(s => new StateProvinceDto
            {
                Id = s.Id,
                Name = s.Name,
                Abbreviation = s.Abbreviation
            }).ToList();

            return Ok(result);
        }

        /// <summary>رهگیری وضعیت ارسال و مرسولات یک سفارش (نیاز به احراز هویت و مالکیت سفارش)</summary>
        [HttpGet("order/{orderId:int}/tracking")]
        [Authorize(AuthenticationSchemes = "ApiJwtBearer")]
        public async Task<IActionResult> GetOrderTracking(int orderId)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var order = await _orderService.GetOrderByIdAsync(orderId);
            if (order == null || order.CustomerId != customer.Id)
                return NotFoundResult("سفارش یافت نشد.");

            var shipments = await _shipmentService.GetShipmentsByOrderIdAsync(orderId);

            var dto = new OrderTrackingDto
            {
                OrderId = order.Id,
                ShippingStatus = order.ShippingStatus.ToString(),
                ShippingMethod = order.ShippingMethod
            };

            foreach (var shipment in shipments)
            {
                var shipmentDto = new ShipmentDto
                {
                    Id = shipment.Id,
                    TrackingNumber = shipment.TrackingNumber,
                    ShippedOnUtc = shipment.ShippedDateUtc,
                    DeliveredOnUtc = shipment.DeliveryDateUtc
                };

                var items = await _shipmentService.GetShipmentItemsByShipmentIdAsync(shipment.Id);
                foreach (var item in items)
                {
                    var orderItem = await _orderService.GetOrderItemByIdAsync(item.OrderItemId);
                    if (orderItem == null) continue;

                    shipmentDto.Items.Add(new ShipmentItemDto
                    {
                        ProductId = orderItem.ProductId,
                        Quantity = item.Quantity
                    });
                }

                dto.Shipments.Add(shipmentDto);
            }

            return Ok(dto);
        }
    }
}
