using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Api.DTOs.Catalog;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Plugin.Api.DTOs.Vendor;
using Nop.Services.Catalog;
using Nop.Services.Media;
using Nop.Services.Seo;
using Nop.Services.Vendors;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>پروفایل عمومی فروشندگان و لیست محصولات هر فروشنده (سناریوی بازارگاه/Marketplace)</summary>
    [AllowAnonymous]
    public class VendorController : BaseNopApiController
    {
        private readonly IVendorService _vendorService;
        private readonly IProductService _productService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly Nop.Services.Catalog.IPriceFormatter _priceFormatter;
        private readonly IPictureService _pictureService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;

        public VendorController(
            IVendorService vendorService,
            IProductService productService,
            IPriceCalculationService priceCalculationService,
            Nop.Services.Catalog.IPriceFormatter priceFormatter,
            IPictureService pictureService,
            IUrlRecordService urlRecordService,
            IWorkContext workContext,
            IStoreContext storeContext)
        {
            _vendorService = vendorService;
            _productService = productService;
            _priceCalculationService = priceCalculationService;
            _priceFormatter = priceFormatter;
            _pictureService = pictureService;
            _urlRecordService = urlRecordService;
            _workContext = workContext;
            _storeContext = storeContext;
        }

        /// <summary>لیست فروشندگان فعال</summary>
        [HttpGet("")]
        public async Task<IActionResult> GetVendors([FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 20)
        {
            var vendors = await _vendorService.GetAllVendorsAsync(pageIndex: pageIndex, pageSize: pageSize);

            var items = new List<VendorDto>();
            foreach (var vendor in vendors)
                items.Add(await MapVendorAsync(vendor));

            var result = new PagedResultDto<VendorDto>
            {
                Items = items,
                PageIndex = vendors.PageIndex,
                PageSize = vendors.PageSize,
                TotalCount = vendors.TotalCount,
                TotalPages = vendors.TotalPages
            };

            return Ok(result);
        }

        /// <summary>جزئیات پروفایل یک فروشنده</summary>
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetVendor(int id)
        {
            var vendor = await _vendorService.GetVendorByIdAsync(id);
            if (vendor == null || vendor.Deleted || !vendor.Active)
                return NotFoundResult("فروشنده یافت نشد.");

            return Ok(await MapVendorAsync(vendor));
        }

        /// <summary>لیست محصولات یک فروشنده با صفحه‌بندی</summary>
        [HttpGet("{id:int}/products")]
        public async Task<IActionResult> GetVendorProducts(int id, [FromQuery] int pageIndex = 0, [FromQuery] int pageSize = 20)
        {
            var vendor = await _vendorService.GetVendorByIdAsync(id);
            if (vendor == null || vendor.Deleted || !vendor.Active)
                return NotFoundResult("فروشنده یافت نشد.");

            var store = await _storeContext.GetCurrentStoreAsync();
            var customer = await _workContext.GetCurrentCustomerAsync();

            var products = await _productService.SearchProductsAsync(
                pageIndex: pageIndex, pageSize: pageSize,
                vendorId: id, storeId: store.Id, visibleIndividuallyOnly: true);

            var items = new List<ProductListItemDto>();
            foreach (var product in products)
            {
                var (price, _) = await _priceCalculationService.GetFinalPriceAsync(product, customer);
                var pictures = await _productService.GetProductPicturesByProductIdAsync(product.Id);
                var picture = pictures.Count > 0 ? pictures[0] : null;
                var pictureEntity = picture != null ? await _pictureService.GetPictureByIdAsync(picture.PictureId) : null;
                var (pictureUrl, _) = pictureEntity != null ? await _pictureService.GetPictureUrlAsync(pictureEntity) : (string.Empty, null);

                items.Add(new ProductListItemDto
                {
                    Id = product.Id,
                    Name = product.Name,
                    ShortDescription = product.ShortDescription,
                    SeName = await _urlRecordService.GetSeNameAsync(product),
                    PictureUrl = pictureUrl,
                    Price = price,
                    PriceFormatted = await _priceFormatter.FormatPriceAsync(price),
                    IsInStock = await _productService.GetTotalStockQuantityAsync(product) > 0,
                    RatingAverage = product.ApprovedRatingSum > 0 && product.ApprovedTotalReviews > 0
                        ? (double)product.ApprovedRatingSum / product.ApprovedTotalReviews : null,
                    TotalReviews = product.ApprovedTotalReviews
                });
            }

            var result = new PagedResultDto<ProductListItemDto>
            {
                Items = items,
                PageIndex = products.PageIndex,
                PageSize = products.PageSize,
                TotalCount = products.TotalCount,
                TotalPages = products.TotalPages
            };

            return Ok(result);
        }

        private async Task<VendorDto> MapVendorAsync(Nop.Core.Domain.Vendors.Vendor vendor)
        {
            var picture = await _pictureService.GetPictureByIdAsync(vendor.PictureId);
            var (pictureUrl, _) = picture != null ? await _pictureService.GetPictureUrlAsync(picture) : (string.Empty, null);

            return new VendorDto
            {
                Id = vendor.Id,
                Name = vendor.Name,
                Description = vendor.Description,
                Email = vendor.Email,
                PictureUrl = pictureUrl,
                SeName = await _urlRecordService.GetSeNameAsync(vendor)
            };
        }
    }
}
