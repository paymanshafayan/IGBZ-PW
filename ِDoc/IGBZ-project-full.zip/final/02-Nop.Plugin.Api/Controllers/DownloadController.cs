using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Api.DTOs.Download;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Media;
using Nop.Services.Orders;

namespace Nop.Plugin.Api.Controllers
{
    /// <summary>
    /// مدیریت محصولات دیجیتال/دانلودی (ویدئو، فایل صوتی، کتاب الکترونیک، آرشیو و...) خریداری‌شده توسط کاربر.
    /// معادل بخش "Downloadable Products" در پنل کاربری نسخه وب nopCommerce.
    /// </summary>
    public class DownloadController : AuthorizedApiController
    {
        private readonly IOrderService _orderService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IProductService _productService;
        private readonly IDownloadService _downloadService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IPictureService _pictureService;

        public DownloadController(
            IOrderService orderService,
            IOrderProcessingService orderProcessingService,
            IProductService productService,
            IDownloadService downloadService,
            IGenericAttributeService genericAttributeService,
            IPictureService pictureService)
        {
            _orderService = orderService;
            _orderProcessingService = orderProcessingService;
            _productService = productService;
            _downloadService = downloadService;
            _genericAttributeService = genericAttributeService;
            _pictureService = pictureService;
        }

        /// <summary>لیست همه محصولات دیجیتالی که کاربر جاری خریداری کرده (از تمام سفارش‌ها)</summary>
        [HttpGet("my-products")]
        public async Task<IActionResult> GetMyDownloadableProducts()
        {
            var customer = await GetCurrentApiCustomerAsync();
            var orders = await _orderService.SearchOrdersAsync(customerId: customer.Id, pageSize: int.MaxValue);

            var result = new List<DownloadableProductDto>();

            foreach (var order in orders)
            {
                var orderItems = await _orderService.GetOrderItemsAsync(order.Id, isNotReturnable: false);
                foreach (var orderItem in orderItems)
                {
                    var product = await _productService.GetProductByIdAsync(orderItem.ProductId);
                    if (product == null || !product.IsDownload)
                        continue;

                    result.Add(await MapAsync(order, orderItem, product, customer.Id));
                }
            }

            return Ok(result);
        }

        /// <summary>متن قرارداد/توافق‌نامه استفاده از محصول (در صورتی که محصول نیازمند آن باشد)</summary>
        [HttpGet("license/{orderItemId:int}")]
        public async Task<IActionResult> GetLicenseAgreement(int orderItemId)
        {
            var (orderItem, product, error) = await ValidateOwnershipAsync(orderItemId);
            if (error != null) return error;

            if (!product.HasUserAgreement)
                return Fail("این محصول نیازی به پذیرش قرارداد ندارد.");

            return Ok(new LicenseAgreementDto
            {
                OrderItemId = orderItem.Id,
                ProductName = product.Name,
                AgreementText = product.UserAgreementText
            });
        }

        /// <summary>پذیرش قرارداد/توافق‌نامه استفاده - پیش‌نیاز دانلود محصولاتی که HasUserAgreement=true دارند</summary>
        [HttpPost("license/{orderItemId:int}/accept")]
        public async Task<IActionResult> AcceptLicenseAgreement(int orderItemId)
        {
            var (orderItem, product, error) = await ValidateOwnershipAsync(orderItemId);
            if (error != null) return error;

            var customer = await GetCurrentApiCustomerAsync();
            await _genericAttributeService.SaveAttributeAsync(customer, LicenseAttributeKey(orderItemId), true);

            return Ok<object>(null, "قرارداد با موفقیت پذیرفته شد. اکنون می‌توانید فایل را دانلود کنید.");
        }

        /// <summary>دانلود فایل اصلی محصول دیجیتال (استریم باینری، نه پاسخ JSON استاندارد)</summary>
        [HttpGet("file/{orderItemId:int}")]
        public async Task<IActionResult> DownloadFile(int orderItemId)
        {
            var (orderItem, product, error) = await ValidateOwnershipAsync(orderItemId);
            if (error != null) return error;

            if (!_orderProcessingService.IsDownloadAllowed(orderItem))
                return Fail("دانلود این فایل مجاز نیست (سفارش هنوز تسویه نشده یا محدودیت تعداد دانلود به پایان رسیده است).", 403);

            if (product.HasUserAgreement)
            {
                var customer = await GetCurrentApiCustomerAsync();
                var accepted = await _genericAttributeService.GetAttributeAsync<bool>(customer, LicenseAttributeKey(orderItemId));
                if (!accepted)
                    return Fail("ابتدا باید قرارداد استفاده را بپذیرید.", 403);
            }

            var download = await _downloadService.GetDownloadByIdAsync(product.DownloadId);
            if (download == null)
                return NotFoundResult("فایل دانلود یافت نشد.");

            if (download.UseDownloadUrl)
                return Ok(new { redirectUrl = download.DownloadUrl }, "این فایل روی یک آدرس خارجی میزبانی می‌شود.");

            // افزایش شمارنده دانلود (مطابق منطق nopCommerce)
            orderItem.DownloadCount++;
            await _orderService.UpdateOrderItemAsync(orderItem);

            var fileName = (product.Name ?? "download") + (download.Extension ?? string.Empty);
            return File(download.DownloadBinary, string.IsNullOrEmpty(download.ContentType) ? "application/octet-stream" : download.ContentType, fileName);
        }

        /// <summary>دانلود فایل نمونه (Sample) - در صورت وجود، بدون نیاز به خرید قابل دریافت است</summary>
        [HttpGet("sample/{productId:int}")]
        [AllowAnonymous]
        public async Task<IActionResult> DownloadSample(int productId)
        {
            var product = await _productService.GetProductByIdAsync(productId);
            if (product == null || !product.HasSampleDownload)
                return NotFoundResult("فایل نمونه‌ای برای این محصول وجود ندارد.");

            var download = await _downloadService.GetDownloadByIdAsync(product.SampleDownloadId);
            if (download == null || download.UseDownloadUrl)
                return NotFoundResult("فایل نمونه در دسترس نیست.");

            var fileName = "sample-" + (product.Name ?? "download") + (download.Extension ?? string.Empty);
            return File(download.DownloadBinary, string.IsNullOrEmpty(download.ContentType) ? "application/octet-stream" : download.ContentType, fileName);
        }

        // ---------------- کمکی ----------------

        private static string LicenseAttributeKey(int orderItemId) => $"Api.LicenseAccepted.{orderItemId}";

        private async Task<(OrderItem orderItem, Nop.Core.Domain.Catalog.Product product, IActionResult error)> ValidateOwnershipAsync(int orderItemId)
        {
            var customer = await GetCurrentApiCustomerAsync();
            var orderItem = await _orderService.GetOrderItemByIdAsync(orderItemId);
            if (orderItem == null)
                return (null, null, NotFoundResult("مورد سفارش یافت نشد."));

            var order = await _orderService.GetOrderByIdAsync(orderItem.OrderId);
            if (order == null || order.CustomerId != customer.Id)
                return (null, null, Fail("این محصول متعلق به شما نیست.", 403));

            var product = await _productService.GetProductByIdAsync(orderItem.ProductId);
            if (product == null || !product.IsDownload)
                return (null, null, Fail("این محصول قابل دانلود نیست.", 400));

            return (orderItem, product, null);
        }

        private async Task<DownloadableProductDto> MapAsync(Nop.Core.Domain.Orders.Order order, OrderItem orderItem, Nop.Core.Domain.Catalog.Product product, int customerId)
        {
            var download = product.DownloadId > 0 ? await _downloadService.GetDownloadByIdAsync(product.DownloadId) : null;
            var picture = (await _productService.GetProductPicturesByProductIdAsync(product.Id)).FirstOrDefault();
            var pictureEntity = picture != null ? await _pictureService.GetPictureByIdAsync(picture.PictureId) : null;
            var (pictureUrl, _) = pictureEntity != null ? await _pictureService.GetPictureUrlAsync(pictureEntity) : (string.Empty, null);

            var licenseAccepted = false;
            if (product.HasUserAgreement)
            {
                var customer = await GetCurrentApiCustomerAsync();
                licenseAccepted = await _genericAttributeService.GetAttributeAsync<bool>(customer, LicenseAttributeKey(orderItem.Id));
            }

            return new DownloadableProductDto
            {
                OrderItemId = orderItem.Id,
                OrderId = order.Id,
                CustomOrderNumber = order.CustomOrderNumber,
                ProductId = product.Id,
                ProductName = product.Name,
                PictureUrl = pictureUrl,
                IsDownloadAllowed = _orderProcessingService.IsDownloadAllowed(orderItem) && (!product.HasUserAgreement || licenseAccepted),
                RequiresLicenseAgreement = product.HasUserAgreement,
                LicenseAccepted = licenseAccepted,
                DownloadCount = orderItem.DownloadCount,
                MaxNumberOfDownloads = product.UnlimitedDownloads ? 0 : product.MaxNumberOfDownloads,
                FileName = download?.Filename,
                ContentType = download?.ContentType,
                FileSizeBytes = download?.DownloadBinary?.LongLength ?? 0,
                HasSampleDownload = product.HasSampleDownload,
                MediaKind = DetectMediaKind(download?.ContentType, download?.Extension)
            };
        }

        private static DigitalMediaKind DetectMediaKind(string contentType, string extension)
        {
            var ext = (extension ?? string.Empty).ToLowerInvariant();
            var type = (contentType ?? string.Empty).ToLowerInvariant();

            if (type.StartsWith("video") || new[] { ".mp4", ".mkv", ".mov", ".avi", ".webm" }.Contains(ext))
                return DigitalMediaKind.Video;
            if (type.StartsWith("audio") || new[] { ".mp3", ".wav", ".m4a", ".aac", ".flac" }.Contains(ext))
                return DigitalMediaKind.Audio;
            if (new[] { ".pdf", ".epub", ".mobi" }.Contains(ext))
                return DigitalMediaKind.Ebook;
            if (new[] { ".zip", ".rar", ".7z" }.Contains(ext))
                return DigitalMediaKind.Archive;

            return DigitalMediaKind.Other;
        }
    }
}
