using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.Api.DTOs.Auth
{
    public class LoginRequestDto
    {
        [Required] public string Email { get; set; }
        [Required] public string Password { get; set; }

        /// <summary>شناسه دستگاه (اختیاری) - برای مدیریت چند دستگاه در اپ فلاتر</summary>
        public string DeviceId { get; set; }
    }

    public class RegisterRequestDto
    {
        [Required] public string FirstName { get; set; }
        [Required] public string LastName { get; set; }
        [Required, EmailAddress] public string Email { get; set; }
        [Required, MinLength(6)] public string Password { get; set; }
        public string PhoneNumber { get; set; }
    }

    public class RefreshTokenRequestDto
    {
        [Required] public string AccessToken { get; set; }
        [Required] public string RefreshToken { get; set; }
    }

    public class TokenResponseDto
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public System.DateTime AccessTokenExpiresOnUtc { get; set; }
        public int CustomerId { get; set; }

        /// <summary>
        /// اگر این حساب صاحب یک فروشگاه (Tenant Store Owner) باشد، شناسهٔ همان فروشگاه؛
        /// در غیر این صورت null. اپ ادمین این مقدار را ذخیره و به‌عنوان X-Store-Id در همهٔ
        /// درخواست‌های بعدی می‌فرستد. اپ مشتریان به‌جای این، از فلوی شمارهٔ موبایل استفاده می‌کند.
        /// </summary>
        public int? OwnedStoreId { get; set; }
    }

    public class ChangePasswordRequestDto
    {
        [Required] public string OldPassword { get; set; }
        [Required, MinLength(6)] public string NewPassword { get; set; }
    }

    public class ForgotPasswordRequestDto
    {
        [Required, EmailAddress] public string Email { get; set; }
    }

    public class ResetPasswordRequestDto
    {
        [Required] public string Token { get; set; }
        [Required] public string Email { get; set; }
        [Required, MinLength(6)] public string NewPassword { get; set; }
    }
}
