using System;
using System.Collections.Generic;

namespace Nop.Plugin.Api.DTOs.Blog
{
    public class BlogPostListItemDto
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public string SeName { get; set; }
        public DateTime? StartDateUtc { get; set; }
        public DateTime CreatedOnUtc { get; set; }
        public int CommentCount { get; set; }
        public List<string> Tags { get; set; } = new List<string>();
    }

    public class BlogPostDto : BlogPostListItemDto
    {
        public List<BlogCommentDto> Comments { get; set; } = new List<BlogCommentDto>();
    }

    public class BlogCommentDto
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string CommentText { get; set; }
        public DateTime CreatedOnUtc { get; set; }
    }

    public class AddBlogCommentRequestDto
    {
        public string CommentText { get; set; }
    }
}
