using System;
using System.Collections.Generic;
using Nop.Plugin.Api.DTOs.Order;

namespace Nop.Plugin.Api.DTOs.Admin
{
    /// <summary>خلاصهٔ وضعیت فروشگاه برای صفحهٔ اول اپلیکیشن ادمین</summary>
    public class AdminDashboardDto
    {
        public string StoreName { get; set; }
        public int TotalProducts { get; set; }
        public int OrdersToday { get; set; }
        public int OrdersThisMonth { get; set; }
        public decimal RevenueToday { get; set; }
        public decimal RevenueThisMonth { get; set; }
        public string RevenueThisMonthFormatted { get; set; }
        public int PendingOrdersCount { get; set; }
        public string SubscriptionStatus { get; set; }
        public DateTime? SubscriptionRenewsOnUtc { get; set; }
    }

    /// <summary>ردیف سفارش در لیست ادمین - همان OrderListItemDto مشتری، به‌علاوهٔ مشخصات مشتری</summary>
    public class AdminOrderListItemDto : OrderListItemDto
    {
        public int CustomerId { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerFullName { get; set; }
    }

    public class AdminOrderDetailDto : AdminOrderListItemDto
    {
        public string ShippingAddressText { get; set; }
        public string CustomerPhone { get; set; }
        public List<AdminOrderItemDto> Items { get; set; } = new List<AdminOrderItemDto>();
        public List<AdminOrderNoteDto> Notes { get; set; } = new List<AdminOrderNoteDto>();
    }

    public class AdminOrderItemDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal LineTotal { get; set; }
    }

    public class AdminOrderNoteDto
    {
        public string Note { get; set; }
        public bool DisplayToCustomer { get; set; }
        public System.DateTime CreatedOnUtc { get; set; }
    }

    public class AdminOrderStatusUpdateRequestDto
    {
        /// <summary>یکی از: Pending, Processing, Complete, Cancelled</summary>
        public string OrderStatus { get; set; }

        public string AdminNote { get; set; }
    }

    /// <summary>درخواست ایجاد/ویرایش محصول از اپ ادمین. فیلدهای Store-محدودسازی به‌صورت خودکار
    /// توسط ProductStoreIsolationConsumer در پلاگین فروشگاه‌ساز اعمال می‌شود - نیازی به ارسال از اپ نیست.</summary>
    public class AdminProductUpsertRequestDto
    {
        public string Name { get; set; }
        public string ShortDescription { get; set; }
        public string FullDescription { get; set; }
        public string Sku { get; set; }
        public decimal Price { get; set; }
        public decimal? OldPrice { get; set; }
        public int StockQuantity { get; set; }
        public bool Published { get; set; } = true;
        public List<int> CategoryIds { get; set; } = new List<int>();
    }

    public class AdminProductListItemDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Sku { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public bool Published { get; set; }
    }

    // ==================== Categories ====================

    public class AdminCategoryDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool Published { get; set; }
        public int DisplayOrder { get; set; }
        public int ParentCategoryId { get; set; }
    }

    /// <summary>مثل محصول: نیازی به فرستادن StoreId نیست - CategoryStoreIsolationConsumer آن را
    /// خودکار بر اساس X-Store-Id هدر جاری اعمال می‌کند.</summary>
    public class AdminCategoryUpsertRequestDto
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public bool Published { get; set; } = true;
        public int DisplayOrder { get; set; }
        public int ParentCategoryId { get; set; }
    }

    // ==================== Customers ====================

    /// <summary>فقط مشتریانی که حداقل یک سفارش در همین فروشگاه ثبت کرده‌اند - این اپ حساب‌های
    /// مشتریان را نمی‌سازد/حذف نمی‌کند، فقط برای دیدن سابقهٔ خرید است.</summary>
    public class AdminCustomerListItemDto
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public string PhoneNumber { get; set; }
        public int OrderCount { get; set; }
        public decimal TotalSpent { get; set; }
        public DateTime? LastOrderOnUtc { get; set; }
    }

    public class AdminCustomerDetailDto : AdminCustomerListItemDto
    {
        public List<OrderListItemDto> Orders { get; set; } = new List<OrderListItemDto>();
    }

    // ==================== Shipments ====================

    public class AdminShipmentCreateRequestDto
    {
        public string TrackingNumber { get; set; }

        /// <summary>اگر خالی/null باشد، همهٔ اقلام باقی‌ماندهٔ سفارش ارسال می‌شوند</summary>
        public List<AdminShipmentItemRequestDto> Items { get; set; }
    }

    public class AdminShipmentItemRequestDto
    {
        public int OrderItemId { get; set; }
        public int Quantity { get; set; }
    }

    // ==================== Discounts ====================

    /// <summary>
    /// NOTE: در نسخهٔ پایهٔ nopCommerce، موجودیت Discount خودش فیلد StoreId/LimitedToStores
    /// ندارد (بر خلاف Product/Category/Manufacturer). به همین دلیل مالکیت هر Discount با یک
    /// Generic Attribute اختصاصی (DiscountOwnerStoreIdKey در AdminDiscountsController) ردیابی
    /// می‌شود، نه با مکانیزم استاندارد Store Mapping. قبل از تکیه کردن، این فرض را با نسخهٔ
    /// نصب‌شدهٔ 4.90 دوباره چک کنید - اگر Discount در نسخهٔ شما Store Mapping بومی دارد،
    /// به‌جای Generic Attribute از همان استفاده کنید.
    /// </summary>
    public class AdminDiscountDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string DiscountType { get; set; }
        public decimal DiscountPercentage { get; set; }
        public decimal DiscountAmount { get; set; }
        public bool UsePercentage { get; set; }
        public string CouponCode { get; set; }
        public DateTime? StartDateUtc { get; set; }
        public DateTime? EndDateUtc { get; set; }
    }

    public class AdminDiscountUpsertRequestDto
    {
        public string Name { get; set; }
        public bool UsePercentage { get; set; }
        public decimal DiscountPercentage { get; set; }
        public decimal DiscountAmount { get; set; }
        public string CouponCode { get; set; }
        public DateTime? StartDateUtc { get; set; }
        public DateTime? EndDateUtc { get; set; }

        /// <summary>یکی از: AssignedToSkus, AssignedToCategories, AssignedToManufacturers, AssignedToOrderTotal</summary>
        public string DiscountType { get; set; } = "AssignedToOrderTotal";
    }

    /// <summary>برندینگ فروشگاه (رنگ + لوگو) - نمایش‌داده‌شده در بخش «تنظیمات» اپ ادمین</summary>
    public class AdminStoreSettingsDto
    {
        /// <summary>هگز رنگ برند، مثل "#2F80ED"، یا null اگر هنوز تنظیم نشده</summary>
        public string BrandColorHex { get; set; }

        /// <summary>null اگر لوگویی آپلود نشده</summary>
        public string LogoUrl { get; set; }
    }

    /// <summary>
    /// هر دو فیلد اختیاری‌اند و مستقل از هم اعمال می‌شوند: صاحب فروشگاه می‌تواند فقط رنگ را
    /// عوض کند بدون این‌که لوگو را دوباره بفرستد، یا برعکس.
    /// </summary>
    public class UpdateAdminStoreSettingsRequestDto
    {
        /// <summary>هگز رنگ، مثل "#2F80ED". اگر null باشد، رنگ فعلی دست‌نخورده می‌ماند.</summary>
        public string BrandColorHex { get; set; }

        /// <summary>
        /// بایت‌های تصویر لوگو به‌صورت Base64 (بدون پیشوند data:...;base64,). اگر null باشد،
        /// لوگوی فعلی دست‌نخورده می‌ماند. برای حذف کامل لوگو، RemoveLogo را true بفرستید.
        /// </summary>
        public string LogoBase64 { get; set; }

        /// <summary>مثل "image/png" یا "image/jpeg" - وقتی LogoBase64 پر شده الزامی است</summary>
        public string LogoMimeType { get; set; }

        public bool RemoveLogo { get; set; }
    }
}
