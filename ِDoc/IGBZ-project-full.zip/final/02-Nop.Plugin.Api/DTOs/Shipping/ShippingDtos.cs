using System;
using System.Collections.Generic;

namespace Nop.Plugin.Api.DTOs.Shipping
{
    public class CountryDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string TwoLetterIsoCode { get; set; }
        public string ThreeLetterIsoCode { get; set; }
        public bool AllowsBilling { get; set; }
        public bool AllowsShipping { get; set; }
    }

    public class StateProvinceDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Abbreviation { get; set; }
    }

    public class ShipmentItemDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
    }

    public class ShipmentDto
    {
        public int Id { get; set; }
        public string TrackingNumber { get; set; }
        public string TrackingUrl { get; set; }
        public DateTime? ShippedOnUtc { get; set; }
        public DateTime? DeliveredOnUtc { get; set; }
        public List<ShipmentItemDto> Items { get; set; } = new List<ShipmentItemDto>();
    }

    public class OrderTrackingDto
    {
        public int OrderId { get; set; }
        public string ShippingStatus { get; set; }
        public string ShippingMethod { get; set; }
        public List<ShipmentDto> Shipments { get; set; } = new List<ShipmentDto>();
    }
}
