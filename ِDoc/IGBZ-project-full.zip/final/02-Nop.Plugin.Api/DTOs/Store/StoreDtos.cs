namespace Nop.Plugin.Api.DTOs.Store
{
    public class ResolveStoreRequestDto
    {
        public string PhoneNumber { get; set; }
    }

    public class ResolveStoreResultDto
    {
        public bool Found { get; set; }
        public int? StoreId { get; set; }
    }

    /// <summary>Branding/config used by the app to look and feel like it belongs to this store</summary>
    public class StoreConfigDto
    {
        public int StoreId { get; set; }
        public string Name { get; set; }
        public string Domain { get; set; }

        /// <summary>Null if the store has no logo configured - the app falls back to its own default icon</summary>
        public string LogoUrl { get; set; }

        /// <summary>Hex color (e.g. "#2F80ED"), null if not configured - the app falls back to its own default</summary>
        public string BrandColorHex { get; set; }
    }
}
