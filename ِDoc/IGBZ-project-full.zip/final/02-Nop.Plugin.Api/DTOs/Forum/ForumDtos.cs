using System;
using System.Collections.Generic;

namespace Nop.Plugin.Api.DTOs.Forum
{
    public class ForumGroupDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<ForumDto> Forums { get; set; } = new List<ForumDto>();
    }

    public class ForumDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int NumTopics { get; set; }
        public int NumPosts { get; set; }
        public DateTime? LastPostTime { get; set; }
    }

    public class ForumTopicListItemDto
    {
        public int Id { get; set; }
        public string Subject { get; set; }
        public string CustomerName { get; set; }
        public int NumReplies { get; set; }
        public int Views { get; set; }
        public DateTime CreatedOnUtc { get; set; }
        public bool IsLocked { get; set; }
        public bool IsPinned { get; set; }
    }

    public class ForumPostDto
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string Text { get; set; }
        public DateTime CreatedOnUtc { get; set; }
    }

    public class ForumTopicDto : ForumTopicListItemDto
    {
        public List<ForumPostDto> Posts { get; set; } = new List<ForumPostDto>();
    }

    public class CreateForumTopicRequestDto
    {
        public int ForumId { get; set; }
        public string Subject { get; set; }
        public string Text { get; set; }
        public string TopicType { get; set; } = "Normal"; // Normal, Sticky, Announcement
    }

    public class CreateForumPostRequestDto
    {
        public string Text { get; set; }
    }
}
