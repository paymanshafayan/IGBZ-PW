using System;

namespace Nop.Plugin.Api.DTOs.Payment
{
    public class PaymentStatusDto
    {
        public int OrderId { get; set; }
        public string CustomOrderNumber { get; set; }
        public string OrderStatus { get; set; }
        public string PaymentStatus { get; set; }
        public bool IsPaid { get; set; }
        public decimal OrderTotal { get; set; }
        public string OrderTotalFormatted { get; set; }
        public string PaymentMethod { get; set; }
        /// <summary>در صورتی که روش پرداخت انتخاب‌شده نیازمند هدایت به درگاه (Redirect) باشد،
        /// آدرس بازگشت (Return URL) که باید در Deep Link اپ فلاتر مدیریت شود</summary>
        public string RedirectUrl { get; set; }
    }

    /// <summary>
    /// درخواستی که اپلیکیشن فلاتر پس از هدایت‌شدن به صفحه بازگشتِ درگاه (Return URL) ارسال می‌کند
    /// تا وضعیت پرداخت نهایی شود (برای درگاه‌هایی که تأییدشان از طریق کلاینت هم قابل انجام است).
    /// توجه: مسیر امن‌تر، تأیید سمت سرور از طریق Webhook درگاه است (به PaymentWebhookRequestDto نگاه کنید).
    /// </summary>
    public class ConfirmClientPaymentRequestDto
    {
        public int OrderId { get; set; }
        public string GatewayTransactionId { get; set; }
        public string GatewayAuthority { get; set; }
    }

    /// <summary>
    /// بدنه استاندارد Webhook که یک پلاگین/سرویس درگاه پرداخت (مثلاً زرین‌پال) باید سرور-به-سرور
    /// به این اندپوینت ارسال کند تا سفارش به‌عنوان پرداخت‌شده یا ناموفق علامت‌گذاری شود.
    /// این اندپوینت با JWT کاربر محافظت نمی‌شود؛ به‌جای آن با هدر X-Webhook-Secret اعتبارسنجی می‌شود.
    /// </summary>
    public class PaymentWebhookRequestDto
    {
        public Guid OrderGuid { get; set; }
        public bool IsSuccess { get; set; }
        public string GatewayTransactionId { get; set; }
        public string GatewayReferenceId { get; set; }
        public decimal? PaidAmount { get; set; }
        public string FailureReason { get; set; }
    }
}
