using System;
using System.Collections.Generic;

namespace Nop.Plugin.Api.DTOs.Catalog
{
    public class CategoryDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string PictureUrl { get; set; }
        public int? ParentCategoryId { get; set; }
        public string SeName { get; set; }
        public int DisplayOrder { get; set; }
        public int ProductCount { get; set; }
    }

    public class ManufacturerDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string PictureUrl { get; set; }
        public string SeName { get; set; }
    }

    public class ProductListItemDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ShortDescription { get; set; }
        public string SeName { get; set; }
        public string PictureUrl { get; set; }
        public decimal Price { get; set; }
        public decimal? OldPrice { get; set; }
        public string PriceFormatted { get; set; }
        public bool IsInStock { get; set; }
        public double? RatingAverage { get; set; }
        public int TotalReviews { get; set; }
    }

    public class ProductDto : ProductListItemDto
    {
        public string FullDescription { get; set; }
        public string Sku { get; set; }
        public List<string> PictureUrls { get; set; } = new List<string>();
        public List<CategoryDto> Categories { get; set; } = new List<CategoryDto>();
        public ManufacturerDto Manufacturer { get; set; }
        public List<ProductAttributeDto> Attributes { get; set; } = new List<ProductAttributeDto>();
        public List<ProductSpecificationDto> Specifications { get; set; } = new List<ProductSpecificationDto>();
        public List<ProductListItemDto> RelatedProducts { get; set; } = new List<ProductListItemDto>();
        public bool CallForPrice { get; set; }
        public int StockQuantity { get; set; }

        /// <summary>آیا این یک محصول دیجیتال/دانلودی است (ویدئو، صدا، کتاب الکترونیک و...) - مطابق Product.IsDownload در nopCommerce</summary>
        public bool IsDownload { get; set; }
    }

    public class ProductAttributeDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsRequired { get; set; }
        public string ControlType { get; set; }
        public List<ProductAttributeValueDto> Values { get; set; } = new List<ProductAttributeValueDto>();
    }

    public class ProductAttributeValueDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal PriceAdjustment { get; set; }
        public bool IsPreSelected { get; set; }
    }

    public class ProductSpecificationDto
    {
        public string GroupName { get; set; }
        public string AttributeName { get; set; }
        public string ValueText { get; set; }
    }

    public class ProductReviewDto
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string Title { get; set; }
        public string ReviewText { get; set; }
        public int Rating { get; set; }
        public DateTime CreatedOnUtc { get; set; }
    }

    public class AddProductReviewRequestDto
    {
        public string Title { get; set; }
        public string ReviewText { get; set; }
        public int Rating { get; set; }
    }

    public class ProductSearchRequestDto
    {
        public string Keyword { get; set; }
        public int? CategoryId { get; set; }
        public int? ManufacturerId { get; set; }
        public decimal? PriceFrom { get; set; }
        public decimal? PriceTo { get; set; }
        public string OrderBy { get; set; } // Position, NameAsc, NameDesc, PriceAsc, PriceDesc, CreatedOnDesc
        public int PageIndex { get; set; } = 0;
        public int PageSize { get; set; } = 20;
    }
}
