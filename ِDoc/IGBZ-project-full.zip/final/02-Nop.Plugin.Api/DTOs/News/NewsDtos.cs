using System;
using System.Collections.Generic;

namespace Nop.Plugin.Api.DTOs.News
{
    public class NewsItemListDto
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Short { get; set; }
        public string SeName { get; set; }
        public DateTime CreatedOnUtc { get; set; }
        public int CommentCount { get; set; }
    }

    public class NewsItemDto : NewsItemListDto
    {
        public string Full { get; set; }
        public List<NewsCommentDto> Comments { get; set; } = new List<NewsCommentDto>();
    }

    public class NewsCommentDto
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string Title { get; set; }
        public string CommentText { get; set; }
        public DateTime CreatedOnUtc { get; set; }
    }

    public class AddNewsCommentRequestDto
    {
        public string Title { get; set; }
        public string CommentText { get; set; }
    }
}
