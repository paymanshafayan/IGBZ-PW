using System.Collections.Generic;

namespace Nop.Plugin.Api.DTOs.Checkout
{
    public class ShippingOptionDto
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Rate { get; set; }
        public string RateFormatted { get; set; }
        public string ShippingRateComputationMethodSystemName { get; set; }
    }

    public class PaymentMethodDto
    {
        public string SystemName { get; set; }
        public string FriendlyName { get; set; }
        public string Description { get; set; }
        public string LogoUrl { get; set; }
    }

    public class CheckoutSummaryDto
    {
        public decimal SubTotal { get; set; }
        public string SubTotalFormatted { get; set; }
        public decimal? ShippingTotal { get; set; }
        public string ShippingTotalFormatted { get; set; }
        public decimal TaxTotal { get; set; }
        public string TaxTotalFormatted { get; set; }
        public decimal DiscountAmount { get; set; }
        public string DiscountAmountFormatted { get; set; }
        public decimal? Total { get; set; }
        public string TotalFormatted { get; set; }
        public bool RequiresShipping { get; set; }
        public List<string> AppliedDiscountCodes { get; set; } = new List<string>();
    }

    public class SelectShippingOptionRequestDto
    {
        public string ShippingOptionName { get; set; }
        public string ShippingRateComputationMethodSystemName { get; set; }
    }

    public class SelectPaymentMethodRequestDto
    {
        public string PaymentMethodSystemName { get; set; }
    }

    public class PlaceOrderRequestDto
    {
        public int BillingAddressId { get; set; }
        public int? ShippingAddressId { get; set; }
        public string PaymentMethodSystemName { get; set; }
        public string ShippingOptionName { get; set; }
        public string ShippingRateComputationMethodSystemName { get; set; }
        public string CustomerComment { get; set; }
    }

    public class PlaceOrderResultDto
    {
        public bool Success { get; set; }
        public int OrderId { get; set; }
        public string CustomOrderNumber { get; set; }
        public decimal OrderTotal { get; set; }
        public string OrderTotalFormatted { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
    }
}
