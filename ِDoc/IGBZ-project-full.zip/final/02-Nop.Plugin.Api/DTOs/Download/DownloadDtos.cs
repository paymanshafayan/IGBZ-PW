using System;

namespace Nop.Plugin.Api.DTOs.Download
{
    /// <summary>نوع محتوای دیجیتال، برای تصمیم‌گیری در اپ موبایل که چه پخش‌کننده/نمایشگری استفاده شود</summary>
    public enum DigitalMediaKind
    {
        Other = 0,
        Video = 1,
        Audio = 2,
        Ebook = 3,       // pdf, epub
        Archive = 4       // zip و مشابه
    }

    public class DownloadableProductDto
    {
        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public string CustomOrderNumber { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string PictureUrl { get; set; }

        /// <summary>آیا در حال حاضر دانلود مجاز است (سفارش پرداخت‌شده + محدودیت تعداد دانلود رعایت شده + قرارداد پذیرفته شده)</summary>
        public bool IsDownloadAllowed { get; set; }

        /// <summary>آیا این محصول نیاز به پذیرش قرارداد/توافق‌نامه استفاده دارد</summary>
        public bool RequiresLicenseAgreement { get; set; }

        /// <summary>آیا کاربر قبلاً قرارداد را پذیرفته است</summary>
        public bool LicenseAccepted { get; set; }

        public int DownloadCount { get; set; }

        /// <summary>صفر یعنی نامحدود</summary>
        public int MaxNumberOfDownloads { get; set; }

        public string FileName { get; set; }
        public string ContentType { get; set; }
        public long FileSizeBytes { get; set; }
        public bool HasSampleDownload { get; set; }
        public DigitalMediaKind MediaKind { get; set; }
    }

    public class LicenseAgreementDto
    {
        public int OrderItemId { get; set; }
        public string ProductName { get; set; }
        public string AgreementText { get; set; }
    }
}
