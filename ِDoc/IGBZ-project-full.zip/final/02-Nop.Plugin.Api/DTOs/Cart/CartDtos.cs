using System;
using System.Collections.Generic;

namespace Nop.Plugin.Api.DTOs.Cart
{
    public class ShoppingCartItemDto
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductSeName { get; set; }
        public string PictureUrl { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal SubTotal { get; set; }
        public string UnitPriceFormatted { get; set; }
        public string SubTotalFormatted { get; set; }
        public List<string> AttributeDescriptions { get; set; } = new List<string>();
        public List<string> Warnings { get; set; } = new List<string>();
    }

    public class ShoppingCartDto
    {
        public List<ShoppingCartItemDto> Items { get; set; } = new List<ShoppingCartItemDto>();
        public decimal SubTotal { get; set; }
        public string SubTotalFormatted { get; set; }
        public decimal? Discount { get; set; }
        public decimal? Total { get; set; }
        public string TotalFormatted { get; set; }
        public int TotalItemsCount { get; set; }
        public List<string> AppliedDiscountCodes { get; set; } = new List<string>();
    }

    public class AddToCartRequestDto
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; } = 1;
        /// <summary>مقادیر ویژگی‌های محصول به‌صورت key=ProductAttributeMappingId, value=Value</summary>
        public Dictionary<int, string> AttributeValues { get; set; } = new Dictionary<int, string>();
    }

    public class UpdateCartItemDto
    {
        public int Quantity { get; set; }
    }

    public class ApplyDiscountCodeRequestDto
    {
        public string CouponCode { get; set; }
    }

    public class WishlistItemDto
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string PictureUrl { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public bool IsInStock { get; set; }
    }
}
