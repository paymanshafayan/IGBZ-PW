using System;
using System.Collections.Generic;

namespace Nop.Plugin.Api.DTOs.Order
{
    public class OrderListItemDto
    {
        public int Id { get; set; }
        public string CustomOrderNumber { get; set; }
        public DateTime CreatedOnUtc { get; set; }
        public decimal OrderTotal { get; set; }
        public string OrderTotalFormatted { get; set; }
        public string OrderStatus { get; set; }
        public string PaymentStatus { get; set; }
        public string ShippingStatus { get; set; }
        public int TotalItems { get; set; }
    }

    public class OrderItemDto
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string PictureUrl { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public string UnitPriceFormatted { get; set; }
        public decimal SubTotal { get; set; }
        public string SubTotalFormatted { get; set; }
    }

    public class OrderDto : OrderListItemDto
    {
        public string BillingAddress { get; set; }
        public string ShippingAddress { get; set; }
        public string ShippingMethod { get; set; }
        public string PaymentMethod { get; set; }
        public decimal SubTotal { get; set; }
        public decimal ShippingTotal { get; set; }
        public decimal TaxTotal { get; set; }
        public decimal DiscountAmount { get; set; }
        public string CustomerComment { get; set; }
        public List<OrderItemDto> Items { get; set; } = new List<OrderItemDto>();
        public bool CanCancel { get; set; }
        public bool CanReturnItems { get; set; }
        public bool CanRePay { get; set; }
        public List<OrderNoteDto> Notes { get; set; } = new List<OrderNoteDto>();
    }

    public class OrderNoteDto
    {
        public string Note { get; set; }
        public DateTime CreatedOnUtc { get; set; }
    }

    public class ReturnRequestItemDto
    {
        public int OrderItemId { get; set; }
        public int Quantity { get; set; }
        public string ReasonForReturn { get; set; }
        public string RequestedAction { get; set; } // مثلاً "Refund" یا "Exchange"
    }

    public class CreateReturnRequestDto
    {
        public List<ReturnRequestItemDto> Items { get; set; } = new List<ReturnRequestItemDto>();
        public string CustomerComments { get; set; }
    }

    public class ReturnRequestDto
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public string ReturnStatus { get; set; }
        public DateTime CreatedOnUtc { get; set; }
    }
}
