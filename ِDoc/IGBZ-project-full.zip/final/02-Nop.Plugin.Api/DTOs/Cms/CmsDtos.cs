namespace Nop.Plugin.Api.DTOs.Cms
{
    public class TopicDto
    {
        public int Id { get; set; }
        public string SystemName { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public string SeName { get; set; }
        public string MetaTitle { get; set; }
        public string MetaDescription { get; set; }
        public string MetaKeywords { get; set; }
    }
}
