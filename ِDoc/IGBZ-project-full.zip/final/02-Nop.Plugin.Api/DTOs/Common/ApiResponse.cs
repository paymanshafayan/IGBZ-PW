using System.Collections.Generic;

namespace Nop.Plugin.Api.DTOs.Common
{
    /// <summary>
    /// قالب یکپارچه پاسخ برای همه اندپوینت‌های API (مناسب پارس شدن راحت در Flutter/Dart)
    /// </summary>
    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
        public List<string> Errors { get; set; }

        public static ApiResponse<T> Ok(T data, string message = null) =>
            new ApiResponse<T> { Success = true, Data = data, Message = message };

        public static ApiResponse<T> Fail(string message, List<string> errors = null) =>
            new ApiResponse<T> { Success = false, Message = message, Errors = errors ?? new List<string>() };
    }

    public class PagedResultDto<T>
    {
        public List<T> Items { get; set; } = new List<T>();
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public int TotalPages { get; set; }
        public bool HasPreviousPage => PageIndex > 0;
        public bool HasNextPage => PageIndex + 1 < TotalPages;
    }
}
