using System;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Nop.Core;
using Nop.Plugin.Misc.MultiTenantStores;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Common;
using Nop.Services.Customers;

namespace Nop.Plugin.Api.Filters
{
    /// <summary>
    /// SECURITY BOUNDARY (API side, third leg alongside TenantAdminScopeFilter and
    /// CrossStoreCustomerGuardFilter from the storefront plugin):
    ///
    /// AuthController only checks store ownership at Login/RefreshToken time. Because JWT access
    /// tokens are stateless, nothing stops a client from obtaining a valid token while X-Store-Id
    /// pointed at their own store, then sending that same still-valid access token again with a
    /// DIFFERENT X-Store-Id header on a later call (Cart/Checkout/Order/...). Without this filter,
    /// IStoreContext would happily resolve to the new store and let that identity act there.
    ///
    /// This filter re-checks, on every authenticated /api request, that the caller's account
    /// still belongs to (or owns) whatever store the current request resolves to - the same rule
    /// as AuthController.BelongsToCurrentStoreAsync, just enforced continuously instead of only
    /// at the door.
    /// </summary>
    public class ApiCrossStoreGuardFilter : IAsyncActionFilter
    {
        private readonly ICustomerService _customerService;
        private readonly IStoreContext _storeContext;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ITenantProvisioningService _tenantProvisioningService;

        public ApiCrossStoreGuardFilter(
            ICustomerService customerService,
            IStoreContext storeContext,
            IGenericAttributeService genericAttributeService,
            ITenantProvisioningService tenantProvisioningService)
        {
            _customerService = customerService;
            _storeContext = storeContext;
            _genericAttributeService = genericAttributeService;
            _tenantProvisioningService = tenantProvisioningService;
        }

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var request = context.HttpContext.Request;
            if (!request.Path.StartsWithSegments("/api", StringComparison.OrdinalIgnoreCase))
            {
                await next();
                return;
            }

            var user = context.HttpContext.User;
            if (user?.Identity == null || !user.Identity.IsAuthenticated)
            {
                // anonymous/public endpoints (catalog browsing, register, login) - nothing to check
                await next();
                return;
            }

            var customerIdClaim = user.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(customerIdClaim, out var customerId) || customerId <= 0)
            {
                await next();
                return;
            }

            var customer = await _customerService.GetCustomerByIdAsync(customerId);
            if (customer == null || !customer.Active || customer.Deleted)
            {
                context.Result = new ObjectResult(new { success = false, message = "حساب کاربری معتبر نیست." }) { StatusCode = 401 };
                return;
            }

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            var homeStoreId = await _genericAttributeService.GetAttributeAsync<int?>(customer, MultiTenantStoresDefaults.HomeStoreIdAttributeKey);

            if (homeStoreId is > 0 && homeStoreId.Value != currentStore.Id)
            {
                var ownedStoreId = await _tenantProvisioningService.GetOwnedStoreIdAsync(customer);
                if (!(ownedStoreId.HasValue && ownedStoreId.Value == currentStore.Id))
                {
                    context.Result = new ObjectResult(new { success = false, message = "این حساب متعلق به فروشگاه دیگری است." }) { StatusCode = 403 };
                    return;
                }
            }

            await next();
        }
    }
}
