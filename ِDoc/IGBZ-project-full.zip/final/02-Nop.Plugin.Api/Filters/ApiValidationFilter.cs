using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Nop.Plugin.Api.DTOs.Common;

namespace Nop.Plugin.Api.Filters
{
    /// <summary>
    /// پیش از اجرای هر اکشن، اگر برای نوع پارامتر ورودی یک IValidator&lt;T&gt; (FluentValidation) ثبت شده باشد،
    /// آن را به‌صورت خودکار اجرا می‌کند و در صورت نامعتبر بودن، پاسخ 400 استاندارد برمی‌گرداند.
    /// این کار نیاز به فراخوانی دستی Validate در تک‌تک اکشن‌ها را از بین می‌برد.
    /// </summary>
    public class ApiValidationFilter : IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            foreach (var argument in context.ActionArguments.Values)
            {
                if (argument == null)
                    continue;

                var argumentType = argument.GetType();
                var validatorType = typeof(IValidator<>).MakeGenericType(argumentType);

                if (context.HttpContext.RequestServices.GetService(validatorType) is IValidator validator)
                {
                    var validationContext = new ValidationContext<object>(argument);
                    var validationResult = await validator.ValidateAsync(validationContext);

                    if (!validationResult.IsValid)
                    {
                        var errors = validationResult.Errors.Select(e => e.ErrorMessage).ToList();
                        context.Result = new BadRequestObjectResult(
                            ApiResponse<object>.Fail("اطلاعات ارسالی نامعتبر است.", errors));
                        return;
                    }
                }
            }

            await next();
        }
    }
}
