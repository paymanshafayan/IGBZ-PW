using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Nop.Plugin.Api.DTOs.Common;
using Nop.Services.Logging;

namespace Nop.Plugin.Api.Filters
{
    /// <summary>
    /// فیلتر سراسری خطا: هر Exception مدیریت‌نشده در کنترلرهای API را می‌گیرد، در جدول Log فروشگاه
    /// (از طریق ILogger خود nopCommerce) ثبت می‌کند و به‌جای صفحه خطای HTML، پاسخ JSON استاندارد برمی‌گرداند.
    /// </summary>
    public class ApiExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            var logger = context.HttpContext.RequestServices.GetService(typeof(ILogger)) as ILogger;
            var workContext = context.HttpContext.RequestServices.GetService(typeof(Nop.Core.IWorkContext)) as Nop.Core.IWorkContext;

            // لاگ خطا به صورت async-fire-and-forget امن نیست؛ از نسخه sync استفاده می‌کنیم تا در فیلتر مسدود نشویم
            logger?.InsertLogAsync(LogLevel.Error,
                $"Nop.Plugin.Api - خطای مدیریت‌نشده در {context.HttpContext.Request.Path}",
                context.Exception.ToString())
                .GetAwaiter().GetResult();

#if DEBUG
            var message = context.Exception.Message;
#else
            var message = "خطای غیرمنتظره‌ای در سرور رخ داد. لطفاً بعداً دوباره تلاش کنید.";
#endif

            context.Result = new ObjectResult(ApiResponse<object>.Fail(message))
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };
            context.ExceptionHandled = true;
        }
    }
}
