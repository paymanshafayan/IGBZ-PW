using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Nop.Core;
using Nop.Plugin.Api.Domain;
using Nop.Plugin.Misc.MultiTenantStores.Infrastructure;
using Nop.Services.Configuration;

namespace Nop.Plugin.Api.Filters
{
    /// <summary>
    /// Every mobile app talks to ONE shared API domain and identifies its tenant via the
    /// "X-Store-Id" header (see MultiTenantStoreContext.StoreIdHeaderName in the store-builder
    /// plugin - that header is what makes IStoreContext resolve correctly here). This filter:
    ///  1. Rejects (400) any /api request missing that header or carrying an unknown store id -
    ///     fails loudly instead of silently falling back to some other store.
    ///  2. Rejects (403) requests for a store whose subscription has been suspended (see
    ///     TenantSubscriptionApiGateConsumer, which keeps ApiSettings.EnableApi per store in
    ///     sync with the subscription's status).
    /// </summary>
    public class ApiStoreGateFilter : IAsyncActionFilter
    {
        private readonly IStoreContext _storeContext;
        private readonly ISettingService _settingService;

        public ApiStoreGateFilter(IStoreContext storeContext, ISettingService settingService)
        {
            _storeContext = storeContext;
            _settingService = settingService;
        }

        /// <summary>
        /// این مسیرها معافند چون خودشان مسئول تشخیص/برگرداندن Store هستند، نه دریافت آن:
        /// merchant-login توسط اپ ادمین در همان اولین اجرا (قبل از این‌که اصلاً بداند صاحب کدام
        /// فروشگاه است) صدا زده می‌شود - نیازمندکردن X-Store-Id اینجا یک تناقض چرخشی بود.
        /// </summary>
        private static readonly string[] ExemptPaths =
        {
            "/api/v1/auth/merchant-login",
            // phase 3 store-detection (see StoreController): the app calls /store/resolve on
            // its very first launch, before it has ever learned a storeId, and /store/{id}/config
            // right after - requiring X-Store-Id on either would be circular.
            "/api/v1/store"
        };

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var request = context.HttpContext.Request;
            if (!request.Path.StartsWithSegments("/api", StringComparison.OrdinalIgnoreCase))
            {
                await next();
                return;
            }

            if (ExemptPaths.Any(p => request.Path.StartsWithSegments(p, StringComparison.OrdinalIgnoreCase)))
            {
                await next();
                return;
            }

            if (!request.Headers.TryGetValue(MultiTenantStoreContext.StoreIdHeaderName, out var headerValues) ||
                !int.TryParse(headerValues.ToString(), out var headerStoreId) || headerStoreId <= 0)
            {
                context.Result = new ObjectResult(new
                {
                    success = false,
                    message = $"هدر {MultiTenantStoreContext.StoreIdHeaderName} با شناسهٔ فروشگاه معتبر الزامی است."
                })
                { StatusCode = 400 };
                return;
            }

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            if (currentStore == null || currentStore.Id != headerStoreId)
            {
                context.Result = new ObjectResult(new { success = false, message = "فروشگاه مشخص‌شده یافت نشد." }) { StatusCode = 404 };
                return;
            }

            var apiSettings = await _settingService.LoadSettingAsync<ApiSettings>(currentStore.Id);
            if (!apiSettings.EnableApi)
            {
                context.Result = new ObjectResult(new { success = false, message = "دسترسی API برای این فروشگاه غیرفعال است." }) { StatusCode = 403 };
                return;
            }

            await next();
        }
    }
}
