using System.Threading.Tasks;
using Nop.Plugin.Api.Domain;

namespace Nop.Plugin.Api.Services
{
    public interface IRefreshTokenService
    {
        Task<ApiRefreshToken> CreateRefreshTokenAsync(int customerId, string tokenValue, int expirationDays, string deviceId = null);
        Task<ApiRefreshToken> GetByTokenValueAsync(string tokenValue);
        Task RevokeAsync(ApiRefreshToken token);
        Task RevokeAllForCustomerAsync(int customerId);
    }
}
