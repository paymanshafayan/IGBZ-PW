using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Nop.Data;
using Nop.Plugin.Api.Domain;

namespace Nop.Plugin.Api.Services
{
    /// <summary>
    /// پیاده‌سازی سرویس مدیریت Refresh Token ها. برای امنیت بالاتر (فاز ۶)، مقدار توکن هرگز به‌صورت متن ساده
    /// در دیتابیس ذخیره نمی‌شود؛ فقط هش SHA-256 آن نگه‌داری می‌شود. اگر دیتابیس افشا شود، مهاجم نمی‌تواند
    /// از رکوردها برای جعل هویت استفاده کند.
    /// </summary>
    public class RefreshTokenService : IRefreshTokenService
    {
        private readonly IRepository<ApiRefreshToken> _refreshTokenRepository;

        public RefreshTokenService(IRepository<ApiRefreshToken> refreshTokenRepository)
        {
            _refreshTokenRepository = refreshTokenRepository;
        }

        public async Task<ApiRefreshToken> CreateRefreshTokenAsync(int customerId, string tokenValue, int expirationDays, string deviceId = null)
        {
            var entity = new ApiRefreshToken
            {
                CustomerId = customerId,
                Token = ComputeHash(tokenValue),
                CreatedOnUtc = DateTime.UtcNow,
                ExpiresOnUtc = DateTime.UtcNow.AddDays(expirationDays),
                IsRevoked = false,
                DeviceId = deviceId
            };

            await _refreshTokenRepository.InsertAsync(entity);
            return entity;
        }

        public async Task<ApiRefreshToken> GetByTokenValueAsync(string tokenValue)
        {
            var hashedValue = ComputeHash(tokenValue);
            var query = _refreshTokenRepository.Table.Where(t => t.Token == hashedValue && !t.IsRevoked);
            return await Task.FromResult(query.FirstOrDefault());
        }

        public async Task RevokeAsync(ApiRefreshToken token)
        {
            if (token == null)
                return;

            token.IsRevoked = true;
            await _refreshTokenRepository.UpdateAsync(token);
        }

        public async Task RevokeAllForCustomerAsync(int customerId)
        {
            var tokens = _refreshTokenRepository.Table.Where(t => t.CustomerId == customerId && !t.IsRevoked).ToList();
            foreach (var token in tokens)
                token.IsRevoked = true;

            await _refreshTokenRepository.UpdateAsync(tokens);
        }

        private static string ComputeHash(string value)
        {
            if (string.IsNullOrEmpty(value))
                return value;

            var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(value));
            return Convert.ToHexString(bytes);
        }
    }
}

