using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;
using Nop.Core.Domain.Customers;
using Nop.Plugin.Api.Domain;
using Nop.Services.Configuration;
using Nop.Services.Customers;

namespace Nop.Plugin.Api.Services
{
    public class JwtTokenService : IJwtTokenService
    {
        private readonly ISettingService _settingService;
        private readonly ICustomerService _customerService;

        public JwtTokenService(ISettingService settingService, ICustomerService customerService)
        {
            _settingService = settingService;
            _customerService = customerService;
        }

        public async Task<string> GenerateAccessTokenAsync(Customer customer)
        {
            var apiSettings = await _settingService.LoadSettingAsync<ApiSettings>();

            var roles = await _customerService.GetCustomerRolesAsync(customer);
            var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Sub, customer.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim("customerGuid", customer.CustomerGuid.ToString()),
                new Claim(ClaimTypes.Email, customer.Email ?? string.Empty),
                new Claim(ClaimTypes.NameIdentifier, customer.Id.ToString())
            };

            foreach (var role in roles)
                claims.Add(new Claim(ClaimTypes.Role, role.SystemName));

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(apiSettings.JwtSecretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: apiSettings.JwtIssuer,
                audience: apiSettings.JwtAudience,
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(apiSettings.AccessTokenExpirationMinutes),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public string GenerateRefreshTokenValue()
        {
            var randomBytes = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomBytes);
            return Convert.ToBase64String(randomBytes);
        }

        public async Task<ClaimsPrincipal> GetPrincipalFromExpiredTokenAsync(string token)
        {
            var apiSettings = await _settingService.LoadSettingAsync<ApiSettings>();

            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateAudience = true,
                ValidateIssuer = true,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(apiSettings.JwtSecretKey)),
                ValidIssuer = apiSettings.JwtIssuer,
                ValidAudience = apiSettings.JwtAudience,
                ValidateLifetime = false // مهم: چون توکن منقضی‌شده را داریم اعتبارسنجی می‌کنیم
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out var securityToken);

            if (securityToken is not JwtSecurityToken jwtSecurityToken ||
                !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
            {
                throw new SecurityTokenException("توکن نامعتبر است.");
            }

            return principal;
        }
    }
}
