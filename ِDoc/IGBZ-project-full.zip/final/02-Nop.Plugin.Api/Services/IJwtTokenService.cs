using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Nop.Core.Domain.Customers;

namespace Nop.Plugin.Api.Services
{
    public interface IJwtTokenService
    {
        /// <summary>تولید Access Token برای مشتری با مدت انقضای کوتاه</summary>
        Task<string> GenerateAccessTokenAsync(Customer customer);

        /// <summary>تولید یک رشته تصادفی امن برای استفاده به‌عنوان Refresh Token</summary>
        string GenerateRefreshTokenValue();

        /// <summary>استخراج claim ها از یک توکن (حتی اگر منقضی شده باشد) - برای فرآیند refresh</summary>
        Task<ClaimsPrincipal> GetPrincipalFromExpiredTokenAsync(string token);
    }
}
