using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Nop.Core.Domain.Localization;
using Nop.Plugin.Api.Domain;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Plugins;

namespace Nop.Plugin.Api
{
    /// <summary>
    /// پلاگین Web API - نقطه ورود نصب/حذف نصب پلاگین در nopCommerce
    /// </summary>
    public class ApiPlugin : BasePlugin
    {
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;

        public ApiPlugin(ISettingService settingService,
            ILocalizationService localizationService)
        {
            _settingService = settingService;
            _localizationService = localizationService;
        }

        public override async Task InstallAsync()
        {
            // تنظیمات پیش‌فرض پلاگین
            var settings = new ApiSettings
            {
                EnableApi = true,
                JwtSecretKey = Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N"), // کلید تصادفی امن - در پنل ادمین قابل تغییر است
                AccessTokenExpirationMinutes = 60,          // انقضای access token: ۶۰ دقیقه
                RefreshTokenExpirationDays = 30,             // انقضای refresh token: ۳۰ روز
                JwtIssuer = "NopCommerceApi",
                JwtAudience = "NopCommerceApiClient",
                AllowRegistrationViaApi = true,
                MaxPageSize = 200,
                DefaultPageSize = 20,
                PaymentWebhookSecretKey = Guid.NewGuid().ToString("N")
            };
            await _settingService.SaveSettingAsync(settings);

            await _localizationService.AddOrUpdateLocaleResourceAsync(new Dictionary<string, string>
            {
                ["Admin.Plugins.Api.EnableApi"] = "فعال‌سازی API",
                ["Admin.Plugins.Api.JwtSecretKey"] = "کلید مخفی JWT",
                ["Admin.Plugins.Api.AccessTokenExpirationMinutes"] = "زمان انقضای Access Token (دقیقه)",
                ["Admin.Plugins.Api.RefreshTokenExpirationDays"] = "زمان انقضای Refresh Token (روز)",
                ["Admin.Plugins.Api.PaymentWebhookSecretKey"] = "کلید مخفی Webhook درگاه پرداخت"
            });

            await base.InstallAsync();
        }

        public override async Task UninstallAsync()
        {
            await _settingService.DeleteSettingAsync<ApiSettings>();
            await _localizationService.DeleteLocaleResourcesAsync("Admin.Plugins.Api");
            await base.UninstallAsync();
        }
    }
}
