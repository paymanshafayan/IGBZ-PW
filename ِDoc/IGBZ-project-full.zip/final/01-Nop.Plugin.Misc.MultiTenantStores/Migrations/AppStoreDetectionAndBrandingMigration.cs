using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Migrations;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Migrations
{
    /// <summary>
    /// Phase 3 additions: the phone-to-store lookup table used for silent store-detection in
    /// the shared customer app, plus a couple of branding columns on the existing
    /// TenantStoreSubscription table (so the app can fetch a store's logo/color once it knows
    /// its storeId). Marked as an Update migration - unlike SchemaMigration.cs (Installation
    /// only) - so it also runs against solutions where this plugin was already installed
    /// before this feature existed.
    /// </summary>
    [NopMigration("2026-07-24 10:00:00", "Misc.MultiTenantStores: app store-detection + branding", MigrationProcessType.Update)]
    public class AppStoreDetectionAndBrandingMigration : Migration
    {
        public override void Up()
        {
            if (!Schema.Table(nameof(AppPhoneStoreLink)).Exists())
            {
                Create.TableFor<AppPhoneStoreLink>();

                // the app-resolve endpoint looks a phone number up on (almost) every cold start
                Create.Index("IX_AppPhoneStoreLink_NormalizedPhone")
                    .OnTable(nameof(AppPhoneStoreLink))
                    .OnColumn(nameof(AppPhoneStoreLink.NormalizedPhone)).Ascending()
                    .WithOptions().NonClustered();
            }

            if (!Schema.Table(nameof(TenantStoreSubscription)).Column(nameof(TenantStoreSubscription.BrandColorHex)).Exists())
            {
                Alter.Table(nameof(TenantStoreSubscription))
                    .AddColumn(nameof(TenantStoreSubscription.BrandColorHex)).AsString(9).Nullable()
                    .AddColumn(nameof(TenantStoreSubscription.LogoPictureId)).AsInt32().Nullable();
            }
        }

        public override void Down()
        {
            if (Schema.Table(nameof(AppPhoneStoreLink)).Exists())
                Delete.Table(nameof(AppPhoneStoreLink));

            if (Schema.Table(nameof(TenantStoreSubscription)).Column(nameof(TenantStoreSubscription.BrandColorHex)).Exists())
                Delete.Column(nameof(TenantStoreSubscription.BrandColorHex)).FromTable(nameof(TenantStoreSubscription));

            if (Schema.Table(nameof(TenantStoreSubscription)).Column(nameof(TenantStoreSubscription.LogoPictureId)).Exists())
                Delete.Column(nameof(TenantStoreSubscription.LogoPictureId)).FromTable(nameof(TenantStoreSubscription));
        }
    }
}
