using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Migrations;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Migrations
{
    [NopMigration("2026-07-19 09:00:00", "Misc.MultiTenantStores base schema", MigrationProcessType.Installation)]
    public class SchemaMigration : AutoReversingMigration
    {
        public override void Up()
        {
            Create.TableFor<StoreDomainMapping>();
            Create.TableFor<TenantPlan>();
            Create.TableFor<TenantStoreSubscription>();

            // helpful index: resolving the current store by host name happens on almost every request
            Create.Index("IX_StoreDomainMapping_Domain")
                .OnTable(nameof(StoreDomainMapping))
                .OnColumn(nameof(StoreDomainMapping.Domain)).Ascending()
                .WithOptions().NonClustered();

            // helpful index: the OrderPaid consumer looks up a pending subscription by token
            Create.Index("IX_TenantStoreSubscription_ProvisioningToken")
                .OnTable(nameof(TenantStoreSubscription))
                .OnColumn(nameof(TenantStoreSubscription.ProvisioningToken)).Ascending()
                .WithOptions().NonClustered();
        }
    }
}
