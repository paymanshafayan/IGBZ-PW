using Microsoft.AspNetCore.Routing;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.ScheduleTasks;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Plugins;
using Nop.Services.ScheduleTasks;
using Nop.Web.Framework.Menu;

namespace Nop.Plugin.Misc.MultiTenantStores
{
    /// <summary>
    /// Multi-Tenant Stores Manager
    /// Lets end users pay a small fee and, in a few clicks, spin up their own online store as
    /// a real domain or a sub-domain of the main installation - fully self-service, with the
    /// resulting store's customers/admin confined to that store only.
    /// </summary>
    public class MultiTenantStoresPlugin : BasePlugin, IAdminMenuPlugin
    {
        private const string TenantSubscriptionExpiryTaskType = "Nop.Plugin.Misc.MultiTenantStores.ScheduledTasks.TenantSubscriptionExpiryTask, Nop.Plugin.Misc.MultiTenantStores";

        private readonly ILocalizationService _localizationService;
        private readonly ICustomerService _customerService;
        private readonly IScheduleTaskService _scheduleTaskService;
        private readonly IWebHelper _webHelper;

        public MultiTenantStoresPlugin(
            ILocalizationService localizationService,
            ICustomerService customerService,
            IScheduleTaskService scheduleTaskService,
            IWebHelper webHelper)
        {
            _localizationService = localizationService;
            _customerService = customerService;
            _scheduleTaskService = scheduleTaskService;
            _webHelper = webHelper;
        }

        public override string GetConfigurationPageUrl()
        {
            return $"{_webHelper.GetStoreLocation()}Admin/TenantSettings/Configure";
        }

        public async Task ManageSiteMapAsync(SiteMapNode rootNode)
        {
            var parentNode = new SiteMapNode
            {
                SystemName = MultiTenantStoresDefaults.AdminMenuSystemName,
                Title = await _localizationService.GetResourceAsync("Plugins.Misc.MultiTenantStores.Menu.Title"),
                IconClass = "far fa-dot-circle",
                Visible = true
            };

            parentNode.ChildNodes.Add(new SiteMapNode
            {
                SystemName = MultiTenantStoresDefaults.AdminMenuSystemName + ".Domains",
                Title = await _localizationService.GetResourceAsync("Plugins.Misc.MultiTenantStores.Menu.Domains"),
                ControllerName = "StoreDomains",
                ActionName = "List",
                Visible = true,
                RouteValues = new RouteValueDictionary { { "area", "Admin" } }
            });

            parentNode.ChildNodes.Add(new SiteMapNode
            {
                SystemName = MultiTenantStoresDefaults.AdminMenuSystemName + ".Plans",
                Title = await _localizationService.GetResourceAsync("Plugins.Misc.MultiTenantStores.Menu.Plans"),
                ControllerName = "TenantPlans",
                ActionName = "List",
                Visible = true,
                RouteValues = new RouteValueDictionary { { "area", "Admin" } }
            });

            parentNode.ChildNodes.Add(new SiteMapNode
            {
                SystemName = MultiTenantStoresDefaults.AdminMenuSystemName + ".Settings",
                Title = await _localizationService.GetResourceAsync("Plugins.Misc.MultiTenantStores.Menu.Settings"),
                ControllerName = "TenantSettings",
                ActionName = "Configure",
                Visible = true,
                RouteValues = new RouteValueDictionary { { "area", "Admin" } }
            });

            // Nest everything under the built-in "Configuration" menu, right next to "Stores"
            var configurationNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Configuration");
            if (configurationNode != null)
                configurationNode.ChildNodes.Add(parentNode);
            else
                rootNode.ChildNodes.Add(parentNode);
        }

        public override async Task InstallAsync()
        {
            // create the restricted role up-front so it shows up in Customers > Customer Roles
            // immediately, even before the first store is ever provisioned
            var role = await _customerService.GetCustomerRoleBySystemNameAsync(MultiTenantStoresDefaults.TenantStoreOwnerRoleSystemName);
            if (role == null)
            {
                await _customerService.InsertCustomerRoleAsync(new CustomerRole
                {
                    Name = MultiTenantStoresDefaults.TenantStoreOwnerRoleName,
                    SystemName = MultiTenantStoresDefaults.TenantStoreOwnerRoleSystemName,
                    Active = true,
                    IsSystemRole = false
                });
            }

            // daily billing-lifecycle check (trial expiry, past-due, auto-suspend)
            var existingTask = await _scheduleTaskService.GetTaskByTypeAsync(TenantSubscriptionExpiryTaskType);
            if (existingTask == null)
            {
                await _scheduleTaskService.InsertTaskAsync(new ScheduleTask
                {
                    Name = "Multi-Tenant Stores: subscription expiry check",
                    Seconds = 60 * 60 * 24, // once a day
                    Type = TenantSubscriptionExpiryTaskType,
                    Enabled = true,
                    StopOnError = false
                });
            }

            await _localizationService.AddOrUpdateLocaleResourceAsync(new Dictionary<string, string>
            {
                ["Plugins.Misc.MultiTenantStores.Menu.Title"] = "Multi-Tenant Stores",
                ["Plugins.Misc.MultiTenantStores.Menu.Domains"] = "Domains",
                ["Plugins.Misc.MultiTenantStores.Menu.Plans"] = "Subscription plans",
                ["Plugins.Misc.MultiTenantStores.Menu.Settings"] = "Settings",

                ["Plugins.Misc.MultiTenantStores.Domains.List.Title"] = "Store domain bindings",
                ["Plugins.Misc.MultiTenantStores.Domains.List.Intro"] =
                    "Bind a real domain (e.g. shop.customer.com) or a sub-domain of this installation " +
                    "(e.g. shop1.yourmainsite.com, or a wildcard *.yourmainsite.com) to any store. " +
                    "Remember to point the domain's DNS (A / CNAME record) to this server and configure " +
                    "your web server / reverse proxy to accept that host name before adding it here.",

                ["Plugins.Misc.MultiTenantStores.Fields.Store"] = "Store",
                ["Plugins.Misc.MultiTenantStores.Fields.Domain"] = "Domain / sub-domain",
                ["Plugins.Misc.MultiTenantStores.Fields.Domain.Hint"] =
                    "Enter a host name only, without http(s):// and without a trailing slash. " +
                    "Examples: shop1.example.com, www.customdomain.com, *.example.com (wildcard).",
                ["Plugins.Misc.MultiTenantStores.Fields.Enabled"] = "Enabled",
                ["Plugins.Misc.MultiTenantStores.Fields.Enabled.Hint"] = "Disabled bindings are ignored when resolving incoming requests.",
                ["Plugins.Misc.MultiTenantStores.Fields.IsPrimary"] = "Primary domain",
                ["Plugins.Misc.MultiTenantStores.Fields.IsPrimary.Hint"] = "Marks this as the canonical domain for the store (informational / for future redirect rules).",
                ["Plugins.Misc.MultiTenantStores.Fields.RequireSsl"] = "Require HTTPS",
                ["Plugins.Misc.MultiTenantStores.Fields.RequireSsl.Hint"] = "Redirect plain HTTP requests on this domain to HTTPS.",
                ["Plugins.Misc.MultiTenantStores.Fields.Note"] = "Note",
                ["Plugins.Misc.MultiTenantStores.Fields.CreatedOn"] = "Created on",

                ["Plugins.Misc.MultiTenantStores.Added"] = "The domain binding has been added successfully.",
                ["Plugins.Misc.MultiTenantStores.Updated"] = "The domain binding has been updated successfully.",
                ["Plugins.Misc.MultiTenantStores.Deleted"] = "The domain binding has been deleted.",

                ["Plugins.Misc.MultiTenantStores.Plan.Name"] = "Name",
                ["Plugins.Misc.MultiTenantStores.Plan.Description"] = "Description",
                ["Plugins.Misc.MultiTenantStores.Plan.LinkedProductId"] = "Linked product Id",
                ["Plugins.Misc.MultiTenantStores.Plan.BillingCycleDays"] = "Billing cycle (days)",
                ["Plugins.Misc.MultiTenantStores.Plan.TrialDays"] = "Trial (days)",
                ["Plugins.Misc.MultiTenantStores.Plan.MaxProducts"] = "Max products (0 = unlimited)",
                ["Plugins.Misc.MultiTenantStores.Plan.IsActive"] = "Active",
                ["Plugins.Misc.MultiTenantStores.Plan.DisplayOrder"] = "Display order",

                ["Plugins.Misc.MultiTenantStores.Settings.BaseDomain"] = "Base domain for sub-domains",
                ["Plugins.Misc.MultiTenantStores.Settings.PlatformStoreId"] = "Platform (main) store",
                ["Plugins.Misc.MultiTenantStores.Settings.ExtraReservedSubdomains"] = "Extra reserved sub-domains",
                ["Plugins.Misc.MultiTenantStores.Settings.AutoActivateAfterPayment"] = "Auto-activate after payment",
                ["Plugins.Misc.MultiTenantStores.Settings.AllowMultipleStoresPerCustomer"] = "Allow multiple stores per customer",

                ["Plugins.Misc.MultiTenantStores.Wizard.Title"] = "Create your store",
                ["Plugins.Misc.MultiTenantStores.Wizard.Intro"] =
                    "Pick a plan, choose your store's address, and click Continue - you will pay on the " +
                    "next page and your store will be ready automatically right after payment.",
                ["Plugins.Misc.MultiTenantStores.Wizard.StoreName"] = "Store name",
                ["Plugins.Misc.MultiTenantStores.Wizard.Subdomain"] = "Store address",
                ["Plugins.Misc.MultiTenantStores.Wizard.Plan"] = "Plan",
                ["Plugins.Misc.MultiTenantStores.Wizard.TrialDays"] = "days free trial",
                ["Plugins.Misc.MultiTenantStores.Wizard.Submit"] = "Continue to payment",

                ["Plugins.Misc.MultiTenantStores.MyStore.Title"] = "My store",
                ["Plugins.Misc.MultiTenantStores.MyStore.NoStore"] = "You don't have a store yet.",
                ["Plugins.Misc.MultiTenantStores.MyStore.Status"] = "Status",
                ["Plugins.Misc.MultiTenantStores.MyStore.TrialEnds"] = "Trial ends on",
                ["Plugins.Misc.MultiTenantStores.MyStore.RenewsOn"] = "Renews on",
                ["Plugins.Misc.MultiTenantStores.MyStore.Visit"] = "Visit my store",

                ["Plugins.Misc.MultiTenantStores.Download.Title"] = "Get the app",
                ["Plugins.Misc.MultiTenantStores.Download.Intro"] =
                    "Enter the same phone number you'll use inside the app - this is how the app knows " +
                    "it belongs to this store.",
                ["Plugins.Misc.MultiTenantStores.Download.PhoneNumber"] = "Mobile number",
                ["Plugins.Misc.MultiTenantStores.Download.PhoneNote"] =
                    "For your security, please use the exact mobile number you will enter in the app.",
                ["Plugins.Misc.MultiTenantStores.Download.Submit"] = "Continue",
                ["Plugins.Misc.MultiTenantStores.Download.Confirmed"] = "Thanks! Now download the app and enter the same number on first launch.",
                ["Plugins.Misc.MultiTenantStores.Download.AppStore"] = "Download on the App Store",
                ["Plugins.Misc.MultiTenantStores.Download.GooglePlay"] = "Get it on Google Play",
                ["Plugins.Misc.MultiTenantStores.Download.DirectApk"] = "Direct APK download",
                ["Plugins.Misc.MultiTenantStores.Download.Reminder"] = "Remember: use the same phone number in the app."
            });

            // Persian (fa-IR) overrides, only applied if the fa-IR language is installed;
            // harmless no-op otherwise
            await _localizationService.AddOrUpdateLocaleResourceAsync(new Dictionary<string, string>
            {
                ["Plugins.Misc.MultiTenantStores.Menu.Title"] = "فروشگاه‌ساز چند‌مستأجری",
                ["Plugins.Misc.MultiTenantStores.Menu.Domains"] = "دامنه‌ها",
                ["Plugins.Misc.MultiTenantStores.Menu.Plans"] = "پلن‌های اشتراک",
                ["Plugins.Misc.MultiTenantStores.Menu.Settings"] = "تنظیمات",
                ["Plugins.Misc.MultiTenantStores.Wizard.Title"] = "فروشگاه خودت رو بساز",
                ["Plugins.Misc.MultiTenantStores.Wizard.StoreName"] = "نام فروشگاه",
                ["Plugins.Misc.MultiTenantStores.Wizard.Subdomain"] = "آدرس فروشگاه",
                ["Plugins.Misc.MultiTenantStores.Wizard.Plan"] = "پلن",
                ["Plugins.Misc.MultiTenantStores.Wizard.Submit"] = "ادامه به پرداخت",
                ["Plugins.Misc.MultiTenantStores.MyStore.Title"] = "فروشگاه من",

                ["Plugins.Misc.MultiTenantStores.Download.Title"] = "دریافت اپلیکیشن",
                ["Plugins.Misc.MultiTenantStores.Download.Intro"] =
                    "همان شماره موبایلی که قرار است در اپلیکیشن استفاده کنید را وارد کنید - این کار به اپلیکیشن " +
                    "کمک می‌کند بفهمد متعلق به همین فروشگاه است.",
                ["Plugins.Misc.MultiTenantStores.Download.PhoneNumber"] = "شماره موبایل",
                ["Plugins.Misc.MultiTenantStores.Download.PhoneNote"] =
                    "به دلایل امنیتی، لطفاً همان شماره موبایلی که در اپلیکیشن وارد می‌کنید را اینجا هم وارد کنید.",
                ["Plugins.Misc.MultiTenantStores.Download.Submit"] = "ادامه",
                ["Plugins.Misc.MultiTenantStores.Download.Confirmed"] = "ممنون! حالا اپلیکیشن را نصب کرده و در اولین اجرا همین شماره را وارد کنید.",
                ["Plugins.Misc.MultiTenantStores.Download.AppStore"] = "دانلود از App Store",
                ["Plugins.Misc.MultiTenantStores.Download.GooglePlay"] = "دریافت از Google Play",
                ["Plugins.Misc.MultiTenantStores.Download.DirectApk"] = "دانلود مستقیم فایل APK",
                ["Plugins.Misc.MultiTenantStores.Download.Reminder"] = "به‌خاطر داشته باشید: همان شماره موبایل را داخل اپلیکیشن هم وارد کنید."
            }, "fa-IR");

            await base.InstallAsync();
        }

        public override async Task UninstallAsync()
        {
            var task = await _scheduleTaskService.GetTaskByTypeAsync(TenantSubscriptionExpiryTaskType);
            if (task != null)
                await _scheduleTaskService.DeleteTaskAsync(task);

            await _localizationService.DeleteLocaleResourcesAsync("Plugins.Misc.MultiTenantStores");

            await base.UninstallAsync();
        }
    }
}
