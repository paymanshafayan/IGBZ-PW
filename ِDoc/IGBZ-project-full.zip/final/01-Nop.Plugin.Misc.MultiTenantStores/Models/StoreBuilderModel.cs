using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Misc.MultiTenantStores.Models
{
    public partial record TenantPlanViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string FormattedPrice { get; set; }
        public int TrialDays { get; set; }
        public int BillingCycleDays { get; set; }
    }

    public partial class StoreBuilderModel : BaseNopModel
    {
        public StoreBuilderModel()
        {
            AvailablePlans = new List<TenantPlanViewModel>();
        }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Wizard.StoreName")]
        public string StoreName { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Wizard.Subdomain")]
        public string SubdomainLabel { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Wizard.Plan")]
        public int PlanId { get; set; }

        public string BaseDomain { get; set; }

        public IList<TenantPlanViewModel> AvailablePlans { get; set; }

        public IList<SelectListItem> AvailablePlanItems =>
            AvailablePlans.Select(p => new SelectListItem { Text = p.Name, Value = p.Id.ToString() }).ToList();
    }

    /// <summary>
    /// Shown to a customer who already owns a store: quick status + link to it
    /// </summary>
    public partial class MyStoreModel : BaseNopModel
    {
        public bool HasStore { get; set; }
        public string StoreName { get; set; }
        public string StoreUrl { get; set; }
        public string Status { get; set; }
        public DateTime? TrialEndsOnUtc { get; set; }
        public DateTime? CurrentPeriodEndUtc { get; set; }
    }
}
