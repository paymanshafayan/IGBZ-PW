using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Misc.MultiTenantStores.Models
{
    /// <summary>
    /// The public "get the app" page shown on each tenant store's own site. Capturing the
    /// phone number here - *before* showing the download links - is what lets the shared
    /// customer app silently figure out which store it belongs to on first launch
    /// (ARCHITECTURE.md section 5).
    /// </summary>
    public partial class StoreDownloadModel : BaseNopModel
    {
        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Download.PhoneNumber")]
        public string PhoneNumber { get; set; }

        /// <summary>Set after a valid submission, so the view can reveal the actual download links</summary>
        public bool PhoneConfirmed { get; set; }

        public string StoreName { get; set; }

        /// <summary>
        /// ⚠️ Replace with your real App Store / Google Play / direct-APK links once the app is
        /// published. Left as placeholders on purpose - this page is generic across every
        /// tenant store and doesn't know your release URLs.
        /// </summary>
        public string AppStoreUrl { get; set; } = "https://apps.apple.com/app/idXXXXXXXXX";
        public string GooglePlayUrl { get; set; } = "https://play.google.com/store/apps/details?id=com.yourcompany.app";
        public string DirectApkUrl { get; set; } = "https://your-store-domain.com/downloads/app-latest.apk";
    }
}
