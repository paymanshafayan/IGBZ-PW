using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Nop.Core;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Customers;

namespace Nop.Plugin.Misc.MultiTenantStores.Infrastructure
{
    /// <summary>
    /// SECURITY BOUNDARY (defense-in-depth layer, not the only one you should rely on):
    ///
    /// Regular super-admins are completely unaffected by this filter. For a customer in the
    /// restricted "Tenant Store Owners" role, this filter:
    ///
    ///  1. Confirms the store currently resolved by IStoreContext (i.e. the domain the admin
    ///     request came in on) is the exact store this customer owns - otherwise Access Denied.
    ///     This is what stops a tenant owner from reaching the platform's main admin, or another
    ///     tenant's admin, even if they somehow know/guess the URL.
    ///  2. Restricts them to a small allow-list of admin controllers that are safe to expose
    ///     unmodified (catalog, orders, limited customer/shipping/tax tools). Everything else
    ///     (Plugins, System, Stores, Settings, Maintenance, Schedule Tasks, ACL, Multi-factor
    ///     auth, Log, etc.) is blocked outright, since those are platform-wide and not naturally
    ///     store-scoped.
    ///
    /// IMPORTANT: several nopCommerce list pages accept an optional store filter but do not by
    /// themselves refuse to *show* data from other stores unless you pick one. Before going to
    /// production, verify each allow-listed controller's list/search actions actually restrict
    /// results to the tenant's own StoreId (most catalog/order search models expose a StoreId
    /// filter you can force server-side) - treat the allow-list below as a starting point, not
    /// a finished audit.
    /// </summary>
    public class TenantAdminScopeFilter : IAsyncActionFilter
    {
        private static readonly HashSet<string> AllowedControllers = new(StringComparer.OrdinalIgnoreCase)
        {
            "Home",
            "Product", "Category", "Manufacturer", "ProductTag", "ProductAttribute", "SpecificationAttribute",
            "Order", "Shipment", "ReturnRequest", "RecurringPayment",
            "Customer", // consider narrowing further: tenant owners generally should only browse
                        // customers who placed orders in their own store
            "MessageTemplate", "Topic", "News", "Blog", "Forum",
            "ShoppingCart", "Discount"
        };

        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly ICustomerService _customerService;
        private readonly ITenantProvisioningService _tenantProvisioningService;

        public TenantAdminScopeFilter(
            IWorkContext workContext,
            IStoreContext storeContext,
            ICustomerService customerService,
            ITenantProvisioningService tenantProvisioningService)
        {
            _workContext = workContext;
            _storeContext = storeContext;
            _customerService = customerService;
            _tenantProvisioningService = tenantProvisioningService;
        }

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var area = context.RouteData.Values["area"] as string;
            if (!string.Equals(area, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                await next();
                return;
            }

            var customer = await _workContext.GetCurrentCustomerAsync();
            var role = await _customerService.GetCustomerRoleBySystemNameAsync(MultiTenantStoresDefaults.TenantStoreOwnerRoleSystemName);
            var customerRoleIds = await _customerService.GetCustomerRoleIdsAsync(customer, showHidden: true);
            var isTenantOwner = role != null && customerRoleIds.Contains(role.Id);

            if (!isTenantOwner)
            {
                await next();
                return;
            }

            var controllerName = context.RouteData.Values["controller"] as string ?? string.Empty;
            if (!AllowedControllers.Contains(controllerName))
            {
                context.Result = new ForbidResult();
                return;
            }

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            var ownedStoreId = await _tenantProvisioningService.GetOwnedStoreIdAsync(customer);

            if (ownedStoreId == null || currentStore.Id != ownedStoreId.Value)
            {
                context.Result = new ForbidResult();
                return;
            }

            // PHASE 1 hardening: nopCommerce's own catalog/order/customer search models expose
            // an optional store filter (commonly a property named "SearchStoreId" or "StoreId")
            // that a super-admin can leave on "all stores". For a tenant owner that must never be
            // possible - force it to their own store on every bound argument, regardless of what
            // was posted from the browser. This runs in addition to (not instead of) each entity
            // already being store-mapped by the *IsolationConsumer classes in this namespace.
            ForceStoreFilterOnBoundArguments(context, ownedStoreId.Value);

            await next();
        }

        private static readonly string[] StoreFilterPropertyNames = { "SearchStoreId", "StoreId" };

        private static void ForceStoreFilterOnBoundArguments(ActionExecutingContext context, int ownedStoreId)
        {
            foreach (var argument in context.ActionArguments.Values)
            {
                if (argument == null)
                    continue;

                var argumentType = argument.GetType();

                foreach (var propertyName in StoreFilterPropertyNames)
                {
                    var property = argumentType.GetProperty(propertyName);
                    if (property != null && property.PropertyType == typeof(int) && property.CanWrite)
                        property.SetValue(argument, ownedStoreId);
                }
            }
        }
    }
}
