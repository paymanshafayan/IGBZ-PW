using Microsoft.AspNetCore.Http;
using Nop.Core;
using Nop.Core.Domain.Stores;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Stores;

namespace Nop.Plugin.Misc.MultiTenantStores.Infrastructure
{
    /// <summary>
    /// Resolves "the current store" for every incoming request.
    ///
    /// Resolution order:
    ///  0. For requests under /api/* ONLY: an "X-Store-Id" request header, if present and valid.
    ///     This exists because the mobile apps call one shared API domain (e.g. api.yourmainsite.com)
    ///     for every tenant instead of each tenant's own sub-domain, so there is no Host to resolve
    ///     from - the app determines its storeId once (see the phone-number lookup flow discussed
    ///     for the customer app) and sends it back on every request instead.
    ///     Deliberately NOT honored outside /api/* (storefront pages, /Admin) so a spoofed header
    ///     can never move the store away from what the actual domain/binding says there - that
    ///     invariant (TenantAdminScopeFilter, CrossStoreCustomerGuardFilter) must stay Host-only.
    ///  1. An explicit domain/sub-domain binding created in Admin -> Multi-Tenant Stores -> Domains
    ///     (this is what lets a store live on its own real domain, e.g. "shop-a.com",
    ///     or on a sub-domain of the main installation, e.g. "shop-a.mymainsite.com",
    ///     including a "*.mymainsite.com" wildcard binding).
    ///  2. nopCommerce's built-in behaviour: match the request host against each Store's "Url" field.
    ///  3. The first store in the system, so the site never hard-fails if nothing matches.
    /// </summary>
    public class MultiTenantStoreContext : IStoreContext
    {
        public const string StoreIdHeaderName = "X-Store-Id";

        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IStoreDomainMappingService _storeDomainMappingService;
        private readonly IStoreService _storeService;

        private Store _cachedStore;

        public MultiTenantStoreContext(
            IHttpContextAccessor httpContextAccessor,
            IStoreDomainMappingService storeDomainMappingService,
            IStoreService storeService)
        {
            _httpContextAccessor = httpContextAccessor;
            _storeDomainMappingService = storeDomainMappingService;
            _storeService = storeService;
        }

        public virtual async Task<Store> GetCurrentStoreAsync()
        {
            // cache the result for the duration of the request (mirrors nopCommerce's default behavior)
            if (_cachedStore != null)
                return _cachedStore;

            var headerStore = await TryResolveByStoreIdHeaderAsync();
            if (headerStore != null)
            {
                _cachedStore = headerStore;
                return _cachedStore;
            }

            var host = GetCurrentHost();

            if (!string.IsNullOrEmpty(host))
            {
                var mapping = await _storeDomainMappingService.FindByHostAsync(host);
                if (mapping != null)
                {
                    var mappedStore = await _storeService.GetStoreByIdAsync(mapping.StoreId);
                    if (mappedStore != null)
                    {
                        _cachedStore = mappedStore;
                        return _cachedStore;
                    }
                }
            }

            var allStores = await _storeService.GetAllStoresAsync();

            _cachedStore = (!string.IsNullOrEmpty(host)
                ? allStores.FirstOrDefault(s => StoreUrlMatchesHost(s, host))
                : null) ?? allStores.FirstOrDefault();

            if (_cachedStore == null)
                throw new Exception("No store could be loaded. Make sure at least one store is configured and, " +
                                     "if using multi-tenant domains, that the requested host is bound to a store " +
                                     "under Admin > Multi-Tenant Stores > Domains.");

            return _cachedStore;
        }

        protected virtual async Task<Store> TryResolveByStoreIdHeaderAsync()
        {
            var request = _httpContextAccessor.HttpContext?.Request;
            if (request == null)
                return null;

            // only ever honored for API traffic - never for /Admin or normal storefront pages
            if (!request.Path.StartsWithSegments("/api", StringComparison.OrdinalIgnoreCase))
                return null;

            if (!request.Headers.TryGetValue(StoreIdHeaderName, out var headerValues))
                return null;

            if (!int.TryParse(headerValues.ToString(), out var headerStoreId) || headerStoreId <= 0)
                return null;

            return await _storeService.GetStoreByIdAsync(headerStoreId);
        }

        protected virtual string GetCurrentHost()
        {
            var request = _httpContextAccessor.HttpContext?.Request;
            if (request == null)
                return string.Empty;

            var host = request.Host.Host; // Host.Host already strips the port
            return host?.Trim().ToLowerInvariant() ?? string.Empty;
        }

        protected virtual bool StoreUrlMatchesHost(Store store, string host)
        {
            if (string.IsNullOrEmpty(store?.Url))
                return false;

            if (!Uri.TryCreate(store.Url.Trim(), UriKind.Absolute, out var storeUri))
                return false;

            var storeHost = storeUri.Host.ToLowerInvariant();

            return string.Equals(storeHost, host, StringComparison.OrdinalIgnoreCase)
                   || string.Equals(TrimWww(storeHost), TrimWww(host), StringComparison.OrdinalIgnoreCase);
        }

        private static string TrimWww(string host)
        {
            return host.StartsWith("www.", StringComparison.OrdinalIgnoreCase) ? host[4..] : host;
        }
    }
}
