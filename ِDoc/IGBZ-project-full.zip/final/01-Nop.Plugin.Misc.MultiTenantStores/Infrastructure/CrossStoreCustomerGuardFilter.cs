using Microsoft.AspNetCore.Mvc.Filters;
using Nop.Core;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Authentication;
using Nop.Services.Common;
using Nop.Services.Customers;

namespace Nop.Plugin.Misc.MultiTenantStores.Infrastructure
{
    /// <summary>
    /// SECURITY BOUNDARY (storefront side, complements TenantAdminScopeFilter which covers /Admin):
    ///
    /// A shopper who registered on tenant store A must not be able to use that same logged-in
    /// session to browse tenant store B or the main platform site, and vice-versa. This filter
    /// signs the customer out (falling back to an anonymous/guest session) whenever their
    /// recorded "home store" (the store they registered on, see CustomerRegisteredEventConsumer)
    /// doesn't match the store currently being browsed - unless they are that store's owner.
    ///
    /// Guests (never registered, no home store recorded) are never affected: anonymous browsing
    /// always works normally on every store, which is required for new visitors and for the
    /// checkout guest flow.
    /// </summary>
    public class CrossStoreCustomerGuardFilter : IAsyncActionFilter
    {
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly ICustomerService _customerService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IAuthenticationService _authenticationService;
        private readonly ITenantProvisioningService _tenantProvisioningService;

        public CrossStoreCustomerGuardFilter(
            IWorkContext workContext,
            IStoreContext storeContext,
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            IAuthenticationService authenticationService,
            ITenantProvisioningService tenantProvisioningService)
        {
            _workContext = workContext;
            _storeContext = storeContext;
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
            _authenticationService = authenticationService;
            _tenantProvisioningService = tenantProvisioningService;
        }

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var area = context.RouteData.Values["area"] as string;
            if (string.Equals(area, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                // the Admin area has its own, separate guard (TenantAdminScopeFilter)
                await next();
                return;
            }

            var customer = await _workContext.GetCurrentCustomerAsync();
            var isRegistered = await _customerService.IsRegisteredAsync(customer);
            if (!isRegistered)
            {
                await next();
                return;
            }

            var homeStoreId = await _genericAttributeService.GetAttributeAsync<int?>(customer, MultiTenantStoresDefaults.HomeStoreIdAttributeKey);
            if (homeStoreId is not > 0)
            {
                await next();
                return;
            }

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            if (homeStoreId.Value == currentStore.Id)
            {
                await next();
                return;
            }

            var ownedStoreId = await _tenantProvisioningService.GetOwnedStoreIdAsync(customer);
            if (ownedStoreId.HasValue && ownedStoreId.Value == currentStore.Id)
            {
                // the store's own owner, visiting their own storefront - always allowed
                await next();
                return;
            }

            // wrong store for this account: drop back to an anonymous session on this store
            // rather than blocking the request outright, so the person can still browse/shop
            // as a guest or register a fresh account for *this* store
            await _authenticationService.SignOutAsync();

            await next();
        }
    }
}
