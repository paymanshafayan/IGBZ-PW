using System.Linq;

namespace Nop.Plugin.Misc.MultiTenantStores
{
    /// <summary>
    /// Normalizes a phone number so the exact same person typing their number with different
    /// formatting (spaces, dashes, a leading 0 vs +98, etc.) still matches. This is what makes
    /// the "type the same phone number on the website and in the app" store-detection trick
    /// (ARCHITECTURE.md section 5) actually work reliably. Tuned for Iranian mobile numbers,
    /// which is the only market this platform currently targets, but degrades gracefully
    /// (falls back to digits-only) for anything else.
    /// </summary>
    public static class PhoneNumberNormalizer
    {
        public static string Normalize(string phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber))
                return string.Empty;

            var digits = new string(phoneNumber.Where(char.IsDigit).ToArray());

            // "+98 912 345 6789" / "0098912..." -> "0912..."
            if (digits.StartsWith("0098"))
                digits = "0" + digits[4..];
            else if (digits.StartsWith("98") && digits.Length == 12)
                digits = "0" + digits[2..];

            // bare "912 345 6789" (no leading 0) typed by mobile-first users -> "0912..."
            if (digits.Length == 10 && digits.StartsWith("9"))
                digits = "0" + digits;

            return digits;
        }
    }
}
