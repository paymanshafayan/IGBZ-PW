using Nop.Core.Caching;

namespace Nop.Plugin.Misc.MultiTenantStores
{
    /// <summary>
    /// Plugin wide constants
    /// </summary>
    public static class MultiTenantStoresDefaults
    {
        public const string SystemName = "Misc.MultiTenantStores";

        /// <summary>
        /// Cache key for the full list of domain mappings (used by the store resolver on every request)
        /// </summary>
        public static CacheKey AllMappingsCacheKey => new("Nop.multitenantstores.all.mappings.", MultiTenantStoresPrefixCacheKey);

        public static string MultiTenantStoresPrefixCacheKey => "Nop.multitenantstores.";

        /// <summary>
        /// The admin route/menu system name
        /// </summary>
        public const string AdminMenuSystemName = "MultiTenantStores.Domains";

        /// <summary>
        /// System name of the restricted customer role automatically assigned to tenant store owners.
        /// Members of this role can only manage their own store from the admin area.
        /// </summary>
        public const string TenantStoreOwnerRoleSystemName = "TenantStoreOwners";

        public const string TenantStoreOwnerRoleName = "Tenant Store Owners";

        /// <summary>
        /// Generic attribute key (on Customer) storing the Id of the store this customer owns.
        /// A customer should own at most one store in this simple model.
        /// </summary>
        public const string OwnerStoreIdAttributeKey = "MultiTenantStores.OwnerStoreId";

        /// <summary>
        /// Generic attribute key (on Customer) storing the Id of the store a shopper registered
        /// on. Used to stop a tenant's customer from browsing/logging into a different tenant's
        /// store or the main platform site.
        /// </summary>
        public const string HomeStoreIdAttributeKey = "MultiTenantStores.HomeStoreId";

        /// <summary>
        /// Generic attribute key (on Order) storing the provisioning token so the OrderPaid
        /// consumer can find which pending TenantStoreSubscription to activate
        /// </summary>
        public const string ProvisioningTokenAttributeKey = "MultiTenantStores.ProvisioningToken";

        /// <summary>
        /// Cache key prefix reused for the plan list
        /// </summary>
        public static CacheKey AllPlansCacheKey => new("Nop.multitenantstores.all.plans.", MultiTenantStoresPrefixCacheKey);

        /// <summary>
        /// Sub-domain labels nobody is allowed to claim for their store
        /// </summary>
        public static readonly string[] DefaultReservedSubdomains =
        {
            "www", "admin", "api", "mail", "smtp", "ftp", "ns1", "ns2", "cpanel",
            "webmail", "autodiscover", "blog", "shop", "store", "app", "cdn", "static",
            "assets", "help", "support", "status", "billing", "dashboard", "portal"
        };
    }
}
