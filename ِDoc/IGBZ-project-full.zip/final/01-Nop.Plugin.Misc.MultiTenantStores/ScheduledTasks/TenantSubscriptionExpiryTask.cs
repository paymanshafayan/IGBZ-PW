using Nop.Plugin.Misc.MultiTenantStores.Domain;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.ScheduleTasks;

namespace Nop.Plugin.Misc.MultiTenantStores.ScheduledTasks
{
    /// <summary>
    /// Runs daily (see the ScheduleTask record created on plugin install). Keeps subscription
    /// status honest over time:
    ///  - Trial past its TrialEndsOnUtc with no successful renewal payment yet -> PastDue
    ///  - Any subscription past its CurrentPeriodEndUtc by more than a short grace window -> Suspended
    ///    (domain binding disabled, admin access blocked, storefront falls through to the
    ///    platform's default/fallback behaviour)
    ///
    /// Actual renewal billing (charging the customer again each cycle) is intentionally left as
    /// an extension point: wire it to whichever recurring-payment mechanism your chosen payment
    /// gateway plugin supports, then call ITenantProvisioningService.ReactivateAsync(...) and
    /// push CurrentPeriodEndUtc forward on successful renewal.
    /// </summary>
    public class TenantSubscriptionExpiryTask : IScheduleTask
    {
        private const int GraceDays = 3;

        private readonly ITenantProvisioningService _tenantProvisioningService;

        public TenantSubscriptionExpiryTask(ITenantProvisioningService tenantProvisioningService)
        {
            _tenantProvisioningService = tenantProvisioningService;
        }

        public async Task ExecuteAsync()
        {
            var all = await _tenantProvisioningService.GetAllAsync();
            var now = DateTime.UtcNow;

            foreach (var subscription in all)
            {
                switch (subscription.Status)
                {
                    case TenantSubscriptionStatus.Trial when subscription.TrialEndsOnUtc.HasValue && subscription.TrialEndsOnUtc.Value < now:
                        subscription.Status = TenantSubscriptionStatus.PastDue;
                        await _tenantProvisioningService.UpdateAsync(subscription);
                        break;

                    case TenantSubscriptionStatus.Active or TenantSubscriptionStatus.PastDue
                        when subscription.CurrentPeriodEndUtc.HasValue &&
                             subscription.CurrentPeriodEndUtc.Value.AddDays(GraceDays) < now:
                        await _tenantProvisioningService.SuspendAsync(subscription);
                        break;
                }
            }
        }
    }
}
