using Nop.Core;

namespace Nop.Plugin.Misc.MultiTenantStores.Domain
{
    /// <summary>
    /// Represents a binding between a real domain / sub-domain and a nopCommerce store.
    /// One store can have several domains (e.g. a custom domain + a fallback sub-domain of the
    /// main installation); one of them can be flagged as "primary" for canonical redirects.
    /// </summary>
    public class StoreDomainMapping : BaseEntity
    {
        /// <summary>
        /// Id of the nopCommerce store (Nop.Core.Domain.Stores.Store) this domain belongs to
        /// </summary>
        public int StoreId { get; set; }

        /// <summary>
        /// The host name, without protocol or trailing slash.
        /// Examples: "shop1.example.com", "www.customer-domain.com".
        /// A leading "*." (e.g. "*.example.com") is treated as a wildcard sub-domain pattern
        /// that matches any sub-domain of example.com that has no explicit mapping of its own.
        /// </summary>
        public string Domain { get; set; }

        /// <summary>
        /// Whether requests should be permanently (301) redirected to this domain
        /// when the store is reached through one of its other bound domains
        /// </summary>
        public bool IsPrimary { get; set; }

        /// <summary>
        /// Whether this mapping is active. Disabled mappings are ignored by the resolver
        /// but kept in the grid so admins can re-enable them later.
        /// </summary>
        public bool Enabled { get; set; }

        /// <summary>
        /// If true, non-HTTPS requests on this domain are redirected to HTTPS
        /// </summary>
        public bool RequireSsl { get; set; }

        /// <summary>
        /// Optional free-text note for admins (e.g. "DNS pointed 2026-07-01", "client's own domain")
        /// </summary>
        public string Note { get; set; }

        /// <summary>
        /// Date/time (UTC) the mapping was created
        /// </summary>
        public DateTime CreatedOnUtc { get; set; }
    }
}
