namespace Nop.Plugin.Misc.MultiTenantStores.Domain
{
    public enum TenantSubscriptionStatus
    {
        /// <summary>
        /// The customer submitted the wizard but has not completed/paid the order yet.
        /// No Store exists yet at this point - only this record does.
        /// </summary>
        PendingPayment = 10,

        /// <summary>
        /// Payment received, store provisioned, currently inside the free trial window
        /// </summary>
        Trial = 20,

        /// <summary>
        /// Payment received, store provisioned and fully active
        /// </summary>
        Active = 30,

        /// <summary>
        /// A renewal payment failed or is late; store is still reachable but flagged
        /// </summary>
        PastDue = 40,

        /// <summary>
        /// Store's domain binding is disabled and admin access is blocked
        /// </summary>
        Suspended = 50,

        /// <summary>
        /// Cancelled by the owner or the platform; kept for record-keeping
        /// </summary>
        Cancelled = 60
    }
}
