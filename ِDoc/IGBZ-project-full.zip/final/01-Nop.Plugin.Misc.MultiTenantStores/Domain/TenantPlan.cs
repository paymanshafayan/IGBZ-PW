using Nop.Core;

namespace Nop.Plugin.Misc.MultiTenantStores.Domain
{
    /// <summary>
    /// A plan that end users can subscribe to in order to get their own store.
    /// Each plan is linked to a real nopCommerce Product (see LinkedProductId) so that the
    /// payment itself is processed through nopCommerce's normal cart/checkout/payment-plugin
    /// pipeline - no custom payment code needed.
    /// </summary>
    public class TenantPlan : BaseEntity
    {
        public string Name { get; set; }

        public string Description { get; set; }

        /// <summary>
        /// Id of the nopCommerce Product that represents this plan in the cart/checkout.
        /// Its Price is what the customer actually pays.
        /// </summary>
        public int LinkedProductId { get; set; }

        /// <summary>
        /// How many days one paid billing cycle covers (e.g. 30 for monthly, 365 for yearly)
        /// </summary>
        public int BillingCycleDays { get; set; }

        /// <summary>
        /// Free trial length in days before the first payment is required (0 = no trial)
        /// </summary>
        public int TrialDays { get; set; }

        /// <summary>
        /// Soft limit communicated to the store owner (0 = unlimited). Enforcing it in the
        /// catalog admin is left as an extension point (see ITenantProvisioningService).
        /// </summary>
        public int MaxProducts { get; set; }

        public bool IsActive { get; set; }

        public int DisplayOrder { get; set; }
    }
}
