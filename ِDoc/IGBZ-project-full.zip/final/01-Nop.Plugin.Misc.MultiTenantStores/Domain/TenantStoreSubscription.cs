using Nop.Core;

namespace Nop.Plugin.Misc.MultiTenantStores.Domain
{
    /// <summary>
    /// One row per store-building attempt. Created the moment a user submits the
    /// "create your store" wizard (before payment), and completed once payment succeeds
    /// and the actual nopCommerce Store + domain binding have been provisioned.
    /// </summary>
    public class TenantStoreSubscription : BaseEntity
    {
        /// <summary>
        /// The customer who requested and owns the store
        /// </summary>
        public int OwnerCustomerId { get; set; }

        /// <summary>
        /// The chosen plan
        /// </summary>
        public int PlanId { get; set; }

        /// <summary>
        /// 0 until the store is actually provisioned (i.e. while Status == PendingPayment)
        /// </summary>
        public int StoreId { get; set; }

        /// <summary>
        /// Store name requested in the wizard (used to create the Store once paid)
        /// </summary>
        public string RequestedStoreName { get; set; }

        /// <summary>
        /// Sub-domain label requested in the wizard, e.g. "shop1" for "shop1.yourmainsite.com"
        /// (used to create the Store + StoreDomainMapping once paid)
        /// </summary>
        public string RequestedSubdomain { get; set; }

        /// <summary>
        /// Random token placed on the cart order (as an order generic attribute) so the
        /// OrderPaid event consumer can match a paid order back to this pending request
        /// </summary>
        public string ProvisioningToken { get; set; }

        public TenantSubscriptionStatus Status { get; set; }

        public DateTime? TrialEndsOnUtc { get; set; }

        public DateTime? CurrentPeriodEndUtc { get; set; }

        public DateTime CreatedOnUtc { get; set; }

        public DateTime? ActivatedOnUtc { get; set; }

        /// <summary>
        /// Optional brand color for this store, as a hex string (e.g. "#2F80ED"), used to seed
        /// the shared customer app's theme once it detects which store it belongs to. Null
        /// falls back to the app's own default color.
        /// </summary>
        public string BrandColorHex { get; set; }

        /// <summary>
        /// Optional Id of a nopCommerce Picture (Nop.Core.Domain.Media.Picture) used as this
        /// store's logo in the shared customer app. Null falls back to the app's generic icon.
        /// </summary>
        public int? LogoPictureId { get; set; }
    }
}
