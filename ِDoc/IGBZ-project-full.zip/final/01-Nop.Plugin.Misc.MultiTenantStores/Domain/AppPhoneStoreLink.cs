using Nop.Core;

namespace Nop.Plugin.Misc.MultiTenantStores.Domain
{
    /// <summary>
    /// Records that a given (normalized) phone number was entered on a given store's
    /// "get the app" download page. This is the whole trick behind silent store-detection
    /// in the shared customer app (phase 3, see ARCHITECTURE.md section 5):
    ///
    ///   1) A shopper visits Store A's website and opens the "download the app" page.
    ///      Before showing the store links, that page asks for the same phone number the
    ///      shopper will use inside the app - a row is written here: (phone, StoreA.Id).
    ///   2) The shopper installs the app (the *same* app binary for every store) and, on
    ///      first launch, types that same phone number. The app calls
    ///      POST /api/v1/store/resolve with it; the API looks the phone up in this table
    ///      and hands back StoreA's id, which the app then saves locally forever.
    ///
    /// One phone number can have several rows over time (e.g. it visited more than one
    /// store's download page) - <see cref="IAppPhoneStoreLinkService.ResolveStoreIdAsync"/>
    /// always returns the most recent one, on the assumption that the last download page the
    /// person visited is the store they actually meant to install the app for.
    /// </summary>
    public class AppPhoneStoreLink : BaseEntity
    {
        /// <summary>
        /// Normalized phone number (digits only, no leading zero/country-code ambiguity -
        /// see <see cref="PhoneNumberNormalizer.Normalize"/>). Never displayed back to anyone;
        /// only ever matched against another normalized number.
        /// </summary>
        public string NormalizedPhone { get; set; }

        /// <summary>Id of the nopCommerce store (Nop.Core.Domain.Stores.Store) this row points to</summary>
        public int StoreId { get; set; }

        /// <summary>When this phone number was first seen on this store's download page</summary>
        public DateTime CreatedOnUtc { get; set; }

        /// <summary>
        /// Updated every time the same phone number submits the download page again for the
        /// same store (harmless - keeps the "most recent" resolution logic simple and correct
        /// without ever-growing duplicate rows for the same phone+store pair)
        /// </summary>
        public DateTime LastSeenOnUtc { get; set; }
    }
}
