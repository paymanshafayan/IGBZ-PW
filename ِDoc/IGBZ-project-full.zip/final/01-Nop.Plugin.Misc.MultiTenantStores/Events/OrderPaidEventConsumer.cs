using Nop.Core.Domain.Orders;
using Nop.Plugin.Misc.MultiTenantStores.Domain;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Events;
using Nop.Services.Orders;

namespace Nop.Plugin.Misc.MultiTenantStores.Events
{
    /// <summary>
    /// NOTE: "OrderPaidEvent" is the standard event nopCommerce publishes when an order's
    /// payment status transitions to Paid (see Nop.Services.Orders.IOrderProcessingService).
    /// Confirm the exact namespace/class name against your nopCommerce version if the build fails.
    /// </summary>
    public class OrderPaidEventConsumer : IConsumer<OrderPaidEvent>
    {
        private readonly ITenantProvisioningService _tenantProvisioningService;
        private readonly ITenantPlanService _tenantPlanService;
        private readonly IOrderService _orderService;

        public OrderPaidEventConsumer(
            ITenantProvisioningService tenantProvisioningService,
            ITenantPlanService tenantPlanService,
            IOrderService orderService)
        {
            _tenantProvisioningService = tenantProvisioningService;
            _tenantPlanService = tenantPlanService;
            _orderService = orderService;
        }

        public async Task HandleEventAsync(OrderPaidEvent eventMessage)
        {
            var order = eventMessage.Order;
            if (order == null)
                return;

            // does this order contain a product linked to one of our plans?
            var plans = await _tenantPlanService.GetAllAsync();
            if (plans.Count == 0)
                return;

            var orderItems = await _orderService.GetOrderItemsAsync(order.Id);
            var purchasedPlan = plans.FirstOrDefault(plan =>
                orderItems.Any(item => item.ProductId == plan.LinkedProductId));

            if (purchasedPlan == null)
                return; // a normal order, unrelated to store subscriptions

            // find this customer's most recent still-pending request for this plan
            var subscriptions = await _tenantProvisioningService.GetByOwnerCustomerIdAsync(order.CustomerId);
            var pending = subscriptions
                .Where(s => s.PlanId == purchasedPlan.Id && s.Status == TenantSubscriptionStatus.PendingPayment)
                .OrderByDescending(s => s.CreatedOnUtc)
                .FirstOrDefault();

            if (pending == null)
                return;

            await _tenantProvisioningService.ActivateAfterPaymentAsync(pending.ProvisioningToken);
        }
    }
}
