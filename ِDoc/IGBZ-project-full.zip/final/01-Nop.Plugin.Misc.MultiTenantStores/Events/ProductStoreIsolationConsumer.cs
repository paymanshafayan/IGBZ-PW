using Nop.Core.Domain.Catalog;
using Nop.Core.Events;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Catalog;
using Nop.Services.Events;
using Nop.Services.Stores;

namespace Nop.Plugin.Misc.MultiTenantStores.Events
{
    /// <summary>
    /// PHASE 1: closes the "products leak between stores" gap noted in the README.
    ///
    /// Whenever a Product is created while the current request resolves to a tenant store
    /// (i.e. any store other than the configured platform/main store), this consumer flags it
    /// as store-limited and maps it exclusively to that store. This mirrors exactly what a
    /// human admin would do by hand under Catalog > Products > Edit > Stores, just automatic -
    /// so a tenant store owner never has to remember to do it, and never accidentally publishes
    /// a product visible on every other tenant's storefront too.
    ///
    /// Products created from the platform's own admin (super-admin managing the platform Store
    /// itself) are left untouched.
    /// </summary>
    public class ProductStoreIsolationConsumer : IConsumer<EntityInsertedEvent<Product>>
    {
        private readonly Nop.Core.IStoreContext _storeContext;
        private readonly IProductService _productService;
        private readonly IStoreMappingService _storeMappingService;
        private readonly MultiTenantStoresSettings _settings;

        public ProductStoreIsolationConsumer(
            Nop.Core.IStoreContext storeContext,
            IProductService productService,
            IStoreMappingService storeMappingService,
            MultiTenantStoresSettings settings)
        {
            _storeContext = storeContext;
            _productService = productService;
            _storeMappingService = storeMappingService;
            _settings = settings;
        }

        public async Task HandleEventAsync(EntityInsertedEvent<Product> eventMessage)
        {
            var product = eventMessage?.Entity;
            if (product == null)
                return;

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            if (currentStore == null || currentStore.Id <= 0)
                return;

            // leave the platform's own catalog (if any) exactly as a normal nopCommerce store
            if (_settings.PlatformStoreId > 0 && currentStore.Id == _settings.PlatformStoreId)
                return;

            if (!product.LimitedToStores)
            {
                product.LimitedToStores = true;
                await _productService.UpdateProductAsync(product);
            }

            await _storeMappingService.InsertStoreMappingAsync(product, currentStore.Id);
        }
    }
}
