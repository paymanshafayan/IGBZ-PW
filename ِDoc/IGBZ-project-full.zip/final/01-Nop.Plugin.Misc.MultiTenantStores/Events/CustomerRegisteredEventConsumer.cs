using Nop.Core;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Events;

namespace Nop.Plugin.Misc.MultiTenantStores.Events
{
    /// <summary>
    /// NOTE: confirm "CustomerRegisteredEvent" (namespace Nop.Services.Customers in recent
    /// versions) and its "Customer" property against your exact nopCommerce release.
    /// </summary>
    public class CustomerRegisteredEventConsumer : IConsumer<CustomerRegisteredEvent>
    {
        private readonly IStoreContext _storeContext;
        private readonly IGenericAttributeService _genericAttributeService;

        public CustomerRegisteredEventConsumer(IStoreContext storeContext, IGenericAttributeService genericAttributeService)
        {
            _storeContext = storeContext;
            _genericAttributeService = genericAttributeService;
        }

        public async Task HandleEventAsync(CustomerRegisteredEvent eventMessage)
        {
            var customer = eventMessage?.Customer;
            if (customer == null)
                return;

            // don't overwrite it if it's already set (e.g. re-fired on profile save in some setups)
            var existing = await _genericAttributeService.GetAttributeAsync<int?>(customer, MultiTenantStoresDefaults.HomeStoreIdAttributeKey);
            if (existing is > 0)
                return;

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            await _genericAttributeService.SaveAttributeAsync(customer, MultiTenantStoresDefaults.HomeStoreIdAttributeKey, currentStore.Id);
        }
    }
}
