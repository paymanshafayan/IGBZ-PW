using Nop.Core.Domain.Catalog;
using Nop.Core.Events;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Catalog;
using Nop.Services.Events;
using Nop.Services.Stores;

namespace Nop.Plugin.Misc.MultiTenantStores.Events
{
    /// <summary>
    /// Same idea as ProductStoreIsolationConsumer, for Manufacturer.
    /// </summary>
    public class ManufacturerStoreIsolationConsumer : IConsumer<EntityInsertedEvent<Manufacturer>>
    {
        private readonly Nop.Core.IStoreContext _storeContext;
        private readonly IManufacturerService _manufacturerService;
        private readonly IStoreMappingService _storeMappingService;
        private readonly MultiTenantStoresSettings _settings;

        public ManufacturerStoreIsolationConsumer(
            Nop.Core.IStoreContext storeContext,
            IManufacturerService manufacturerService,
            IStoreMappingService storeMappingService,
            MultiTenantStoresSettings settings)
        {
            _storeContext = storeContext;
            _manufacturerService = manufacturerService;
            _storeMappingService = storeMappingService;
            _settings = settings;
        }

        public async Task HandleEventAsync(EntityInsertedEvent<Manufacturer> eventMessage)
        {
            var manufacturer = eventMessage?.Entity;
            if (manufacturer == null)
                return;

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            if (currentStore == null || currentStore.Id <= 0)
                return;

            if (_settings.PlatformStoreId > 0 && currentStore.Id == _settings.PlatformStoreId)
                return;

            if (!manufacturer.LimitedToStores)
            {
                manufacturer.LimitedToStores = true;
                await _manufacturerService.UpdateManufacturerAsync(manufacturer);
            }

            await _storeMappingService.InsertStoreMappingAsync(manufacturer, currentStore.Id);
        }
    }
}
