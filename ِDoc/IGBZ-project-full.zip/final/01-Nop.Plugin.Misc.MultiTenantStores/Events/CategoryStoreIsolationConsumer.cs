using Nop.Core.Domain.Catalog;
using Nop.Core.Events;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Catalog;
using Nop.Services.Events;
using Nop.Services.Stores;

namespace Nop.Plugin.Misc.MultiTenantStores.Events
{
    /// <summary>
    /// Same idea as ProductStoreIsolationConsumer, for Category. See that class for the full
    /// explanation of when this does/doesn't apply.
    /// </summary>
    public class CategoryStoreIsolationConsumer : IConsumer<EntityInsertedEvent<Category>>
    {
        private readonly Nop.Core.IStoreContext _storeContext;
        private readonly ICategoryService _categoryService;
        private readonly IStoreMappingService _storeMappingService;
        private readonly MultiTenantStoresSettings _settings;

        public CategoryStoreIsolationConsumer(
            Nop.Core.IStoreContext storeContext,
            ICategoryService categoryService,
            IStoreMappingService storeMappingService,
            MultiTenantStoresSettings settings)
        {
            _storeContext = storeContext;
            _categoryService = categoryService;
            _storeMappingService = storeMappingService;
            _settings = settings;
        }

        public async Task HandleEventAsync(EntityInsertedEvent<Category> eventMessage)
        {
            var category = eventMessage?.Entity;
            if (category == null)
                return;

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            if (currentStore == null || currentStore.Id <= 0)
                return;

            if (_settings.PlatformStoreId > 0 && currentStore.Id == _settings.PlatformStoreId)
                return;

            if (!category.LimitedToStores)
            {
                category.LimitedToStores = true;
                await _categoryService.UpdateCategoryAsync(category);
            }

            await _storeMappingService.InsertStoreMappingAsync(category, currentStore.Id);
        }
    }
}
