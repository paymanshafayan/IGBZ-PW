using FluentMigrator.Builders.Create.Table;
using Nop.Data.Mapping.Builders;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Data
{
    public class AppPhoneStoreLinkBuilder : NopEntityBuilder<AppPhoneStoreLink>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table
                .WithColumn(nameof(AppPhoneStoreLink.NormalizedPhone)).AsString(32).NotNullable()
                .WithColumn(nameof(AppPhoneStoreLink.StoreId)).AsInt32().NotNullable();
        }
    }
}
