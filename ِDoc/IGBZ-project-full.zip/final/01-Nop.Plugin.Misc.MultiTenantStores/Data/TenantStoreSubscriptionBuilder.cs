using FluentMigrator.Builders.Create.Table;
using Nop.Data.Mapping.Builders;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Data
{
    public class TenantStoreSubscriptionBuilder : NopEntityBuilder<TenantStoreSubscription>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table
                .WithColumn(nameof(TenantStoreSubscription.RequestedStoreName)).AsString(400).Nullable()
                .WithColumn(nameof(TenantStoreSubscription.RequestedSubdomain)).AsString(300).Nullable()
                .WithColumn(nameof(TenantStoreSubscription.ProvisioningToken)).AsString(100).Nullable();
        }
    }
}
