using FluentMigrator.Builders.Create.Table;
using Nop.Data.Mapping.Builders;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Data
{
    /// <summary>
    /// Describes column types/lengths for the StoreDomainMapping table.
    /// Used by the FluentMigrator "Create.TableFor{T}()" helper.
    /// </summary>
    public class StoreDomainMappingBuilder : NopEntityBuilder<StoreDomainMapping>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table
                .WithColumn(nameof(StoreDomainMapping.Domain)).AsString(400).NotNullable()
                .WithColumn(nameof(StoreDomainMapping.StoreId)).AsInt32().NotNullable()
                .WithColumn(nameof(StoreDomainMapping.Note)).AsString(400).Nullable();
        }
    }
}
