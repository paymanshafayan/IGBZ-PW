using FluentMigrator.Builders.Create.Table;
using Nop.Data.Mapping.Builders;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Data
{
    public class TenantPlanBuilder : NopEntityBuilder<TenantPlan>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table
                .WithColumn(nameof(TenantPlan.Name)).AsString(200).NotNullable()
                .WithColumn(nameof(TenantPlan.Description)).AsString(1000).Nullable();
        }
    }
}
