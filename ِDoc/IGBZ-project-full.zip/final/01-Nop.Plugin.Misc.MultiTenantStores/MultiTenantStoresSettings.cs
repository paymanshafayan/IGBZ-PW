using Nop.Core.Configuration;

namespace Nop.Plugin.Misc.MultiTenantStores
{
    public class MultiTenantStoresSettings : ISettings
    {
        /// <summary>
        /// The root domain new tenant sub-domains are built from, e.g. "yourmainsite.com" so that
        /// a tenant choosing "shop1" gets "shop1.yourmainsite.com". Leave empty to force tenants
        /// to bring their own fully custom domain instead (configured after signup, manually
        /// verified by an administrator under Configuration > Multi-Tenant Domains).
        /// </summary>
        public string BaseDomain { get; set; }

        /// <summary>
        /// Comma separated list of sub-domain labels nobody may claim (in addition to the
        /// built-in defaults in MultiTenantStoresDefaults.DefaultReservedSubdomains)
        /// </summary>
        public string ExtraReservedSubdomains { get; set; }

        /// <summary>
        /// If true, a newly paid store starts in "Trial" (if the plan has trial days) or
        /// "Active" immediately. If false, a super-admin must manually flip the subscription
        /// from PendingPayment/Trial to Active after a manual review (e.g. fraud/content check).
        /// </summary>
        public bool AutoActivateAfterPayment { get; set; } = true;

        /// <summary>
        /// Whether a customer may own more than one store. Kept simple (false) by default:
        /// one store per customer account.
        /// </summary>
        public bool AllowMultipleStoresPerCustomer { get; set; }

        /// <summary>
        /// Id of the "platform" / main Store (the one that hosts the public marketing site and
        /// the "create your store" wizard). 0 = not configured yet (an admin must set this after
        /// installing the plugin, under Configuration > Multi-Tenant Domains > Settings).
        /// The wizard refuses to run on any other store, so tenant sub-sites never expose it.
        /// </summary>
        public int PlatformStoreId { get; set; }
    }
}
