using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Plugin.Misc.MultiTenantStores.Infrastructure;
using Nop.Plugin.Misc.MultiTenantStores.Services;

namespace Nop.Plugin.Misc.MultiTenantStores
{
    public class NopStartup : INopStartup
    {
        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // plugin's own domain-mapping service
            services.AddScoped<IStoreDomainMappingService, StoreDomainMappingService>();
            services.AddScoped<ITenantPlanService, TenantPlanService>();
            services.AddScoped<ITenantProvisioningService, TenantProvisioningService>();

            // phase 3: silent store-detection for the shared customer app (phone number
            // entered on a store's download page -> looked up again from the app's first run)
            services.AddScoped<IAppPhoneStoreLinkService, AppPhoneStoreLinkService>();

            // override the store-resolution logic used everywhere in nopCommerce
            // (this MUST run after Nop.Web.Framework's own registration, hence the high Order below)
            services.AddScoped<IStoreContext, MultiTenantStoreContext>();

            // confines "Tenant Store Owners" to their own store's admin area (see the filter's
            // own comments for exactly what it does and does not guarantee)
            services.Configure<Microsoft.AspNetCore.Mvc.MvcOptions>(options =>
            {
                options.Filters.Add(typeof(TenantAdminScopeFilter));
                options.Filters.Add(typeof(CrossStoreCustomerGuardFilter));
            });
        }

        public void Configure(IApplicationBuilder application)
        {
            // nothing to configure at the pipeline level
        }

        // must run after all core Nop startups (which typically use orders in the 0-3000 range)
        // so that our IStoreContext registration is the one that "wins" in the service collection
        public int Order => 10000;
    }
}
