using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Misc.MultiTenantStores.Domain;
using Nop.Plugin.Misc.MultiTenantStores.Models;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Catalog;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Misc.MultiTenantStores.Controllers
{
    /// <summary>
    /// Public (storefront) controller. Intentionally lives outside the Admin area:
    /// this is where a regular customer of the *main* platform site signs up for their own store.
    /// </summary>
    [AutoValidateAntiforgeryToken]
    public class StoreBuilderController : BasePublicController
    {
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly Nop.Services.Stores.IStoreService _storeService;
        private readonly ICustomerService _customerService;
        private readonly IProductService _productService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly ITenantPlanService _tenantPlanService;
        private readonly ITenantProvisioningService _tenantProvisioningService;
        private readonly ILocalizationService _localizationService;
        private readonly MultiTenantStoresSettings _settings;

        public StoreBuilderController(
            IWorkContext workContext,
            IStoreContext storeContext,
            Nop.Services.Stores.IStoreService storeService,
            ICustomerService customerService,
            IProductService productService,
            IShoppingCartService shoppingCartService,
            ITenantPlanService tenantPlanService,
            ITenantProvisioningService tenantProvisioningService,
            ILocalizationService localizationService,
            MultiTenantStoresSettings settings)
        {
            _workContext = workContext;
            _storeContext = storeContext;
            _storeService = storeService;
            _customerService = customerService;
            _productService = productService;
            _shoppingCartService = shoppingCartService;
            _tenantPlanService = tenantPlanService;
            _tenantProvisioningService = tenantProvisioningService;
            _localizationService = localizationService;
            _settings = settings;
        }

        [HttpGet]
        public virtual async Task<IActionResult> Start()
        {
            var accessCheck = await EnsurePlatformSiteAsync();
            if (accessCheck != null)
                return accessCheck;

            var customer = await _workContext.GetCurrentCustomerAsync();
            if (!await _customerService.IsRegisteredAsync(customer))
                return RedirectToRoute("Login");

            var model = await BuildStartModelAsync();
            return View("~/Plugins/Misc.MultiTenantStores/Views/StoreBuilder/Start.cshtml", model);
        }

        // TIP: add nopCommerce's [ValidateCaptcha] attribute here once you've enabled a captcha
        // provider under Configuration > Settings > General, to slow down automated sign-ups.
        [HttpPost]
        public virtual async Task<IActionResult> Start(StoreBuilderModel model)
        {
            var accessCheck = await EnsurePlatformSiteAsync();
            if (accessCheck != null)
                return accessCheck;

            var customer = await _workContext.GetCurrentCustomerAsync();
            if (!await _customerService.IsRegisteredAsync(customer))
                return RedirectToRoute("Login");

            var subdomainError = await _tenantProvisioningService.ValidateRequestedSubdomainAsync(model.SubdomainLabel);
            if (!string.IsNullOrEmpty(subdomainError))
                ModelState.AddModelError(nameof(model.SubdomainLabel), subdomainError);

            var plan = await _tenantPlanService.GetByIdAsync(model.PlanId);
            if (plan == null || !plan.IsActive)
                ModelState.AddModelError(nameof(model.PlanId), "Please choose a valid plan");

            if (!ModelState.IsValid)
            {
                var refreshed = await BuildStartModelAsync();
                refreshed.StoreName = model.StoreName;
                refreshed.SubdomainLabel = model.SubdomainLabel;
                refreshed.PlanId = model.PlanId;
                return View("~/Plugins/Misc.MultiTenantStores/Views/StoreBuilder/Start.cshtml", refreshed);
            }

            TenantStoreSubscription subscription;
            try
            {
                subscription = await _tenantProvisioningService.CreatePendingRequestAsync(
                    customer, model.StoreName, model.SubdomainLabel, model.PlanId);
            }
            catch (InvalidOperationException ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
                var refreshed = await BuildStartModelAsync();
                return View("~/Plugins/Misc.MultiTenantStores/Views/StoreBuilder/Start.cshtml", refreshed);
            }

            // add the plan's linked product to the cart and send the customer to the normal,
            // fully-featured nopCommerce checkout (any payment method the platform owner has
            // configured - card, PayPal, bank transfer, etc. - works here with zero extra code)
            var product = await _productService.GetProductByIdAsync(plan.LinkedProductId);
            if (product == null)
            {
                ModelState.AddModelError(string.Empty, "This plan is temporarily unavailable. Please contact support");
                var refreshed = await BuildStartModelAsync();
                return View("~/Plugins/Misc.MultiTenantStores/Views/StoreBuilder/Start.cshtml", refreshed);
            }

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            await _shoppingCartService.AddToCartAsync(customer, product, ShoppingCartType.ShoppingCart, currentStore.Id, quantity: 1);

            return RedirectToRoute("ShoppingCart");
        }

        [HttpGet]
        public virtual async Task<IActionResult> MyStore()
        {
            var customer = await _workContext.GetCurrentCustomerAsync();
            if (!await _customerService.IsRegisteredAsync(customer))
                return RedirectToRoute("Login");

            var model = new MyStoreModel();

            var ownedStoreId = await _tenantProvisioningService.GetOwnedStoreIdAsync(customer);
            if (ownedStoreId.HasValue)
            {
                var subscription = await _tenantProvisioningService.GetByStoreIdAsync(ownedStoreId.Value);
                var store = await _storeService.GetStoreByIdAsync(ownedStoreId.Value);

                model.HasStore = true;
                model.StoreName = store?.Name;
                model.StoreUrl = store?.Url;
                model.Status = subscription?.Status.ToString();
                model.TrialEndsOnUtc = subscription?.TrialEndsOnUtc;
                model.CurrentPeriodEndUtc = subscription?.CurrentPeriodEndUtc;
            }

            return View("~/Plugins/Misc.MultiTenantStores/Views/StoreBuilder/MyStore.cshtml", model);
        }

        /// <summary>
        /// Blocks the wizard everywhere except the configured "platform" store, so tenant
        /// sub-sites never expose a way to spin up yet another store from inside someone else's
        /// shop front-end.
        /// </summary>
        private async Task<IActionResult> EnsurePlatformSiteAsync()
        {
            if (_settings.PlatformStoreId <= 0)
                return NotFound();

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            return currentStore.Id == _settings.PlatformStoreId ? null : NotFound();
        }

        private async Task<StoreBuilderModel> BuildStartModelAsync()
        {
            var plans = await _tenantPlanService.GetAllAsync(activeOnly: true);

            return new StoreBuilderModel
            {
                BaseDomain = _settings.BaseDomain,
                AvailablePlans = plans.Select(p => new TenantPlanViewModel
                {
                    Id = p.Id,
                    Name = p.Name,
                    Description = p.Description,
                    TrialDays = p.TrialDays,
                    BillingCycleDays = p.BillingCycleDays
                }).ToList()
            };
        }
    }
}
