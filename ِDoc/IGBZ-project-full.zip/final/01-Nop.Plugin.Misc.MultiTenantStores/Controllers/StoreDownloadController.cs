using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Misc.MultiTenantStores.Models;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Misc.MultiTenantStores.Controllers
{
    /// <summary>
    /// Public (storefront) "get the app" page. Lives on *every* tenant store's own site/domain
    /// (unlike StoreBuilderController, which is restricted to the main platform site) - the
    /// current store is whatever MultiTenantStoreContext resolved from the Host header, and
    /// that's exactly the store the phone number gets tied to.
    /// </summary>
    [AutoValidateAntiforgeryToken]
    public class StoreDownloadController : BasePublicController
    {
        // Iranian mobile numbers: 09xxxxxxxxx, or the same with +98/0098/98 prefixes, with
        // optional spaces/dashes - normalized further by PhoneNumberNormalizer before storage.
        private static readonly Regex PhoneRegex = new(@"^(\+98|0098|0|98)?\s?9\d{2}[\s-]?\d{3}[\s-]?\d{4}$", RegexOptions.Compiled);

        private readonly IStoreContext _storeContext;
        private readonly Nop.Services.Stores.IStoreService _storeService;
        private readonly IAppPhoneStoreLinkService _appPhoneStoreLinkService;

        public StoreDownloadController(
            IStoreContext storeContext,
            Nop.Services.Stores.IStoreService storeService,
            IAppPhoneStoreLinkService appPhoneStoreLinkService)
        {
            _storeContext = storeContext;
            _storeService = storeService;
            _appPhoneStoreLinkService = appPhoneStoreLinkService;
        }

        [HttpGet]
        public virtual async Task<IActionResult> Index()
        {
            var currentStore = await _storeContext.GetCurrentStoreAsync();
            var model = new StoreDownloadModel { StoreName = currentStore?.Name };
            return View("~/Plugins/Misc.MultiTenantStores/Views/StoreDownload/Index.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> Index(StoreDownloadModel model)
        {
            var currentStore = await _storeContext.GetCurrentStoreAsync();
            model.StoreName = currentStore?.Name;

            if (string.IsNullOrWhiteSpace(model.PhoneNumber) || !PhoneRegex.IsMatch(model.PhoneNumber.Trim()))
            {
                ModelState.AddModelError(nameof(model.PhoneNumber), "شماره موبایل را به‌صورت صحیح وارد کنید (مثال: 0912xxxxxxx).");
                return View("~/Plugins/Misc.MultiTenantStores/Views/StoreDownload/Index.cshtml", model);
            }

            // this is the entire trick: the same number entered here now resolves this store
            // for the app on its very first launch (see AppPhoneStoreLink for the full flow)
            await _appPhoneStoreLinkService.RecordAsync(model.PhoneNumber, currentStore.Id);

            model.PhoneConfirmed = true;
            return View("~/Plugins/Misc.MultiTenantStores/Views/StoreDownload/Index.cshtml", model);
        }
    }
}
