using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Models;
using Nop.Plugin.Misc.MultiTenantStores.Domain;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Catalog;
using Nop.Services.Localization;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Controllers
{
    [Area(AreaNames.Admin)]
    [AuthorizeAdmin]
    [AutoValidateAntiforgeryToken]
    public class TenantPlansController : BaseAdminController
    {
        private readonly ITenantPlanService _tenantPlanService;
        private readonly IProductService _productService;
        private readonly IPermissionService _permissionService;
        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;

        public TenantPlansController(
            ITenantPlanService tenantPlanService,
            IProductService productService,
            IPermissionService permissionService,
            ILocalizationService localizationService,
            INotificationService notificationService)
        {
            _tenantPlanService = tenantPlanService;
            _productService = productService;
            _permissionService = permissionService;
            _localizationService = localizationService;
            _notificationService = notificationService;
        }

        public virtual async Task<IActionResult> List()
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var plans = await _tenantPlanService.GetAllAsync();
            var models = new List<TenantPlanModel>();
            foreach (var plan in plans)
                models.Add(await PrepareModelAsync(plan));

            var model = new TenantPlanListModel { Data = models, Total = models.Count };
            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/TenantPlans/List.cshtml", model);
        }

        public virtual async Task<IActionResult> Create()
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/TenantPlans/Create.cshtml", new TenantPlanModel { IsActive = true, BillingCycleDays = 30 });
        }

        [HttpPost]
        public virtual async Task<IActionResult> Create(TenantPlanModel model, bool continueEditing)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            if (await _productService.GetProductByIdAsync(model.LinkedProductId) == null)
                ModelState.AddModelError(nameof(model.LinkedProductId), "Please enter a valid, existing Product Id to charge for this plan");

            if (ModelState.IsValid)
            {
                var plan = new TenantPlan
                {
                    Name = model.Name,
                    Description = model.Description,
                    LinkedProductId = model.LinkedProductId,
                    BillingCycleDays = model.BillingCycleDays,
                    TrialDays = model.TrialDays,
                    MaxProducts = model.MaxProducts,
                    IsActive = model.IsActive,
                    DisplayOrder = model.DisplayOrder
                };
                await _tenantPlanService.InsertAsync(plan);

                _notificationService.SuccessNotification("The plan has been added successfully.");

                return continueEditing ? RedirectToAction("Edit", new { id = plan.Id }) : RedirectToAction("List");
            }

            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/TenantPlans/Create.cshtml", model);
        }

        public virtual async Task<IActionResult> Edit(int id)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var plan = await _tenantPlanService.GetByIdAsync(id);
            if (plan == null)
                return RedirectToAction("List");

            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/TenantPlans/Edit.cshtml", await PrepareModelAsync(plan));
        }

        [HttpPost]
        public virtual async Task<IActionResult> Edit(TenantPlanModel model, bool continueEditing)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var plan = await _tenantPlanService.GetByIdAsync(model.Id);
            if (plan == null)
                return RedirectToAction("List");

            if (await _productService.GetProductByIdAsync(model.LinkedProductId) == null)
                ModelState.AddModelError(nameof(model.LinkedProductId), "Please enter a valid, existing Product Id to charge for this plan");

            if (ModelState.IsValid)
            {
                plan.Name = model.Name;
                plan.Description = model.Description;
                plan.LinkedProductId = model.LinkedProductId;
                plan.BillingCycleDays = model.BillingCycleDays;
                plan.TrialDays = model.TrialDays;
                plan.MaxProducts = model.MaxProducts;
                plan.IsActive = model.IsActive;
                plan.DisplayOrder = model.DisplayOrder;

                await _tenantPlanService.UpdateAsync(plan);

                _notificationService.SuccessNotification("The plan has been updated successfully.");

                return continueEditing ? RedirectToAction("Edit", new { id = plan.Id }) : RedirectToAction("List");
            }

            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/TenantPlans/Edit.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> Delete(int id)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var plan = await _tenantPlanService.GetByIdAsync(id);
            if (plan != null)
                await _tenantPlanService.DeleteAsync(plan);

            _notificationService.SuccessNotification("The plan has been deleted.");
            return RedirectToAction("List");
        }

        private async Task<TenantPlanModel> PrepareModelAsync(TenantPlan plan)
        {
            var product = await _productService.GetProductByIdAsync(plan.LinkedProductId);

            return new TenantPlanModel
            {
                Id = plan.Id,
                Name = plan.Name,
                Description = plan.Description,
                LinkedProductId = plan.LinkedProductId,
                LinkedProductName = product?.Name ?? $"#{plan.LinkedProductId} (not found)",
                BillingCycleDays = plan.BillingCycleDays,
                TrialDays = plan.TrialDays,
                MaxProducts = plan.MaxProducts,
                IsActive = plan.IsActive,
                DisplayOrder = plan.DisplayOrder
            };
        }
    }
}
