using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Models;
using Nop.Plugin.Misc.MultiTenantStores.Domain;
using Nop.Plugin.Misc.MultiTenantStores.Services;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Security;
using Nop.Services.Stores;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Controllers
{
    [Area(AreaNames.Admin)]
    [AuthorizeAdmin]
    [AutoValidateAntiforgeryToken]
    public class StoreDomainsController : BaseAdminController
    {
        private readonly IStoreDomainMappingService _storeDomainMappingService;
        private readonly IStoreService _storeService;
        private readonly IPermissionService _permissionService;
        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;

        public StoreDomainsController(
            IStoreDomainMappingService storeDomainMappingService,
            IStoreService storeService,
            IPermissionService permissionService,
            ILocalizationService localizationService,
            INotificationService notificationService)
        {
            _storeDomainMappingService = storeDomainMappingService;
            _storeService = storeService;
            _permissionService = permissionService;
            _localizationService = localizationService;
            _notificationService = notificationService;
        }

        public virtual async Task<IActionResult> List()
        {
            if (!await _permissionService.AuthorizeAsync(Nop.Services.Security.StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var allMappings = (await _storeDomainMappingService.GetAllAsync())
                .OrderBy(m => m.StoreId).ThenBy(m => m.Domain)
                .ToList();

            var storeModels = new List<StoreDomainMappingModel>();
            foreach (var mapping in allMappings)
                storeModels.Add(await PrepareModelAsync(mapping));

            var model = new StoreDomainMappingListModel
            {
                Data = storeModels,
                Total = storeModels.Count
            };

            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/StoreDomains/List.cshtml", model);
        }

        public virtual async Task<IActionResult> Create()
        {
            if (!await _permissionService.AuthorizeAsync(Nop.Services.Security.StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var model = new StoreDomainMappingModel
            {
                Enabled = true,
                RequireSsl = true
            };
            await PrepareStoresDropDownAsync(model);

            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/StoreDomains/Create.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> Create(StoreDomainMappingModel model, bool continueEditing)
        {
            if (!await _permissionService.AuthorizeAsync(Nop.Services.Security.StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var validationError = await _storeDomainMappingService.ValidateDomainAsync(model.Domain, 0);
            if (!string.IsNullOrEmpty(validationError))
                ModelState.AddModelError(string.Empty, validationError);

            if (ModelState.IsValid)
            {
                var mapping = new StoreDomainMapping
                {
                    StoreId = model.StoreId,
                    Domain = model.Domain,
                    Enabled = model.Enabled,
                    IsPrimary = model.IsPrimary,
                    RequireSsl = model.RequireSsl,
                    Note = model.Note
                };

                await _storeDomainMappingService.InsertAsync(mapping);

                _notificationService.SuccessNotification(
                    await _localizationService.GetResourceAsync("Plugins.Misc.MultiTenantStores.Added"));

                return continueEditing
                    ? RedirectToAction("Edit", new { id = mapping.Id })
                    : RedirectToAction("List");
            }

            await PrepareStoresDropDownAsync(model);
            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/StoreDomains/Create.cshtml", model);
        }

        public virtual async Task<IActionResult> Edit(int id)
        {
            if (!await _permissionService.AuthorizeAsync(Nop.Services.Security.StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var mapping = await _storeDomainMappingService.GetByIdAsync(id);
            if (mapping == null)
                return RedirectToAction("List");

            var model = await PrepareModelAsync(mapping);
            await PrepareStoresDropDownAsync(model);

            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/StoreDomains/Edit.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> Edit(StoreDomainMappingModel model, bool continueEditing)
        {
            if (!await _permissionService.AuthorizeAsync(Nop.Services.Security.StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var mapping = await _storeDomainMappingService.GetByIdAsync(model.Id);
            if (mapping == null)
                return RedirectToAction("List");

            var validationError = await _storeDomainMappingService.ValidateDomainAsync(model.Domain, model.Id);
            if (!string.IsNullOrEmpty(validationError))
                ModelState.AddModelError(string.Empty, validationError);

            if (ModelState.IsValid)
            {
                mapping.StoreId = model.StoreId;
                mapping.Domain = model.Domain;
                mapping.Enabled = model.Enabled;
                mapping.IsPrimary = model.IsPrimary;
                mapping.RequireSsl = model.RequireSsl;
                mapping.Note = model.Note;

                await _storeDomainMappingService.UpdateAsync(mapping);

                _notificationService.SuccessNotification(
                    await _localizationService.GetResourceAsync("Plugins.Misc.MultiTenantStores.Updated"));

                return continueEditing
                    ? RedirectToAction("Edit", new { id = mapping.Id })
                    : RedirectToAction("List");
            }

            await PrepareStoresDropDownAsync(model);
            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/StoreDomains/Edit.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> Delete(int id)
        {
            if (!await _permissionService.AuthorizeAsync(Nop.Services.Security.StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var mapping = await _storeDomainMappingService.GetByIdAsync(id);
            if (mapping != null)
                await _storeDomainMappingService.DeleteAsync(mapping);

            _notificationService.SuccessNotification(
                await _localizationService.GetResourceAsync("Plugins.Misc.MultiTenantStores.Deleted"));

            return RedirectToAction("List");
        }

        private async Task<StoreDomainMappingModel> PrepareModelAsync(StoreDomainMapping mapping)
        {
            var store = await _storeService.GetStoreByIdAsync(mapping.StoreId);

            return new StoreDomainMappingModel
            {
                Id = mapping.Id,
                StoreId = mapping.StoreId,
                StoreName = store?.Name ?? $"#{mapping.StoreId}",
                Domain = mapping.Domain,
                Enabled = mapping.Enabled,
                IsPrimary = mapping.IsPrimary,
                RequireSsl = mapping.RequireSsl,
                Note = mapping.Note,
                CreatedOnUtc = mapping.CreatedOnUtc
            };
        }

        private async Task PrepareStoresDropDownAsync(StoreDomainMappingModel model)
        {
            var stores = await _storeService.GetAllStoresAsync();
            model.AvailableStores = stores
                .Select(s => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                {
                    Text = s.Name,
                    Value = s.Id.ToString(),
                    Selected = s.Id == model.StoreId
                })
                .ToList();
        }
    }
}
