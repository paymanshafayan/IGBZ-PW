using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Models;
using Nop.Services.Configuration;
using Nop.Services.Security;
using Nop.Services.Stores;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Controllers
{
    [Area(AreaNames.Admin)]
    [AuthorizeAdmin]
    [AutoValidateAntiforgeryToken]
    public class TenantSettingsController : BaseAdminController
    {
        private readonly ISettingService _settingService;
        private readonly IStoreService _storeService;
        private readonly IPermissionService _permissionService;
        private readonly INotificationService _notificationService;
        private readonly MultiTenantStoresSettings _settings;

        public TenantSettingsController(
            ISettingService settingService,
            IStoreService storeService,
            IPermissionService permissionService,
            INotificationService notificationService,
            MultiTenantStoresSettings settings)
        {
            _settingService = settingService;
            _storeService = storeService;
            _permissionService = permissionService;
            _notificationService = notificationService;
            _settings = settings;
        }

        public virtual async Task<IActionResult> Configure()
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            var model = new MultiTenantStoresConfigModel
            {
                BaseDomain = _settings.BaseDomain,
                PlatformStoreId = _settings.PlatformStoreId,
                ExtraReservedSubdomains = _settings.ExtraReservedSubdomains,
                AutoActivateAfterPayment = _settings.AutoActivateAfterPayment,
                AllowMultipleStoresPerCustomer = _settings.AllowMultipleStoresPerCustomer
            };

            var stores = await _storeService.GetAllStoresAsync();
            model.AvailableStores = stores
                .Select(s => new SelectListItem { Text = s.Name, Value = s.Id.ToString() })
                .ToList();
            model.AvailableStores.Insert(0, new SelectListItem { Text = "-- not configured --", Value = "0" });

            return View("~/Plugins/Misc.MultiTenantStores/Areas/Admin/Views/TenantSettings/Configure.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> Configure(MultiTenantStoresConfigModel model)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageStores))
                return AccessDeniedView();

            _settings.BaseDomain = model.BaseDomain?.Trim().ToLowerInvariant();
            _settings.PlatformStoreId = model.PlatformStoreId;
            _settings.ExtraReservedSubdomains = model.ExtraReservedSubdomains;
            _settings.AutoActivateAfterPayment = model.AutoActivateAfterPayment;
            _settings.AllowMultipleStoresPerCustomer = model.AllowMultipleStoresPerCustomer;

            await _settingService.SaveSettingAsync(_settings);

            _notificationService.SuccessNotification("Settings saved.");

            return RedirectToAction("Configure");
        }
    }
}
