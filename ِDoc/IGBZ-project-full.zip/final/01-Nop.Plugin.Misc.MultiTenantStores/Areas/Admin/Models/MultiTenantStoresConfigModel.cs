using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Models
{
    public partial class MultiTenantStoresConfigModel : BaseNopModel
    {
        public MultiTenantStoresConfigModel()
        {
            AvailableStores = new List<SelectListItem>();
        }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Settings.BaseDomain")]
        public string BaseDomain { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Settings.PlatformStoreId")]
        public int PlatformStoreId { get; set; }

        public IList<SelectListItem> AvailableStores { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Settings.ExtraReservedSubdomains")]
        public string ExtraReservedSubdomains { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Settings.AutoActivateAfterPayment")]
        public bool AutoActivateAfterPayment { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Settings.AllowMultipleStoresPerCustomer")]
        public bool AllowMultipleStoresPerCustomer { get; set; }
    }
}
