using Nop.Web.Framework.Models;

namespace Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Models
{
    public partial class StoreDomainSearchModel : BaseSearchModel
    {
        public StoreDomainSearchModel()
        {
        }
    }
}
