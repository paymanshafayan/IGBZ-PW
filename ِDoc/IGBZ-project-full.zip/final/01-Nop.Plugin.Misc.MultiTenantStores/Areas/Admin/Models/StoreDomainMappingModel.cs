using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Models
{
    public partial class StoreDomainMappingModel : BaseNopEntityModel
    {
        public StoreDomainMappingModel()
        {
            AvailableStores = new List<SelectListItem>();
        }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Fields.Store")]
        public int StoreId { get; set; }

        public string StoreName { get; set; }

        public IList<SelectListItem> AvailableStores { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Fields.Domain")]
        public string Domain { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Fields.Enabled")]
        public bool Enabled { get; set; } = true;

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Fields.IsPrimary")]
        public bool IsPrimary { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Fields.RequireSsl")]
        public bool RequireSsl { get; set; } = true;

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Fields.Note")]
        public string Note { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Fields.CreatedOn")]
        public DateTime CreatedOnUtc { get; set; }
    }
}
