using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Models
{
    public partial class TenantPlanModel : BaseNopEntityModel
    {
        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Plan.Name")]
        public string Name { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Plan.Description")]
        public string Description { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Plan.LinkedProductId")]
        public int LinkedProductId { get; set; }

        public string LinkedProductName { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Plan.BillingCycleDays")]
        public int BillingCycleDays { get; set; } = 30;

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Plan.TrialDays")]
        public int TrialDays { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Plan.MaxProducts")]
        public int MaxProducts { get; set; }

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Plan.IsActive")]
        public bool IsActive { get; set; } = true;

        [NopResourceDisplayName("Plugins.Misc.MultiTenantStores.Plan.DisplayOrder")]
        public int DisplayOrder { get; set; }
    }

    public partial class TenantPlanListModel : BasePagedListModel<TenantPlanModel>
    {
    }
}
