using Nop.Web.Framework.Models;

namespace Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Models
{
    public partial class StoreDomainMappingListModel : BasePagedListModel<StoreDomainMappingModel>
    {
    }
}
