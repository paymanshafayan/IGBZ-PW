using FluentValidation;
using Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Models;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;

namespace Nop.Plugin.Misc.MultiTenantStores.Areas.Admin.Validators
{
    public class StoreDomainMappingValidator : BaseNopValidator<StoreDomainMappingModel>
    {
        public StoreDomainMappingValidator(ILocalizationService localizationService)
        {
            RuleFor(x => x.Domain)
                .NotEmpty()
                .WithMessage("Please enter a domain or sub-domain (e.g. shop1.example.com or *.example.com)");

            RuleFor(x => x.StoreId)
                .NotEqual(0)
                .WithMessage("Please select a store");
        }
    }
}
