namespace Nop.Plugin.Misc.MultiTenantStores.Services
{
    /// <summary>
    /// Backs the silent store-detection flow for the shared customer app (see
    /// ARCHITECTURE.md section 5 and <see cref="Domain.AppPhoneStoreLink"/> for the full
    /// rationale).
    /// </summary>
    public partial interface IAppPhoneStoreLinkService
    {
        /// <summary>
        /// Called from the storefront "get the app" download page: records that this phone
        /// number was entered while browsing the given store. Safe to call repeatedly for the
        /// same phone+store pair (upserts rather than piling up duplicate rows).
        /// </summary>
        Task RecordAsync(string phoneNumber, int storeId);

        /// <summary>
        /// Called from the API's resolve endpoint: returns the Id of the store this phone
        /// number was most recently seen on, or null if it has never been entered on any
        /// store's download page.
        /// </summary>
        Task<int?> ResolveStoreIdAsync(string phoneNumber);
    }
}
