using Nop.Data;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Services
{
    public partial class AppPhoneStoreLinkService : IAppPhoneStoreLinkService
    {
        private readonly IRepository<AppPhoneStoreLink> _linkRepository;

        public AppPhoneStoreLinkService(IRepository<AppPhoneStoreLink> linkRepository)
        {
            _linkRepository = linkRepository;
        }

        public virtual async Task RecordAsync(string phoneNumber, int storeId)
        {
            var normalized = PhoneNumberNormalizer.Normalize(phoneNumber);
            if (string.IsNullOrEmpty(normalized) || storeId <= 0)
                return;

            var existing = _linkRepository.Table
                .FirstOrDefault(l => l.NormalizedPhone == normalized && l.StoreId == storeId);

            var now = DateTime.UtcNow;

            if (existing != null)
            {
                existing.LastSeenOnUtc = now;
                await _linkRepository.UpdateAsync(existing);
                return;
            }

            await _linkRepository.InsertAsync(new AppPhoneStoreLink
            {
                NormalizedPhone = normalized,
                StoreId = storeId,
                CreatedOnUtc = now,
                LastSeenOnUtc = now
            });
        }

        public virtual async Task<int?> ResolveStoreIdAsync(string phoneNumber)
        {
            var normalized = PhoneNumberNormalizer.Normalize(phoneNumber);
            if (string.IsNullOrEmpty(normalized))
                return null;

            var latest = _linkRepository.Table
                .Where(l => l.NormalizedPhone == normalized)
                .OrderByDescending(l => l.LastSeenOnUtc)
                .FirstOrDefault();

            return await Task.FromResult(latest?.StoreId);
        }
    }
}
