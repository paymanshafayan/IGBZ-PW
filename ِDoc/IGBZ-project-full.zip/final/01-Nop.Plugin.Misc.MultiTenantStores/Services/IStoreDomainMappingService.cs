using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Services
{
    public partial interface IStoreDomainMappingService
    {
        Task InsertAsync(StoreDomainMapping mapping);

        Task UpdateAsync(StoreDomainMapping mapping);

        Task DeleteAsync(StoreDomainMapping mapping);

        Task<StoreDomainMapping> GetByIdAsync(int id);

        Task<IList<StoreDomainMapping>> GetAllAsync();

        Task<IList<StoreDomainMapping>> GetByStoreIdAsync(int storeId);

        /// <summary>
        /// Resolves a mapping for an incoming host name (e.g. "shop1.example.com").
        /// Tries an exact match first, then falls back to wildcard sub-domain patterns
        /// such as "*.example.com".
        /// </summary>
        Task<StoreDomainMapping> FindByHostAsync(string host);

        /// <summary>
        /// Validates that a domain is well formed and not already bound to a different store
        /// </summary>
        Task<string> ValidateDomainAsync(string domain, int currentMappingId);
    }
}
