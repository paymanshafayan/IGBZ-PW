using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Services
{
    public partial interface ITenantPlanService
    {
        Task InsertAsync(TenantPlan plan);
        Task UpdateAsync(TenantPlan plan);
        Task DeleteAsync(TenantPlan plan);
        Task<TenantPlan> GetByIdAsync(int id);
        Task<IList<TenantPlan>> GetAllAsync(bool activeOnly = false);
    }
}
