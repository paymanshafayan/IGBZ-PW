using Nop.Core.Caching;
using Nop.Data;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Services
{
    public partial class TenantPlanService : ITenantPlanService
    {
        private readonly IRepository<TenantPlan> _planRepository;
        private readonly IStaticCacheManager _staticCacheManager;

        public TenantPlanService(IRepository<TenantPlan> planRepository, IStaticCacheManager staticCacheManager)
        {
            _planRepository = planRepository;
            _staticCacheManager = staticCacheManager;
        }

        public virtual async Task InsertAsync(TenantPlan plan)
        {
            await _planRepository.InsertAsync(plan);
            await _staticCacheManager.RemoveByPrefixAsync(MultiTenantStoresDefaults.MultiTenantStoresPrefixCacheKey);
        }

        public virtual async Task UpdateAsync(TenantPlan plan)
        {
            await _planRepository.UpdateAsync(plan);
            await _staticCacheManager.RemoveByPrefixAsync(MultiTenantStoresDefaults.MultiTenantStoresPrefixCacheKey);
        }

        public virtual async Task DeleteAsync(TenantPlan plan)
        {
            await _planRepository.DeleteAsync(plan);
            await _staticCacheManager.RemoveByPrefixAsync(MultiTenantStoresDefaults.MultiTenantStoresPrefixCacheKey);
        }

        public virtual async Task<TenantPlan> GetByIdAsync(int id)
        {
            return await _planRepository.GetByIdAsync(id);
        }

        public virtual async Task<IList<TenantPlan>> GetAllAsync(bool activeOnly = false)
        {
            var all = await _staticCacheManager.GetAsync(MultiTenantStoresDefaults.AllPlansCacheKey, async () =>
            {
                var query = _planRepository.Table.OrderBy(p => p.DisplayOrder).ThenBy(p => p.Name);
                return await Task.FromResult(query.ToList());
            });

            return activeOnly ? all.Where(p => p.IsActive).ToList() : all;
        }
    }
}
