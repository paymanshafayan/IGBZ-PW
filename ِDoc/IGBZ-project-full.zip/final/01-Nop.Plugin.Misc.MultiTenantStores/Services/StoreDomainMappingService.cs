using Nop.Core.Caching;
using Nop.Data;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Services
{
    public partial class StoreDomainMappingService : IStoreDomainMappingService
    {
        private readonly IRepository<StoreDomainMapping> _mappingRepository;
        private readonly IStaticCacheManager _staticCacheManager;

        public StoreDomainMappingService(
            IRepository<StoreDomainMapping> mappingRepository,
            IStaticCacheManager staticCacheManager)
        {
            _mappingRepository = mappingRepository;
            _staticCacheManager = staticCacheManager;
        }

        public virtual async Task InsertAsync(StoreDomainMapping mapping)
        {
            ArgumentNullException.ThrowIfNull(mapping);

            mapping.Domain = NormalizeHost(mapping.Domain);
            mapping.CreatedOnUtc = DateTime.UtcNow;

            await _mappingRepository.InsertAsync(mapping);
            await _staticCacheManager.RemoveByPrefixAsync(MultiTenantStoresDefaults.MultiTenantStoresPrefixCacheKey);
        }

        public virtual async Task UpdateAsync(StoreDomainMapping mapping)
        {
            ArgumentNullException.ThrowIfNull(mapping);

            mapping.Domain = NormalizeHost(mapping.Domain);

            await _mappingRepository.UpdateAsync(mapping);
            await _staticCacheManager.RemoveByPrefixAsync(MultiTenantStoresDefaults.MultiTenantStoresPrefixCacheKey);
        }

        public virtual async Task DeleteAsync(StoreDomainMapping mapping)
        {
            ArgumentNullException.ThrowIfNull(mapping);

            await _mappingRepository.DeleteAsync(mapping);
            await _staticCacheManager.RemoveByPrefixAsync(MultiTenantStoresDefaults.MultiTenantStoresPrefixCacheKey);
        }

        public virtual async Task<StoreDomainMapping> GetByIdAsync(int id)
        {
            return await _mappingRepository.GetByIdAsync(id);
        }

        public virtual async Task<IList<StoreDomainMapping>> GetAllAsync()
        {
            return await _staticCacheManager.GetAsync(MultiTenantStoresDefaults.AllMappingsCacheKey, async () =>
            {
                var query = _mappingRepository.Table.OrderBy(m => m.StoreId).ThenBy(m => m.Domain);
                return await Task.FromResult(query.ToList());
            });
        }

        public virtual async Task<IList<StoreDomainMapping>> GetByStoreIdAsync(int storeId)
        {
            var all = await GetAllAsync();
            return all.Where(m => m.StoreId == storeId).ToList();
        }

        public virtual async Task<StoreDomainMapping> FindByHostAsync(string host)
        {
            if (string.IsNullOrWhiteSpace(host))
                return null;

            host = NormalizeHost(host);

            var all = await GetAllAsync();
            var enabled = all.Where(m => m.Enabled).ToList();

            // 1) exact match, e.g. "shop1.example.com"
            var exact = enabled.FirstOrDefault(m =>
                !m.Domain.StartsWith("*.") &&
                string.Equals(m.Domain, host, StringComparison.OrdinalIgnoreCase));
            if (exact != null)
                return exact;

            // 2) wildcard sub-domain match, e.g. "*.example.com" matches "anything.example.com"
            var wildcard = enabled
                .Where(m => m.Domain.StartsWith("*.", StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(m => m.Domain.Length) // most specific wildcard wins
                .FirstOrDefault(m =>
                {
                    var suffix = m.Domain[1..]; // keep the leading dot, e.g. ".example.com"
                    return host.EndsWith(suffix, StringComparison.OrdinalIgnoreCase) &&
                           host.Length > suffix.Length;
                });

            return wildcard;
        }

        public virtual Task<string> ValidateDomainAsync(string domain, int currentMappingId)
        {
            if (string.IsNullOrWhiteSpace(domain))
                return Task.FromResult("Domain is required");

            domain = NormalizeHost(domain);

            var isWildcard = domain.StartsWith("*.", StringComparison.OrdinalIgnoreCase);
            var hostToValidate = isWildcard ? domain[2..] : domain;

            if (!IsValidHostName(hostToValidate))
                return Task.FromResult("The domain format is invalid. Use a real domain or sub-domain, e.g. shop1.example.com or *.example.com for a wildcard");

            var duplicate = _mappingRepository.Table
                .FirstOrDefault(m => m.Id != currentMappingId &&
                                     m.Domain.ToLower() == domain.ToLower());

            if (duplicate != null)
                return Task.FromResult("This domain is already bound to another store");

            return Task.FromResult(string.Empty);
        }

        protected virtual string NormalizeHost(string host)
        {
            if (string.IsNullOrWhiteSpace(host))
                return host;

            host = host.Trim().ToLowerInvariant();

            // strip protocol, path, port and trailing slash if a full URL was pasted by mistake
            host = host.Replace("https://", string.Empty).Replace("http://", string.Empty);
            host = host.Split('/')[0];
            host = host.Split(':')[0];

            return host.TrimEnd('.');
        }

        protected virtual bool IsValidHostName(string host)
        {
            if (string.IsNullOrWhiteSpace(host) || host.Length > 253)
                return false;

            var labels = host.Split('.');
            if (labels.Length < 2)
                return false;

            foreach (var label in labels)
            {
                if (label.Length == 0 || label.Length > 63)
                    return false;

                if (!label.All(c => char.IsLetterOrDigit(c) || c == '-'))
                    return false;

                if (label.StartsWith('-') || label.EndsWith('-'))
                    return false;
            }

            return true;
        }
    }
}
