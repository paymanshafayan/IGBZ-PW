using Nop.Core.Domain.Customers;
using Nop.Plugin.Misc.MultiTenantStores.Domain;

namespace Nop.Plugin.Misc.MultiTenantStores.Services
{
    public partial interface ITenantProvisioningService
    {
        /// <summary>
        /// Validates a sub-domain label typed in the wizard: format, reserved words, and
        /// uniqueness against both this plugin's domain-mapping table and every Store's own
        /// Url/Hosts fields. Returns an empty string when valid, otherwise a user-facing error.
        /// </summary>
        Task<string> ValidateRequestedSubdomainAsync(string subdomainLabel);

        /// <summary>
        /// Step 1 of the wizard: records the request (store name, chosen sub-domain, plan)
        /// against the current customer with Status = PendingPayment, and returns the
        /// subscription together with a provisioning token to stamp on the cart order.
        /// No Store is created yet - only after payment succeeds.
        /// </summary>
        Task<TenantStoreSubscription> CreatePendingRequestAsync(Customer owner, string storeName, string subdomainLabel, int planId);

        /// <summary>
        /// Step 2 of the wizard (called from the OrderPaid event consumer): finds the pending
        /// request by its provisioning token and, if still awaiting payment, actually creates
        /// the nopCommerce Store, the domain binding, assigns the restricted "Tenant Store
        /// Owners" role to the customer, and activates the subscription (Trial or Active).
        /// Safe to call more than once for the same token (idempotent).
        /// </summary>
        Task<TenantStoreSubscription> ActivateAfterPaymentAsync(string provisioningToken);

        Task<TenantStoreSubscription> GetByProvisioningTokenAsync(string provisioningToken);

        Task<TenantStoreSubscription> GetByStoreIdAsync(int storeId);

        Task<IList<TenantStoreSubscription>> GetByOwnerCustomerIdAsync(int customerId);

        Task<IList<TenantStoreSubscription>> GetAllAsync();

        Task UpdateAsync(TenantStoreSubscription subscription);

        /// <summary>
        /// Returns the Id of the store the given customer owns, or null if they don't own one.
        /// Backed by a generic attribute on the Customer for a fast, cache-friendly lookup.
        /// </summary>
        Task<int?> GetOwnedStoreIdAsync(Customer customer);

        /// <summary>
        /// Disables the domain binding(s) and marks the subscription Suspended - used for
        /// non-payment / abuse / manual action. Reversible via ReactivateAsync.
        /// </summary>
        Task SuspendAsync(TenantStoreSubscription subscription);

        Task ReactivateAsync(TenantStoreSubscription subscription);
    }
}
