using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Stores;
using Nop.Data;
using Nop.Plugin.Misc.MultiTenantStores.Domain;
using Nop.Services.Customers;
using Nop.Services.Common;
using Nop.Services.Stores;

namespace Nop.Plugin.Misc.MultiTenantStores.Services
{
    public partial class TenantProvisioningService : ITenantProvisioningService
    {
        private readonly IRepository<TenantStoreSubscription> _subscriptionRepository;
        private readonly IStoreDomainMappingService _storeDomainMappingService;
        private readonly ITenantPlanService _tenantPlanService;
        private readonly IStoreService _storeService;
        private readonly ICustomerService _customerService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly MultiTenantStoresSettings _settings;

        public TenantProvisioningService(
            IRepository<TenantStoreSubscription> subscriptionRepository,
            IStoreDomainMappingService storeDomainMappingService,
            ITenantPlanService tenantPlanService,
            IStoreService storeService,
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            MultiTenantStoresSettings settings)
        {
            _subscriptionRepository = subscriptionRepository;
            _storeDomainMappingService = storeDomainMappingService;
            _tenantPlanService = tenantPlanService;
            _storeService = storeService;
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
            _settings = settings;
        }

        public virtual async Task<string> ValidateRequestedSubdomainAsync(string subdomainLabel)
        {
            if (string.IsNullOrWhiteSpace(subdomainLabel))
                return "Please choose a sub-domain";

            subdomainLabel = subdomainLabel.Trim().ToLowerInvariant();

            if (subdomainLabel.Length < 3 || subdomainLabel.Length > 63)
                return "The sub-domain must be between 3 and 63 characters long";

            if (!subdomainLabel.All(c => char.IsLetterOrDigit(c) || c == '-') ||
                subdomainLabel.StartsWith('-') || subdomainLabel.EndsWith('-'))
                return "The sub-domain can only contain letters, digits and hyphens, and cannot start or end with a hyphen";

            var reserved = MultiTenantStoresDefaults.DefaultReservedSubdomains
                .Concat((_settings.ExtraReservedSubdomains ?? string.Empty)
                    .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                .Select(s => s.ToLowerInvariant());

            if (reserved.Contains(subdomainLabel))
                return "This sub-domain name is reserved. Please choose another one";

            if (string.IsNullOrWhiteSpace(_settings.BaseDomain))
                return "The platform base domain is not configured yet. Please contact the site administrator";

            var fullHost = $"{subdomainLabel}.{_settings.BaseDomain}".ToLowerInvariant();

            var existingMapping = await _storeDomainMappingService.FindByHostAsync(fullHost);
            if (existingMapping != null)
                return "This store name is already taken. Please choose another one";

            var pendingWithSameLabel = _subscriptionRepository.Table
                .FirstOrDefault(s => s.RequestedSubdomain == subdomainLabel &&
                                     s.Status == TenantSubscriptionStatus.PendingPayment);
            if (pendingWithSameLabel != null)
                return "Someone else is already completing checkout for this store name. Please choose another one, or try again later";

            return string.Empty;
        }

        public virtual async Task<TenantStoreSubscription> CreatePendingRequestAsync(Customer owner, string storeName, string subdomainLabel, int planId)
        {
            ArgumentNullException.ThrowIfNull(owner);

            if (!_settings.AllowMultipleStoresPerCustomer)
            {
                var alreadyOwned = await GetOwnedStoreIdAsync(owner);
                if (alreadyOwned.HasValue)
                    throw new InvalidOperationException("This account already owns a store");
            }

            var validationError = await ValidateRequestedSubdomainAsync(subdomainLabel);
            if (!string.IsNullOrEmpty(validationError))
                throw new InvalidOperationException(validationError);

            var plan = await _tenantPlanService.GetByIdAsync(planId)
                ?? throw new InvalidOperationException("The selected plan does not exist");

            var subscription = new TenantStoreSubscription
            {
                OwnerCustomerId = owner.Id,
                PlanId = plan.Id,
                StoreId = 0,
                RequestedStoreName = string.IsNullOrWhiteSpace(storeName) ? subdomainLabel : storeName.Trim(),
                RequestedSubdomain = subdomainLabel.Trim().ToLowerInvariant(),
                ProvisioningToken = Guid.NewGuid().ToString("N"),
                Status = TenantSubscriptionStatus.PendingPayment,
                CreatedOnUtc = DateTime.UtcNow
            };

            await _subscriptionRepository.InsertAsync(subscription);

            return subscription;
        }

        public virtual async Task<TenantStoreSubscription> ActivateAfterPaymentAsync(string provisioningToken)
        {
            var subscription = await GetByProvisioningTokenAsync(provisioningToken);
            if (subscription == null)
                return null;

            // idempotent: if this has already been provisioned (e.g. the OrderPaid event fired
            // twice), just return the existing, already-activated subscription
            if (subscription.Status != TenantSubscriptionStatus.PendingPayment)
                return subscription;

            var plan = await _tenantPlanService.GetByIdAsync(subscription.PlanId);
            var baseDomain = _settings.BaseDomain;
            var fullHost = $"{subscription.RequestedSubdomain}.{baseDomain}".ToLowerInvariant();

            // 1) create the actual nopCommerce store
            var allStores = await _storeService.GetAllStoresAsync();
            var store = new Store
            {
                Name = subscription.RequestedStoreName,
                Url = $"https://{fullHost}/",
                Hosts = fullHost, // native nopCommerce field: also matched by the default store resolver
                SslEnabled = true,
                DisplayOrder = (allStores.Count > 0 ? allStores.Max(s => s.DisplayOrder) : 0) + 1,
                CompanyName = subscription.RequestedStoreName
            };
            await _storeService.InsertStoreAsync(store);

            // 2) bind the sub-domain through this plugin's own mapping table too (adds wildcard
            //    support, validation and the admin grid; harmless duplication with Store.Hosts)
            await _storeDomainMappingService.InsertAsync(new Domain.StoreDomainMapping
            {
                StoreId = store.Id,
                Domain = fullHost,
                Enabled = true,
                IsPrimary = true,
                RequireSsl = true,
                Note = "Auto-created by the self-service store wizard"
            });

            // 3) restrict the owner to their own store from now on
            await EnsureTenantOwnerRoleAssignedAsync(subscription.OwnerCustomerId);
            var ownerCustomer = await _customerService.GetCustomerByIdAsync(subscription.OwnerCustomerId);
            if (ownerCustomer != null)
                await _genericAttributeService.SaveAttributeAsync(ownerCustomer, MultiTenantStoresDefaults.OwnerStoreIdAttributeKey, store.Id);

            // 4) activate the subscription
            subscription.StoreId = store.Id;
            subscription.ActivatedOnUtc = DateTime.UtcNow;
            subscription.Status = plan?.TrialDays > 0 ? TenantSubscriptionStatus.Trial : TenantSubscriptionStatus.Active;
            subscription.TrialEndsOnUtc = plan?.TrialDays > 0 ? DateTime.UtcNow.AddDays(plan.TrialDays) : null;
            subscription.CurrentPeriodEndUtc = DateTime.UtcNow.AddDays(plan?.BillingCycleDays > 0 ? plan.BillingCycleDays : 30);

            if (!_settings.AutoActivateAfterPayment)
            {
                // platform owner wants to manually review new stores before they go live:
                // keep the domain mapping disabled until reviewed
                var mapping = await _storeDomainMappingService.FindByHostAsync(fullHost);
                if (mapping != null)
                {
                    mapping.Enabled = false;
                    await _storeDomainMappingService.UpdateAsync(mapping);
                }
            }

            await _subscriptionRepository.UpdateAsync(subscription);

            return subscription;
        }

        public virtual async Task<TenantStoreSubscription> GetByProvisioningTokenAsync(string provisioningToken)
        {
            if (string.IsNullOrEmpty(provisioningToken))
                return null;

            return await Task.FromResult(_subscriptionRepository.Table
                .FirstOrDefault(s => s.ProvisioningToken == provisioningToken));
        }

        public virtual async Task<TenantStoreSubscription> GetByStoreIdAsync(int storeId)
        {
            return await Task.FromResult(_subscriptionRepository.Table.FirstOrDefault(s => s.StoreId == storeId));
        }

        public virtual async Task<IList<TenantStoreSubscription>> GetByOwnerCustomerIdAsync(int customerId)
        {
            return await Task.FromResult(_subscriptionRepository.Table
                .Where(s => s.OwnerCustomerId == customerId)
                .OrderByDescending(s => s.CreatedOnUtc)
                .ToList());
        }

        public virtual async Task<IList<TenantStoreSubscription>> GetAllAsync()
        {
            return await Task.FromResult(_subscriptionRepository.Table
                .OrderByDescending(s => s.CreatedOnUtc)
                .ToList());
        }

        public virtual async Task UpdateAsync(TenantStoreSubscription subscription)
        {
            await _subscriptionRepository.UpdateAsync(subscription);
        }

        public virtual async Task<int?> GetOwnedStoreIdAsync(Customer customer)
        {
            if (customer == null)
                return null;

            var storeId = await _genericAttributeService.GetAttributeAsync<int?>(customer, MultiTenantStoresDefaults.OwnerStoreIdAttributeKey);
            return storeId is > 0 ? storeId : null;
        }

        public virtual async Task SuspendAsync(TenantStoreSubscription subscription)
        {
            ArgumentNullException.ThrowIfNull(subscription);

            subscription.Status = TenantSubscriptionStatus.Suspended;
            await _subscriptionRepository.UpdateAsync(subscription);

            var mappings = await _storeDomainMappingService.GetByStoreIdAsync(subscription.StoreId);
            foreach (var mapping in mappings)
            {
                mapping.Enabled = false;
                await _storeDomainMappingService.UpdateAsync(mapping);
            }
        }

        public virtual async Task ReactivateAsync(TenantStoreSubscription subscription)
        {
            ArgumentNullException.ThrowIfNull(subscription);

            subscription.Status = TenantSubscriptionStatus.Active;
            await _subscriptionRepository.UpdateAsync(subscription);

            var mappings = await _storeDomainMappingService.GetByStoreIdAsync(subscription.StoreId);
            foreach (var mapping in mappings)
            {
                mapping.Enabled = true;
                await _storeDomainMappingService.UpdateAsync(mapping);
            }
        }

        /// <summary>
        /// Creates the restricted "Tenant Store Owners" role on first use and adds the
        /// given customer to it. NOTE: the exact method names on ICustomerService for
        /// role <-> customer mapping have shifted slightly across nopCommerce releases
        /// (CustomerCustomerRoleMapping vs. Customer.CustomerRoles). Verify this block
        /// compiles against the exact nopCommerce version you are targeting.
        /// </summary>
        protected virtual async Task EnsureTenantOwnerRoleAssignedAsync(int customerId)
        {
            var role = await _customerService.GetCustomerRoleBySystemNameAsync(MultiTenantStoresDefaults.TenantStoreOwnerRoleSystemName);

            if (role == null)
            {
                role = new CustomerRole
                {
                    Name = MultiTenantStoresDefaults.TenantStoreOwnerRoleName,
                    SystemName = MultiTenantStoresDefaults.TenantStoreOwnerRoleSystemName,
                    Active = true,
                    IsSystemRole = false
                };
                await _customerService.InsertCustomerRoleAsync(role);
            }

            var customer = await _customerService.GetCustomerByIdAsync(customerId);
            if (customer == null)
                return;

            var existingRoleIds = await _customerService.GetCustomerRoleIdsAsync(customer, showHidden: true);
            if (!existingRoleIds.Contains(role.Id))
            {
                await _customerService.AddCustomerRoleMappingAsync(new CustomerCustomerRoleMapping
                {
                    CustomerId = customer.Id,
                    CustomerRoleId = role.Id
                });
            }
        }
    }
}
