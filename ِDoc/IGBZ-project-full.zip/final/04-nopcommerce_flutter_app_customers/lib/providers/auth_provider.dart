import 'package:flutter/material.dart';
import '../core/network/token_storage.dart';
import '../models/customer/customer.dart';
import '../services/auth_service.dart';
import '../services/customer_service.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

/// وضعیت کلی احراز هویت کاربر؛ در بالای اپ با Provider در دسترس همه صفحات قرار می‌گیرد.
class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  final CustomerService _customerService = CustomerService();

  AuthStatus status = AuthStatus.unknown;
  Customer? currentCustomer;

  bool get isAuthenticated => status == AuthStatus.authenticated;

  Future<void> checkInitialAuthState() async {
    final hasSession = await TokenStorage.instance.hasValidSession();
    if (!hasSession) {
      status = AuthStatus.unauthenticated;
      notifyListeners();
      return;
    }
    try {
      currentCustomer = await _customerService.getProfile();
      status = AuthStatus.authenticated;
    } catch (_) {
      status = AuthStatus.unauthenticated;
    }
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    await _authService.login(email: email, password: password);
    currentCustomer = await _customerService.getProfile();
    status = AuthStatus.authenticated;
    notifyListeners();
  }

  Future<void> register({
    required String firstName,
    required String lastName,
    required String email,
    required String password,
    String? phoneNumber,
  }) async {
    await _authService.register(
      firstName: firstName,
      lastName: lastName,
      email: email,
      password: password,
      phoneNumber: phoneNumber,
    );
    currentCustomer = await _customerService.getProfile();
    status = AuthStatus.authenticated;
    notifyListeners();
  }

  Future<void> logout() async {
    await _authService.logout();
    currentCustomer = null;
    status = AuthStatus.unauthenticated;
    notifyListeners();
  }

  /// وقتی ApiClient تشخیص دهد نشست منقضی شده (حتی بعد از تلاش برای refresh)، این متد فراخوانی می‌شود.
  void handleSessionExpired() {
    currentCustomer = null;
    status = AuthStatus.unauthenticated;
    notifyListeners();
  }

  Future<void> refreshProfile() async {
    if (!isAuthenticated) return;
    currentCustomer = await _customerService.getProfile();
    notifyListeners();
  }
}
