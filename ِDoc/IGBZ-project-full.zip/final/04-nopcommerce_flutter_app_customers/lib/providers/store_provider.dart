import 'package:flutter/material.dart';
import '../core/network/store_storage.dart';
import '../models/store/store_config.dart';
import '../services/store_service.dart';

enum StoreDetectionStatus { unknown, resolved, unresolved }

/// وضعیت «این اپ متعلق به کدام فروشگاه است؟» را در سراسر اپ نگه می‌دارد.
/// این Provider جدا از AuthProvider است چون طول عمرش فرق دارد: تشخیص فروشگاه فقط یک‌بار
/// (در اولین نصب اپ) اتفاق می‌افتد و مستقل از این‌که کاربر لاگین است یا نه باقی می‌ماند.
class StoreProvider extends ChangeNotifier {
  final StoreService _storeService = StoreService();

  StoreDetectionStatus status = StoreDetectionStatus.unknown;
  int? storeId;
  StoreConfig? config;
  bool isResolving = false;
  String? lastError;

  bool get isResolved => status == StoreDetectionStatus.resolved;

  /// در splash صدا زده می‌شود: اگر storeId قبلاً ذخیره شده، سعی می‌کند برندینگ را (تازه یا از
  /// آخرین مقدار شناخته‌شده) بارگذاری کند؛ در غیر این صورت کاربر باید شمارهٔ موبایلش را
  /// در StoreDetectionScreen وارد کند.
  Future<void> bootstrap() async {
    final savedStoreId = await StoreStorage.instance.getStoreId();

    if (savedStoreId == null) {
      status = StoreDetectionStatus.unresolved;
      notifyListeners();
      return;
    }

    storeId = savedStoreId;
    status = StoreDetectionStatus.resolved;
    notifyListeners();

    // برندینگ را در پس‌زمینه تازه می‌کنیم؛ اگر آفلاین بود یا خطا داد، مشکلی نیست - اپ با
    // تم پیش‌فرض خودش کار می‌کند و همین که storeId شناخته‌شده کافی است تا از صفحهٔ تشخیص رد شود.
    try {
      config = await _storeService.getConfig(savedStoreId);
      notifyListeners();
    } catch (_) {
      // silent - non-critical
    }
  }

  /// از StoreDetectionScreen صدا زده می‌شود. در صورت موفقیت، storeId را برای همیشه ذخیره
  /// می‌کند و true برمی‌گرداند تا صفحه به ادامهٔ اپ برود.
  Future<bool> resolveByPhone(String phoneNumber) async {
    isResolving = true;
    lastError = null;
    notifyListeners();

    try {
      final result = await _storeService.resolveByPhone(phoneNumber);
      if (!result.found || result.storeId == null) {
        lastError = 'این شماره با هیچ فروشگاهی مرتبط نیست. لطفاً همان شماره‌ای که در صفحهٔ دانلود اپ وارد کرده‌اید را امتحان کنید.';
        isResolving = false;
        notifyListeners();
        return false;
      }

      await StoreStorage.instance.saveStoreId(result.storeId!);
      storeId = result.storeId;
      status = StoreDetectionStatus.resolved;

      try {
        config = await _storeService.getConfig(result.storeId!);
      } catch (_) {
        // برندینگ اختیاری است؛ نبودش نباید جلوی ورود کاربر به اپ را بگیرد
      }

      isResolving = false;
      notifyListeners();
      return true;
    } catch (_) {
      lastError = 'اتصال به سرور برقرار نشد. اینترنت خود را بررسی کنید و دوباره تلاش کنید.';
      isResolving = false;
      notifyListeners();
      return false;
    }
  }
}
