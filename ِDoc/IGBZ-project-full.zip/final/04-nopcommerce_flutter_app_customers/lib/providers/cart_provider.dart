import 'package:flutter/material.dart';
import '../models/cart/shopping_cart.dart';
import '../services/cart_service.dart';

class CartProvider extends ChangeNotifier {
  final CartService _cartService = CartService();

  ShoppingCart cart = ShoppingCart.empty();
  bool isLoading = false;

  int get itemCount => cart.totalItemsCount;

  Future<void> loadCart() async {
    isLoading = true;
    notifyListeners();
    try {
      cart = await _cartService.getCart();
    } catch (_) {
      // اگر کاربر لاگین نیست یا خطای شبکه رخ داد، سبد خالی نمایش داده می‌شود
      cart = ShoppingCart.empty();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addItem(int productId, {int quantity = 1, Map<int, String>? attributeValues}) async {
    cart = await _cartService.addItem(productId: productId, quantity: quantity, attributeValues: attributeValues);
    notifyListeners();
  }

  Future<void> updateItem(int itemId, int quantity) async {
    cart = await _cartService.updateItem(itemId, quantity);
    notifyListeners();
  }

  Future<void> removeItem(int itemId) async {
    cart = await _cartService.removeItem(itemId);
    notifyListeners();
  }

  Future<void> clear() async {
    await _cartService.clearCart();
    cart = ShoppingCart.empty();
    notifyListeners();
  }

  void reset() {
    cart = ShoppingCart.empty();
    notifyListeners();
  }
}
