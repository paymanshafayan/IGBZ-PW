import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme_provider.dart';
import 'providers/store_provider.dart';
import 'screens/splash/splash_screen.dart';

class NopCommerceApp extends StatelessWidget {
  const NopCommerceApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<AppThemeProvider>();
    final storeName = context.watch<StoreProvider>().config?.name;

    return MaterialApp(
      title: storeName ?? 'فروشگاه من',
      debugShowCheckedModeBanner: false,
      theme: themeProvider.lightTheme,
      darkTheme: themeProvider.darkTheme,
      themeMode: themeProvider.themeMode,
      // نکته: برای پشتیبانی کامل از تقویم/انتخابگر تاریخ فارسی، پکیج flutter_localizations
      // و تنظیم localizationsDelegates/supportedLocales را اضافه کنید. متن‌های اپ همگی فارسی هستند
      // و Directionality زیر جهت راست‌به‌چپ را برای کل اپ تضمین می‌کند.
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const SplashScreen(),
    );
  }
}
