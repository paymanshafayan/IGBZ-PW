import 'package:email_validator/email_validator.dart';

class Validators {
  Validators._();

  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) return 'ایمیل الزامی است.';
    if (!EmailValidator.validate(value.trim())) return 'فرمت ایمیل صحیح نیست.';
    return null;
  }

  static String? password(String? value, {int minLength = 6}) {
    if (value == null || value.isEmpty) return 'رمز عبور الزامی است.';
    if (value.length < minLength) return 'رمز عبور باید حداقل $minLength کاراکتر باشد.';
    return null;
  }

  static String? required(String? value, {String fieldName = 'این فیلد'}) {
    if (value == null || value.trim().isEmpty) return '$fieldName الزامی است.';
    return null;
  }

  static String? confirmPassword(String? value, String original) {
    if (value != original) return 'رمزهای عبور یکسان نیستند.';
    return null;
  }

  static final _phoneRegex = RegExp(r'^(\+98|0098|0|98)?\s?9\d{2}[\s-]?\d{3}[\s-]?\d{4}$');

  static String? phone(String? value) {
    if (value == null || value.trim().isEmpty) return 'شماره موبایل الزامی است.';
    if (!_phoneRegex.hasMatch(value.trim())) return 'شماره موبایل را به‌صورت صحیح وارد کنید (مثال: 0912xxxxxxx).';
    return null;
  }
}
