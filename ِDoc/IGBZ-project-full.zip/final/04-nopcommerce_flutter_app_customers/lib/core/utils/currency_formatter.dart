import 'package:intl/intl.dart';

class CurrencyFormatter {
  static String format(num amount, {String symbol = '\$'}) {
    final formatter = NumberFormat.currency(symbol: symbol, decimalDigits: 2);
    return formatter.format(amount);
  }
}
