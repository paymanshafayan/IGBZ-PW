import 'package:dio/dio.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import '../constants/api_endpoints.dart';
import 'api_exception.dart';
import 'store_storage.dart';
import 'token_storage.dart';

/// Callback که وقتی نشست کاربر (حتی بعد از تلاش برای refresh) منقضی می‌شود فراخوانی می‌شود
/// تا لایه UI بتواند کاربر را به صفحه ورود هدایت کند.
typedef OnSessionExpired = void Function();

/// کلاینت مرکزی HTTP اپلیکیشن. تمام سرویس‌ها (Auth/Catalog/Cart/...) از این کلاس استفاده می‌کنند.
class ApiClient {
  ApiClient._internal() {
    _dio = Dio(BaseOptions(
      baseUrl: ApiConfig.apiBase,
      connectTimeout: Duration(seconds: ApiConfig.connectTimeoutSeconds),
      receiveTimeout: Duration(seconds: ApiConfig.receiveTimeoutSeconds),
      headers: {'Content-Type': 'application/json'},
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await TokenStorage.instance.getAccessToken();
        if (token != null && token.isNotEmpty) {
          options.headers['Authorization'] = 'Bearer $token';
        }

        // هدر X-Store-Id روی همهٔ درخواست‌ها به‌جز مسیر خودِ تشخیص فروشگاه لازم است؛ قبل از
        // این‌که storeId شناسایی/ذخیره شود (splash/StoreDetectionScreen)، این مقدار null است
        // و به‌سادگی اضافه نمی‌شود - سرور هم دقیقاً همین دو مسیر (/store/resolve و
        // /store/{id}/config) را از الزام این هدر معاف کرده (ApiStoreGateFilter.ExemptPaths).
        final storeId = await StoreStorage.instance.getStoreId();
        if (storeId != null) {
          options.headers['X-Store-Id'] = storeId.toString();
        }

        handler.next(options);
      },
      onError: (DioException error, handler) async {
        // اگر توکن منقضی شده (401) و درخواست هنوز retry نشده، یک‌بار refresh token را امتحان کن
        if (error.response?.statusCode == 401 &&
            error.requestOptions.extra['retried'] != true) {
          final refreshed = await _tryRefreshToken();
          if (refreshed) {
            final newToken = await TokenStorage.instance.getAccessToken();
            final requestOptions = error.requestOptions;
            requestOptions.headers['Authorization'] = 'Bearer $newToken';
            requestOptions.extra['retried'] = true;
            try {
              final response = await _dio.fetch(requestOptions);
              return handler.resolve(response);
            } catch (_) {
              // اگر retry هم شکست خورد، ادامه بده تا خطای اصلی برگردد
            }
          } else {
            await TokenStorage.instance.clear();
            onSessionExpired?.call();
          }
        }
        handler.next(error);
      },
    ));

    _dio.interceptors.add(PrettyDioLogger(
      requestHeader: false,
      requestBody: true,
      responseBody: true,
      compact: true,
    ));
  }

  static final ApiClient instance = ApiClient._internal();
  late final Dio _dio;

  /// این callback را از لایه بالای اپ (مثلاً main.dart) ست کنید تا با انقضای نشست، کاربر Logout شود.
  OnSessionExpired? onSessionExpired;

  Future<bool> _tryRefreshToken() async {
    try {
      final accessToken = await TokenStorage.instance.getAccessToken();
      final refreshToken = await TokenStorage.instance.getRefreshToken();
      if (refreshToken == null) return false;

      final storeId = await StoreStorage.instance.getStoreId();
      final refreshDio = Dio(BaseOptions(
        baseUrl: ApiConfig.apiBase,
        headers: storeId != null ? {'X-Store-Id': storeId.toString()} : null,
      ));

      final response = await refreshDio.post(
        ApiEndpoints.refreshToken,
        data: {'accessToken': accessToken, 'refreshToken': refreshToken},
      );

      final data = response.data['data'];
      if (response.data['success'] == true && data != null) {
        await TokenStorage.instance.saveTokens(
          accessToken: data['accessToken'],
          refreshToken: data['refreshToken'],
          customerId: data['customerId'],
        );
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  /// درخواست GET با پارس خودکار پاسخ استاندارد { success, message, data, errors }
  Future<T> get<T>(String path,
      {Map<String, dynamic>? query, required T Function(dynamic json) parser}) async {
    try {
      final response = await _dio.get(path, queryParameters: query);
      return _parse(response, parser);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<T> post<T>(String path,
      {dynamic data, required T Function(dynamic json) parser}) async {
    try {
      final response = await _dio.post(path, data: data);
      return _parse(response, parser);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<T> put<T>(String path,
      {dynamic data, required T Function(dynamic json) parser}) async {
    try {
      final response = await _dio.put(path, data: data);
      return _parse(response, parser);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<T> delete<T>(String path,
      {dynamic data, required T Function(dynamic json) parser}) async {
    try {
      final response = await _dio.delete(path, data: data);
      return _parse(response, parser);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  T _parse<T>(Response response, T Function(dynamic json) parser) {
    final body = response.data;
    if (body is Map<String, dynamic> && body.containsKey('success')) {
      if (body['success'] == true) {
        return parser(body['data']);
      }
      throw ApiException(
        body['message']?.toString() ?? 'خطایی رخ داد.',
        statusCode: response.statusCode,
        errors: (body['errors'] as List?)?.map((e) => e.toString()).toList() ?? [],
      );
    }
    // در صورتی که پاسخ فرمت استاندارد نداشت (نادر)
    return parser(body);
  }

  ApiException _mapError(DioException e) {
    if (e.response?.data is Map<String, dynamic>) {
      final body = e.response!.data as Map<String, dynamic>;
      return ApiException(
        body['message']?.toString() ?? 'خطای ارتباط با سرور.',
        statusCode: e.response?.statusCode,
        errors: (body['errors'] as List?)?.map((x) => x.toString()).toList() ?? [],
      );
    }
    if (e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.connectionError) {
      return ApiException('اتصال به سرور برقرار نشد. اینترنت خود را بررسی کنید.');
    }
    return ApiException(e.message ?? 'خطای ناشناخته‌ای رخ داد.', statusCode: e.response?.statusCode);
  }
}
