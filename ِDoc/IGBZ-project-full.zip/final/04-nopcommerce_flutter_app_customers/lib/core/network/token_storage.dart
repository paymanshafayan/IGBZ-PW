import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// نگهداری امن Access Token و Refresh Token روی دستگاه (Keychain در iOS، Keystore در Android)
class TokenStorage {
  TokenStorage._internal();
  static final TokenStorage instance = TokenStorage._internal();

  final _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _accessTokenKey = 'nop_access_token';
  static const _refreshTokenKey = 'nop_refresh_token';
  static const _customerIdKey = 'nop_customer_id';

  Future<void> saveTokens({
    required String accessToken,
    required String refreshToken,
    required int customerId,
  }) async {
    await Future.wait([
      _storage.write(key: _accessTokenKey, value: accessToken),
      _storage.write(key: _refreshTokenKey, value: refreshToken),
      _storage.write(key: _customerIdKey, value: customerId.toString()),
    ]);
  }

  Future<String?> getAccessToken() => _storage.read(key: _accessTokenKey);
  Future<String?> getRefreshToken() => _storage.read(key: _refreshTokenKey);

  Future<int?> getCustomerId() async {
    final value = await _storage.read(key: _customerIdKey);
    return value != null ? int.tryParse(value) : null;
  }

  Future<bool> hasValidSession() async {
    final token = await getAccessToken();
    return token != null && token.isNotEmpty;
  }

  Future<void> clear() async {
    await Future.wait([
      _storage.delete(key: _accessTokenKey),
      _storage.delete(key: _refreshTokenKey),
      _storage.delete(key: _customerIdKey),
    ]);
  }
}
