import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// نگهداری محلی شناسهٔ فروشگاهی که اپ در اولین اجرا تشخیص داده (بخش ۵ سند معماری).
/// این ذخیره‌سازی جدا از TokenStorage است چون طول عمرش فرق دارد: توکن‌ها با logout پاک
/// می‌شوند، اما storeId باید حتی بعد از خروج کاربر از حساب کاربری‌اش باقی بماند - اپ همیشه
/// متعلق به همان فروشگاه است، فارغ از این‌که چه کسی درونش لاگین کرده.
class StoreStorage {
  StoreStorage._internal();
  static final StoreStorage instance = StoreStorage._internal();

  final _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _storeIdKey = 'nop_store_id';

  Future<void> saveStoreId(int storeId) => _storage.write(key: _storeIdKey, value: storeId.toString());

  Future<int?> getStoreId() async {
    final value = await _storage.read(key: _storeIdKey);
    return value != null ? int.tryParse(value) : null;
  }

  Future<bool> hasResolvedStore() async => (await getStoreId()) != null;

  /// فقط برای سناریوهای توسعه/تست (مثلاً دکمهٔ "تغییر فروشگاه" در تنظیمات دیباگ)؛
  /// در اپ منتشرشده معمولاً هرگز صدا زده نمی‌شود.
  Future<void> clear() => _storage.delete(key: _storeIdKey);
}
