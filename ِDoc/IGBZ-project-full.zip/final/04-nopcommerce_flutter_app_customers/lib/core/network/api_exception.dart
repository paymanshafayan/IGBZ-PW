class ApiException implements Exception {
  final String message;
  final int? statusCode;
  final List<String> errors;

  ApiException(this.message, {this.statusCode, this.errors = const []});

  @override
  String toString() => message;
}
