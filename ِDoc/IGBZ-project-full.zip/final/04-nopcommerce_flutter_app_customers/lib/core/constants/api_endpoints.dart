/// تنظیمات اتصال به فروشگاه nopCommerce.
/// ⚠️ حتماً قبل از build گرفتن، baseUrl را به آدرس واقعی فروشگاه خودتان تغییر دهید.
class ApiConfig {
  ApiConfig._();

  /// آدرس پایه فروشگاه (بدون اسلش انتهایی)
  static const String baseUrl = 'https://your-store-domain.com';

  /// مسیر پایه API (مطابق BaseNopApiController در پلاگین)
  static const String apiBase = '$baseUrl/api/v1';

  static const int connectTimeoutSeconds = 20;
  static const int receiveTimeoutSeconds = 20;
}

/// مسیرهای دقیق اندپوینت‌ها، هماهنگ با کنترلرهای Nop.Plugin.Api
class ApiEndpoints {
  ApiEndpoints._();

  // ---------------- Auth ----------------
  static const String register = '/auth/register';
  static const String login = '/auth/login';
  static const String refreshToken = '/auth/refresh-token';
  static const String logout = '/auth/logout';
  static const String changePassword = '/auth/change-password';
  static const String forgotPassword = '/auth/forgot-password';
  static const String resetPassword = '/auth/reset-password';

  // ---------------- Customer ----------------
  static const String profile = '/customer/profile';
  static const String addresses = '/customer/addresses';
  static String addressById(int id) => '/customer/addresses/$id';

  // ---------------- Catalog ----------------
  static const String categories = '/catalog/categories';
  static String categoryById(int id) => '/catalog/categories/$id';
  static const String manufacturers = '/catalog/manufacturers';
  static String manufacturerById(int id) => '/catalog/manufacturers/$id';
  static const String products = '/catalog/products';
  static String productById(int id) => '/catalog/products/$id';
  static String productReviews(int id) => '/catalog/products/$id/reviews';

  // ---------------- Cart ----------------
  static const String cart = '/shoppingcart';
  static const String cartItems = '/shoppingcart/items';
  static String cartItemById(int id) => '/shoppingcart/items/$id';
  static const String wishlist = '/wishlist';
  static const String wishlistItems = '/wishlist/items';

  // ---------------- Checkout ----------------
  static const String checkoutSummary = '/checkout/summary';
  static const String shippingMethods = '/checkout/shipping-methods';
  static const String selectShippingMethod = '/checkout/shipping-methods/select';
  static const String paymentMethods = '/checkout/payment-methods';
  static const String selectPaymentMethod = '/checkout/payment-methods/select';
  static const String placeOrder = '/checkout/place-order';

  // ---------------- Orders ----------------
  static const String orders = '/order';
  static String orderById(int id) => '/order/$id';
  static String cancelOrder(int id) => '/order/$id/cancel';
  static String returnRequest(int id) => '/order/$id/return-request';

  // ---------------- Payment ----------------
  static String paymentStatus(int orderId) => '/payment/order/$orderId/status';
  static String confirmClientPayment(int orderId) => '/payment/order/$orderId/confirm-client';

  // ---------------- Shipping ----------------
  static const String countries = '/shipping/countries';
  static String statesByCountry(int countryId) => '/shipping/countries/$countryId/states';
  static String orderTracking(int orderId) => '/shipping/order/$orderId/tracking';

  // ---------------- CMS / Blog / News / Forum / Vendor ----------------
  static const String topics = '/cms/topics';
  static String topicBySystemName(String systemName) => '/cms/topics/$systemName';
  static const String blogPosts = '/blog';
  static String blogPostById(int id) => '/blog/$id';
  static const String news = '/news';
  static String newsById(int id) => '/news/$id';
  static const String vendors = '/vendor';
  static String vendorById(int id) => '/vendor/$id';
  static String vendorProducts(int id) => '/vendor/$id/products';

  // ---------------- Download (محصولات دیجیتال: ویدئو/صدا/کتاب الکترونیک) ----------------
  static const String myDownloadableProducts = '/download/my-products';
  static String licenseAgreement(int orderItemId) => '/download/license/$orderItemId';
  static String acceptLicenseAgreement(int orderItemId) => '/download/license/$orderItemId/accept';
  static String downloadFile(int orderItemId) => '/download/file/$orderItemId';
  static String downloadSample(int productId) => '/download/sample/$productId';

  // ---------------- Store detection (تشخیص خودکار فروشگاه در اولین اجرای اپ) ----------------
  static const String storeResolve = '/store/resolve';
  static String storeConfig(int storeId) => '/store/$storeId/config';
}
