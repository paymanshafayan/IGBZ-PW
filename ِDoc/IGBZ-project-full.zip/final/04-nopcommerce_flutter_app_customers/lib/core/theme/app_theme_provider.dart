import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// یک گزینه رنگی از پیش تعریف‌شده برای تم اپلیکیشن
class AppThemeOption {
  final String name;
  final String nameFa;
  final Color color;
  const AppThemeOption(this.name, this.nameFa, this.color);
}

/// لیست رنگ‌های قابل انتخاب برای تم اپلیکیشن. اولین مورد (آبی) دقیقاً هم‌رنگ
/// تم نمونه‌ی nopCommerce در تصاویر مرجع است و به‌عنوان پیش‌فرض استفاده می‌شود.
const List<AppThemeOption> kAppThemeOptions = [
  AppThemeOption('blue', 'آبی (پیش‌فرض)', Color(0xFF2F80ED)),
  AppThemeOption('indigo', 'نیلی', Color(0xFF3F51B5)),
  AppThemeOption('purple', 'بنفش', Color(0xFF8E44AD)),
  AppThemeOption('teal', 'فیروزه‌ای', Color(0xFF009688)),
  AppThemeOption('green', 'سبز', Color(0xFF27AE60)),
  AppThemeOption('orange', 'نارنجی', Color(0xFFF2994A)),
  AppThemeOption('red', 'قرمز', Color(0xFFEB5757)),
  AppThemeOption('pink', 'صورتی', Color(0xFFE91E63)),
];

/// مدیریت تم اپلیکیشن. تمام صفحات به‌جای رنگ‌های hard-coded، از Theme.of(context).colorScheme
/// استفاده می‌کنند تا با تغییر رنگ در این پرووایدر، کل ظاهر اپ (بدون نیاز به تغییر کد صفحات) عوض شود.
class AppThemeProvider extends ChangeNotifier {
  static const _prefsKey = 'app_theme_seed_color';

  Color _seedColor = kAppThemeOptions.first.color;
  ThemeMode _themeMode = ThemeMode.light;
  bool _hasUserPreference = false;

  Color get seedColor => _seedColor;
  ThemeMode get themeMode => _themeMode;

  AppThemeProvider() {
    _loadSavedTheme();
  }

  Future<void> _loadSavedTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final savedValue = prefs.getInt(_prefsKey);
    if (savedValue != null) {
      _seedColor = Color(savedValue);
      _hasUserPreference = true;
      notifyListeners();
    }
  }

  /// از StoreProvider صدا زده می‌شود وقتی برندینگ فروشگاه بارگذاری می‌شود. فقط در صورتی رنگ
  /// پیش‌فرض اپ را عوض می‌کند که کاربر خودش قبلاً از تنظیمات، رنگی را دستی انتخاب نکرده باشد -
  /// انتخاب کاربر همیشه اولویت دارد.
  void applyStoreBrandColor(Color? color) {
    if (color == null || _hasUserPreference) return;
    _seedColor = color;
    notifyListeners();
  }

  Future<void> changeSeedColor(Color color) async {
    _seedColor = color;
    _hasUserPreference = true;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_prefsKey, color.toARGB32());
  }

  void toggleDarkMode(bool isDark) {
    _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
  }

  ThemeData get lightTheme => _buildTheme(Brightness.light);
  ThemeData get darkTheme => _buildTheme(Brightness.dark);

  ThemeData _buildTheme(Brightness brightness) {
    final colorScheme = ColorScheme.fromSeed(seedColor: _seedColor, brightness: brightness);
    final baseTextTheme = brightness == Brightness.light
        ? Typography.material2021().black
        : Typography.material2021().white;

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: brightness == Brightness.light ? const Color(0xFFF7F8FA) : const Color(0xFF121212),
      textTheme: GoogleFonts.vazirmatnTextTheme(baseTextTheme),
      appBarTheme: AppBarTheme(
        backgroundColor: colorScheme.surface,
        foregroundColor: colorScheme.onSurface,
        elevation: 0,
        centerTitle: false,
        surfaceTintColor: Colors.transparent,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: colorScheme.primary,
          foregroundColor: colorScheme.onPrimary,
          minimumSize: const Size(double.infinity, 50),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(double.infinity, 50),
          side: BorderSide(color: colorScheme.primary),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: brightness == Brightness.light ? Colors.white : const Color(0xFF1E1E1E),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colorScheme.outlineVariant),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colorScheme.outlineVariant),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colorScheme.primary, width: 1.6),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colorScheme.error),
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: brightness == Brightness.light ? Colors.white : const Color(0xFF1E1E1E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        margin: EdgeInsets.zero,
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: brightness == Brightness.light ? Colors.white : const Color(0xFF1E1E1E),
        selectedItemColor: colorScheme.primary,
        unselectedItemColor: brightness == Brightness.light ? Colors.grey[500] : Colors.grey[400],
        type: BottomNavigationBarType.fixed,
        elevation: 8,
      ),
      chipTheme: ChipThemeData(
        backgroundColor: colorScheme.primaryContainer.withValues(alpha: 0.4),
        labelStyle: TextStyle(color: colorScheme.primary, fontWeight: FontWeight.w600),
        side: BorderSide.none,
      ),
      dividerTheme: DividerThemeData(color: colorScheme.outlineVariant.withValues(alpha: 0.6)),
    );
  }
}
