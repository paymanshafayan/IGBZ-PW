import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme_provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/cart_provider.dart';
import '../../providers/store_provider.dart';
import '../home/main_shell.dart';
import '../store/store_detection_screen.dart';

/// نکته طراحی: مرور اپ (Home/Search/Product) بدون ورود مجاز است (Guest Browsing)؛
/// ورود فقط هنگام نیاز واقعی (Checkout، Account، Wishlist) درخواست می‌شود.
///
/// نکتهٔ دیگر: تشخیص فروشگاه (StoreProvider) همیشه *قبل* از هر چیز دیگری اجرا می‌شود، چون
/// X-Store-Id لازمهٔ تقریباً همهٔ درخواست‌های دیگر (شامل بررسی نشست کاربر) است.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  Future<void> _bootstrap() async {
    final storeProvider = context.read<StoreProvider>();
    await storeProvider.bootstrap();

    if (!mounted) return;

    if (!storeProvider.isResolved) {
      // اولین اجرای اپ روی این دستگاه: هنوز نمی‌دانیم متعلق به کدام فروشگاه است
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const StoreDetectionScreen()),
      );
      return;
    }

    // برندینگ فروشگاه (در صورت تنظیم‌شدن) را به‌عنوان رنگ پیش‌فرض اپ اعمال کن
    final brandColor = storeProvider.config?.brandColor;
    if (brandColor != null && mounted) {
      context.read<AppThemeProvider>().applyStoreBrandColor(brandColor);
    }

    final authProvider = context.read<AuthProvider>();
    await authProvider.checkInitialAuthState();

    if (authProvider.isAuthenticated) {
      await context.read<CartProvider>().loadCart();
    }

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const MainShell()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: colorScheme.primary,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Icon(Icons.storefront_rounded, size: 52, color: colorScheme.primary),
            ),
            const SizedBox(height: 20),
            const Text(
              'فروشگاه من',
              style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 28),
            const CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}
