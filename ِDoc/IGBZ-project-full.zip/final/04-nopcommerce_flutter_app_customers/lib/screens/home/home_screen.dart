import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../core/network/api_exception.dart';
import '../../models/catalog/category.dart';
import '../../models/catalog/product.dart';
import '../../services/catalog_service.dart';
import '../../widgets/product_card.dart';
import '../../widgets/section_header.dart';
import '../../widgets/common_states.dart';
import '../catalog/product_list_screen.dart';
import '../catalog/product_detail_screen.dart';
import '../settings/theme_settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _catalogService = CatalogService();

  late Future<_HomeData> _future;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<_HomeData> _loadData() async {
    final categories = await _catalogService.getCategories();
    final newArrivals = await _catalogService.searchProducts(
      ProductSearchParams(orderBy: 'CreatedOnDesc', pageSize: 10),
    );
    return _HomeData(categories: categories, newArrivals: newArrivals.items);
  }

  Future<void> _refresh() async {
    setState(() => _future = _loadData());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.storefront_rounded, color: colorScheme.primary),
            const SizedBox(width: 8),
            const Text('فروشگاه من', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.palette_outlined),
            tooltip: 'تغییر تم رنگی',
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ThemeSettingsScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProductListScreen())),
          ),
        ],
      ),
      body: FutureBuilder<_HomeData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingIndicator();
          }
          if (snapshot.hasError) {
            return ErrorStateView(
              message: snapshot.error is ApiException ? (snapshot.error as ApiException).message : 'خطا در بارگذاری اطلاعات',
              onRetry: _refresh,
            );
          }

          final data = snapshot.data!;
          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(
              padding: const EdgeInsets.only(bottom: 24),
              children: [
                _PromoBanner(colorScheme: colorScheme),
                SectionHeader(title: 'دسته‌بندی‌ها'),
                _CategoryGrid(categories: data.categories),
                SectionHeader(
                  title: 'محصولات جدید',
                  onViewAll: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const ProductListScreen(initialSort: 'CreatedOnDesc')),
                  ),
                ),
                _NewArrivalsList(products: data.newArrivals),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _HomeData {
  final List<Category> categories;
  final List<ProductListItem> newArrivals;
  _HomeData({required this.categories, required this.newArrivals});
}

class _PromoBanner extends StatelessWidget {
  final ColorScheme colorScheme;
  const _PromoBanner({required this.colorScheme});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      height: 170,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          colors: [colorScheme.primary, colorScheme.primary.withValues(alpha: 0.75)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -20,
            bottom: -20,
            child: Icon(Icons.shopping_bag_rounded, size: 160, color: Colors.white.withValues(alpha: 0.12)),
          ),
          Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'تخفیف ویژه فصل',
                  style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  'تا ۳۰٪ تخفیف روی محصولات منتخب',
                  style: TextStyle(color: Colors.white.withValues(alpha: 0.9), fontSize: 13.5),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: colorScheme.primary,
                    minimumSize: const Size(120, 38),
                  ),
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProductListScreen())),
                  child: const Text('مشاهده محصولات'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CategoryGrid extends StatelessWidget {
  final List<Category> categories;
  const _CategoryGrid({required this.categories});

  @override
  Widget build(BuildContext context) {
    if (categories.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: categories.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          mainAxisSpacing: 12,
          crossAxisSpacing: 8,
          childAspectRatio: 0.8,
        ),
        itemBuilder: (context, index) {
          final category = categories[index];
          return InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => ProductListScreen(categoryId: category.id, categoryName: category.name)),
            ),
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: SizedBox(
                    width: 56,
                    height: 56,
                    child: category.pictureUrl != null && category.pictureUrl!.isNotEmpty
                        ? CachedNetworkImage(imageUrl: category.pictureUrl!, fit: BoxFit.cover)
                        : Container(
                            color: Theme.of(context).colorScheme.primaryContainer,
                            child: Icon(Icons.category_outlined, color: Theme.of(context).colorScheme.primary),
                          ),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  category.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 11.5),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _NewArrivalsList extends StatelessWidget {
  final List<ProductListItem> products;
  const _NewArrivalsList({required this.products});

  @override
  Widget build(BuildContext context) {
    if (products.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: Text('محصولی برای نمایش وجود ندارد.'),
      );
    }

    return SizedBox(
      height: 240,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: products.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final product = products[index];
          return SizedBox(
            width: 160,
            child: ProductCard(
              product: product,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => ProductDetailScreen(productId: product.id)),
              ),
            ),
          );
        },
      ),
    );
  }
}
