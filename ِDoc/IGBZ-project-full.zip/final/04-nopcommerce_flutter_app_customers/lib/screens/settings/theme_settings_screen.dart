import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme_provider.dart';

class ThemeSettingsScreen extends StatelessWidget {
  const ThemeSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<AppThemeProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات ظاهری')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('رنگ اصلی اپلیکیشن', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 6),
            Text(
              'با انتخاب هر رنگ، تمام اجزای اپ (دکمه‌ها، آیکون‌ها، نوار پایین و...) به‌صورت خودکار هماهنگ می‌شوند.',
              style: TextStyle(color: Theme.of(context).colorScheme.outline, fontSize: 12.5),
            ),
            const SizedBox(height: 20),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: kAppThemeOptions.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 16,
                crossAxisSpacing: 12,
                childAspectRatio: 0.85,
              ),
              itemBuilder: (context, index) {
                final option = kAppThemeOptions[index];
                final isSelected = themeProvider.seedColor.toARGB32() == option.color.toARGB32();
                return InkWell(
                  onTap: () => themeProvider.changeSeedColor(option.color),
                  borderRadius: BorderRadius.circular(40),
                  child: Column(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: option.color,
                          shape: BoxShape.circle,
                          border: isSelected ? Border.all(color: Colors.black87, width: 2.5) : null,
                        ),
                        child: isSelected ? const Icon(Icons.check, color: Colors.white) : null,
                      ),
                      const SizedBox(height: 6),
                      Text(option.nameFa, style: const TextStyle(fontSize: 10.5), textAlign: TextAlign.center),
                    ],
                  ),
                );
              },
            ),
            const Divider(height: 40),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('حالت تیره'),
              value: themeProvider.themeMode == ThemeMode.dark,
              onChanged: themeProvider.toggleDarkMode,
            ),
          ],
        ),
      ),
    );
  }
}
