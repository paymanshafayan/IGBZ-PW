import 'package:flutter/material.dart';
import '../../core/network/api_exception.dart';
import '../../models/order/order.dart';
import '../../services/order_service.dart';
import '../../widgets/common_states.dart';
import '../home/main_shell.dart';

class OrderDetailScreen extends StatefulWidget {
  final int orderId;
  final bool justPlaced;
  const OrderDetailScreen({super.key, required this.orderId, this.justPlaced = false});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final _orderService = OrderService();
  late Future<OrderDetail> _future;
  bool _isCancelling = false;

  @override
  void initState() {
    super.initState();
    _future = _orderService.getOrder(widget.orderId);
  }

  Future<void> _cancelOrder() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('لغو سفارش'),
        content: const Text('آیا از لغو این سفارش مطمئن هستید؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('بله، لغو شود')),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _isCancelling = true);
    try {
      await _orderService.cancelOrder(widget.orderId);
      setState(() => _future = _orderService.getOrder(widget.orderId));
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _isCancelling = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('جزئیات سفارش'),
        automaticallyImplyLeading: !widget.justPlaced,
      ),
      body: FutureBuilder<OrderDetail>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const LoadingIndicator();
          if (snapshot.hasError) {
            return ErrorStateView(message: 'خطا در بارگذاری سفارش', onRetry: () => setState(() => _future = _orderService.getOrder(widget.orderId)));
          }
          final order = snapshot.data!;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (widget.justPlaced)
                Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.green[50], borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    children: [
                      const Icon(Icons.check_circle, color: Colors.green, size: 32),
                      const SizedBox(width: 12),
                      const Expanded(child: Text('سفارش شما با موفقیت ثبت شد!', style: TextStyle(fontWeight: FontWeight.bold))),
                    ],
                  ),
                ),
              Text('سفارش #${order.customOrderNumber ?? order.id}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(_formatDate(order.createdOnUtc), style: TextStyle(color: Theme.of(context).colorScheme.outline, fontSize: 12.5)),
              const SizedBox(height: 16),
              Wrap(spacing: 8, runSpacing: 8, children: [
                _statusChip('وضعیت سفارش', order.orderStatus),
                _statusChip('پرداخت', order.paymentStatus),
                _statusChip('ارسال', order.shippingStatus),
              ]),
              const SizedBox(height: 20),
              const Text('اقلام سفارش', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 8),
              ...order.items.map((item) => Card(
                    child: ListTile(
                      leading: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: SizedBox(
                          width: 48,
                          height: 48,
                          child: item.pictureUrl != null
                              ? Image.network(item.pictureUrl!, fit: BoxFit.cover)
                              : Container(color: Theme.of(context).colorScheme.surfaceContainerHighest),
                        ),
                      ),
                      title: Text(item.productName ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
                      subtitle: Text('تعداد: ${item.quantity}'),
                      trailing: Text(item.subTotalFormatted ?? '\$${item.subTotal.toStringAsFixed(2)}'),
                    ),
                  )),
              const SizedBox(height: 12),
              if (order.shippingAddress != null) _infoTile('آدرس ارسال', order.shippingAddress!),
              if (order.billingAddress != null) _infoTile('آدرس صورتحساب', order.billingAddress!),
              if (order.shippingMethod != null) _infoTile('روش ارسال', order.shippingMethod!),
              if (order.paymentMethod != null) _infoTile('روش پرداخت', order.paymentMethod!),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(children: [
                    _priceRow('جمع جزء', order.subTotal),
                    _priceRow('هزینه ارسال', order.shippingTotal),
                    _priceRow('مالیات', order.taxTotal),
                    if (order.discountAmount > 0) _priceRow('تخفیف', -order.discountAmount),
                    const Divider(),
                    _priceRow('مجموع', order.orderTotal, isBold: true),
                  ]),
                ),
              ),
              const SizedBox(height: 20),
              if (order.canCancel)
                OutlinedButton.icon(
                  onPressed: _isCancelling ? null : _cancelOrder,
                  icon: const Icon(Icons.cancel_outlined, color: Colors.red),
                  label: Text(_isCancelling ? 'در حال لغو...' : 'لغو سفارش', style: const TextStyle(color: Colors.red)),
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.red)),
                ),
              if (widget.justPlaced) ...[
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const MainShell()),
                    (route) => false,
                  ),
                  child: const Text('بازگشت به صفحه اصلی'),
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  Widget _statusChip(String label, String value) {
    return Chip(label: Text('$label: $value', style: const TextStyle(fontSize: 11.5)));
  }

  Widget _infoTile(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5)),
          Text(value, style: const TextStyle(fontSize: 13)),
        ],
      ),
    );
  }

  Widget _priceRow(String label, double value, {bool isBold = false}) {
    final style = TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal, fontSize: isBold ? 15.5 : 13.5);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label, style: style), Text('\$${value.toStringAsFixed(2)}', style: style)],
      ),
    );
  }

  String _formatDate(DateTime date) => '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}';
}
