import 'package:flutter/material.dart';
import '../../models/order/order.dart';
import '../../services/order_service.dart';
import '../../widgets/common_states.dart';
import 'order_detail_screen.dart';

class OrderListScreen extends StatefulWidget {
  const OrderListScreen({super.key});

  @override
  State<OrderListScreen> createState() => _OrderListScreenState();
}

class _OrderListScreenState extends State<OrderListScreen> {
  final _orderService = OrderService();
  final List<OrderListItem> _orders = [];
  bool _isLoading = true;
  bool _hasError = false;
  int _pageIndex = 0;
  bool _hasNextPage = true;

  @override
  void initState() {
    super.initState();
    _load(reset: true);
  }

  Future<void> _load({bool reset = false}) async {
    setState(() {
      _isLoading = true;
      _hasError = false;
      if (reset) {
        _pageIndex = 0;
        _orders.clear();
      }
    });
    try {
      final result = await _orderService.getOrders(pageIndex: _pageIndex);
      setState(() {
        _orders.addAll(result.items);
        _hasNextPage = result.hasNextPage;
        _pageIndex++;
      });
    } catch (_) {
      setState(() => _hasError = true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Complete':
      case 'Processing':
        return Colors.green;
      case 'Cancelled':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('سفارش‌های من')),
      body: _isLoading && _orders.isEmpty
          ? const LoadingIndicator()
          : _hasError && _orders.isEmpty
              ? ErrorStateView(message: 'خطا در بارگذاری سفارش‌ها', onRetry: () => _load(reset: true))
              : _orders.isEmpty
                  ? const EmptyState(icon: Icons.receipt_long_outlined, title: 'هنوز سفارشی ثبت نکرده‌اید.')
                  : RefreshIndicator(
                      onRefresh: () => _load(reset: true),
                      child: ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: _orders.length + (_hasNextPage ? 1 : 0),
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, index) {
                          if (index >= _orders.length) {
                            _load();
                            return const Padding(padding: EdgeInsets.all(16), child: LoadingIndicator());
                          }
                          final order = _orders[index];
                          return Card(
                            child: ListTile(
                              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: order.id))),
                              title: Text('سفارش #${order.customOrderNumber ?? order.id}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              subtitle: Padding(
                                padding: const EdgeInsets.only(top: 6),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                      decoration: BoxDecoration(
                                        color: _statusColor(order.orderStatus).withValues(alpha: 0.12),
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      child: Text(order.orderStatus, style: TextStyle(color: _statusColor(order.orderStatus), fontSize: 11)),
                                    ),
                                    const SizedBox(width: 8),
                                    Text('${order.totalItems} کالا', style: const TextStyle(fontSize: 11)),
                                  ],
                                ),
                              ),
                              trailing: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(order.orderTotalFormatted ?? '\$${order.orderTotal.toStringAsFixed(2)}',
                                      style: const TextStyle(fontWeight: FontWeight.bold)),
                                  const Icon(Icons.chevron_left, size: 18),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}
