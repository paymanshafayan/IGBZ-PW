import 'dart:io';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

/// پخش‌کننده فایل صوتی محلی (پادکست، کتاب صوتی، موسیقی و ...).
class AudioPlayerScreen extends StatefulWidget {
  final File file;
  final String title;
  const AudioPlayerScreen({super.key, required this.file, required this.title});

  @override
  State<AudioPlayerScreen> createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<AudioPlayerScreen> {
  final _player = AudioPlayer();
  String? _error;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await _player.setFilePath(widget.file.path);
      await _player.play();
    } catch (_) {
      setState(() => _error = 'پخش این فایل صوتی ممکن نیست. فرمت فایل ممکن است پشتیبانی نشود.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(d.inMinutes.remainder(60));
    final seconds = twoDigits(d.inSeconds.remainder(60));
    return d.inHours > 0 ? '${twoDigits(d.inHours)}:$minutes:$seconds' : '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: SafeArea(
        child: _error != null
            ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center)))
            : _isLoading
                ? const Center(child: CircularProgressIndicator())
                : Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 180,
                          height: 180,
                          decoration: BoxDecoration(color: colorScheme.primaryContainer, shape: BoxShape.circle),
                          child: Icon(Icons.music_note_rounded, size: 84, color: colorScheme.primary),
                        ),
                        const SizedBox(height: 32),
                        Text(widget.title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 24),
                        StreamBuilder<Duration?>(
                          stream: _player.durationStream,
                          builder: (context, durationSnapshot) {
                            final duration = durationSnapshot.data ?? Duration.zero;
                            return StreamBuilder<Duration>(
                              stream: _player.positionStream,
                              builder: (context, positionSnapshot) {
                                var position = positionSnapshot.data ?? Duration.zero;
                                if (position > duration) position = duration;
                                return Column(
                                  children: [
                                    Slider(
                                      value: position.inMilliseconds.toDouble().clamp(0, duration.inMilliseconds.toDouble() + 1),
                                      max: duration.inMilliseconds.toDouble() + 1,
                                      onChanged: (value) => _player.seek(Duration(milliseconds: value.toInt())),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 8),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(_formatDuration(position), style: const TextStyle(fontSize: 12)),
                                          Text(_formatDuration(duration), style: const TextStyle(fontSize: 12)),
                                        ],
                                      ),
                                    ),
                                  ],
                                );
                              },
                            );
                          },
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            IconButton(
                              iconSize: 36,
                              icon: const Icon(Icons.replay_10_rounded),
                              onPressed: () => _player.seek(_player.position - const Duration(seconds: 10)),
                            ),
                            const SizedBox(width: 12),
                            StreamBuilder<PlayerState>(
                              stream: _player.playerStateStream,
                              builder: (context, snapshot) {
                                final playing = snapshot.data?.playing ?? false;
                                return Container(
                                  decoration: BoxDecoration(color: colorScheme.primary, shape: BoxShape.circle),
                                  child: IconButton(
                                    iconSize: 44,
                                    color: Colors.white,
                                    icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                                    onPressed: () => playing ? _player.pause() : _player.play(),
                                  ),
                                );
                              },
                            ),
                            const SizedBox(width: 12),
                            IconButton(
                              iconSize: 36,
                              icon: const Icon(Icons.forward_10_rounded),
                              onPressed: () => _player.seek(_player.position + const Duration(seconds: 10)),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }
}
