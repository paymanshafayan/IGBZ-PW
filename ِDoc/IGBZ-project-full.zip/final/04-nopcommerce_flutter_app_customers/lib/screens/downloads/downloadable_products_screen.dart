import 'package:flutter/material.dart';
import '../../core/network/api_exception.dart';
import '../../models/download/downloadable_product.dart';
import '../../services/download_service.dart';
import '../../widgets/common_states.dart';
import 'digital_product_detail_screen.dart';

class DownloadableProductsScreen extends StatefulWidget {
  const DownloadableProductsScreen({super.key});

  @override
  State<DownloadableProductsScreen> createState() => _DownloadableProductsScreenState();
}

class _DownloadableProductsScreenState extends State<DownloadableProductsScreen> {
  final _downloadService = DownloadService();
  late Future<List<DownloadableProduct>> _future;

  @override
  void initState() {
    super.initState();
    _future = _downloadService.getMyDownloadableProducts();
  }

  void _reload() => setState(() => _future = _downloadService.getMyDownloadableProducts());

  IconData _iconFor(DigitalMediaKind kind) {
    switch (kind) {
      case DigitalMediaKind.video:
        return Icons.play_circle_outline_rounded;
      case DigitalMediaKind.audio:
        return Icons.headphones_outlined;
      case DigitalMediaKind.ebook:
        return Icons.menu_book_outlined;
      case DigitalMediaKind.archive:
        return Icons.folder_zip_outlined;
      case DigitalMediaKind.other:
        return Icons.insert_drive_file_outlined;
    }
  }

  String _labelFor(DigitalMediaKind kind) {
    switch (kind) {
      case DigitalMediaKind.video:
        return 'ویدئو';
      case DigitalMediaKind.audio:
        return 'فایل صوتی';
      case DigitalMediaKind.ebook:
        return 'کتاب الکترونیک';
      case DigitalMediaKind.archive:
        return 'فایل فشرده';
      case DigitalMediaKind.other:
        return 'فایل دیجیتال';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('محصولات دیجیتال من')),
      body: FutureBuilder<List<DownloadableProduct>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const LoadingIndicator();
          if (snapshot.hasError) {
            final message = snapshot.error is ApiException ? (snapshot.error as ApiException).message : 'خطا در بارگذاری محصولات دیجیتال';
            return ErrorStateView(message: message, onRetry: _reload);
          }
          final items = snapshot.data ?? [];
          if (items.isEmpty) {
            return const EmptyState(
              icon: Icons.cloud_download_outlined,
              title: 'محصول دیجیتالی ندارید.',
              subtitle: 'ویدئو، فایل صوتی یا کتاب الکترونیکی که خریداری کنید اینجا نمایش داده می‌شود.',
            );
          }
          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final item = items[index];
                final colorScheme = Theme.of(context).colorScheme;
                return Card(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => DigitalProductDetailScreen(product: item)))
                        .then((_) => _reload()),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(color: colorScheme.primaryContainer, borderRadius: BorderRadius.circular(12)),
                            child: Icon(_iconFor(item.mediaKind), color: colorScheme.primary, size: 26),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.productName, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                                const SizedBox(height: 4),
                                Row(children: [
                                  Chip(
                                    label: Text(_labelFor(item.mediaKind), style: const TextStyle(fontSize: 10.5)),
                                    visualDensity: VisualDensity.compact,
                                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                  ),
                                  const SizedBox(width: 6),
                                  if (item.fileSizeFormatted.isNotEmpty)
                                    Text(item.fileSizeFormatted, style: TextStyle(fontSize: 11, color: colorScheme.outline)),
                                ]),
                                const SizedBox(height: 4),
                                Text(
                                  item.isDownloadAllowed
                                      ? (item.hasUnlimitedDownloads ? 'دانلود نامحدود' : 'باقی‌مانده: ${item.remainingDownloads} دانلود')
                                      : 'در انتظار تأیید پرداخت سفارش',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: item.isDownloadAllowed ? Colors.green[700] : Colors.orange[800],
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_left),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
