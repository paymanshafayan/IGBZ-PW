import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:open_filex/open_filex.dart';

/// نمایش‌گر کتاب الکترونیک (PDF) محلی. برای فرمت‌های غیر PDF (مثل epub)
/// که پکیج flutter_pdfview پشتیبانی نمی‌کند، فایل با اپ پیش‌فرض سیستم باز می‌شود.
class EbookViewerScreen extends StatefulWidget {
  final File file;
  final String title;
  const EbookViewerScreen({super.key, required this.file, required this.title});

  @override
  State<EbookViewerScreen> createState() => _EbookViewerScreenState();
}

class _EbookViewerScreenState extends State<EbookViewerScreen> {
  int? _totalPages;
  int _currentPage = 0;
  bool _isPdf = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _isPdf = widget.file.path.toLowerCase().endsWith('.pdf');
    if (!_isPdf) {
      // فرمت‌های غیر PDF (epub/mobi) را با اپ پیش‌فرض دستگاه باز می‌کنیم
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        final result = await OpenFilex.open(widget.file.path);
        if (result.type != ResultType.done && mounted) {
          setState(() => _error = 'برای مشاهده این فایل، یک اپ کتاب‌خوان مناسب (مثلاً برای EPUB) روی دستگاه خود نصب کنید.');
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        bottom: _isPdf && _totalPages != null
            ? PreferredSize(
                preferredSize: const Size.fromHeight(28),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text('صفحه ${_currentPage + 1} از $_totalPages', style: const TextStyle(fontSize: 12)),
                ),
              )
            : null,
      ),
      body: !_isPdf
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  _error ?? 'در حال باز کردن فایل با اپ مناسب دستگاه...',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : PDFView(
              filePath: widget.file.path,
              enableSwipe: true,
              swipeHorizontal: false,
              autoSpacing: true,
              pageFling: true,
              onRender: (pages) => setState(() => _totalPages = pages),
              onPageChanged: (page, total) => setState(() => _currentPage = page ?? 0),
              onError: (error) => setState(() => _error = 'خطا در نمایش فایل PDF: $error'),
            ),
    );
  }
}
