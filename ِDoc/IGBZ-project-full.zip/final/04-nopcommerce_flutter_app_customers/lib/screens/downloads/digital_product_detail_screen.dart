import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/network/api_exception.dart';
import '../../models/download/downloadable_product.dart';
import '../../services/download_service.dart';
import 'video_player_screen.dart';
import 'audio_player_screen.dart';
import 'ebook_viewer_screen.dart';

class DigitalProductDetailScreen extends StatefulWidget {
  final DownloadableProduct product;
  const DigitalProductDetailScreen({super.key, required this.product});

  @override
  State<DigitalProductDetailScreen> createState() => _DigitalProductDetailScreenState();
}

class _DigitalProductDetailScreenState extends State<DigitalProductDetailScreen> {
  final _downloadService = DownloadService();

  bool _licenseAccepted = false;
  bool _isAcceptingLicense = false;
  bool _isDownloading = false;
  double _progress = 0;
  File? _localFile;
  String? _error;

  @override
  void initState() {
    super.initState();
    _licenseAccepted = widget.product.licenseAccepted;
  }

  String get _suggestedFileName {
    final name = widget.product.fileName;
    if (name != null && name.isNotEmpty) return name;
    final ext = switch (widget.product.mediaKind) {
      DigitalMediaKind.video => '.mp4',
      DigitalMediaKind.audio => '.mp3',
      DigitalMediaKind.ebook => '.pdf',
      _ => '',
    };
    return 'product_${widget.product.orderItemId}$ext';
  }

  Future<void> _showLicenseDialogAndAccept() async {
    setState(() => _isAcceptingLicense = true);
    try {
      final agreement = await _downloadService.getLicenseAgreement(widget.product.orderItemId);
      if (!mounted) return;

      final accepted = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('قرارداد استفاده'),
          content: SingleChildScrollView(child: Text(_stripHtml(agreement.agreementText))),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('می‌پذیرم')),
          ],
        ),
      );

      if (accepted == true) {
        await _downloadService.acceptLicenseAgreement(widget.product.orderItemId);
        setState(() => _licenseAccepted = true);
      }
    } on ApiException catch (e) {
      _showError(e.message);
    } finally {
      if (mounted) setState(() => _isAcceptingLicense = false);
    }
  }

  String _stripHtml(String html) => html.replaceAll(RegExp(r'<[^>]*>'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();

  Future<void> _downloadAndOpen() async {
    setState(() {
      _isDownloading = true;
      _progress = 0;
      _error = null;
    });

    try {
      final file = await _downloadService.downloadFile(
        widget.product.orderItemId,
        _suggestedFileName,
        onProgress: (p) => setState(() => _progress = p),
      );
      setState(() => _localFile = file);
      if (mounted) _openFile(file);
    } on ExternalDownloadUrlException catch (e) {
      final uri = Uri.tryParse(e.url);
      if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error = 'دانلود فایل با خطا مواجه شد.');
    } finally {
      if (mounted) setState(() => _isDownloading = false);
    }
  }

  void _openFile(File file) {
    switch (widget.product.mediaKind) {
      case DigitalMediaKind.video:
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => VideoPlayerScreen(file: file, title: widget.product.productName)));
        break;
      case DigitalMediaKind.audio:
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => AudioPlayerScreen(file: file, title: widget.product.productName)));
        break;
      case DigitalMediaKind.ebook:
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => EbookViewerScreen(file: file, title: widget.product.productName)));
        break;
      case DigitalMediaKind.archive:
      case DigitalMediaKind.other:
        OpenFilex.open(file.path);
        break;
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), backgroundColor: Colors.red));
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    final colorScheme = Theme.of(context).colorScheme;
    final needsLicense = product.requiresLicenseAgreement && !_licenseAccepted;

    return Scaffold(
      appBar: AppBar(title: Text(product.productName, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(color: colorScheme.primaryContainer, borderRadius: BorderRadius.circular(24)),
                  child: Icon(_iconFor(product.mediaKind), size: 48, color: colorScheme.primary),
                ),
              ),
              const SizedBox(height: 16),
              Text(product.productName, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              if (product.fileSizeFormatted.isNotEmpty)
                Text('حجم فایل: ${product.fileSizeFormatted}', textAlign: TextAlign.center, style: TextStyle(color: colorScheme.outline, fontSize: 12.5)),
              const SizedBox(height: 4),
              Text(
                product.hasUnlimitedDownloads ? 'دانلود نامحدود' : 'باقی‌مانده: ${product.remainingDownloads} از ${product.maxNumberOfDownloads} دانلود',
                textAlign: TextAlign.center,
                style: TextStyle(color: colorScheme.outline, fontSize: 12.5),
              ),
              const SizedBox(height: 28),
              if (!product.isDownloadAllowed)
                _infoBanner(
                  icon: Icons.hourglass_empty_rounded,
                  color: Colors.orange,
                  text: 'این فایل هنوز قابل دانلود نیست. لطفاً منتظر تأیید پرداخت سفارش بمانید یا با پشتیبانی تماس بگیرید.',
                )
              else if (needsLicense)
                Column(
                  children: [
                    _infoBanner(
                      icon: Icons.gavel_outlined,
                      color: colorScheme.primary,
                      text: 'برای دانلود این محصول ابتدا باید قرارداد استفاده را بپذیرید.',
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      onPressed: _isAcceptingLicense ? null : _showLicenseDialogAndAccept,
                      child: _isAcceptingLicense
                          ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Text('مشاهده و پذیرش قرارداد استفاده'),
                    ),
                  ],
                )
              else ...[
                if (_error != null) ...[
                  _infoBanner(icon: Icons.error_outline, color: Colors.red, text: _error!),
                  const SizedBox(height: 12),
                ],
                if (_isDownloading) ...[
                  LinearProgressIndicator(value: _progress > 0 ? _progress : null),
                  const SizedBox(height: 8),
                  Text('${(_progress * 100).toStringAsFixed(0)}٪ دانلود شد', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                  const SizedBox(height: 12),
                ],
                ElevatedButton.icon(
                  onPressed: _isDownloading ? null : _downloadAndOpen,
                  icon: Icon(_localFile != null ? Icons.play_arrow_rounded : Icons.download_rounded),
                  label: Text(_localFile != null ? 'باز کردن مجدد' : 'دانلود و باز کردن'),
                ),
              ],
              if (product.hasSampleDownload) ...[
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () async {
                    try {
                      final file = await _downloadService.downloadSample(product.productId, 'sample_${product.productId}');
                      _openFile(file);
                    } on ApiException catch (e) {
                      _showError(e.message);
                    }
                  },
                  icon: const Icon(Icons.visibility_outlined),
                  label: const Text('مشاهده نمونه رایگان'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoBanner({required IconData icon, required Color color, required String text}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: TextStyle(color: color, fontSize: 12.5))),
        ],
      ),
    );
  }

  IconData _iconFor(DigitalMediaKind kind) {
    switch (kind) {
      case DigitalMediaKind.video:
        return Icons.play_circle_outline_rounded;
      case DigitalMediaKind.audio:
        return Icons.headphones_outlined;
      case DigitalMediaKind.ebook:
        return Icons.menu_book_outlined;
      case DigitalMediaKind.archive:
        return Icons.folder_zip_outlined;
      case DigitalMediaKind.other:
        return Icons.insert_drive_file_outlined;
    }
  }
}
