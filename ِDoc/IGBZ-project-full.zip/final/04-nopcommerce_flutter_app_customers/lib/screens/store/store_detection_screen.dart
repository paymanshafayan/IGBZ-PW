import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/utils/validators.dart';
import '../../providers/store_provider.dart';
import '../home/main_shell.dart';

/// نمایش‌داده‌شده فقط یک‌بار، در اولین اجرای اپ روی هر دستگاه (تا وقتی storeId محلی ذخیره
/// نشده). کاربر همان شماره‌ای را وارد می‌کند که قبلاً در صفحهٔ «دریافت اپ» روی سایت فروشگاه
/// وارد کرده بود؛ از همان‌جا اپ می‌فهمد متعلق به کدام فروشگاه است - بدون این‌که کاربر اصلاً
/// متوجه شود در حال «انتخاب فروشگاه» است (طبق تصمیم بخش ۵ سند معماری).
class StoreDetectionScreen extends StatefulWidget {
  const StoreDetectionScreen({super.key});

  @override
  State<StoreDetectionScreen> createState() => _StoreDetectionScreenState();
}

class _StoreDetectionScreenState extends State<StoreDetectionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final storeProvider = context.read<StoreProvider>();
    final success = await storeProvider.resolveByPhone(_phoneController.text.trim());

    if (!mounted) return;

    if (success) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const MainShell()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(storeProvider.lastError ?? 'مشکلی پیش آمد.'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final storeProvider = context.watch<StoreProvider>();

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 40),
                Center(
                  child: Container(
                    width: 84,
                    height: 84,
                    decoration: BoxDecoration(color: colorScheme.primaryContainer, borderRadius: BorderRadius.circular(20)),
                    child: Icon(Icons.storefront_rounded, size: 44, color: colorScheme.primary),
                  ),
                ),
                const SizedBox(height: 24),
                const Text('خوش آمدید', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                const SizedBox(height: 8),
                Text(
                  'برای شروع، همان شماره موبایلی را وارد کنید که قبلاً در سایت فروشگاه، در صفحهٔ '
                  'دریافت اپ، وارد کرده‌اید.',
                  style: TextStyle(color: colorScheme.outline),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),
                TextFormField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(labelText: 'شماره موبایل', hintText: '0912xxxxxxx', prefixIcon: Icon(Icons.phone_iphone_outlined)),
                  validator: Validators.phone,
                  enabled: !storeProvider.isResolving,
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: storeProvider.isResolving ? null : _submit,
                  child: storeProvider.isResolving
                      ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
                      : const Text('ادامه'),
                ),
                const SizedBox(height: 16),
                Text(
                  'اگر هنوز شماره‌ای وارد نکرده‌اید، ابتدا از سایت فروشگاه موردنظرتان وارد صفحهٔ '
                  '«دریافت اپ» شوید.',
                  style: TextStyle(color: colorScheme.outline, fontSize: 12),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
