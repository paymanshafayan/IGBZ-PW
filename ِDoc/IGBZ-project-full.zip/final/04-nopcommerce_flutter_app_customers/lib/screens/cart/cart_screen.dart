import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_exception.dart';
import '../../providers/auth_provider.dart';
import '../../providers/cart_provider.dart';
import '../../widgets/common_states.dart';
import '../../widgets/quantity_selector.dart';
import '../auth/login_screen.dart';
import '../checkout/address_list_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.read<AuthProvider>().isAuthenticated) {
        context.read<CartProvider>().loadCart();
      }
    });
  }

  Future<void> _goToCheckout() async {
    if (!context.read<AuthProvider>().isAuthenticated) {
      final loggedIn = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const LoginScreen()));
      if (loggedIn != true) return;
      if (!mounted) return;
      await context.read<CartProvider>().loadCart();
    }
    if (!mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AddressListScreen(isCheckoutFlow: true)));
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final cartProvider = context.watch<CartProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('سبد خرید')),
      body: !authProvider.isAuthenticated
          ? EmptyState(
              icon: Icons.shopping_cart_outlined,
              title: 'برای مشاهده سبد خرید وارد شوید',
              action: ElevatedButton(
                onPressed: () async {
                  final loggedIn = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const LoginScreen()));
                  if (loggedIn == true) context.read<CartProvider>().loadCart();
                },
                child: const Text('ورود به حساب کاربری'),
              ),
            )
          : cartProvider.isLoading
              ? const LoadingIndicator()
              : cartProvider.cart.isEmpty
                  ? const EmptyState(icon: Icons.remove_shopping_cart_outlined, title: 'سبد خرید شما خالی است.')
                  : _buildCartContent(context, cartProvider),
    );
  }

  Widget _buildCartContent(BuildContext context, CartProvider cartProvider) {
    final cart = cartProvider.cart;
    return Column(
      children: [
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: cart.items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final item = cart.items[index];
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: SizedBox(
                          width: 80,
                          height: 80,
                          child: item.pictureUrl != null && item.pictureUrl!.isNotEmpty
                              ? Image.network(item.pictureUrl!, fit: BoxFit.cover)
                              : Container(color: Theme.of(context).colorScheme.surfaceContainerHighest),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item.productName, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                            if (item.attributeDescriptions.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 2),
                                child: Text(item.attributeDescriptions.join('، '), style: TextStyle(fontSize: 11.5, color: Theme.of(context).colorScheme.outline)),
                              ),
                            const SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                QuantitySelector(
                                  quantity: item.quantity,
                                  onChanged: (q) => context.read<CartProvider>().updateItem(item.id, q),
                                ),
                                Text(
                                  item.subTotalFormatted ?? '\$${item.subTotal.toStringAsFixed(2)}',
                                  style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, size: 18),
                        onPressed: () async {
                          try {
                            await context.read<CartProvider>().removeItem(item.id);
                          } on ApiException catch (e) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
                            }
                          }
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        _buildSummaryBar(context, cart),
      ],
    );
  }

  Widget _buildSummaryBar(BuildContext context, cart) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 10, offset: const Offset(0, -3))],
      ),
      child: SafeArea(
        top: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('جمع جزء', style: TextStyle(fontSize: 13)),
                Text(cart.subTotalFormatted ?? '\$${cart.subTotal.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 4),
            Text('مالیات و هزینه ارسال هنگام تسویه‌حساب محاسبه می‌شود.',
                style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.outline)),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: _goToCheckout, child: const Text('ادامه فرآیند خرید')),
          ],
        ),
      ),
    );
  }
}
