import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/cart_provider.dart';
import '../../services/cart_service.dart';
import '../../widgets/common_states.dart';
import '../catalog/product_detail_screen.dart';

class WishlistScreen extends StatefulWidget {
  const WishlistScreen({super.key});

  @override
  State<WishlistScreen> createState() => _WishlistScreenState();
}

class _WishlistScreenState extends State<WishlistScreen> {
  final _cartService = CartService();
  late Future<List<WishlistItem>> _future;

  @override
  void initState() {
    super.initState();
    _future = _cartService.getWishlist();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لیست علاقه‌مندی‌ها')),
      body: FutureBuilder<List<WishlistItem>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const LoadingIndicator();
          if (snapshot.hasError) {
            return ErrorStateView(message: 'خطا در بارگذاری لیست علاقه‌مندی‌ها', onRetry: () => setState(() => _future = _cartService.getWishlist()));
          }
          final items = snapshot.data ?? [];
          if (items.isEmpty) {
            return const EmptyState(icon: Icons.favorite_border, title: 'لیست علاقه‌مندی‌های شما خالی است.');
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final item = items[index];
              return Card(
                child: ListTile(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProductDetailScreen(productId: item.productId))),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: SizedBox(
                      width: 52,
                      height: 52,
                      child: item.pictureUrl != null
                          ? Image.network(item.pictureUrl!, fit: BoxFit.cover)
                          : Container(color: Theme.of(context).colorScheme.surfaceContainerHighest),
                    ),
                  ),
                  title: Text(item.productName, maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text(item.isInStock ? 'موجود در انبار' : 'ناموجود'),
                  trailing: IconButton(
                    icon: const Icon(Icons.add_shopping_cart_outlined),
                    onPressed: item.isInStock
                        ? () async {
                            await context.read<CartProvider>().addItem(item.productId);
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('به سبد خرید اضافه شد.')));
                            }
                          }
                        : null,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
