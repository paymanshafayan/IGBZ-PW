import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/cart_provider.dart';
import '../auth/login_screen.dart';
import '../checkout/address_list_screen.dart';
import '../orders/order_list_screen.dart';
import 'edit_profile_screen.dart';
import 'change_password_screen.dart';
import 'wishlist_screen.dart';
import 'cms_topic_screen.dart';
import '../downloads/downloadable_products_screen.dart';
import '../settings/theme_settings_screen.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();

    if (!authProvider.isAuthenticated) {
      return Scaffold(
        appBar: AppBar(title: const Text('حساب کاربری')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.account_circle_outlined, size: 84, color: Theme.of(context).colorScheme.outline),
                const SizedBox(height: 16),
                const Text('برای دسترسی به حساب کاربری وارد شوید', textAlign: TextAlign.center),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    final loggedIn = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const LoginScreen()));
                    if (loggedIn == true && context.mounted) context.read<CartProvider>().loadCart();
                  },
                  child: const Text('ورود / ثبت‌نام'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final customer = authProvider.currentCustomer;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            _buildProfileHeader(context, customer?.fullName ?? '', customer?.email ?? ''),
            const SizedBox(height: 16),
            _menuTile(context, Icons.receipt_long_outlined, 'سفارش‌های من', () => _push(context, const OrderListScreen())),
            _menuTile(context, Icons.cloud_download_outlined, 'محصولات دیجیتال من', () => _push(context, const DownloadableProductsScreen())),
            _menuTile(context, Icons.favorite_border, 'لیست علاقه‌مندی‌ها', () => _push(context, const WishlistScreen())),
            _menuTile(context, Icons.location_on_outlined, 'آدرس‌های من', () => _push(context, const AddressListScreen())),
            _menuTile(context, Icons.lock_outline, 'تغییر رمز عبور', () => _push(context, const ChangePasswordScreen())),
            _menuTile(context, Icons.palette_outlined, 'تغییر تم رنگی', () => _push(context, const ThemeSettingsScreen())),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text('لینک‌های سریع', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            _menuTile(context, Icons.info_outline, 'درباره ما', () => _push(context, const CmsTopicScreen(systemName: 'AboutUs', title: 'درباره ما'))),
            _menuTile(context, Icons.support_agent_outlined, 'تماس با ما', () => _push(context, const CmsTopicScreen(systemName: 'ContactUs', title: 'تماس با ما'))),
            _menuTile(context, Icons.description_outlined, 'قوانین و مقررات', () => _push(context, const CmsTopicScreen(systemName: 'ConditionsOfUse', title: 'قوانین و مقررات'))),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: OutlinedButton.icon(
                onPressed: () async {
                  await context.read<AuthProvider>().logout();
                  context.read<CartProvider>().reset();
                },
                icon: const Icon(Icons.logout, color: Colors.red),
                label: const Text('خروج از حساب کاربری', style: TextStyle(color: Colors.red)),
                style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.red)),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  void _push(BuildContext context, Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  Widget _buildProfileHeader(BuildContext context, String name, String email) {
    final colorScheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 28),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [colorScheme.primary, colorScheme.primary.withValues(alpha: 0.75)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Column(
        children: [
          const CircleAvatar(radius: 40, backgroundColor: Colors.white, child: Icon(Icons.person, size: 44, color: Colors.grey)),
          const SizedBox(height: 12),
          Text(name.isNotEmpty ? name : 'کاربر عزیز', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 2),
          Text(email, style: TextStyle(color: Colors.white.withValues(alpha: 0.85), fontSize: 12.5)),
          const SizedBox(height: 10),
          TextButton(
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EditProfileScreen())),
            style: TextButton.styleFrom(backgroundColor: Colors.white.withValues(alpha: 0.15), foregroundColor: Colors.white),
            child: const Text('ویرایش پروفایل'),
          ),
        ],
      ),
    );
  }

  Widget _menuTile(BuildContext context, IconData icon, String title, VoidCallback onTap) {
    final colorScheme = Theme.of(context).colorScheme;
    return ListTile(
      leading: CircleAvatar(backgroundColor: colorScheme.primaryContainer, foregroundColor: colorScheme.primary, child: Icon(icon, size: 20)),
      title: Text(title),
      trailing: const Icon(Icons.chevron_left),
      onTap: onTap,
    );
  }
}
