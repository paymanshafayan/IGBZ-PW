import 'package:flutter/material.dart';
import '../../core/constants/api_endpoints.dart';
import '../../core/network/api_client.dart';
import '../../widgets/common_states.dart';

class CmsTopicScreen extends StatefulWidget {
  final String systemName;
  final String title;
  const CmsTopicScreen({super.key, required this.systemName, required this.title});

  @override
  State<CmsTopicScreen> createState() => _CmsTopicScreenState();
}

class _CmsTopicScreenState extends State<CmsTopicScreen> {
  late Future<_Topic> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_Topic> _load() {
    return ApiClient.instance.get<_Topic>(
      ApiEndpoints.topicBySystemName(widget.systemName),
      parser: (json) => _Topic(title: json['title'] ?? widget.title, body: json['body'] ?? ''),
    );
  }

  String _stripHtml(String html) => html.replaceAll(RegExp(r'<[^>]*>'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: FutureBuilder<_Topic>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const LoadingIndicator();
          if (snapshot.hasError) {
            return ErrorStateView(message: 'این صفحه در دسترس نیست.', onRetry: () => setState(() => _future = _load()));
          }
          final topic = snapshot.data!;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Text(_stripHtml(topic.body), style: const TextStyle(height: 1.8, fontSize: 14)),
          );
        },
      ),
    );
  }
}

class _Topic {
  final String title;
  final String body;
  _Topic({required this.title, required this.body});
}
