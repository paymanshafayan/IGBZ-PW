import 'package:flutter/material.dart';
import '../../core/network/api_exception.dart';
import '../../models/customer/address.dart';
import '../../services/customer_service.dart';
import '../../widgets/common_states.dart';
import 'address_form_screen.dart';
import 'shipping_payment_screen.dart';

class AddressListScreen extends StatefulWidget {
  /// اگر true باشد، بعد از انتخاب آدرس مستقیماً وارد مرحله بعدی تسویه‌حساب می‌شویم.
  final bool isCheckoutFlow;
  const AddressListScreen({super.key, this.isCheckoutFlow = false});

  @override
  State<AddressListScreen> createState() => _AddressListScreenState();
}

class _AddressListScreenState extends State<AddressListScreen> {
  final _customerService = CustomerService();
  late Future<List<CustomerAddress>> _future;

  @override
  void initState() {
    super.initState();
    _future = _customerService.getAddresses();
  }

  void _reload() => setState(() => _future = _customerService.getAddresses());

  Future<void> _selectAddress(CustomerAddress address) async {
    if (!widget.isCheckoutFlow) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ShippingPaymentScreen(billingAddress: address)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.isCheckoutFlow ? 'انتخاب آدرس' : 'آدرس‌های من')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final added = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const AddressFormScreen()));
          if (added == true) _reload();
        },
        icon: const Icon(Icons.add),
        label: const Text('آدرس جدید'),
      ),
      body: FutureBuilder<List<CustomerAddress>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const LoadingIndicator();
          if (snapshot.hasError) {
            final message = snapshot.error is ApiException ? (snapshot.error as ApiException).message : 'خطا در بارگذاری آدرس‌ها';
            return ErrorStateView(message: message, onRetry: _reload);
          }
          final addresses = snapshot.data ?? [];
          if (addresses.isEmpty) {
            return const EmptyState(icon: Icons.location_off_outlined, title: 'هنوز آدرسی ثبت نکرده‌اید.', subtitle: 'برای ادامه، یک آدرس جدید اضافه کنید.');
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
            itemCount: addresses.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final address = addresses[index];
              return Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => _selectAddress(address),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${address.firstName} ${address.lastName}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              const SizedBox(height: 4),
                              Text(address.oneLine, style: TextStyle(color: Theme.of(context).colorScheme.outline, fontSize: 12.5)),
                              if (address.phoneNumber != null) ...[
                                const SizedBox(height: 4),
                                Text(address.phoneNumber!, style: TextStyle(color: Theme.of(context).colorScheme.outline, fontSize: 12.5)),
                              ],
                              if (address.isDefaultShipping || address.isDefaultBilling) ...[
                                const SizedBox(height: 6),
                                Wrap(spacing: 6, children: [
                                  if (address.isDefaultShipping) _tag(context, 'پیش‌فرض ارسال'),
                                  if (address.isDefaultBilling) _tag(context, 'پیش‌فرض صورتحساب'),
                                ]),
                              ],
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, size: 20),
                          onPressed: () async {
                            final updated = await Navigator.of(context)
                                .push<bool>(MaterialPageRoute(builder: (_) => AddressFormScreen(existingAddress: address)));
                            if (updated == true) _reload();
                          },
                        ),
                        if (widget.isCheckoutFlow) const Icon(Icons.chevron_left),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _tag(BuildContext context, String text) => Chip(
        label: Text(text, style: const TextStyle(fontSize: 10.5)),
        visualDensity: VisualDensity.compact,
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      );
}
