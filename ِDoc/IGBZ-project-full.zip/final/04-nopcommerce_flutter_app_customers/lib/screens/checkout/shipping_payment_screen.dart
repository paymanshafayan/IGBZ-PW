import 'package:flutter/material.dart';
import '../../core/network/api_exception.dart';
import '../../models/checkout/checkout_models.dart';
import '../../models/customer/address.dart';
import '../../services/checkout_service.dart';
import '../../widgets/common_states.dart';
import 'order_summary_screen.dart';

class ShippingPaymentScreen extends StatefulWidget {
  final CustomerAddress billingAddress;
  const ShippingPaymentScreen({super.key, required this.billingAddress});

  @override
  State<ShippingPaymentScreen> createState() => _ShippingPaymentScreenState();
}

class _ShippingPaymentScreenState extends State<ShippingPaymentScreen> {
  final _checkoutService = CheckoutService();

  List<ShippingOption> _shippingOptions = [];
  List<PaymentMethod> _paymentMethods = [];
  ShippingOption? _selectedShipping;
  PaymentMethod? _selectedPayment;
  bool _isLoading = true;
  bool _hasError = false;
  bool _requiresShipping = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });
    try {
      final summary = await _checkoutService.getSummary();
      _requiresShipping = summary.requiresShipping;

      if (_requiresShipping) {
        _shippingOptions = await _checkoutService.getShippingMethods(widget.billingAddress.id);
        if (_shippingOptions.isNotEmpty) _selectedShipping = _shippingOptions.first;
      }

      _paymentMethods = await _checkoutService.getPaymentMethods();
      if (_paymentMethods.isNotEmpty) _selectedPayment = _paymentMethods.first;
    } catch (_) {
      setState(() => _hasError = true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _continue() async {
    if (_requiresShipping && _selectedShipping == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لطفاً یک روش ارسال انتخاب کنید.')));
      return;
    }
    if (_selectedPayment == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لطفاً یک روش پرداخت انتخاب کنید.')));
      return;
    }

    try {
      if (_requiresShipping && _selectedShipping != null) {
        await _checkoutService.selectShippingMethod(
          _selectedShipping!.name,
          _selectedShipping!.shippingRateComputationMethodSystemName,
        );
      }
      await _checkoutService.selectPaymentMethod(_selectedPayment!.systemName);

      if (!mounted) return;
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => OrderSummaryScreen(
          billingAddress: widget.billingAddress,
          shippingAddress: _requiresShipping ? widget.billingAddress : null,
          selectedShipping: _selectedShipping,
          selectedPayment: _selectedPayment!,
        ),
      ));
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message), backgroundColor: Colors.red));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ارسال و پرداخت')),
      body: _isLoading
          ? const LoadingIndicator()
          : _hasError
              ? ErrorStateView(message: 'خطا در بارگذاری اطلاعات تسویه‌حساب', onRetry: _load)
              : SafeArea(
                  child: Column(
                    children: [
                      Expanded(
                        child: ListView(
                          padding: const EdgeInsets.all(16),
                          children: [
                            if (_requiresShipping) ...[
                              const Text('روش ارسال', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                              const SizedBox(height: 8),
                              if (_shippingOptions.isEmpty)
                                const Text('روش ارسالی برای این آدرس یافت نشد.')
                              else
                                ..._shippingOptions.map((option) => Card(
                                      child: RadioListTile<ShippingOption>(
                                        value: option,
                                        groupValue: _selectedShipping,
                                        onChanged: (v) => setState(() => _selectedShipping = v),
                                        title: Text(option.name),
                                        subtitle: option.description != null ? Text(option.description!) : null,
                                        secondary: Text(option.rateFormatted ?? '\$${option.rate.toStringAsFixed(2)}',
                                            style: const TextStyle(fontWeight: FontWeight.bold)),
                                      ),
                                    )),
                              const SizedBox(height: 20),
                            ],
                            const Text('روش پرداخت', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                            const SizedBox(height: 8),
                            if (_paymentMethods.isEmpty)
                              const Text('روش پرداختی در دسترس نیست.')
                            else
                              ..._paymentMethods.map((method) => Card(
                                    child: RadioListTile<PaymentMethod>(
                                      value: method,
                                      groupValue: _selectedPayment,
                                      onChanged: (v) => setState(() => _selectedPayment = v),
                                      title: Text(method.friendlyName),
                                      subtitle: method.description != null ? Text(method.description!) : null,
                                    ),
                                  )),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: ElevatedButton(onPressed: _continue, child: const Text('ادامه')),
                      ),
                    ],
                  ),
                ),
    );
  }
}
