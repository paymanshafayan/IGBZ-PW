import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_exception.dart';
import '../../models/checkout/checkout_models.dart';
import '../../models/customer/address.dart';
import '../../providers/cart_provider.dart';
import '../../services/checkout_service.dart';
import '../../widgets/common_states.dart';
import '../orders/order_detail_screen.dart';

class OrderSummaryScreen extends StatefulWidget {
  final CustomerAddress billingAddress;
  final CustomerAddress? shippingAddress;
  final ShippingOption? selectedShipping;
  final PaymentMethod selectedPayment;

  const OrderSummaryScreen({
    super.key,
    required this.billingAddress,
    this.shippingAddress,
    this.selectedShipping,
    required this.selectedPayment,
  });

  @override
  State<OrderSummaryScreen> createState() => _OrderSummaryScreenState();
}

class _OrderSummaryScreenState extends State<OrderSummaryScreen> {
  final _checkoutService = CheckoutService();
  final _commentController = TextEditingController();

  late Future<CheckoutSummary> _future;
  bool _isPlacingOrder = false;

  @override
  void initState() {
    super.initState();
    _future = _checkoutService.getSummary();
  }

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  Future<void> _placeOrder() async {
    setState(() => _isPlacingOrder = true);
    try {
      final result = await _checkoutService.placeOrder(
        billingAddressId: widget.billingAddress.id,
        shippingAddressId: widget.shippingAddress?.id,
        paymentMethodSystemName: widget.selectedPayment.systemName,
        shippingOptionName: widget.selectedShipping?.name,
        shippingRateComputationMethodSystemName: widget.selectedShipping?.shippingRateComputationMethodSystemName,
        customerComment: _commentController.text.trim().isEmpty ? null : _commentController.text.trim(),
      );

      if (!mounted) return;

      if (!result.success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result.errors.isNotEmpty ? result.errors.join('\n') : 'ثبت سفارش ناموفق بود.'), backgroundColor: Colors.red),
        );
        return;
      }

      await context.read<CartProvider>().loadCart();

      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: result.orderId, justPlaced: true)),
        (route) => route.isFirst,
      );
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _isPlacingOrder = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('بررسی نهایی سفارش')),
      body: FutureBuilder<CheckoutSummary>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const LoadingIndicator();
          if (snapshot.hasError) {
            return ErrorStateView(message: 'خطا در بارگذاری خلاصه سفارش', onRetry: () => setState(() => _future = _checkoutService.getSummary()));
          }
          final summary = snapshot.data!;

          return SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      _sectionCard(
                        title: 'آدرس صورتحساب',
                        icon: Icons.receipt_long_outlined,
                        content: '${widget.billingAddress.firstName} ${widget.billingAddress.lastName}\n${widget.billingAddress.oneLine}',
                      ),
                      if (widget.shippingAddress != null) ...[
                        const SizedBox(height: 12),
                        _sectionCard(
                          title: 'آدرس ارسال',
                          icon: Icons.local_shipping_outlined,
                          content: '${widget.shippingAddress!.firstName} ${widget.shippingAddress!.lastName}\n${widget.shippingAddress!.oneLine}',
                        ),
                      ],
                      if (widget.selectedShipping != null) ...[
                        const SizedBox(height: 12),
                        _sectionCard(
                          title: 'روش ارسال',
                          icon: Icons.local_shipping_outlined,
                          content: widget.selectedShipping!.name,
                        ),
                      ],
                      const SizedBox(height: 12),
                      _sectionCard(title: 'روش پرداخت', icon: Icons.payment_outlined, content: widget.selectedPayment.friendlyName),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _commentController,
                        maxLines: 3,
                        decoration: const InputDecoration(labelText: 'توضیحات سفارش (اختیاری)', alignLabelWithHint: true),
                      ),
                      const SizedBox(height: 20),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            children: [
                              _priceRow('جمع جزء', summary.subTotalFormatted ?? '\$${summary.subTotal.toStringAsFixed(2)}'),
                              if (summary.shippingTotal != null)
                                _priceRow('هزینه ارسال', summary.shippingTotalFormatted ?? '\$${summary.shippingTotal!.toStringAsFixed(2)}'),
                              _priceRow('مالیات', summary.taxTotalFormatted ?? '\$${summary.taxTotal.toStringAsFixed(2)}'),
                              if (summary.discountAmount > 0)
                                _priceRow('تخفیف', '- ${summary.discountAmountFormatted ?? summary.discountAmount.toStringAsFixed(2)}'),
                              const Divider(height: 24),
                              _priceRow(
                                'مبلغ قابل پرداخت',
                                summary.totalFormatted ?? '\$${(summary.total ?? 0).toStringAsFixed(2)}',
                                isBold: true,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: ElevatedButton(
                    onPressed: _isPlacingOrder ? null : _placeOrder,
                    child: _isPlacingOrder
                        ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
                        : const Text('ثبت نهایی سفارش'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _sectionCard({required String title, required IconData icon, required String content}) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        subtitle: Text(content),
      ),
    );
  }

  Widget _priceRow(String label, String value, {bool isBold = false}) {
    final style = TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal, fontSize: isBold ? 16 : 13.5);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label, style: style), Text(value, style: style)],
      ),
    );
  }
}
