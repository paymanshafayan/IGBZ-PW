import 'package:flutter/material.dart';
import '../../core/network/api_exception.dart';
import '../../core/utils/validators.dart';
import '../../models/customer/address.dart';
import '../../models/shipping/location.dart';
import '../../services/customer_service.dart';
import '../../services/shipping_location_service.dart';
import '../../widgets/common_states.dart';

class AddressFormScreen extends StatefulWidget {
  final CustomerAddress? existingAddress;
  const AddressFormScreen({super.key, this.existingAddress});

  @override
  State<AddressFormScreen> createState() => _AddressFormScreenState();
}

class _AddressFormScreenState extends State<AddressFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _customerService = CustomerService();
  final _locationService = ShippingLocationService();

  late final TextEditingController _firstNameController;
  late final TextEditingController _lastNameController;
  late final TextEditingController _phoneController;
  late final TextEditingController _cityController;
  late final TextEditingController _address1Controller;
  late final TextEditingController _address2Controller;
  late final TextEditingController _zipController;

  int? _selectedCountryId;
  int? _selectedStateId;
  bool _isDefaultShipping = false;
  bool _isDefaultBilling = false;
  bool _isSaving = false;

  List<Country> _countries = [];
  List<StateProvince> _states = [];
  bool _isLoadingLocations = true;

  @override
  void initState() {
    super.initState();
    final existing = widget.existingAddress;
    _firstNameController = TextEditingController(text: existing?.firstName);
    _lastNameController = TextEditingController(text: existing?.lastName);
    _phoneController = TextEditingController(text: existing?.phoneNumber);
    _cityController = TextEditingController(text: existing?.city);
    _address1Controller = TextEditingController(text: existing?.address1);
    _address2Controller = TextEditingController(text: existing?.address2);
    _zipController = TextEditingController(text: existing?.zipPostalCode);
    _selectedCountryId = existing?.countryId;
    _selectedStateId = existing?.stateProvinceId;
    _isDefaultShipping = existing?.isDefaultShipping ?? false;
    _isDefaultBilling = existing?.isDefaultBilling ?? false;
    _loadCountries();
  }

  Future<void> _loadCountries() async {
    try {
      _countries = await _locationService.getCountries();
      if (_selectedCountryId != null) {
        _states = await _locationService.getStates(_selectedCountryId!);
      }
    } catch (_) {
      // اگر لود کشورها شکست بخورد، فرم بدون این فیلدها هم قابل استفاده است
    } finally {
      if (mounted) setState(() => _isLoadingLocations = false);
    }
  }

  Future<void> _onCountryChanged(int? countryId) async {
    setState(() {
      _selectedCountryId = countryId;
      _selectedStateId = null;
      _states = [];
    });
    if (countryId != null) {
      final states = await _locationService.getStates(countryId);
      setState(() => _states = states);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);

    final address = CustomerAddress(
      id: widget.existingAddress?.id ?? 0,
      firstName: _firstNameController.text.trim(),
      lastName: _lastNameController.text.trim(),
      countryId: _selectedCountryId,
      stateProvinceId: _selectedStateId,
      city: _cityController.text.trim(),
      address1: _address1Controller.text.trim(),
      address2: _address2Controller.text.trim().isEmpty ? null : _address2Controller.text.trim(),
      zipPostalCode: _zipController.text.trim(),
      phoneNumber: _phoneController.text.trim(),
      isDefaultShipping: _isDefaultShipping,
      isDefaultBilling: _isDefaultBilling,
    );

    try {
      if (widget.existingAddress != null) {
        await _customerService.updateAddress(widget.existingAddress!.id, address);
      } else {
        await _customerService.addAddress(address);
      }
      if (mounted) Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message), backgroundColor: Colors.red));
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _phoneController.dispose();
    _cityController.dispose();
    _address1Controller.dispose();
    _address2Controller.dispose();
    _zipController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.existingAddress != null ? 'ویرایش آدرس' : 'آدرس جدید')),
      body: _isLoadingLocations
          ? const LoadingIndicator()
          : SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(children: [
                        Expanded(
                          child: TextFormField(
                            controller: _firstNameController,
                            decoration: const InputDecoration(labelText: 'نام'),
                            validator: (v) => Validators.required(v, fieldName: 'نام'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextFormField(
                            controller: _lastNameController,
                            decoration: const InputDecoration(labelText: 'نام خانوادگی'),
                            validator: (v) => Validators.required(v, fieldName: 'نام خانوادگی'),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(labelText: 'شماره تماس'),
                        validator: (v) => Validators.required(v, fieldName: 'شماره تماس'),
                      ),
                      const SizedBox(height: 14),
                      if (_countries.isNotEmpty)
                        DropdownButtonFormField<int>(
                          initialValue: _selectedCountryId,
                          decoration: const InputDecoration(labelText: 'کشور'),
                          items: _countries.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
                          onChanged: _onCountryChanged,
                        ),
                      if (_states.isNotEmpty) ...[
                        const SizedBox(height: 14),
                        DropdownButtonFormField<int>(
                          initialValue: _selectedStateId,
                          decoration: const InputDecoration(labelText: 'استان'),
                          items: _states.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))).toList(),
                          onChanged: (v) => setState(() => _selectedStateId = v),
                        ),
                      ],
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _cityController,
                        decoration: const InputDecoration(labelText: 'شهر'),
                        validator: (v) => Validators.required(v, fieldName: 'شهر'),
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _address1Controller,
                        decoration: const InputDecoration(labelText: 'آدرس'),
                        validator: (v) => Validators.required(v, fieldName: 'آدرس'),
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _address2Controller,
                        decoration: const InputDecoration(labelText: 'آدرس تکمیلی (اختیاری)'),
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _zipController,
                        decoration: const InputDecoration(labelText: 'کد پستی'),
                        validator: (v) => Validators.required(v, fieldName: 'کد پستی'),
                      ),
                      const SizedBox(height: 10),
                      CheckboxListTile(
                        value: _isDefaultShipping,
                        onChanged: (v) => setState(() => _isDefaultShipping = v ?? false),
                        title: const Text('آدرس پیش‌فرض ارسال'),
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                      ),
                      CheckboxListTile(
                        value: _isDefaultBilling,
                        onChanged: (v) => setState(() => _isDefaultBilling = v ?? false),
                        title: const Text('آدرس پیش‌فرض صورتحساب'),
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _isSaving ? null : _save,
                        child: _isSaving
                            ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
                            : const Text('ذخیره آدرس'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}
