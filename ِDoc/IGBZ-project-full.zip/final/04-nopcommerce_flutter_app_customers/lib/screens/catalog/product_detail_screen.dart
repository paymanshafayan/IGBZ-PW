import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_exception.dart';
import '../../models/catalog/product.dart';
import '../../providers/auth_provider.dart';
import '../../providers/cart_provider.dart';
import '../../services/catalog_service.dart';
import '../../widgets/common_states.dart';
import '../../widgets/quantity_selector.dart';
import '../../widgets/rating_stars.dart';
import '../auth/login_screen.dart';
import '../cart/cart_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final int productId;
  const ProductDetailScreen({super.key, required this.productId});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  final _catalogService = CatalogService();
  late Future<Product> _future;

  int _quantity = 1;
  int _selectedImageIndex = 0;
  final Map<int, String> _selectedAttributes = {};
  bool _isAddingToCart = false;
  bool _isFavorite = false;

  @override
  void initState() {
    super.initState();
    _future = _catalogService.getProduct(widget.productId);
  }

  Future<void> _addToCart(Product product) async {
    if (!context.read<AuthProvider>().isAuthenticated) {
      final loggedIn = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const LoginScreen()));
      if (loggedIn != true) return;
    }

    for (final attribute in product.attributes) {
      if (attribute.isRequired && !_selectedAttributes.containsKey(attribute.id)) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('لطفاً «${attribute.name}» را انتخاب کنید.')));
        return;
      }
    }

    setState(() => _isAddingToCart = true);
    try {
      await context.read<CartProvider>().addItem(product.id, quantity: _quantity, attributeValues: _selectedAttributes);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('محصول به سبد خرید اضافه شد.'),
        action: SnackBarAction(
          label: 'مشاهده سبد',
          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CartScreen())),
        ),
      ));
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _isAddingToCart = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<Product>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingIndicator();
          }
          if (snapshot.hasError || !snapshot.hasData) {
            return SafeArea(
              child: ErrorStateView(
                message: 'خطا در بارگذاری محصول',
                onRetry: () => setState(() => _future = _catalogService.getProduct(widget.productId)),
              ),
            );
          }

          final product = snapshot.data!;
          final images = product.pictureUrls.isNotEmpty ? product.pictureUrls : [product.pictureUrl ?? ''];

          return Stack(
            children: [
              CustomScrollView(
                slivers: [
                  SliverAppBar(
                    pinned: true,
                    expandedHeight: 320,
                    backgroundColor: Theme.of(context).colorScheme.surface,
                    leading: _circleIconButton(context, Icons.arrow_back, () => Navigator.pop(context)),
                    actions: [
                      _circleIconButton(context, Icons.share_outlined, () {}),
                      const SizedBox(width: 8),
                    ],
                    flexibleSpace: FlexibleSpaceBar(
                      background: _ImageGallery(
                        images: images,
                        selectedIndex: _selectedImageIndex,
                        onChanged: (i) => setState(() => _selectedImageIndex = i),
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(product.name, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          RatingStars(rating: product.ratingAverage ?? 0, reviewCount: product.totalReviews),
                          const SizedBox(height: 10),
                          if (product.sku != null)
                            Text('کد محصول: ${product.sku}', style: TextStyle(color: Theme.of(context).colorScheme.outline, fontSize: 12.5)),
                          const SizedBox(height: 4),
                          Text(
                            product.isInStock ? 'موجود در انبار' : 'ناموجود',
                            style: TextStyle(
                              color: product.isInStock ? Colors.green[700] : Colors.red,
                              fontWeight: FontWeight.w600,
                              fontSize: 12.5,
                            ),
                          ),
                          if (product.isDownload) ...[
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.primaryContainer,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.cloud_download_outlined, size: 15, color: Theme.of(context).colorScheme.primary),
                                  const SizedBox(width: 6),
                                  Text(
                                    'محصول دیجیتال — پس از خرید در بخش «محصولات دیجیتال من» قابل دانلود است',
                                    style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.primary),
                                  ),
                                ],
                              ),
                            ),
                          ],
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              if (product.oldPrice != null && product.oldPrice! > product.price)
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Text('\$${product.oldPrice!.toStringAsFixed(2)}',
                                      style: TextStyle(decoration: TextDecoration.lineThrough, color: Theme.of(context).colorScheme.outline)),
                                ),
                              Text(
                                product.callForPrice ? 'تماس بگیرید' : (product.priceFormatted ?? '\$${product.price.toStringAsFixed(2)}'),
                                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary),
                              ),
                            ],
                          ),
                          const Divider(height: 32),
                          if (product.attributes.isNotEmpty) ...[
                            ..._buildAttributeSelectors(product),
                            const Divider(height: 32),
                          ],
                          if ((product.fullDescription ?? '').isNotEmpty) ...[
                            const Text('توضیحات', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                            const SizedBox(height: 8),
                            Text(_stripHtml(product.fullDescription!), style: const TextStyle(height: 1.6, fontSize: 13.5)),
                            const Divider(height: 32),
                          ],
                          if (product.specifications.isNotEmpty) ...[
                            const Text('مشخصات فنی', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                            const SizedBox(height: 8),
                            ...product.specifications.map((s) => Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 4),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.check_circle_outline, size: 15),
                                      const SizedBox(width: 6),
                                      Expanded(child: Text(s.valueText, style: const TextStyle(fontSize: 13))),
                                    ],
                                  ),
                                )),
                          ],
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: _BottomBar(
                  isFavorite: _isFavorite,
                  onFavoriteToggle: () => setState(() => _isFavorite = !_isFavorite),
                  quantity: _quantity,
                  onQuantityChanged: (q) => setState(() => _quantity = q),
                  isLoading: _isAddingToCart,
                  isInStock: product.isInStock,
                  onAddToCart: () => _addToCart(product),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> _buildAttributeSelectors(Product product) {
    return product.attributes.map((attribute) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${attribute.name}${attribute.isRequired ? ' *' : ''}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: attribute.values.map((value) {
                final isSelected = _selectedAttributes[attribute.id] == value.name;
                return ChoiceChip(
                  label: Text(value.name + (value.priceAdjustment > 0 ? ' (+\$${value.priceAdjustment.toStringAsFixed(2)})' : '')),
                  selected: isSelected,
                  onSelected: (_) => setState(() => _selectedAttributes[attribute.id] = value.name),
                );
              }).toList(),
            ),
          ],
        ),
      );
    }).toList();
  }

  String _stripHtml(String html) => html.replaceAll(RegExp(r'<[^>]*>'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();

  Widget _circleIconButton(BuildContext context, IconData icon, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: CircleAvatar(
        backgroundColor: Colors.black.withValues(alpha: 0.35),
        child: IconButton(icon: Icon(icon, color: Colors.white, size: 20), onPressed: onTap),
      ),
    );
  }
}

class _ImageGallery extends StatelessWidget {
  final List<String> images;
  final int selectedIndex;
  final ValueChanged<int> onChanged;

  const _ImageGallery({required this.images, required this.selectedIndex, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      itemCount: images.length,
      onPageChanged: onChanged,
      itemBuilder: (context, index) {
        final url = images[index];
        return url.isEmpty
            ? Container(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                child: const Icon(Icons.image_not_supported_outlined, size: 48))
            : Image.network(url, fit: BoxFit.contain);
      },
    );
  }
}

class _BottomBar extends StatelessWidget {
  final bool isFavorite;
  final VoidCallback onFavoriteToggle;
  final int quantity;
  final ValueChanged<int> onQuantityChanged;
  final bool isLoading;
  final bool isInStock;
  final VoidCallback onAddToCart;

  const _BottomBar({
    required this.isFavorite,
    required this.onFavoriteToggle,
    required this.quantity,
    required this.onQuantityChanged,
    required this.isLoading,
    required this.isInStock,
    required this.onAddToCart,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 12, offset: const Offset(0, -3))],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            IconButton(
              onPressed: onFavoriteToggle,
              icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border, color: isFavorite ? Colors.redAccent : null),
            ),
            QuantitySelector(quantity: quantity, onChanged: onQuantityChanged),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: (isLoading || !isInStock) ? null : onAddToCart,
                icon: isLoading
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.add_shopping_cart_rounded, size: 20),
                label: Text(isInStock ? 'افزودن به سبد خرید' : 'ناموجود'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
