import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/catalog/product.dart';
import '../../providers/cart_provider.dart';
import '../../services/catalog_service.dart';
import '../../widgets/product_card.dart';
import '../../widgets/common_states.dart';
import 'product_detail_screen.dart';
import '../cart/cart_screen.dart';

class ProductListScreen extends StatefulWidget {
  final int? categoryId;
  final String? categoryName;
  final String? initialKeyword;
  final String? initialSort;

  const ProductListScreen({
    super.key,
    this.categoryId,
    this.categoryName,
    this.initialKeyword,
    this.initialSort,
  });

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

enum _ViewMode { grid, list }

class _ProductListScreenState extends State<ProductListScreen> {
  final _catalogService = CatalogService();
  final _scrollController = ScrollController();
  final _searchController = TextEditingController();

  final List<ProductListItem> _products = [];
  bool _isLoading = false;
  bool _isLoadingMore = false;
  bool _hasError = false;
  int _pageIndex = 0;
  bool _hasNextPage = true;

  _ViewMode _viewMode = _ViewMode.grid;
  String? _sortBy;
  RangeValues _priceRange = const RangeValues(0, 1000);

  @override
  void initState() {
    super.initState();
    _searchController.text = widget.initialKeyword ?? '';
    _sortBy = widget.initialSort;
    _scrollController.addListener(_onScroll);
    _loadProducts(reset: true);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 300) {
      if (!_isLoadingMore && _hasNextPage && !_isLoading) {
        _loadProducts();
      }
    }
  }

  Future<void> _loadProducts({bool reset = false}) async {
    setState(() {
      if (reset) {
        _isLoading = true;
        _pageIndex = 0;
        _products.clear();
        _hasNextPage = true;
      } else {
        _isLoadingMore = true;
      }
      _hasError = false;
    });

    try {
      final result = await _catalogService.searchProducts(ProductSearchParams(
        keyword: _searchController.text.trim(),
        categoryId: widget.categoryId,
        priceFrom: _priceRange.start > 0 ? _priceRange.start : null,
        priceTo: _priceRange.end < 1000 ? _priceRange.end : null,
        orderBy: _sortBy,
        pageIndex: _pageIndex,
      ));

      setState(() {
        _products.addAll(result.items);
        _hasNextPage = result.hasNextPage;
        _pageIndex++;
      });
    } catch (_) {
      setState(() => _hasError = true);
    } finally {
      setState(() {
        _isLoading = false;
        _isLoadingMore = false;
      });
    }
  }

  void _openSortSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        final options = {
          'CreatedOnDesc': 'جدیدترین',
          'NameAsc': 'نام (صعودی)',
          'NameDesc': 'نام (نزولی)',
          'PriceAsc': 'قیمت (کم به زیاد)',
          'PriceDesc': 'قیمت (زیاد به کم)',
          'Position': 'پیش‌فرض',
        };
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('مرتب‌سازی بر اساس', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ),
              ...options.entries.map((entry) => RadioListTile<String>(
                    value: entry.key,
                    groupValue: _sortBy,
                    title: Text(entry.value),
                    onChanged: (value) {
                      setState(() => _sortBy = value);
                      Navigator.pop(context);
                      _loadProducts(reset: true);
                    },
                  )),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  void _openFilterSheet() {
    var tempRange = _priceRange;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) => SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('فیلتر قیمت', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      TextButton(
                        onPressed: () {
                          setState(() => _priceRange = tempRange);
                          Navigator.pop(context);
                          _loadProducts(reset: true);
                        },
                        child: const Text('اعمال'),
                      ),
                    ],
                  ),
                  Text('${tempRange.start.round()} تا ${tempRange.end.round()} دلار'),
                  RangeSlider(
                    values: tempRange,
                    min: 0,
                    max: 5000,
                    divisions: 100,
                    labels: RangeLabels('${tempRange.start.round()}', '${tempRange.end.round()}'),
                    onChanged: (values) => setSheetState(() => tempRange = values),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final cartCount = context.watch<CartProvider>().itemCount;

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _searchController,
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: widget.categoryName ?? 'جستجوی محصولات...',
            border: InputBorder.none,
          ),
          onSubmitted: (_) => _loadProducts(reset: true),
        ),
        actions: [
          IconButton(
            icon: Badge(label: Text('$cartCount'), isLabelVisible: cartCount > 0, child: const Icon(Icons.shopping_cart_outlined)),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CartScreen())),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: Column(
        children: [
          _buildToolbar(),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Theme.of(context).colorScheme.outlineVariant))),
      child: Row(
        children: [
          IconButton(
            icon: Icon(_viewMode == _ViewMode.grid ? Icons.grid_view_rounded : Icons.view_list_rounded),
            onPressed: () => setState(() => _viewMode = _viewMode == _ViewMode.grid ? _ViewMode.list : _ViewMode.grid),
          ),
          const VerticalDivider(width: 1),
          Expanded(
            child: TextButton.icon(
              icon: const Icon(Icons.filter_alt_outlined, size: 20),
              label: const Text('فیلتر'),
              onPressed: _openFilterSheet,
            ),
          ),
          const VerticalDivider(width: 1),
          Expanded(
            child: TextButton.icon(
              icon: const Icon(Icons.swap_vert_rounded, size: 20),
              label: const Text('مرتب‌سازی'),
              onPressed: _openSortSheet,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) return const LoadingIndicator();
    if (_hasError && _products.isEmpty) {
      return ErrorStateView(message: 'خطا در بارگذاری محصولات', onRetry: () => _loadProducts(reset: true));
    }
    if (_products.isEmpty) {
      return const EmptyState(icon: Icons.search_off_rounded, title: 'محصولی یافت نشد.', subtitle: 'کلمه کلیدی یا فیلتر دیگری را امتحان کنید.');
    }

    return RefreshIndicator(
      onRefresh: () => _loadProducts(reset: true),
      child: _viewMode == _ViewMode.grid ? _buildGrid() : _buildList(),
    );
  }

  Widget _buildGrid() {
    return GridView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.62,
      ),
      itemCount: _products.length + (_isLoadingMore ? 2 : 0),
      itemBuilder: (context, index) {
        if (index >= _products.length) return const _CardSkeleton();
        final product = _products[index];
        return ProductCard(
          product: product,
          onTap: () => _openDetail(product.id),
          onFavoriteTap: () => _addToWishlistQuick(product),
        );
      },
    );
  }

  Widget _buildList() {
    return ListView.separated(
      controller: _scrollController,
      padding: const EdgeInsets.all(12),
      itemCount: _products.length + (_isLoadingMore ? 1 : 0),
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        if (index >= _products.length) return const Padding(padding: EdgeInsets.all(12), child: LoadingIndicator());
        final product = _products[index];
        return Card(
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => _openDetail(product.id),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: SizedBox(
                      width: 90,
                      height: 90,
                      child: product.pictureUrl != null
                          ? Image.network(product.pictureUrl!, fit: BoxFit.cover)
                          : Container(color: Theme.of(context).colorScheme.surfaceContainerHighest),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                        const SizedBox(height: 6),
                        Text(
                          product.priceFormatted ?? '\$${product.price.toStringAsFixed(2)}',
                          style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  IconButton(icon: const Icon(Icons.favorite_border), onPressed: () => _addToWishlistQuick(product)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _openDetail(int productId) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProductDetailScreen(productId: productId)));
  }

  void _addToWishlistQuick(ProductListItem product) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${product.name} به علاقه‌مندی‌ها اضافه شد.')),
    );
  }
}

class _CardSkeleton extends StatelessWidget {
  const _CardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(14),
      ),
    );
  }
}
