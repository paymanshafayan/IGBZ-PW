import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../models/catalog/category.dart';
import '../../services/catalog_service.dart';
import '../../widgets/common_states.dart';
import 'product_list_screen.dart';

class CategoryListScreen extends StatefulWidget {
  const CategoryListScreen({super.key});

  @override
  State<CategoryListScreen> createState() => _CategoryListScreenState();
}

class _CategoryListScreenState extends State<CategoryListScreen> {
  final _catalogService = CatalogService();
  late Future<List<Category>> _future;

  @override
  void initState() {
    super.initState();
    _future = _catalogService.getCategories();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('دسته‌بندی‌ها'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProductListScreen())),
          ),
        ],
      ),
      body: FutureBuilder<List<Category>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const LoadingIndicator();
          if (snapshot.hasError) {
            return ErrorStateView(message: 'خطا در بارگذاری دسته‌بندی‌ها', onRetry: () => setState(() => _future = _catalogService.getCategories()));
          }
          final categories = snapshot.data ?? [];
          if (categories.isEmpty) {
            return const EmptyState(icon: Icons.category_outlined, title: 'دسته‌بندی‌ای یافت نشد.');
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: categories.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final category = categories[index];
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: SizedBox(
                      width: 52,
                      height: 52,
                      child: category.pictureUrl != null && category.pictureUrl!.isNotEmpty
                          ? CachedNetworkImage(imageUrl: category.pictureUrl!, fit: BoxFit.cover)
                          : Container(
                              color: Theme.of(context).colorScheme.primaryContainer,
                              child: Icon(Icons.category_outlined, color: Theme.of(context).colorScheme.primary),
                            ),
                    ),
                  ),
                  title: Text(category.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => ProductListScreen(categoryId: category.id, categoryName: category.name)),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
