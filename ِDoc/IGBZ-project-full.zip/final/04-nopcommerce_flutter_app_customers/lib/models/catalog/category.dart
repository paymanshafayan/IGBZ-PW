class Category {
  final int id;
  final String name;
  final String? description;
  final String? pictureUrl;
  final int? parentCategoryId;
  final String? seName;
  final int displayOrder;

  Category({
    required this.id,
    required this.name,
    this.description,
    this.pictureUrl,
    this.parentCategoryId,
    this.seName,
    this.displayOrder = 0,
  });

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        id: json['id'],
        name: json['name'] ?? '',
        description: json['description'],
        pictureUrl: json['pictureUrl'],
        parentCategoryId: json['parentCategoryId'],
        seName: json['seName'],
        displayOrder: json['displayOrder'] ?? 0,
      );
}
