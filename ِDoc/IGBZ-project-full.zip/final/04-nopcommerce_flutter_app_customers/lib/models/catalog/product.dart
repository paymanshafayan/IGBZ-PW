import 'category.dart';
import 'manufacturer.dart';

class ProductListItem {
  final int id;
  final String name;
  final String? shortDescription;
  final String? seName;
  final String? pictureUrl;
  final double price;
  final double? oldPrice;
  final String? priceFormatted;
  final bool isInStock;
  final double? ratingAverage;
  final int totalReviews;

  ProductListItem({
    required this.id,
    required this.name,
    this.shortDescription,
    this.seName,
    this.pictureUrl,
    required this.price,
    this.oldPrice,
    this.priceFormatted,
    this.isInStock = true,
    this.ratingAverage,
    this.totalReviews = 0,
  });

  factory ProductListItem.fromJson(Map<String, dynamic> json) => ProductListItem(
        id: json['id'],
        name: json['name'] ?? '',
        shortDescription: json['shortDescription'],
        seName: json['seName'],
        pictureUrl: json['pictureUrl'],
        price: (json['price'] ?? 0).toDouble(),
        oldPrice: json['oldPrice'] != null ? (json['oldPrice']).toDouble() : null,
        priceFormatted: json['priceFormatted'],
        isInStock: json['isInStock'] ?? true,
        ratingAverage: json['ratingAverage'] != null ? (json['ratingAverage']).toDouble() : null,
        totalReviews: json['totalReviews'] ?? 0,
      );
}

class ProductAttributeValue {
  final int id;
  final String name;
  final double priceAdjustment;
  final bool isPreSelected;

  ProductAttributeValue({required this.id, required this.name, this.priceAdjustment = 0, this.isPreSelected = false});

  factory ProductAttributeValue.fromJson(Map<String, dynamic> json) => ProductAttributeValue(
        id: json['id'],
        name: json['name'] ?? '',
        priceAdjustment: (json['priceAdjustment'] ?? 0).toDouble(),
        isPreSelected: json['isPreSelected'] ?? false,
      );
}

class ProductAttribute {
  final int id;
  final String name;
  final bool isRequired;
  final String? controlType;
  final List<ProductAttributeValue> values;

  ProductAttribute({required this.id, required this.name, this.isRequired = false, this.controlType, this.values = const []});

  factory ProductAttribute.fromJson(Map<String, dynamic> json) => ProductAttribute(
        id: json['id'],
        name: json['name'] ?? '',
        isRequired: json['isRequired'] ?? false,
        controlType: json['controlType'],
        values: (json['values'] as List? ?? []).map((e) => ProductAttributeValue.fromJson(e)).toList(),
      );
}

class ProductSpecification {
  final String? groupName;
  final String? attributeName;
  final String valueText;

  ProductSpecification({this.groupName, this.attributeName, required this.valueText});

  factory ProductSpecification.fromJson(Map<String, dynamic> json) => ProductSpecification(
        groupName: json['groupName'],
        attributeName: json['attributeName'],
        valueText: json['valueText'] ?? '',
      );
}

class Product extends ProductListItem {
  final String? fullDescription;
  final String? sku;
  final List<String> pictureUrls;
  final List<Category> categories;
  final Manufacturer? manufacturer;
  final List<ProductAttribute> attributes;
  final List<ProductSpecification> specifications;
  final bool callForPrice;
  final int stockQuantity;
  final bool isDownload;

  Product({
    required super.id,
    required super.name,
    super.shortDescription,
    super.seName,
    super.pictureUrl,
    required super.price,
    super.oldPrice,
    super.priceFormatted,
    super.isInStock,
    super.ratingAverage,
    super.totalReviews,
    this.fullDescription,
    this.sku,
    this.pictureUrls = const [],
    this.categories = const [],
    this.manufacturer,
    this.attributes = const [],
    this.specifications = const [],
    this.callForPrice = false,
    this.stockQuantity = 0,
    this.isDownload = false,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json['id'],
        name: json['name'] ?? '',
        shortDescription: json['shortDescription'],
        seName: json['seName'],
        pictureUrl: json['pictureUrl'],
        price: (json['price'] ?? 0).toDouble(),
        oldPrice: json['oldPrice'] != null ? (json['oldPrice']).toDouble() : null,
        priceFormatted: json['priceFormatted'],
        isInStock: json['isInStock'] ?? true,
        ratingAverage: json['ratingAverage'] != null ? (json['ratingAverage']).toDouble() : null,
        totalReviews: json['totalReviews'] ?? 0,
        fullDescription: json['fullDescription'],
        sku: json['sku'],
        pictureUrls: (json['pictureUrls'] as List?)?.map((e) => e.toString()).toList() ?? [],
        categories: (json['categories'] as List? ?? []).map((e) => Category.fromJson(e)).toList(),
        manufacturer: json['manufacturer'] != null ? Manufacturer.fromJson(json['manufacturer']) : null,
        attributes: (json['attributes'] as List? ?? []).map((e) => ProductAttribute.fromJson(e)).toList(),
        specifications: (json['specifications'] as List? ?? []).map((e) => ProductSpecification.fromJson(e)).toList(),
        callForPrice: json['callForPrice'] ?? false,
        stockQuantity: json['stockQuantity'] ?? 0,
        isDownload: json['isDownload'] ?? false,
      );
}

class ProductReview {
  final int id;
  final String customerName;
  final String? title;
  final String reviewText;
  final int rating;
  final DateTime createdOnUtc;

  ProductReview({
    required this.id,
    required this.customerName,
    this.title,
    required this.reviewText,
    required this.rating,
    required this.createdOnUtc,
  });

  factory ProductReview.fromJson(Map<String, dynamic> json) => ProductReview(
        id: json['id'],
        customerName: json['customerName'] ?? 'کاربر',
        title: json['title'],
        reviewText: json['reviewText'] ?? '',
        rating: json['rating'] ?? 0,
        createdOnUtc: DateTime.tryParse(json['createdOnUtc'] ?? '') ?? DateTime.now(),
      );
}
