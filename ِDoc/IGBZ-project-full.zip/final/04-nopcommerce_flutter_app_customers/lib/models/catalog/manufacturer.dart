class Manufacturer {
  final int id;
  final String name;
  final String? description;
  final String? pictureUrl;
  final String? seName;

  Manufacturer({required this.id, required this.name, this.description, this.pictureUrl, this.seName});

  factory Manufacturer.fromJson(Map<String, dynamic> json) => Manufacturer(
        id: json['id'],
        name: json['name'] ?? '',
        description: json['description'],
        pictureUrl: json['pictureUrl'],
        seName: json['seName'],
      );
}
