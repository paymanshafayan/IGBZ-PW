import 'package:flutter/material.dart';

/// برندینگ فروشگاهی که اپ در اولین اجرا (و بعد از آن، از کش محلی) دریافت می‌کند.
class StoreConfig {
  final int storeId;
  final String name;
  final String domain;
  final String? logoUrl;
  final String? brandColorHex;

  const StoreConfig({
    required this.storeId,
    required this.name,
    required this.domain,
    this.logoUrl,
    this.brandColorHex,
  });

  factory StoreConfig.fromJson(Map<String, dynamic> json) {
    return StoreConfig(
      storeId: json['storeId'] as int,
      name: json['name'] as String? ?? '',
      domain: json['domain'] as String? ?? '',
      logoUrl: json['logoUrl'] as String?,
      brandColorHex: json['brandColorHex'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'storeId': storeId,
        'name': name,
        'domain': domain,
        'logoUrl': logoUrl,
        'brandColorHex': brandColorHex,
      };

  /// رنگ برند به‌عنوان Color فلاتر، یا null اگر فروشگاه رنگی تنظیم نکرده باشد
  /// (در این حالت AppThemeProvider رنگ پیش‌فرض خودش را نگه می‌دارد).
  Color? get brandColor {
    if (brandColorHex == null || brandColorHex!.isEmpty) return null;
    var hex = brandColorHex!.trim().replaceFirst('#', '');
    if (hex.length == 6) hex = 'FF$hex';
    final value = int.tryParse(hex, radix: 16);
    return value != null ? Color(value) : null;
  }
}
