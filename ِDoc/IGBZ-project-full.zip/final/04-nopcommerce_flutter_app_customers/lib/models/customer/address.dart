class CustomerAddress {
  final int id;
  final String firstName;
  final String lastName;
  final String? email;
  final String? company;
  final int? countryId;
  final String? countryName;
  final int? stateProvinceId;
  final String? stateProvinceName;
  final String? city;
  final String? county;
  final String address1;
  final String? address2;
  final String? zipPostalCode;
  final String? phoneNumber;
  final String? faxNumber;
  final bool isDefaultBilling;
  final bool isDefaultShipping;

  CustomerAddress({
    this.id = 0,
    required this.firstName,
    required this.lastName,
    this.email,
    this.company,
    this.countryId,
    this.countryName,
    this.stateProvinceId,
    this.stateProvinceName,
    this.city,
    this.county,
    required this.address1,
    this.address2,
    this.zipPostalCode,
    this.phoneNumber,
    this.faxNumber,
    this.isDefaultBilling = false,
    this.isDefaultShipping = false,
  });

  String get oneLine => [address1, city, stateProvinceName, countryName]
      .where((e) => e != null && e.toString().isNotEmpty)
      .join('، ');

  factory CustomerAddress.fromJson(Map<String, dynamic> json) => CustomerAddress(
        id: json['id'] ?? 0,
        firstName: json['firstName'] ?? '',
        lastName: json['lastName'] ?? '',
        email: json['email'],
        company: json['company'],
        countryId: json['countryId'],
        countryName: json['countryName'],
        stateProvinceId: json['stateProvinceId'],
        stateProvinceName: json['stateProvinceName'],
        city: json['city'],
        county: json['county'],
        address1: json['address1'] ?? '',
        address2: json['address2'],
        zipPostalCode: json['zipPostalCode'],
        phoneNumber: json['phoneNumber'],
        faxNumber: json['faxNumber'],
        isDefaultBilling: json['isDefaultBilling'] ?? false,
        isDefaultShipping: json['isDefaultShipping'] ?? false,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'firstName': firstName,
        'lastName': lastName,
        'email': email,
        'company': company,
        'countryId': countryId,
        'stateProvinceId': stateProvinceId,
        'city': city,
        'county': county,
        'address1': address1,
        'address2': address2,
        'zipPostalCode': zipPostalCode,
        'phoneNumber': phoneNumber,
        'faxNumber': faxNumber,
        'isDefaultBilling': isDefaultBilling,
        'isDefaultShipping': isDefaultShipping,
      };
}
