class Customer {
  final int id;
  final String email;
  final String? firstName;
  final String? lastName;
  final String? phoneNumber;
  final DateTime? dateOfBirth;
  final String? gender;
  final bool isActive;
  final List<String> roles;

  Customer({
    required this.id,
    required this.email,
    this.firstName,
    this.lastName,
    this.phoneNumber,
    this.dateOfBirth,
    this.gender,
    this.isActive = true,
    this.roles = const [],
  });

  String get fullName => [firstName, lastName].where((e) => e != null && e.isNotEmpty).join(' ');

  factory Customer.fromJson(Map<String, dynamic> json) => Customer(
        id: json['id'],
        email: json['email'] ?? '',
        firstName: json['firstName'],
        lastName: json['lastName'],
        phoneNumber: json['phoneNumber'],
        dateOfBirth: json['dateOfBirth'] != null ? DateTime.tryParse(json['dateOfBirth']) : null,
        gender: json['gender'],
        isActive: json['isActive'] ?? true,
        roles: (json['roles'] as List?)?.map((e) => e.toString()).toList() ?? [],
      );
}
