/// نوع رسانه دیجیتال - هماهنگ با enum سمت سرور (DigitalMediaKind)
enum DigitalMediaKind { other, video, audio, ebook, archive }

DigitalMediaKind mediaKindFromInt(int value) {
  switch (value) {
    case 1:
      return DigitalMediaKind.video;
    case 2:
      return DigitalMediaKind.audio;
    case 3:
      return DigitalMediaKind.ebook;
    case 4:
      return DigitalMediaKind.archive;
    default:
      return DigitalMediaKind.other;
  }
}

class DownloadableProduct {
  final int orderItemId;
  final int orderId;
  final String? customOrderNumber;
  final int productId;
  final String productName;
  final String? pictureUrl;
  final bool isDownloadAllowed;
  final bool requiresLicenseAgreement;
  final bool licenseAccepted;
  final int downloadCount;
  final int maxNumberOfDownloads;
  final String? fileName;
  final String? contentType;
  final int fileSizeBytes;
  final bool hasSampleDownload;
  final DigitalMediaKind mediaKind;

  DownloadableProduct({
    required this.orderItemId,
    required this.orderId,
    this.customOrderNumber,
    required this.productId,
    required this.productName,
    this.pictureUrl,
    required this.isDownloadAllowed,
    required this.requiresLicenseAgreement,
    required this.licenseAccepted,
    this.downloadCount = 0,
    this.maxNumberOfDownloads = 0,
    this.fileName,
    this.contentType,
    this.fileSizeBytes = 0,
    this.hasSampleDownload = false,
    this.mediaKind = DigitalMediaKind.other,
  });

  /// صفر یعنی نامحدود (مطابق منطق nopCommerce)
  bool get hasUnlimitedDownloads => maxNumberOfDownloads == 0;

  int? get remainingDownloads => hasUnlimitedDownloads ? null : (maxNumberOfDownloads - downloadCount).clamp(0, maxNumberOfDownloads);

  String get fileSizeFormatted {
    if (fileSizeBytes <= 0) return '';
    const suffixes = ['B', 'KB', 'MB', 'GB'];
    var size = fileSizeBytes.toDouble();
    var i = 0;
    while (size >= 1024 && i < suffixes.length - 1) {
      size /= 1024;
      i++;
    }
    return '${size.toStringAsFixed(size < 10 && i > 0 ? 1 : 0)} ${suffixes[i]}';
  }

  factory DownloadableProduct.fromJson(Map<String, dynamic> json) => DownloadableProduct(
        orderItemId: json['orderItemId'],
        orderId: json['orderId'],
        customOrderNumber: json['customOrderNumber'],
        productId: json['productId'],
        productName: json['productName'] ?? '',
        pictureUrl: json['pictureUrl'],
        isDownloadAllowed: json['isDownloadAllowed'] ?? false,
        requiresLicenseAgreement: json['requiresLicenseAgreement'] ?? false,
        licenseAccepted: json['licenseAccepted'] ?? false,
        downloadCount: json['downloadCount'] ?? 0,
        maxNumberOfDownloads: json['maxNumberOfDownloads'] ?? 0,
        fileName: json['fileName'],
        contentType: json['contentType'],
        fileSizeBytes: json['fileSizeBytes'] ?? 0,
        hasSampleDownload: json['hasSampleDownload'] ?? false,
        mediaKind: mediaKindFromInt(json['mediaKind'] ?? 0),
      );
}

class LicenseAgreement {
  final int orderItemId;
  final String productName;
  final String agreementText;

  LicenseAgreement({required this.orderItemId, required this.productName, required this.agreementText});

  factory LicenseAgreement.fromJson(Map<String, dynamic> json) => LicenseAgreement(
        orderItemId: json['orderItemId'],
        productName: json['productName'] ?? '',
        agreementText: json['agreementText'] ?? '',
      );
}
