class Country {
  final int id;
  final String name;
  final String? twoLetterIsoCode;
  final bool allowsBilling;
  final bool allowsShipping;

  Country({required this.id, required this.name, this.twoLetterIsoCode, this.allowsBilling = true, this.allowsShipping = true});

  factory Country.fromJson(Map<String, dynamic> json) => Country(
        id: json['id'],
        name: json['name'] ?? '',
        twoLetterIsoCode: json['twoLetterIsoCode'],
        allowsBilling: json['allowsBilling'] ?? true,
        allowsShipping: json['allowsShipping'] ?? true,
      );
}

class StateProvince {
  final int id;
  final String name;
  final String? abbreviation;

  StateProvince({required this.id, required this.name, this.abbreviation});

  factory StateProvince.fromJson(Map<String, dynamic> json) => StateProvince(
        id: json['id'],
        name: json['name'] ?? '',
        abbreviation: json['abbreviation'],
      );
}
