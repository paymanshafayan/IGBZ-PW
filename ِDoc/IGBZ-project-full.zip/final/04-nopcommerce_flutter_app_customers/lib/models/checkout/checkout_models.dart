class ShippingOption {
  final String name;
  final String? description;
  final double rate;
  final String? rateFormatted;
  final String shippingRateComputationMethodSystemName;

  ShippingOption({
    required this.name,
    this.description,
    required this.rate,
    this.rateFormatted,
    required this.shippingRateComputationMethodSystemName,
  });

  factory ShippingOption.fromJson(Map<String, dynamic> json) => ShippingOption(
        name: json['name'] ?? '',
        description: json['description'],
        rate: (json['rate'] ?? 0).toDouble(),
        rateFormatted: json['rateFormatted'],
        shippingRateComputationMethodSystemName: json['shippingRateComputationMethodSystemName'] ?? '',
      );
}

class PaymentMethod {
  final String systemName;
  final String friendlyName;
  final String? description;
  final String? logoUrl;

  PaymentMethod({required this.systemName, required this.friendlyName, this.description, this.logoUrl});

  factory PaymentMethod.fromJson(Map<String, dynamic> json) => PaymentMethod(
        systemName: json['systemName'] ?? '',
        friendlyName: json['friendlyName'] ?? '',
        description: json['description'],
        logoUrl: json['logoUrl'],
      );
}

class CheckoutSummary {
  final double subTotal;
  final String? subTotalFormatted;
  final double? shippingTotal;
  final String? shippingTotalFormatted;
  final double taxTotal;
  final String? taxTotalFormatted;
  final double discountAmount;
  final String? discountAmountFormatted;
  final double? total;
  final String? totalFormatted;
  final bool requiresShipping;

  CheckoutSummary({
    required this.subTotal,
    this.subTotalFormatted,
    this.shippingTotal,
    this.shippingTotalFormatted,
    required this.taxTotal,
    this.taxTotalFormatted,
    required this.discountAmount,
    this.discountAmountFormatted,
    this.total,
    this.totalFormatted,
    this.requiresShipping = true,
  });

  factory CheckoutSummary.fromJson(Map<String, dynamic> json) => CheckoutSummary(
        subTotal: (json['subTotal'] ?? 0).toDouble(),
        subTotalFormatted: json['subTotalFormatted'],
        shippingTotal: json['shippingTotal'] != null ? (json['shippingTotal']).toDouble() : null,
        shippingTotalFormatted: json['shippingTotalFormatted'],
        taxTotal: (json['taxTotal'] ?? 0).toDouble(),
        taxTotalFormatted: json['taxTotalFormatted'],
        discountAmount: (json['discountAmount'] ?? 0).toDouble(),
        discountAmountFormatted: json['discountAmountFormatted'],
        total: json['total'] != null ? (json['total']).toDouble() : null,
        totalFormatted: json['totalFormatted'],
        requiresShipping: json['requiresShipping'] ?? true,
      );
}

class PlaceOrderResult {
  final bool success;
  final int orderId;
  final String? customOrderNumber;
  final double orderTotal;
  final String? orderTotalFormatted;
  final List<String> errors;

  PlaceOrderResult({
    required this.success,
    this.orderId = 0,
    this.customOrderNumber,
    this.orderTotal = 0,
    this.orderTotalFormatted,
    this.errors = const [],
  });

  factory PlaceOrderResult.fromJson(Map<String, dynamic> json) => PlaceOrderResult(
        success: json['success'] ?? false,
        orderId: json['orderId'] ?? 0,
        customOrderNumber: json['customOrderNumber'],
        orderTotal: (json['orderTotal'] ?? 0).toDouble(),
        orderTotalFormatted: json['orderTotalFormatted'],
        errors: (json['errors'] as List?)?.map((e) => e.toString()).toList() ?? [],
      );
}
