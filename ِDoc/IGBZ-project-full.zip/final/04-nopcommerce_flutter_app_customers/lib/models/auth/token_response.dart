class TokenResponse {
  final String accessToken;
  final String refreshToken;
  final DateTime accessTokenExpiresOnUtc;
  final int customerId;

  TokenResponse({
    required this.accessToken,
    required this.refreshToken,
    required this.accessTokenExpiresOnUtc,
    required this.customerId,
  });

  factory TokenResponse.fromJson(Map<String, dynamic> json) => TokenResponse(
        accessToken: json['accessToken'],
        refreshToken: json['refreshToken'],
        accessTokenExpiresOnUtc: DateTime.parse(json['accessTokenExpiresOnUtc']),
        customerId: json['customerId'],
      );
}
