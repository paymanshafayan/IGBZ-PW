class PagedResult<T> {
  final List<T> items;
  final int pageIndex;
  final int pageSize;
  final int totalCount;
  final int totalPages;

  PagedResult({
    required this.items,
    required this.pageIndex,
    required this.pageSize,
    required this.totalCount,
    required this.totalPages,
  });

  bool get hasNextPage => pageIndex + 1 < totalPages;

  factory PagedResult.fromJson(dynamic json, T Function(dynamic) itemParser) {
    final list = (json['items'] as List? ?? []).map(itemParser).toList();
    return PagedResult<T>(
      items: list,
      pageIndex: json['pageIndex'] ?? 0,
      pageSize: json['pageSize'] ?? list.length,
      totalCount: json['totalCount'] ?? list.length,
      totalPages: json['totalPages'] ?? 1,
    );
  }
}
