class OrderItem {
  final int id;
  final int productId;
  final String? productName;
  final String? pictureUrl;
  final int quantity;
  final double unitPrice;
  final String? unitPriceFormatted;
  final double subTotal;
  final String? subTotalFormatted;

  OrderItem({
    required this.id,
    required this.productId,
    this.productName,
    this.pictureUrl,
    required this.quantity,
    required this.unitPrice,
    this.unitPriceFormatted,
    required this.subTotal,
    this.subTotalFormatted,
  });

  factory OrderItem.fromJson(Map<String, dynamic> json) => OrderItem(
        id: json['id'],
        productId: json['productId'],
        productName: json['productName'],
        pictureUrl: json['pictureUrl'],
        quantity: json['quantity'] ?? 0,
        unitPrice: (json['unitPrice'] ?? 0).toDouble(),
        unitPriceFormatted: json['unitPriceFormatted'],
        subTotal: (json['subTotal'] ?? 0).toDouble(),
        subTotalFormatted: json['subTotalFormatted'],
      );
}

class OrderListItem {
  final int id;
  final String? customOrderNumber;
  final DateTime createdOnUtc;
  final double orderTotal;
  final String? orderTotalFormatted;
  final String orderStatus;
  final String paymentStatus;
  final String shippingStatus;
  final int totalItems;

  OrderListItem({
    required this.id,
    this.customOrderNumber,
    required this.createdOnUtc,
    required this.orderTotal,
    this.orderTotalFormatted,
    required this.orderStatus,
    required this.paymentStatus,
    required this.shippingStatus,
    this.totalItems = 0,
  });

  factory OrderListItem.fromJson(Map<String, dynamic> json) => OrderListItem(
        id: json['id'],
        customOrderNumber: json['customOrderNumber'],
        createdOnUtc: DateTime.tryParse(json['createdOnUtc'] ?? '') ?? DateTime.now(),
        orderTotal: (json['orderTotal'] ?? 0).toDouble(),
        orderTotalFormatted: json['orderTotalFormatted'],
        orderStatus: json['orderStatus'] ?? '',
        paymentStatus: json['paymentStatus'] ?? '',
        shippingStatus: json['shippingStatus'] ?? '',
        totalItems: json['totalItems'] ?? 0,
      );
}

class OrderDetail extends OrderListItem {
  final String? billingAddress;
  final String? shippingAddress;
  final String? shippingMethod;
  final String? paymentMethod;
  final double subTotal;
  final double shippingTotal;
  final double taxTotal;
  final double discountAmount;
  final String? customerComment;
  final List<OrderItem> items;
  final bool canCancel;
  final bool canReturnItems;
  final bool canRePay;

  OrderDetail({
    required super.id,
    super.customOrderNumber,
    required super.createdOnUtc,
    required super.orderTotal,
    super.orderTotalFormatted,
    required super.orderStatus,
    required super.paymentStatus,
    required super.shippingStatus,
    super.totalItems,
    this.billingAddress,
    this.shippingAddress,
    this.shippingMethod,
    this.paymentMethod,
    this.subTotal = 0,
    this.shippingTotal = 0,
    this.taxTotal = 0,
    this.discountAmount = 0,
    this.customerComment,
    this.items = const [],
    this.canCancel = false,
    this.canReturnItems = false,
    this.canRePay = false,
  });

  factory OrderDetail.fromJson(Map<String, dynamic> json) => OrderDetail(
        id: json['id'],
        customOrderNumber: json['customOrderNumber'],
        createdOnUtc: DateTime.tryParse(json['createdOnUtc'] ?? '') ?? DateTime.now(),
        orderTotal: (json['orderTotal'] ?? 0).toDouble(),
        orderTotalFormatted: json['orderTotalFormatted'],
        orderStatus: json['orderStatus'] ?? '',
        paymentStatus: json['paymentStatus'] ?? '',
        shippingStatus: json['shippingStatus'] ?? '',
        totalItems: json['totalItems'] ?? 0,
        billingAddress: json['billingAddress'],
        shippingAddress: json['shippingAddress'],
        shippingMethod: json['shippingMethod'],
        paymentMethod: json['paymentMethod'],
        subTotal: (json['subTotal'] ?? 0).toDouble(),
        shippingTotal: (json['shippingTotal'] ?? 0).toDouble(),
        taxTotal: (json['taxTotal'] ?? 0).toDouble(),
        discountAmount: (json['discountAmount'] ?? 0).toDouble(),
        customerComment: json['customerComment'],
        items: (json['items'] as List? ?? []).map((e) => OrderItem.fromJson(e)).toList(),
        canCancel: json['canCancel'] ?? false,
        canReturnItems: json['canReturnItems'] ?? false,
        canRePay: json['canRePay'] ?? false,
      );
}
