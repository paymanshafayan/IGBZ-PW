class ShoppingCartItem {
  final int id;
  final int productId;
  final String productName;
  final String? productSeName;
  final String? pictureUrl;
  final int quantity;
  final double unitPrice;
  final double subTotal;
  final String? unitPriceFormatted;
  final String? subTotalFormatted;
  final List<String> attributeDescriptions;
  final List<String> warnings;

  ShoppingCartItem({
    required this.id,
    required this.productId,
    required this.productName,
    this.productSeName,
    this.pictureUrl,
    required this.quantity,
    required this.unitPrice,
    required this.subTotal,
    this.unitPriceFormatted,
    this.subTotalFormatted,
    this.attributeDescriptions = const [],
    this.warnings = const [],
  });

  factory ShoppingCartItem.fromJson(Map<String, dynamic> json) => ShoppingCartItem(
        id: json['id'],
        productId: json['productId'],
        productName: json['productName'] ?? '',
        productSeName: json['productSeName'],
        pictureUrl: json['pictureUrl'],
        quantity: json['quantity'] ?? 1,
        unitPrice: (json['unitPrice'] ?? 0).toDouble(),
        subTotal: (json['subTotal'] ?? 0).toDouble(),
        unitPriceFormatted: json['unitPriceFormatted'],
        subTotalFormatted: json['subTotalFormatted'],
        attributeDescriptions: (json['attributeDescriptions'] as List?)?.map((e) => e.toString()).toList() ?? [],
        warnings: (json['warnings'] as List?)?.map((e) => e.toString()).toList() ?? [],
      );
}

class ShoppingCart {
  final List<ShoppingCartItem> items;
  final double subTotal;
  final String? subTotalFormatted;
  final double? discount;
  final double? total;
  final String? totalFormatted;
  final int totalItemsCount;
  final List<String> appliedDiscountCodes;

  ShoppingCart({
    this.items = const [],
    this.subTotal = 0,
    this.subTotalFormatted,
    this.discount,
    this.total,
    this.totalFormatted,
    this.totalItemsCount = 0,
    this.appliedDiscountCodes = const [],
  });

  bool get isEmpty => items.isEmpty;

  factory ShoppingCart.fromJson(Map<String, dynamic> json) => ShoppingCart(
        items: (json['items'] as List? ?? []).map((e) => ShoppingCartItem.fromJson(e)).toList(),
        subTotal: (json['subTotal'] ?? 0).toDouble(),
        subTotalFormatted: json['subTotalFormatted'],
        discount: json['discount'] != null ? (json['discount']).toDouble() : null,
        total: json['total'] != null ? (json['total']).toDouble() : null,
        totalFormatted: json['totalFormatted'],
        totalItemsCount: json['totalItemsCount'] ?? 0,
        appliedDiscountCodes: (json['appliedDiscountCodes'] as List?)?.map((e) => e.toString()).toList() ?? [],
      );

  factory ShoppingCart.empty() => ShoppingCart();
}
