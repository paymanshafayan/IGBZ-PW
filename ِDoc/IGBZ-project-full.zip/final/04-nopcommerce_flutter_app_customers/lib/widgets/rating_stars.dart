import 'package:flutter/material.dart';

class RatingStars extends StatelessWidget {
  final double rating;
  final double size;
  final int? reviewCount;

  const RatingStars({super.key, required this.rating, this.size = 16, this.reviewCount});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        ...List.generate(5, (index) {
          IconData icon;
          if (rating >= index + 1) {
            icon = Icons.star_rounded;
          } else if (rating > index && rating < index + 1) {
            icon = Icons.star_half_rounded;
          } else {
            icon = Icons.star_border_rounded;
          }
          return Icon(icon, size: size, color: rating > 0 ? Colors.amber[700] : Colors.grey[400]);
        }),
        if (reviewCount != null && reviewCount! > 0) ...[
          const SizedBox(width: 4),
          Text('($reviewCount)', style: TextStyle(fontSize: size * 0.7, color: Colors.grey[600])),
        ],
      ],
    );
  }
}
