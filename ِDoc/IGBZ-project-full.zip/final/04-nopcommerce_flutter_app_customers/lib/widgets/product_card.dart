import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/catalog/product.dart';
import 'rating_stars.dart';

class ProductCard extends StatelessWidget {
  final ProductListItem product;
  final VoidCallback onTap;
  final VoidCallback? onFavoriteTap;
  final bool isFavorite;
  final bool isGridView;

  const ProductCard({
    super.key,
    required this.product,
    required this.onTap,
    this.onFavoriteTap,
    this.isFavorite = false,
    this.isGridView = true,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    final image = AspectRatio(
      aspectRatio: 1,
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
        child: CachedNetworkImage(
          imageUrl: product.pictureUrl ?? '',
          fit: BoxFit.cover,
          placeholder: (_, __) => Container(color: colorScheme.surfaceContainerHighest),
          errorWidget: (_, __, ___) => Container(
            color: colorScheme.surfaceContainerHighest,
            child: Icon(Icons.image_not_supported_outlined, color: colorScheme.outline),
          ),
        ),
      ),
    );

    final favoriteButton = Positioned(
      top: 8,
      right: 8,
      child: GestureDetector(
        onTap: onFavoriteTap,
        child: CircleAvatar(
          radius: 16,
          backgroundColor: Colors.white.withValues(alpha: 0.9),
          child: Icon(
            isFavorite ? Icons.favorite : Icons.favorite_border,
            size: 18,
            color: isFavorite ? Colors.redAccent : colorScheme.primary,
          ),
        ),
      ),
    );

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(children: [image, favoriteButton]),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5, height: 1.3),
                  ),
                  const SizedBox(height: 4),
                  RatingStars(rating: product.ratingAverage ?? 0, size: 13, reviewCount: product.totalReviews),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (product.oldPrice != null && product.oldPrice! > product.price)
                        Padding(
                          padding: const EdgeInsets.only(left: 6),
                          child: Text(
                            '\$${product.oldPrice!.toStringAsFixed(2)}',
                            style: TextStyle(
                              decoration: TextDecoration.lineThrough,
                              color: colorScheme.outline,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      Text(
                        product.priceFormatted ?? '\$${product.price.toStringAsFixed(2)}',
                        style: TextStyle(
                          color: colorScheme.primary,
                          fontWeight: FontWeight.bold,
                          fontSize: 14.5,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
