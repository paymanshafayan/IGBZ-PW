import '../core/constants/api_endpoints.dart';
import '../core/network/api_client.dart';
import '../core/network/token_storage.dart';
import '../models/auth/token_response.dart';

class AuthService {
  final _client = ApiClient.instance;

  Future<TokenResponse> register({
    required String firstName,
    required String lastName,
    required String email,
    required String password,
    String? phoneNumber,
  }) async {
    final result = await _client.post<TokenResponse>(
      ApiEndpoints.register,
      data: {
        'firstName': firstName,
        'lastName': lastName,
        'email': email,
        'password': password,
        'phoneNumber': phoneNumber,
      },
      parser: (json) => TokenResponse.fromJson(json),
    );
    await _persistTokens(result);
    return result;
  }

  Future<TokenResponse> login({required String email, required String password, String? deviceId}) async {
    final result = await _client.post<TokenResponse>(
      ApiEndpoints.login,
      data: {'email': email, 'password': password, 'deviceId': deviceId},
      parser: (json) => TokenResponse.fromJson(json),
    );
    await _persistTokens(result);
    return result;
  }

  Future<void> logout({bool allDevices = false}) async {
    final refreshToken = await TokenStorage.instance.getRefreshToken();
    try {
      await _client.post<void>(
        '${ApiEndpoints.logout}?allDevices=$allDevices',
        data: {'refreshToken': refreshToken},
        parser: (_) {},
      );
    } catch (_) {
      // حتی اگر درخواست سرور شکست بخورد، نشست محلی را پاک می‌کنیم
    } finally {
      await TokenStorage.instance.clear();
    }
  }

  Future<void> changePassword({required String oldPassword, required String newPassword}) {
    return _client.post<void>(
      ApiEndpoints.changePassword,
      data: {'oldPassword': oldPassword, 'newPassword': newPassword},
      parser: (_) {},
    );
  }

  Future<void> forgotPassword(String email) {
    return _client.post<void>(ApiEndpoints.forgotPassword, data: {'email': email}, parser: (_) {});
  }

  Future<void> resetPassword({required String email, required String token, required String newPassword}) {
    return _client.post<void>(
      ApiEndpoints.resetPassword,
      data: {'email': email, 'token': token, 'newPassword': newPassword},
      parser: (_) {},
    );
  }

  Future<void> _persistTokens(TokenResponse token) {
    return TokenStorage.instance.saveTokens(
      accessToken: token.accessToken,
      refreshToken: token.refreshToken,
      customerId: token.customerId,
    );
  }
}
