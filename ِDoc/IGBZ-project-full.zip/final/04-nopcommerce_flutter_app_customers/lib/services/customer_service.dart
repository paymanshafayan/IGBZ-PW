import '../core/constants/api_endpoints.dart';
import '../core/network/api_client.dart';
import '../models/customer/customer.dart';
import '../models/customer/address.dart';

class CustomerService {
  final _client = ApiClient.instance;

  Future<Customer> getProfile() => _client.get<Customer>(
        ApiEndpoints.profile,
        parser: (json) => Customer.fromJson(json),
      );

  Future<Customer> updateProfile({
    required String firstName,
    required String lastName,
    String? phoneNumber,
    DateTime? dateOfBirth,
    String? gender,
  }) =>
      _client.put<Customer>(
        ApiEndpoints.profile,
        data: {
          'firstName': firstName,
          'lastName': lastName,
          'phoneNumber': phoneNumber,
          'dateOfBirth': dateOfBirth?.toIso8601String(),
          'gender': gender,
        },
        parser: (json) => Customer.fromJson(json),
      );

  Future<List<CustomerAddress>> getAddresses() => _client.get<List<CustomerAddress>>(
        ApiEndpoints.addresses,
        parser: (json) => (json as List).map((e) => CustomerAddress.fromJson(e)).toList(),
      );

  Future<CustomerAddress> addAddress(CustomerAddress address) => _client.post<CustomerAddress>(
        ApiEndpoints.addresses,
        data: address.toJson(),
        parser: (json) => CustomerAddress.fromJson(json),
      );

  Future<CustomerAddress> updateAddress(int id, CustomerAddress address) => _client.put<CustomerAddress>(
        ApiEndpoints.addressById(id),
        data: address.toJson(),
        parser: (json) => CustomerAddress.fromJson(json),
      );

  Future<void> deleteAddress(int id) => _client.delete<void>(ApiEndpoints.addressById(id), parser: (_) {});
}
