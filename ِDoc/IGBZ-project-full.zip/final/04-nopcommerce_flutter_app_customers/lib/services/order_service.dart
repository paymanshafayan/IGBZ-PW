import '../core/constants/api_endpoints.dart';
import '../core/network/api_client.dart';
import '../models/common/paged_result.dart';
import '../models/order/order.dart';

class OrderService {
  final _client = ApiClient.instance;

  Future<PagedResult<OrderListItem>> getOrders({int pageIndex = 0, int pageSize = 20}) => _client.get(
        ApiEndpoints.orders,
        query: {'pageIndex': pageIndex, 'pageSize': pageSize},
        parser: (json) => PagedResult<OrderListItem>.fromJson(json, (e) => OrderListItem.fromJson(e)),
      );

  Future<OrderDetail> getOrder(int id) => _client.get<OrderDetail>(
        ApiEndpoints.orderById(id),
        parser: (json) => OrderDetail.fromJson(json),
      );

  Future<void> cancelOrder(int id) => _client.post<void>(ApiEndpoints.cancelOrder(id), parser: (_) {});

  Future<void> createReturnRequest(int orderId, List<Map<String, dynamic>> items, {String? customerComments}) =>
      _client.post<void>(
        ApiEndpoints.returnRequest(orderId),
        data: {'items': items, 'customerComments': customerComments},
        parser: (_) {},
      );
}
