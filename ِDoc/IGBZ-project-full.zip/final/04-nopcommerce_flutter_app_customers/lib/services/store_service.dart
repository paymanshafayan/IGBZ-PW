import '../core/constants/api_endpoints.dart';
import '../core/network/api_client.dart';
import '../models/store/store_config.dart';

/// نتیجهٔ POST /store/resolve
class ResolveStoreResult {
  final bool found;
  final int? storeId;

  const ResolveStoreResult({required this.found, this.storeId});

  factory ResolveStoreResult.fromJson(Map<String, dynamic> json) => ResolveStoreResult(
        found: json['found'] as bool? ?? false,
        storeId: json['storeId'] as int?,
      );
}

class StoreService {
  final _client = ApiClient.instance;

  /// همان شماره‌ای که کاربر قبلاً در صفحهٔ دانلود اپ (روی سایت فروشگاه) وارد کرده را می‌فرستد
  /// و اگر شناخته‌شده باشد، شناسهٔ فروشگاه را برمی‌گرداند.
  Future<ResolveStoreResult> resolveByPhone(String phoneNumber) => _client.post<ResolveStoreResult>(
        ApiEndpoints.storeResolve,
        data: {'phoneNumber': phoneNumber},
        parser: (json) => ResolveStoreResult.fromJson(json),
      );

  Future<StoreConfig> getConfig(int storeId) => _client.get<StoreConfig>(
        ApiEndpoints.storeConfig(storeId),
        parser: (json) => StoreConfig.fromJson(json),
      );
}
