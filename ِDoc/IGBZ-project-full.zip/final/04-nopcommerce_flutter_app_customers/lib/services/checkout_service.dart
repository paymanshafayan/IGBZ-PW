import '../core/constants/api_endpoints.dart';
import '../core/network/api_client.dart';
import '../models/checkout/checkout_models.dart';

class CheckoutService {
  final _client = ApiClient.instance;

  Future<CheckoutSummary> getSummary() => _client.get<CheckoutSummary>(
        ApiEndpoints.checkoutSummary,
        parser: (json) => CheckoutSummary.fromJson(json),
      );

  Future<List<ShippingOption>> getShippingMethods(int shippingAddressId) => _client.get(
        ApiEndpoints.shippingMethods,
        query: {'shippingAddressId': shippingAddressId},
        parser: (json) => (json as List).map((e) => ShippingOption.fromJson(e)).toList(),
      );

  Future<void> selectShippingMethod(String name, String computationMethodSystemName) => _client.post<void>(
        ApiEndpoints.selectShippingMethod,
        data: {
          'shippingOptionName': name,
          'shippingRateComputationMethodSystemName': computationMethodSystemName,
        },
        parser: (_) {},
      );

  Future<List<PaymentMethod>> getPaymentMethods() => _client.get(
        ApiEndpoints.paymentMethods,
        parser: (json) => (json as List).map((e) => PaymentMethod.fromJson(e)).toList(),
      );

  Future<void> selectPaymentMethod(String systemName) => _client.post<void>(
        ApiEndpoints.selectPaymentMethod,
        data: {'paymentMethodSystemName': systemName},
        parser: (_) {},
      );

  Future<PlaceOrderResult> placeOrder({
    required int billingAddressId,
    int? shippingAddressId,
    required String paymentMethodSystemName,
    String? shippingOptionName,
    String? shippingRateComputationMethodSystemName,
    String? customerComment,
  }) =>
      _client.post<PlaceOrderResult>(
        ApiEndpoints.placeOrder,
        data: {
          'billingAddressId': billingAddressId,
          'shippingAddressId': shippingAddressId,
          'paymentMethodSystemName': paymentMethodSystemName,
          'shippingOptionName': shippingOptionName,
          'shippingRateComputationMethodSystemName': shippingRateComputationMethodSystemName,
          'customerComment': customerComment,
        },
        parser: (json) => PlaceOrderResult.fromJson(json),
      );
}
