import '../core/constants/api_endpoints.dart';
import '../core/network/api_client.dart';
import '../models/catalog/category.dart';
import '../models/catalog/manufacturer.dart';
import '../models/catalog/product.dart';
import '../models/common/paged_result.dart';

class ProductSearchParams {
  final String? keyword;
  final int? categoryId;
  final int? manufacturerId;
  final double? priceFrom;
  final double? priceTo;
  final String? orderBy; // NameAsc, NameDesc, PriceAsc, PriceDesc, CreatedOnDesc
  final int pageIndex;
  final int pageSize;

  ProductSearchParams({
    this.keyword,
    this.categoryId,
    this.manufacturerId,
    this.priceFrom,
    this.priceTo,
    this.orderBy,
    this.pageIndex = 0,
    this.pageSize = 20,
  });

  Map<String, dynamic> toQuery() => {
        if (keyword != null && keyword!.isNotEmpty) 'Keyword': keyword,
        if (categoryId != null) 'CategoryId': categoryId,
        if (manufacturerId != null) 'ManufacturerId': manufacturerId,
        if (priceFrom != null) 'PriceFrom': priceFrom,
        if (priceTo != null) 'PriceTo': priceTo,
        if (orderBy != null) 'OrderBy': orderBy,
        'PageIndex': pageIndex,
        'PageSize': pageSize,
      };

  ProductSearchParams copyWith({
    String? keyword,
    int? categoryId,
    int? manufacturerId,
    double? priceFrom,
    double? priceTo,
    String? orderBy,
    int? pageIndex,
    int? pageSize,
  }) =>
      ProductSearchParams(
        keyword: keyword ?? this.keyword,
        categoryId: categoryId ?? this.categoryId,
        manufacturerId: manufacturerId ?? this.manufacturerId,
        priceFrom: priceFrom ?? this.priceFrom,
        priceTo: priceTo ?? this.priceTo,
        orderBy: orderBy ?? this.orderBy,
        pageIndex: pageIndex ?? this.pageIndex,
        pageSize: pageSize ?? this.pageSize,
      );
}

class CatalogService {
  final _client = ApiClient.instance;

  Future<List<Category>> getCategories({int parentCategoryId = 0}) => _client.get<List<Category>>(
        ApiEndpoints.categories,
        query: {'parentCategoryId': parentCategoryId},
        parser: (json) => (json as List).map((e) => Category.fromJson(e)).toList(),
      );

  Future<List<Manufacturer>> getManufacturers() => _client.get<List<Manufacturer>>(
        ApiEndpoints.manufacturers,
        parser: (json) => (json as List).map((e) => Manufacturer.fromJson(e)).toList(),
      );

  Future<PagedResult<ProductListItem>> searchProducts(ProductSearchParams params) => _client.get(
        ApiEndpoints.products,
        query: params.toQuery(),
        parser: (json) => PagedResult<ProductListItem>.fromJson(json, (e) => ProductListItem.fromJson(e)),
      );

  Future<Product> getProduct(int id) => _client.get<Product>(
        ApiEndpoints.productById(id),
        parser: (json) => Product.fromJson(json),
      );

  Future<List<ProductReview>> getProductReviews(int id, {int pageIndex = 0, int pageSize = 20}) => _client.get(
        ApiEndpoints.productReviews(id),
        query: {'pageIndex': pageIndex, 'pageSize': pageSize},
        parser: (json) => (json as List).map((e) => ProductReview.fromJson(e)).toList(),
      );

  Future<void> addProductReview(int id, {String? title, required String reviewText, required int rating}) =>
      _client.post<void>(
        ApiEndpoints.productReviews(id),
        data: {'title': title, 'reviewText': reviewText, 'rating': rating},
        parser: (_) {},
      );
}
