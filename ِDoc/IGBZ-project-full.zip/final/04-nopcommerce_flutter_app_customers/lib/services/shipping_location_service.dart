import '../core/constants/api_endpoints.dart';
import '../core/network/api_client.dart';
import '../models/shipping/location.dart';

class ShippingLocationService {
  final _client = ApiClient.instance;

  Future<List<Country>> getCountries() => _client.get<List<Country>>(
        ApiEndpoints.countries,
        parser: (json) => (json as List).map((e) => Country.fromJson(e)).toList(),
      );

  Future<List<StateProvince>> getStates(int countryId) => _client.get<List<StateProvince>>(
        ApiEndpoints.statesByCountry(countryId),
        parser: (json) => (json as List).map((e) => StateProvince.fromJson(e)).toList(),
      );
}
