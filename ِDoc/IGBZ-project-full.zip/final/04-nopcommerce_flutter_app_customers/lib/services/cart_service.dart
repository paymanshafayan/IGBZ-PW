import '../core/constants/api_endpoints.dart';
import '../core/network/api_client.dart';
import '../models/cart/shopping_cart.dart';

class WishlistItem {
  final int id;
  final int productId;
  final String productName;
  final String? pictureUrl;
  final int quantity;
  final double unitPrice;
  final bool isInStock;

  WishlistItem({
    required this.id,
    required this.productId,
    required this.productName,
    this.pictureUrl,
    required this.quantity,
    required this.unitPrice,
    this.isInStock = true,
  });

  factory WishlistItem.fromJson(Map<String, dynamic> json) => WishlistItem(
        id: json['id'],
        productId: json['productId'],
        productName: json['productName'] ?? '',
        pictureUrl: json['pictureUrl'],
        quantity: json['quantity'] ?? 1,
        unitPrice: (json['unitPrice'] ?? 0).toDouble(),
        isInStock: json['isInStock'] ?? true,
      );
}

class CartService {
  final _client = ApiClient.instance;

  Future<ShoppingCart> getCart() => _client.get<ShoppingCart>(
        ApiEndpoints.cart,
        parser: (json) => ShoppingCart.fromJson(json),
      );

  Future<ShoppingCart> addItem({required int productId, int quantity = 1, Map<int, String>? attributeValues}) =>
      _client.post<ShoppingCart>(
        ApiEndpoints.cartItems,
        data: {
          'productId': productId,
          'quantity': quantity,
          'attributeValues': attributeValues?.map((k, v) => MapEntry(k.toString(), v)) ?? {},
        },
        parser: (json) => ShoppingCart.fromJson(json),
      );

  Future<ShoppingCart> updateItem(int itemId, int quantity) => _client.put<ShoppingCart>(
        ApiEndpoints.cartItemById(itemId),
        data: {'quantity': quantity},
        parser: (json) => ShoppingCart.fromJson(json),
      );

  Future<ShoppingCart> removeItem(int itemId) => _client.delete<ShoppingCart>(
        ApiEndpoints.cartItemById(itemId),
        parser: (json) => ShoppingCart.fromJson(json),
      );

  Future<void> clearCart() => _client.delete<void>(ApiEndpoints.cart, parser: (_) {});

  // ---------------- Wishlist ----------------

  Future<List<WishlistItem>> getWishlist() => _client.get<List<WishlistItem>>(
        ApiEndpoints.wishlist,
        parser: (json) => (json as List).map((e) => WishlistItem.fromJson(e)).toList(),
      );

  Future<void> addToWishlist(int productId, {int quantity = 1}) => _client.post<void>(
        ApiEndpoints.wishlistItems,
        data: {'productId': productId, 'quantity': quantity},
        parser: (_) {},
      );
}
