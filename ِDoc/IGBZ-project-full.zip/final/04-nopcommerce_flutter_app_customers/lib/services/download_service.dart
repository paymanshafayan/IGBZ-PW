import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import '../core/constants/api_endpoints.dart';
import '../core/network/api_client.dart';
import '../core/network/api_exception.dart';
import '../core/network/token_storage.dart';
import '../models/download/downloadable_product.dart';

class DownloadService {
  final _client = ApiClient.instance;

  Future<List<DownloadableProduct>> getMyDownloadableProducts() => _client.get<List<DownloadableProduct>>(
        ApiEndpoints.myDownloadableProducts,
        parser: (json) => (json as List).map((e) => DownloadableProduct.fromJson(e)).toList(),
      );

  Future<LicenseAgreement> getLicenseAgreement(int orderItemId) => _client.get<LicenseAgreement>(
        ApiEndpoints.licenseAgreement(orderItemId),
        parser: (json) => LicenseAgreement.fromJson(json),
      );

  Future<void> acceptLicenseAgreement(int orderItemId) => _client.post<void>(
        ApiEndpoints.acceptLicenseAgreement(orderItemId),
        parser: (_) {},
      );

  /// دانلود فایل نمونه (بدون نیاز به ورود) به مسیر محلی دستگاه
  Future<File> downloadSample(int productId, String suggestedFileName, {void Function(double progress)? onProgress}) {
    return _downloadToLocalFile(ApiEndpoints.downloadSample(productId), suggestedFileName, requiresAuth: false, onProgress: onProgress);
  }

  /// دانلود فایل اصلی محصول خریداری‌شده به مسیر محلی دستگاه.
  /// توجه: اگر فایل روی یک URL خارجی میزبانی شده باشد، سرور یک پاسخ JSON با فیلد redirectUrl برمی‌گرداند
  /// که این متد آن را به‌صورت [ExternalDownloadUrlException] پرتاب می‌کند تا لایه UI آن را در مرورگر/WebView باز کند.
  Future<File> downloadFile(int orderItemId, String suggestedFileName, {void Function(double progress)? onProgress}) {
    return _downloadToLocalFile(ApiEndpoints.downloadFile(orderItemId), suggestedFileName, requiresAuth: true, onProgress: onProgress);
  }

  Future<File> _downloadToLocalFile(
    String path,
    String suggestedFileName, {
    required bool requiresAuth,
    void Function(double progress)? onProgress,
  }) async {
    final dio = Dio(BaseOptions(baseUrl: ApiConfig.apiBase));

    if (requiresAuth) {
      final token = await TokenStorage.instance.getAccessToken();
      if (token != null) dio.options.headers['Authorization'] = 'Bearer $token';
    }

    final dir = await getApplicationDocumentsDirectory();
    final downloadsDir = Directory('${dir.path}/downloads');
    if (!await downloadsDir.exists()) await downloadsDir.create(recursive: true);
    final localFile = File('${downloadsDir.path}/$suggestedFileName');

    try {
      final response = await dio.get<List<int>>(
        path,
        options: Options(responseType: ResponseType.bytes, validateStatus: (status) => status != null && status < 500),
        onReceiveProgress: (received, total) {
          if (total > 0 && onProgress != null) onProgress(received / total);
        },
      );

      final contentType = response.headers.value('content-type') ?? '';

      // اگر سرور به‌جای فایل باینری، JSON حاوی redirectUrl برگردانده (فایل خارجی) یا خطا داده
      if (contentType.contains('application/json')) {
        final decoded = String.fromCharCodes(response.data ?? []);
        throw _handleJsonResponse(decoded);
      }

      await localFile.writeAsBytes(response.data ?? []);
      return localFile;
    } on DioException catch (e) {
      if (e.response?.data != null) {
        final bytes = e.response!.data;
        String bodyText = '';
        try {
          bodyText = bytes is List<int> ? String.fromCharCodes(bytes) : bytes.toString();
        } catch (_) {}
        throw _handleJsonResponse(bodyText);
      }
      throw ApiException('دانلود فایل با خطا مواجه شد. اتصال اینترنت خود را بررسی کنید.');
    }
  }

  Exception _handleJsonResponse(String body) {
    try {
      if (body.contains('"redirectUrl"')) {
        final match = RegExp(r'"redirectUrl"\s*:\s*"([^"]+)"').firstMatch(body);
        if (match != null) {
          return ExternalDownloadUrlException(match.group(1)!);
        }
      }
      final messageMatch = RegExp(r'"message"\s*:\s*"([^"]+)"').firstMatch(body);
      if (messageMatch != null) {
        return ApiException(messageMatch.group(1)!);
      }
    } catch (_) {}
    return ApiException('دانلود این فایل امکان‌پذیر نیست.');
  }
}

/// پرتاب می‌شود وقتی فایل واقعی روی یک آدرس خارجی میزبانی شده (nopCommerce: Download.UseDownloadUrl)
/// و باید در مرورگر/WebView به‌جای دانلود مستقیم باز شود.
class ExternalDownloadUrlException implements Exception {
  final String url;
  ExternalDownloadUrlException(this.url);
}
