import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'core/network/api_client.dart';
import 'core/theme/app_theme_provider.dart';
import 'providers/auth_provider.dart';
import 'providers/cart_provider.dart';
import 'providers/store_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  final authProvider = AuthProvider();
  final cartProvider = CartProvider();
  final storeProvider = StoreProvider();

  // وقتی نشست کاربر (حتی بعد از تلاش برای تمدید توکن) منقضی شود، وضعیت را در سراسر اپ به‌روزرسانی می‌کنیم
  ApiClient.instance.onSessionExpired = () {
    authProvider.handleSessionExpired();
    cartProvider.reset();
  };

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AppThemeProvider>(create: (_) => AppThemeProvider()),
        ChangeNotifierProvider<StoreProvider>.value(value: storeProvider),
        ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
        ChangeNotifierProvider<CartProvider>.value(value: cartProvider),
      ],
      child: const NopCommerceApp(),
    ),
  );
}
