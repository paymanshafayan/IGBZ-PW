# اپلیکیشن فلاتر nopCommerce (Android/iOS)

اپلیکیشن موبایل کامل و حرفه‌ای برای فروشگاه nopCommerce، متصل به پلاگین **Nop.Plugin.Api** که پیش‌تر ساختیم. طراحی ظاهری از روی تصاویر مرجع (تم آبی نمونه اپ رسمی nopCommerce) الهام گرفته شده، اما **کاملاً قابل تغییر به هر رنگی** است.

## ⚠️ گام اول (الزامی) — اسکلت‌سازی پروژه با Flutter CLI
این پوشه فقط شامل **کد Dart (`lib/`)**، `pubspec.yaml` و assets است. پوشه‌های native اندروید/iOS (`android/`, `ios/`, `web/` و غیره) باید توسط خود Flutter CLI ساخته شوند (این پوشه‌ها حجیم و کاملاً استاندارد هستند و دستی نوشتن‌شان نه لازم است نه توصیه می‌شود). مراحل:

```bash
# 1) یک پروژه خالی فلاتر بسازید (نسخه پیشنهادی: Flutter 3.24+ / Dart 3.5+)
flutter create --org com.yourcompany --project-name nopcommerce_flutter_app temp_app

# 2) فایل‌های lib/, pubspec.yaml, assets/ همین پکیج را جایگزین نسخه‌ی temp_app کنید
#    (پوشه‌های android/ ,ios/ ,web/ که flutter create ساخته را دست‌نخورده نگه دارید)

# 3) وارد پوشه پروژه شوید و پکیج‌ها را نصب کنید
flutter pub get

# 4) اجرا روی شبیه‌ساز/دستگاه متصل
flutter run
```

## ⚠️ گام دوم (الزامی) — تنظیم آدرس API
فایل `lib/core/constants/api_endpoints.dart` را باز کنید و مقدار زیر را با آدرس واقعی فروشگاهتان جایگزین کنید:
```dart
static const String baseUrl = 'https://your-store-domain.com';
```
این آدرس باید همان دامنه‌ای باشد که پلاگین `Nop.Plugin.Api` روی آن نصب شده (یعنی `baseUrl/api/v1/...` باید در دسترس باشد؛ برای تست سریع `baseUrl/api/docs` را در مرورگر باز کنید تا Swagger پلاگین را ببینید).

اگر فروشگاه فعلاً روی HTTP (نه HTTPS) تست می‌شود:
- **Android**: در `android/app/src/main/AndroidManifest.xml` باید `android:usesCleartextTraffic="true"` اضافه کنید (فقط برای توسعه؛ در Production حتماً HTTPS).
- **iOS**: در `ios/Runner/Info.plist` باید `NSAppTransportSecurity` را برای دامنه تست تنظیم کنید.

## 🎨 تم رنگی قابل تغییر (نکته کلیدی درخواستی)
تمام ظاهر اپ (دکمه‌ها، AppBar، نوار پایین، فیلدهای فرم، Chip ها و ...) از طریق `Theme.of(context).colorScheme` رنگ می‌گیرند — **هیچ رنگی به‌صورت مستقیم (hard-coded) در ویجت‌های صفحات نوشته نشده**. مدیریت تم در فایل زیر است:

```
lib/core/theme/app_theme_provider.dart
```

- `kAppThemeOptions`: لیست رنگ‌های آماده (آبی پیش‌فرض دقیقاً هم‌رنگ تصاویر مرجع، به‌علاوه نیلی/بنفش/فیروزه‌ای/سبز/نارنجی/قرمز/صورتی).
- کاربر از مسیر **حساب کاربری > تغییر تم رنگی** (یا آیکون 🎨 در صفحه اصلی) می‌تواند رنگ را عوض کند؛ انتخاب او در `SharedPreferences` ذخیره و در باز کردن بعدی اپ بازیابی می‌شود.
- برای افزودن یک رنگ جدید، فقط یک آیتم به `kAppThemeOptions` اضافه کنید — نیازی به تغییر هیچ صفحه‌ای نیست چون همه از `ColorScheme.fromSeed(seedColor: ...)` مشتق می‌شوند (پشتیبانی کامل از Material 3).
- حالت تیره (Dark Mode) نیز از همان صفحه قابل فعال‌سازی است.

## 📱 صفحات پیاده‌سازی‌شده (مطابق تصاویر مرجع)

| صفحه | توضیح |
|---|---|
| Splash | بررسی نشست کاربر و ورود به اپ |
| Home | بنر تبلیغاتی، دسته‌بندی‌ها (گرید آیکونی)، محصولات جدید |
| دسته‌بندی‌ها | لیست کامل دسته‌بندی‌ها |
| جستجو/لیست محصولات | نمایش Grid/List، فیلتر قیمت (RangeSlider)، مرتب‌سازی (Bottom Sheet)، Infinite Scroll |
| جزئیات محصول | گالری تصاویر، رتبه‌بندی، ویژگی‌های قابل انتخاب (رنگ/سایز و...)، توضیحات، مشخصات فنی، افزودن به سبد خرید با تعداد |
| سبد خرید | لیست اقلام با تغییر تعداد/حذف، جمع جزء، دکمه ادامه خرید |
| آدرس‌ها | لیست/افزودن/ویرایش آدرس با انتخاب کشور و استان (پویا از API) |
| ارسال و پرداخت | انتخاب روش ارسال و روش پرداخت |
| بررسی نهایی سفارش | خلاصه مبالغ (جمع جزء/ارسال/مالیات/تخفیف/مجموع) و ثبت سفارش |
| سفارش‌های من | لیست سفارش‌ها + جزئیات هر سفارش + لغو سفارش |
| حساب کاربری | پروفایل، سفارش‌ها، علاقه‌مندی‌ها، آدرس‌ها، تغییر رمز، لینک‌های سریع (درباره ما/تماس با ما/قوانین از CMS) |
| ورود/ثبت‌نام/فراموشی رمز | جریان کامل احراز هویت JWT |
| تنظیمات تم | تغییر رنگ اصلی اپ و حالت تیره |

**نکته طراحی مهم:** مرور اپ (خانه/دسته‌بندی/جستجو/جزئیات محصول) بدون ورود هم امکان‌پذیر است (Guest Browsing، دقیقاً مثل اکثر اپ‌های فروشگاهی)؛ ورود فقط هنگام افزودن به سبد خرید، مشاهده سبد/حساب کاربری یا تسویه‌حساب درخواست می‌شود.

## 🔗 معماری ارتباط با API
```
lib/core/network/api_client.dart   -> هسته Dio + افزودن خودکار Authorization header + تمدید خودکار Refresh Token روی خطای 401
lib/core/network/token_storage.dart -> ذخیره امن توکن‌ها (flutter_secure_storage: Keychain/Keystore)
lib/services/*.dart                 -> یک کلاس سرویس به‌ازای هر گروه از اندپوینت‌های پلاگین (Auth, Catalog, Cart, Checkout, Order, Customer, Shipping)
lib/providers/*.dart                -> AuthProvider و CartProvider (ChangeNotifier) برای وضعیت سراسری
```

هر پاسخ API با فرمت استاندارد پلاگین (`{ success, message, data, errors }`) به‌صورت خودکار در `ApiClient` پارس می‌شود؛ در صورت خطا، یک `ApiException` با پیام فارسی سرور پرتاب می‌شود که صفحات آن را در `SnackBar` نمایش می‌دهند.

## 🧩 نگاشت اندپوینت‌ها (`lib/core/constants/api_endpoints.dart`)
همه مسیرها دقیقاً مطابق کنترلرهای پلاگین `Nop.Plugin.Api` (فازهای ۱ تا ۶) تعریف شده‌اند: Auth، Customer، Catalog، ShoppingCart، Checkout، Order، Payment، Shipping، CMS/Blog/News (endpointها آماده‌اند، فقط UI اختصاصی برایشان ساخته نشده).

## 📥 محصولات دیجیتال (ویدئو، فایل صوتی، کتاب الکترونیک)

پشتیبانی کامل از محصولات دانلودی nopCommerce (`Product.IsDownload = true`) اضافه شده است:

| بخش | مسیر |
|---|---|
| سرویس ارتباط با API | `lib/services/download_service.dart` |
| مدل داده | `lib/models/download/downloadable_product.dart` |
| لیست محصولات دیجیتال خریداری‌شده | `lib/screens/downloads/downloadable_products_screen.dart` (از منوی «حساب کاربری» در دسترس است) |
| جزئیات + دانلود با نوار پیشرفت + پذیرش قرارداد استفاده | `lib/screens/downloads/digital_product_detail_screen.dart` |
| پخش‌کننده ویدئو (Chewie/video_player) | `lib/screens/downloads/video_player_screen.dart` |
| پخش‌کننده صدا (just_audio) با کنترل سرعت/جابجایی | `lib/screens/downloads/audio_player_screen.dart` |
| نمایش‌گر کتاب الکترونیک PDF (flutter_pdfview) | `lib/screens/downloads/ebook_viewer_screen.dart` |

### نحوه کار
1. فایل بر اساس `contentType`/پسوند در پلاگین (`Nop.Plugin.Api` فاز ۷) به یکی از انواع Video/Audio/Ebook/Archive/Other دسته‌بندی می‌شود.
2. اگر محصول نیازمند قرارداد استفاده باشد (`HasUserAgreement`)، متن قرارداد واقعی از سرور گرفته و در یک دیالوگ نمایش داده می‌شود؛ فقط بعد از پذیرش صریح کاربر، دکمه دانلود فعال می‌شود.
3. فایل با `Dio` (به همراه هدر Authorization و `onReceiveProgress`) به مسیر `ApplicationDocumentsDirectory/downloads/` دستگاه دانلود می‌شود (نه حافظه پابلیک، پس نیازی به Permission مخصوص فایل روی اندروید ۱۳+ نیست).
4. بسته به نوع رسانه، فایل محلی مستقیماً در پخش‌کننده مناسب باز می‌شود؛ برای فرمت‌های ناشناخته/فشرده از `open_filex` برای باز کردن با اپ پیش‌فرض سیستم استفاده می‌شود.
5. اگر فایل روی nopCommerce با `Download.UseDownloadUrl = true` روی یک آدرس خارجی میزبانی شده باشد، به‌جای دانلود، همان لینک در مرورگر خارجی باز می‌شود.

### ⚠️ پیکربندی اضافه لازم روی اندروید/iOS (بعد از `flutter create`)
- **Android**: پکیج `open_filex` به‌صورت خودکار یک `FileProvider` را merge می‌کند؛ نیازی به تنظیم دستی نیست، ولی روی اندروید ۱۳+ اگر بخواهید فایل نمونه یا فایل نهایی را در گالری/پلیر خارجی هم قابل مشاهده کنید، مجوزهای `READ_MEDIA_VIDEO` / `READ_MEDIA_AUDIO` را در `AndroidManifest.xml` اضافه کنید (پکیج `permission_handler` از قبل در `pubspec.yaml` هست).
- **iOS**: برای پخش ویدئو/صدا هیچ Permission خاصی لازم نیست چون فایل از حافظه داخلی اپ (Sandbox) پخش می‌شود. اگر بعداً Picture-in-Picture یا پخش پس‌زمینه صدا اضافه کردید، باید `UIBackgroundModes: audio` را به `Info.plist` اضافه کنید.
- محصولات دیجیتال چون داخل `AuthorizedApiController` هستند، لیست آن‌ها فقط برای کاربر لاگین‌شده قابل مشاهده است (مسیر: حساب کاربری > محصولات دیجیتال من).

## 🗺️ موارد آماده برای توسعه بعدی (در صورت نیاز)
- UI برای Blog / News / Forum / Vendor (اندپوینت‌ها در `api_endpoints.dart` و می‌توانید `services/` مشابه بسازید).
- صفحه پرداخت با WebView برای درگاه‌های Redirect-based (پکیج `webview_flutter` از قبل در `pubspec.yaml` اضافه شده).
- Push Notification (Firebase) برای اطلاع‌رسانی تغییر وضعیت سفارش.
- بومی‌سازی کامل با `flutter_localizations` (در حال حاضر همه متن‌ها فارسی static هستند).
- آیکون و Splash اختصاصی اپ (`flutter_launcher_icons`, `flutter_native_splash`).

## 📦 پکیج‌های اصلی استفاده‌شده
`dio` (شبکه)، `provider` (مدیریت وضعیت)، `flutter_secure_storage` (توکن)، `cached_network_image` (تصاویر)، `google_fonts` (فونت Vazirmatn برای فارسی)، `flutter_rating_bar`، `shared_preferences` (ذخیره تم).

## نصب PWA نسخه وب (اختیاری)
چون flutter create پوشه `web/` هم می‌سازد، همین اپ با `flutter run -d chrome` یا `flutter build web` بدون تغییر کد قابل اجرا در مرورگر هم هست.
