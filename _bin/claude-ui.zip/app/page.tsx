"use client";
import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import NewChat from "@/components/views/NewChat";
import Chats from "@/components/views/Chats";
import Projects from "@/components/views/Projects";
import Artifacts from "@/components/views/Artifacts";
import Design from "@/components/views/Design";
import SettingsModal from "@/components/SettingsModal";
import ChatView from "@/components/views/ChatView";


import { PanelLeft } from "lucide-react";
export default function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const [currentView, setCurrentView] = useState("new_chat");
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState("general");

  const renderView = () => {
    switch (currentView) {
      case "new_chat": return <NewChat setCurrentView={setCurrentView} />;
      case "chats": return <Chats />;
      case "projects": return <Projects />;
      case "artifacts": return <Artifacts />;
      case "design": return <Design />;
      case "chat_view": return <ChatView />;
      default: return <NewChat setCurrentView={setCurrentView} />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-white text-[#2C2C2C] font-sans overflow-hidden">
      <Sidebar 
        isOpen={isSidebarOpen} 
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        openSettings={(tab: string) => {
          setSettingsTab(tab || "general");
          setIsSettingsOpen(true);
        }} 
      />
      <main className="flex-1 flex flex-col h-full bg-white overflow-hidden border-l border-[#E5E5E5] relative">
        {!isSidebarOpen && (
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="absolute top-4 left-4 p-2 text-gray-500 hover:bg-[#FAF9F7] rounded-xl z-10"
            title="Open sidebar"
          >
            <PanelLeft size={20} strokeWidth={2} />
          </button>
        )}
        {renderView()}
      </main>
      {isSettingsOpen && (
        <SettingsModal 
          onClose={() => setIsSettingsOpen(false)} 
          activeTab={settingsTab}
          setActiveTab={setSettingsTab}
        />
      )}
    </div>
  );
}
