import { Plus, MessageSquare, Folder, Shapes, Code, Settings, Palette, Search, PanelLeft, Download, Globe, HelpCircle, ArrowUpCircle, Info, LogOut, ChevronUp } from "lucide-react";

import { useState } from "react";

export default function Sidebar({ currentView, setCurrentView, openSettings, isOpen, toggleSidebar }: any) {
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const navItems = [
    { id: "chats", label: "Chats", icon: MessageSquare },
    { id: "projects", label: "Projects", icon: Folder },
    { id: "artifacts", label: "Artifacts", icon: Shapes },
    { id: "code", label: "Code", icon: Code, badge: "Upgrade" },
    { id: "customize", label: "Customize", icon: Settings, action: () => openSettings("skills") },
  ];

  const recentChats = [
    { title: "سلام و احوالپرسی", time: "4 hours ago" },
    { title: "سلام", time: "yesterday" },
    { title: "نصب Skill از GitHub", time: "Aug 10" },
    { title: "استخراج فایل و بررسی اسناد پروژه", time: "Aug 6" },
    { title: "بررسی اطلاعات پروژه و راهنما", time: "Jul 29" },
  ];

  return (
    <div className={`h-full flex flex-col bg-white text-[14px] transition-all duration-300 overflow-hidden shrink-0 ${isOpen ? "w-[280px]" : "w-0"}`}>
      <div className="w-[280px] h-full flex flex-col">
      {/* Top Header */}
      <div className="flex items-center justify-between p-4 pb-2">
        <h1 className="font-serif text-[22px] font-medium tracking-tight">Claude</h1>
        <div className="flex gap-1 text-gray-500">
          <button className="p-1.5 hover:bg-[#EFECE5] rounded-md"><Search size={18} /></button>
          <button onClick={toggleSidebar} className="p-1.5 hover:bg-[#EFECE5] rounded-md"><PanelLeft size={18} /></button>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-3 py-2 flex flex-col gap-0.5">
        <button 
          onClick={() => setCurrentView("new_chat")}
          className="flex items-center gap-2 px-2 py-1.5 hover:bg-[#EFECE5] rounded-lg mb-4 mt-2"
        >
          <Plus size={16} className="text-gray-600" />
          <span className="font-medium text-[14.5px]">New chat</span>
        </button>

        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => item.action ? item.action() : setCurrentView(item.id)}
            className={`flex items-center justify-between px-2 py-1.5 rounded-lg group ${currentView === item.id && !item.action ? 'bg-[#EFECE5] font-medium' : 'hover:bg-[#EFECE5]'}`}
          >
            <div className="flex items-center gap-2.5">
              <item.icon size={16} className={currentView === item.id ? 'text-black' : 'text-gray-500'} strokeWidth={2} />
              <span className={currentView === item.id ? 'text-black' : 'text-gray-700'}>{item.label}</span>
            </div>
            {item.badge && (
              <span className="text-[10px] uppercase tracking-wider font-semibold text-gray-500 border border-gray-300 px-1.5 rounded-full bg-white">
                {item.badge}
              </span>
            )}
          </button>
        ))}

        <div className="mt-6 mb-1 px-2 text-[11px] font-medium text-gray-400 uppercase tracking-wider">Products</div>
        <button 
          onClick={() => setCurrentView("design")}
          className={`flex items-center gap-2.5 px-2 py-1.5 rounded-lg ${currentView === 'design' ? 'bg-[#EFECE5] font-medium text-black' : 'hover:bg-[#EFECE5] text-gray-700'}`}
        >
          <Palette size={16} className={currentView === 'design' ? 'text-black' : 'text-gray-500'} strokeWidth={2} />
          <span>Design</span>
        </button>

        <div className="mt-6 mb-1 flex items-center justify-between px-2 text-[11px] font-medium text-gray-400 uppercase tracking-wider">
          <span>Recents</span>
          <svg className="cursor-pointer text-gray-400 hover:text-gray-600" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 16l-4 4-4-4"/><path d="M7 20V4"/><path d="M13 8l4-4 4 4"/><path d="M17 4v16"/></svg>
        </div>
        
        {recentChats.map((chat, i) => (
          <button key={i} className="flex items-center px-2 py-1.5 hover:bg-[#EFECE5] rounded-lg text-left truncate w-full text-gray-700 text-[13.5px]">
            <span className="truncate">{chat.title}</span>
          </button>
        ))}
      </div>

      {/* User Profile */}
      <div className="mt-auto px-3 pb-3 pt-1 relative z-50">
        <div className="flex items-center gap-1 w-full border-t border-gray-100 pt-2">
          <button 
            onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
            className="flex-1 flex items-center justify-between hover:bg-[#EFECE5] p-2 rounded-xl transition-colors text-left min-w-0"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-7 h-7 rounded-full bg-[#E5E0D8] flex items-center justify-center font-medium text-gray-700 text-xs shrink-0">
                P
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-medium text-[13.5px] leading-tight text-gray-800 truncate">payman</span>
                <span className="text-[11.5px] text-gray-500 leading-tight truncate mt-0.5">Free plan</span>
              </div>
            </div>
            <ChevronUp size={16} className="text-gray-400 shrink-0 ml-1" />
          </button>
          <button className="p-2 text-gray-600 hover:bg-[#EFECE5] rounded-xl transition-colors shrink-0">
            <Download size={16} />
          </button>
        </div>

        {/* Profile Menu Popup */}
        {isProfileMenuOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setIsProfileMenuOpen(false)}></div>
            <div className="absolute bottom-[calc(100%-10px)] left-3 mb-2 w-[240px] bg-white border border-[#E5E5E5] rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] py-1.5 z-50 text-[14px] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-100">
              <div className="px-3.5 py-2.5 text-gray-500 text-[13px] truncate">
                pshafayan@gmail.com
              </div>
              <button onClick={() => { setIsProfileMenuOpen(false); openSettings("general"); }} className="w-full text-left px-3.5 py-1.5 hover:bg-[#F5F5F5] flex items-center justify-between text-gray-700">
                <div className="flex items-center gap-3"><Settings size={16} className="text-gray-500" /> Settings</div>
                <span className="text-[11px] text-gray-400 font-sans tracking-wide">Ctrl+⇧+,</span>
              </button>
              <button className="w-full text-left px-3.5 py-1.5 hover:bg-[#F5F5F5] flex items-center justify-between text-gray-700">
                <div className="flex items-center gap-3"><Globe size={16} className="text-gray-500" /> Language</div>
                <span className="text-gray-400 text-lg leading-none">&gt;</span>
              </button>
              <button className="w-full text-left px-3.5 py-1.5 hover:bg-[#F5F5F5] flex items-center text-gray-700">
                <div className="flex items-center gap-3"><HelpCircle size={16} className="text-gray-500" /> Get help</div>
              </button>
              
              <div className="h-px bg-gray-100 my-1 mx-3"></div>
              
              <button className="w-full text-left px-3.5 py-1.5 hover:bg-[#F5F5F5] flex items-center text-gray-700">
                <div className="flex items-center gap-3"><ArrowUpCircle size={16} className="text-gray-500" /> Upgrade plan</div>
              </button>
              <button className="w-full text-left px-3.5 py-1.5 hover:bg-[#F5F5F5] flex items-center text-gray-700">
                <div className="flex items-center gap-3"><Download size={16} className="text-gray-500" /> Get apps and extensions</div>
              </button>
              <button className="w-full text-left px-3.5 py-1.5 hover:bg-[#F5F5F5] flex items-center justify-between text-gray-700">
                <div className="flex items-center gap-3"><Info size={16} className="text-gray-500" /> Learn more</div>
                <span className="text-gray-400 text-lg leading-none">&gt;</span>
              </button>
              
              <div className="h-px bg-gray-100 my-1 mx-3"></div>
              
              <button className="w-full text-left px-3.5 py-1.5 hover:bg-[#F5F5F5] flex items-center text-gray-700">
                <div className="flex items-center gap-3"><LogOut size={16} className="text-gray-500" /> Log out</div>
              </button>
            </div>
          </>
        )}
      </div>
    </div>
    </div>
  );
}
