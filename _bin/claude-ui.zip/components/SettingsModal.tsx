import { useState } from "react";
import { 
  X, Search, Settings, User, Shield, CreditCard, 
  Layers, MoonStar, Clock, Code, FileCode, Blocks, Puzzle, RotateCcw 
} from "lucide-react";


function ToggleSwitch({ defaultChecked = true }) {
  const [checked, setChecked] = useState(defaultChecked);
  return (
    <div 
      onClick={() => setChecked(!checked)}
      className={`w-11 h-6 rounded-full relative flex items-center shrink-0 cursor-pointer mt-1 transition-colors ${checked ? "bg-[#2563EB]" : "bg-[#E5E5E5] border border-gray-200"}`}
    >
      <div className={`w-4 h-4 bg-white rounded-full absolute shadow-sm transition-all ${checked ? "right-1" : "left-1"}`}></div>
    </div>
  );
}

export default function SettingsModal({ onClose, activeTab, setActiveTab }: any) {
  
  const settingsCategories = [
    { id: "general", label: "General", icon: Settings },
    { id: "account", label: "Account", icon: User },
    { id: "privacy", label: "Privacy", icon: Shield },
    { id: "billing", label: "Billing", icon: CreditCard },
    { id: "capabilities", label: "Capabilities", icon: Layers },
    { id: "reflect", label: "Reflect", icon: MoonStar },
    { id: "time", label: "Time and focus", icon: Clock },
    { id: "code", label: "Claude Code", icon: Code },
  ];

  const customizeCategories = [
    { id: "skills", label: "Skills", icon: FileCode },
    { id: "connectors", label: "Connectors", icon: Blocks },
    { id: "plugins", label: "Plugins", icon: Puzzle },
    { id: "memory", label: "Memory", icon: RotateCcw },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case "general":
        return (
          <div className="max-w-[640px] text-[15px]">
            <h2 className="font-semibold text-[17px] mb-6 text-gray-900">Profile</h2>
            
            <div className="flex items-center justify-between py-4 border-b border-gray-100">
              <span className="text-gray-700">Avatar</span>
              <div className="w-8 h-8 rounded-full bg-[#E5E0D8] flex items-center justify-center font-medium text-gray-700 text-sm">P</div>
            </div>
            
            <div className="flex items-center justify-between py-4 border-b border-gray-100">
              <span className="text-gray-700">Full name</span>
              <input type="text" defaultValue="payman" className="border border-gray-200 rounded-lg px-3 py-1.5 w-[280px] text-[14px] focus:outline-none focus:ring-1 focus:ring-gray-300 transition-shadow" />
            </div>
            
            <div className="flex items-center justify-between py-4 border-b border-gray-100">
              <span className="text-gray-700">What should Claude call you?</span>
              <input type="text" defaultValue="payman" className="border border-gray-200 rounded-lg px-3 py-1.5 w-[280px] text-[14px] focus:outline-none focus:ring-1 focus:ring-gray-300 transition-shadow" />
            </div>

            <div className="flex items-center justify-between py-4 border-b border-gray-100">
              <span className="text-gray-700">What best describes your work?</span>
              <button className="border border-gray-200 rounded-lg px-3 py-1.5 w-[280px] text-[14px] text-left flex justify-between items-center bg-white hover:bg-gray-50 transition-colors">
                Other <span className="text-[10px] text-gray-500">▼</span>
              </button>
            </div>

            <div className="py-6">
              <h3 className="font-medium text-gray-800 mb-1">Instructions for Claude</h3>
              <p className="text-[14px] text-gray-500 mb-3">
                Claude will keep these in mind across chats and Cowork within <a href="#" className="underline text-gray-500 hover:text-gray-800">Anthropic's guidelines</a>. <a href="#" className="underline text-gray-500 hover:text-gray-800">Learn more</a>
              </p>
              <textarea 
                placeholder="e.g. ask clarifying questions before giving detailed answers"
                className="w-full border border-gray-200 rounded-xl p-3 h-28 resize-none text-[14px] focus:outline-none focus:ring-[3px] focus:ring-[#EFECE5] focus:border-transparent transition-all"
              ></textarea>
            </div>
            
            <h2 className="font-semibold text-[17px] mt-2 mb-4 text-gray-900">Preferences</h2>
          </div>
        );
      case "account":
        return (
          <div className="max-w-[640px] text-[15px]">
            <h2 className="font-semibold text-[17px] mb-6 text-gray-900">Account</h2>
            
            <div className="flex items-center justify-between py-4 border-b border-gray-100">
              <span className="text-gray-700">Log out of all devices</span>
              <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] transition-colors shadow-sm text-gray-800">Log out</button>
            </div>
            
            <div className="flex items-center justify-between py-4 border-b border-gray-100">
              <span className="text-gray-700">Delete your account</span>
              <button className="px-4 py-1.5 bg-black text-white rounded-xl text-[14px] font-medium hover:bg-gray-800 transition-colors shadow-sm">Delete account</button>
            </div>
            
            <div className="flex items-center justify-between py-4 border-b border-gray-100">
              <span className="text-gray-700">Organization ID</span>
              <code className="bg-gray-50 px-2 py-1 rounded-md text-[13px] text-gray-500 font-mono tracking-tight">09fbf550-0a67-4483-b3f7-3ef4fdfc8f7d</code>
            </div>

            <h3 className="font-semibold text-gray-800 mt-10 mb-1.5">Trusted devices</h3>
            <p className="text-[14px] text-gray-500 mb-6">Devices that can control your local machine through remote sessions.</p>
            
            <div className="flex items-center justify-between text-[13px] font-medium text-gray-500 mb-2 px-1">
              <span>Device</span>
              <span>Added</span>
            </div>
            <div className="text-center py-12 text-gray-500 text-[14px]">
              No trusted devices.
            </div>
          </div>
        );
      case "privacy":
        return (
          <div className="max-w-[640px] text-[15px]">
            <h2 className="font-semibold text-[17px] mb-4 text-gray-900">Privacy</h2>
            <p className="text-gray-600 mb-8 leading-relaxed text-[15px]">
              Anthropic believes in transparent data practices. Learn how your information is protected when using Anthropic products, and visit our <a href="#" className="underline text-gray-600 hover:text-gray-900">Privacy Center</a> and <a href="#" className="underline text-gray-600 hover:text-gray-900">Privacy Policy</a> for more details.
            </p>
            
            <div className="flex justify-between py-4 border-t border-gray-100 cursor-pointer hover:bg-[#FAF9F7] -mx-4 px-4 rounded-xl transition-colors">
              <span className="text-gray-800">How we protect your data</span>
              <span className="text-gray-400">&gt;</span>
            </div>
            <div className="flex justify-between py-4 border-t border-gray-100 cursor-pointer hover:bg-[#FAF9F7] -mx-4 px-4 rounded-xl transition-colors">
              <span className="text-gray-800">How we use your data</span>
              <span className="text-gray-400">&gt;</span>
            </div>

            <h3 className="font-semibold text-gray-800 mt-10 mb-4">Preferences</h3>
            
            <div className="flex items-start justify-between py-5 border-t border-gray-100">
              <div className="max-w-lg">
                <div className="text-gray-800 font-medium mb-1">Location metadata</div>
                <div className="text-[14px] text-gray-500">Allow Claude to use coarse location metadata (city/region) to improve product experiences. <a href="#" className="underline text-gray-500 hover:text-gray-800">Learn more</a>.</div>
              </div>
              <ToggleSwitch />
            </div>
            
            <div className="flex items-start justify-between py-5 border-t border-gray-100">
              <div className="max-w-lg">
                <div className="text-gray-800 font-medium mb-1">Help improve our AI models</div>
                <div className="text-[14px] text-gray-500">Allow the use of your chats and coding sessions to train and improve Anthropic AI models. <a href="#" className="underline text-gray-500 hover:text-gray-800">Learn more</a>.</div>
              </div>
              <ToggleSwitch />
            </div>

            <h3 className="font-semibold text-gray-800 mt-10 mb-4">Your data</h3>
            
            <div className="flex items-center justify-between py-4 border-t border-gray-100">
              <span className="text-gray-800">Export data</span>
              <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] transition-colors shadow-sm text-gray-800">Export data</button>
            </div>
            <div className="flex items-center justify-between py-4 border-t border-gray-100">
              <span className="text-gray-800">Shared chats</span>
              <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] transition-colors shadow-sm text-gray-800">Manage</button>
            </div>
            <div className="flex items-center justify-between py-4 border-t border-gray-100">
              <span className="text-gray-800">Shared artifacts</span>
              <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] transition-colors shadow-sm text-gray-800">Manage</button>
            </div>
            <div className="flex items-center justify-between py-4 border-t border-gray-100">
              <span className="text-gray-800">Uploaded files</span>
              <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] transition-colors shadow-sm text-gray-800">Manage</button>
            </div>
            <div className="flex items-center justify-between py-4 border-t border-gray-100">
              <span className="text-gray-800">Memory preferences</span>
              <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] transition-colors shadow-sm text-gray-800">Manage</button>
            </div>
          </div>
        );
      case "capabilities":
        return (
          <div className="max-w-[640px] text-[15px]">
             <h2 className="font-semibold text-[17px] mb-6 text-gray-900">General</h2>
             
             <div className="flex justify-between py-5 border-b border-gray-100">
                <div className="max-w-md">
                  <div className="text-gray-800 font-medium mb-1">Tool access mode</div>
                  <div className="text-[14px] text-gray-500">Controls how connector tools are loaded in new conversations.</div>
                </div>
                <div className="text-[14px] text-gray-700 flex items-center cursor-pointer hover:bg-gray-50 px-3 py-1.5 rounded-lg -mr-3">
                  Load tools when needed <span className="ml-2 text-[10px] text-gray-400">▼</span>
                </div>
             </div>

             <div className="flex items-start justify-between py-5 border-b border-gray-100">
              <div className="max-w-lg">
                <div className="text-gray-800 font-medium mb-1">Connector search</div>
                <div className="text-[14px] text-gray-500">Let Claude search the connector directory and surface ones relevant to your conversation.</div>
              </div>
              <ToggleSwitch />
            </div>

            <div className="flex items-start justify-between py-5 border-b border-gray-100">
              <div className="max-w-lg">
                <div className="text-gray-800 font-medium mb-1">Switch models when a message is flagged</div>
                <div className="text-[14px] text-gray-500">When safeguards flag a message, automatically switch to a different model to keep chatting. When off, your chat will pause instead.</div>
              </div>
              <ToggleSwitch />
            </div>

            <h2 className="font-semibold text-[17px] mt-10 mb-4 text-gray-900">Visuals</h2>
            
            <div className="flex items-start justify-between py-5 border-b border-gray-100">
              <div className="max-w-lg">
                <div className="text-gray-800 font-medium mb-1">Artifacts</div>
                <div className="text-[14px] text-gray-500">Generate code, documents, and designs in a dedicated window alongside your conversation.</div>
              </div>
              <ToggleSwitch />
            </div>
            
            <div className="flex items-start justify-between py-5 border-b border-gray-100">
              <div className="max-w-lg">
                <div className="text-gray-800 font-medium mb-1">AI-powered artifacts</div>
                <div className="text-[14px] text-gray-500">Build apps and interactive documents that use Claude inside the artifact.</div>
              </div>
              <ToggleSwitch defaultChecked={false} />
            </div>

            <div className="flex items-start justify-between py-5 border-b border-gray-100">
              <div className="max-w-lg">
                <div className="text-gray-800 font-medium mb-1">Inline visualizations</div>
                <div className="text-[14px] text-gray-500">Allow Claude to generate interactive visualizations, charts, and diagrams directly in the conversation.</div>
              </div>
              <ToggleSwitch />
            </div>

            <h2 className="font-semibold text-[17px] mt-10 mb-4 text-gray-900">Code execution and file creation</h2>
            <div className="flex items-start justify-between py-5 border-b border-gray-100">
              <div className="max-w-lg">
                <div className="text-gray-800 font-medium mb-1">Code execution and file creation</div>
                <div className="text-[14px] text-gray-500">Claude can execute code and create and edit docs, spreadsheets, presentations, PDFs, and data reports. Required for skills.</div>
              </div>
              <ToggleSwitch />
            </div>
          </div>
        );
      case "skills":
        return (
          <div className="max-w-3xl text-[15px]">
            <div className="flex items-center justify-between mb-8">
              <h2 className="font-semibold text-[17px] text-gray-900">Skills</h2>
              <div className="flex items-center gap-2">
                <button className="p-2 border border-transparent hover:bg-[#FAF9F7] rounded-xl transition-colors">
                  <Search size={18} className="text-gray-600" />
                </button>
                <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] transition-colors shadow-sm text-gray-800">Browse</button>
                <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] flex items-center gap-2 transition-colors shadow-sm text-gray-800">
                  Add <span className="text-[10px] text-gray-400">▼</span>
                </button>
              </div>
            </div>
            
            <div className="flex text-[13px] text-gray-500 font-medium border-b border-gray-200 pb-2 mb-2 px-3">
              <div className="flex-1">Skill</div>
              <div className="w-32">Last updated</div>
              <div className="w-32">Author</div>
            </div>
            
            <div className="flex items-center hover:bg-[#FAF9F7] px-3 py-2.5 rounded-xl -mx-3 transition-colors cursor-pointer">
              <div className="flex-1 font-medium text-gray-800">morning</div>
              <div className="w-32 text-[14px] text-gray-500">8/14/26</div>
              <div className="w-32 text-[14px] text-gray-500">Anthropic</div>
            </div>
            <div className="flex items-center hover:bg-[#FAF9F7] px-3 py-2.5 rounded-xl -mx-3 transition-colors cursor-pointer">
              <div className="flex-1 font-medium text-gray-800">skill-creator</div>
              <div className="w-32 text-[14px] text-gray-500">8/14/26</div>
              <div className="w-32 text-[14px] text-gray-500">Anthropic</div>
            </div>
          </div>
        );
      case "connectors":
        return (
          <div className="max-w-3xl text-[15px]">
             <div className="flex items-center justify-between mb-8">
              <h2 className="font-semibold text-[17px] text-gray-900">Connectors</h2>
              <div className="flex items-center gap-2">
                <button className="p-2 border border-transparent hover:bg-[#FAF9F7] rounded-xl transition-colors">
                  <Search size={18} className="text-gray-600" />
                </button>
                <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] flex items-center gap-2 transition-colors shadow-sm text-gray-800">
                  Add <span className="text-[10px] text-gray-400">▼</span>
                </button>
              </div>
            </div>
            
            <h3 className="text-[13px] text-gray-500 mb-4 font-medium">Popular</h3>
            <div className="flex gap-4 mb-10">
               <div className="border border-[#E5E5E5] rounded-2xl p-4 flex items-center gap-3 bg-white hover:shadow-md transition-all shadow-sm w-44 justify-center flex-col text-center group cursor-pointer relative">
                 <div className="w-10 h-10 flex items-center justify-center font-bold text-red-500 text-2xl">M</div>
                 <span className="font-medium text-[14px]">Gmail</span>
                 <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-lg text-[13px] font-medium hover:bg-[#FAF9F7] mt-1 w-full transition-colors text-gray-800">Connect</button>
               </div>
               <div className="border border-[#E5E5E5] rounded-2xl p-4 flex items-center gap-3 bg-white hover:shadow-md transition-all shadow-sm w-44 justify-center flex-col text-center group cursor-pointer relative">
                 <div className="w-10 h-10 flex items-center justify-center">
                    <svg viewBox="0 0 24 24" className="w-8 h-8"><path fill="#FFC107" d="M8 18h8l4-7H12z"/><path fill="#1976D2" d="M22 11l-4-7H10l4 7z"/><path fill="#4CAF50" d="M12 11L8 4 4 11l4 7z"/></svg>
                 </div>
                 <span className="font-medium text-[14px]">Google Drive</span>
                 <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-lg text-[13px] font-medium hover:bg-[#FAF9F7] mt-1 w-full transition-colors text-gray-800">Connect</button>
               </div>
               <div className="border border-[#E5E5E5] rounded-2xl p-4 flex items-center gap-3 bg-white hover:shadow-md transition-all shadow-sm w-44 justify-center flex-col text-center group cursor-pointer relative">
                 <div className="w-10 h-10 flex items-center justify-center text-3xl font-light text-[#E01E5A]">#</div>
                 <span className="font-medium text-[14px]">Slack</span>
                 <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-lg text-[13px] font-medium hover:bg-[#FAF9F7] mt-1 w-full transition-colors text-gray-800">Connect</button>
               </div>
            </div>

            <div className="flex gap-5 border-b border-gray-200 mb-4 px-1">
              <button className="pb-3 border-b-2 border-black font-medium text-[14px] text-gray-900">All</button>
              <button className="pb-3 text-gray-500 hover:text-gray-800 text-[14px] transition-colors">Connected</button>
              <button className="pb-3 text-gray-500 hover:text-gray-800 text-[14px] transition-colors">Not connected</button>
            </div>

            <div className="flex text-[13px] text-gray-500 font-medium mb-2 px-3 pt-2">
              <div className="flex-1">Connector</div>
              <div className="w-32">Type</div>
              <div className="w-28 text-center">Status</div>
            </div>
            
            <div className="flex items-center hover:bg-[#FAF9F7] px-3 py-3 rounded-xl -mx-3 transition-colors cursor-pointer border border-transparent hover:border-gray-100">
              <div className="flex-1 font-medium text-gray-800 flex items-center gap-3">
                 <div className="w-6 h-6 bg-gray-900 rounded-full text-white flex items-center justify-center text-[10px] font-bold">GH</div>
                 GitHub Integration
              </div>
              <div className="w-32 text-[14px] text-gray-500">Web</div>
              <div className="w-28 text-right">
                <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-lg text-[13px] font-medium hover:bg-white shadow-sm transition-colors text-gray-800 bg-[#FAF9F7]">Connect</button>
              </div>
            </div>
          </div>
        );
      case "plugins":
        return (
           <div className="max-w-3xl text-[15px] h-full flex flex-col">
             <div className="flex items-center justify-between mb-16">
              <h2 className="font-semibold text-[17px] text-gray-900">Plugins</h2>
              <div className="flex items-center gap-2">
                <button className="p-2 border border-transparent hover:bg-[#FAF9F7] rounded-xl transition-colors">
                  <Search size={18} className="text-gray-600" />
                </button>
                <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] transition-colors shadow-sm text-gray-800">Browse</button>
                <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] flex items-center gap-2 transition-colors shadow-sm text-gray-800">
                  Add <span className="text-[10px] text-gray-400">▼</span>
                </button>
              </div>
            </div>
            
            <div className="flex-1 flex flex-col items-center justify-center -mt-20">
               <div className="mb-6 opacity-80">
                 <svg width="64" height="64" viewBox="0 0 100 100" fill="none" stroke="#2C2C2C" strokeWidth="3">
                    <path d="M40 20 H60 V40 H80 V60 H60 V80 H40 V60 H20 V40 H40 Z" strokeLinejoin="round" />
                 </svg>
               </div>
               <p className="text-gray-500 mb-6 text-[15px]">Give Claude role-level expertise with plugins</p>
               <button className="px-5 py-2 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] shadow-sm transition-colors text-gray-800">Browse plugins</button>
            </div>
           </div>
        );
      case "memory":
        return (
          <div className="max-w-[640px] text-[15px]">
            <h2 className="font-semibold text-[17px] mb-6 text-gray-900">Memory</h2>
            
            <div className="flex items-start justify-between py-5 border-b border-gray-100">
              <div className="max-w-lg">
                <div className="text-gray-800 font-medium mb-1">Generate memory from chats</div>
                <div className="text-[14px] text-gray-500">Allow Claude to generate memory from your chats.</div>
              </div>
              <ToggleSwitch />
            </div>
            
            <div className="flex items-start justify-between py-6 border-b border-gray-100">
              <div className="max-w-[450px]">
                <div className="text-gray-800 font-medium mb-1">Import memory from other AI providers</div>
                <div className="text-[14px] text-gray-500">Bring relevant context and data from another AI provider to Claude. We&apos;ll provide a prompt you can use to fetch the memory from your other account. <a href="#" className="underline text-gray-500 hover:text-gray-800">Learn more</a></div>
              </div>
              <button className="px-4 py-1.5 border border-[#E5E5E5] rounded-xl text-[14px] font-medium hover:bg-[#FAF9F7] mt-1 whitespace-nowrap shadow-sm text-gray-800 transition-colors">Start import</button>
            </div>

            <h3 className="font-semibold text-gray-800 mt-10 mb-4">Areas</h3>
            
            <div className="flex items-center justify-between py-4 border-t border-gray-100 hover:bg-[#FAF9F7] -mx-4 px-4 rounded-xl cursor-pointer group transition-colors">
               <div className="flex gap-16 items-center">
                 <div className="w-40 font-medium text-gray-800 text-[14.5px]">Gamenet Project</div>
                 <div className="text-gray-500 text-[14px] truncate max-w-xs">User's website + app project for...</div>
               </div>
               <div className="text-[13px] text-gray-400 flex items-center gap-4">
                 Updated Jul 16
                 <span className="opacity-0 group-hover:opacity-100 text-gray-400 transition-opacity">&gt;</span>
               </div>
            </div>
          </div>
        );
      default:
        return <div>Select a setting</div>;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center font-sans p-4">
      <div className="bg-white w-[960px] max-w-full h-[90vh] max-h-[750px] rounded-3xl shadow-2xl flex relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Settings Sidebar */}
        <div className="w-[260px] bg-[#FAF9F7] flex flex-col pt-3 pb-3 px-3.5 border-r border-[#E5E5E5] shrink-0">
          <div className="relative mb-6 mt-2">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" strokeWidth={2.5} />
            <input 
              type="text" 
              placeholder="Search" 
              className="w-full bg-white border border-[#E5E5E5] rounded-[10px] py-1.5 pl-9 pr-3 text-[14px] focus:outline-none focus:ring-[3px] focus:ring-[#EFECE5] focus:border-transparent transition-all shadow-sm"
            />
          </div>

          <div className="text-[11.5px] font-medium text-gray-400 mb-2.5 px-2 uppercase tracking-wider">Settings</div>
          <div className="flex flex-col gap-0.5 mb-4">
            {settingsCategories.map(cat => (
              <button 
                key={cat.id} 
                onClick={() => setActiveTab(cat.id)}
                className={`flex items-center gap-3 px-3 py-1.5 rounded-xl text-[14px] text-left transition-colors ${activeTab === cat.id ? 'bg-[#EFECE5] font-medium text-black' : 'text-gray-700 hover:bg-[#EFECE5]'}`}
              >
                <cat.icon size={16} className={activeTab === cat.id ? "text-gray-900" : "text-gray-500"} strokeWidth={2} />
                {cat.label}
              </button>
            ))}
          </div>

          <div className="text-[11.5px] font-medium text-gray-400 mb-2.5 px-2 uppercase tracking-wider">Customize</div>
          <div className="flex flex-col gap-0.5">
            {customizeCategories.map(cat => (
              <button 
                key={cat.id} 
                onClick={() => setActiveTab(cat.id)}
                className={`flex items-center gap-3 px-3 py-1.5 rounded-xl text-[14px] text-left transition-colors ${activeTab === cat.id ? 'bg-[#EFECE5] font-medium text-black' : 'text-gray-700 hover:bg-[#EFECE5]'}`}
              >
                <cat.icon size={16} className={activeTab === cat.id ? "text-gray-900" : "text-gray-500"} strokeWidth={2} />
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Settings Content Area */}
        <div className="flex-1 bg-white relative flex flex-col">
          <div className="absolute top-5 right-5 z-10">
            <button onClick={onClose} className="p-1.5 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors">
              <X size={20} strokeWidth={2.5} />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto px-12 py-10">
            {renderContent()}
          </div>
        </div>

      </div>
    </div>
  );
}
