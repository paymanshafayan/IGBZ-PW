export default function Design() {
  return (
    <div className="flex-1 bg-white overflow-y-auto px-8 py-16 flex flex-col items-center justify-center">
       <div className="w-full max-w-[800px] bg-[#0A0A0B] rounded-[32px] overflow-hidden aspect-[2.1/1] relative flex items-center justify-center mb-14 shadow-md">
         {/* Simple dark patterned background representing the globe graphic */}
         <div className="absolute inset-0 opacity-[0.15]" style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, #444 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
         
         <div className="bg-white px-8 py-5 rounded-2xl flex items-center gap-3 shadow-xl z-10 mx-auto">
           <span className="text-[#D97757] text-[32px] leading-none mt-1">✺</span>
           <span className="font-serif text-[28px] italic font-medium tracking-tight pr-1">Designing.</span>
         </div>
       </div>

       <h1 className="font-serif text-[36px] font-medium text-[#2C2C2C] mb-4 tracking-tight">Design with Claude</h1>
       <p className="text-[#6B6B6B] text-center max-w-lg mb-8 text-[16px] leading-relaxed">
         Build interactive prototypes, wireframes, slides, or anything else you want to make.<br />
         Start from a file you already have or just describe what you need.
       </p>
       <button className="px-6 py-3 bg-black text-white rounded-xl font-medium text-[15px] hover:bg-gray-800 transition-colors shadow-sm">
         Get Claude Design
       </button>
    </div>
  );
}
