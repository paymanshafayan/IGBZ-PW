import { Plus, Mic, AudioLines, Paperclip, Camera, FolderPlus, Blocks, Puzzle, Globe, FileCode, ArrowUp } from "lucide-react";
import { useState } from "react";

export default function ChatView() {
  const [inputValue, setInputValue] = useState("سلام");
  const [isAttachMenuOpen, setIsAttachMenuOpen] = useState(false);
  const [isMicHovered, setIsMicHovered] = useState(false);
  const [isMicActive, setIsMicActive] = useState(false);

  return (
    <div className="flex-1 flex flex-col h-full bg-white relative">
      <div className="flex-1 overflow-y-auto w-full flex flex-col items-center">
        <div className="w-full max-w-[800px] px-4 py-8 flex flex-col gap-6">
          
          {/* User Message 1 */}
          <div className="self-end max-w-[80%] bg-[#F3F2EF] px-5 py-3.5 rounded-2xl text-[15.5px] leading-relaxed text-[#2C2C2C]" dir="rtl">
            سلام خوبی
          </div>
          
          {/* Claude Message 1 */}
          <div className="self-start max-w-[85%] flex gap-4 w-full" dir="rtl">
            <div className="w-7 h-7 shrink-0 flex items-center justify-center mt-0.5">
              <span className="text-[#D97757] text-[28px] leading-none">✺</span>
            </div>
            <div className="flex-1 text-[16px] leading-relaxed text-[#2C2C2C] pt-0.5">
              سلام! ممنون، خوبم 🙂 چطوری؟ کاری هست که بتونم کمکت کنم؟
            </div>
          </div>
          
          {/* User Message 2 */}
          <div className="self-end max-w-[80%] bg-[#F3F2EF] px-5 py-3.5 rounded-2xl text-[15.5px] leading-relaxed text-[#2C2C2C] mt-4" dir="rtl">
            تو میتونی از روی عکس ویدئو بسازی
          </div>
          
          {/* Claude Message 2 */}
          <div className="self-start max-w-[85%] flex gap-4 w-full" dir="rtl">
            <div className="w-7 h-7 shrink-0 flex items-center justify-center mt-0.5">
              <span className="text-[#D97757] text-[28px] leading-none">✺</span>
            </div>
            <div className="flex-1 text-[16px] leading-relaxed text-[#2C2C2C] pt-0.5">
              <p className="mb-4">نه، متأسفانه من نمی‌تونم مستقیماً از روی عکس ویدئو بسازم. من یک مدل زبانی هستم و قابلیت تولید ویدئو یا انیمیشن ندارم.</p>
              <p className="mb-2">اگه دنبال این هستی که از یک عکس ویدئو بسازی، چند تا راه‌حل دیگه هست که می‌تونم پیشنهاد بدم:</p>
              <ul className="list-disc pr-6 mb-4 flex flex-col gap-2">
                <li><strong>ابزارهای آنلاین AI مثل Kling, Runway, Pika Labs یا Luma Dream Machine:</strong> این ابزارها دقیقاً تخصصشون تبدیل عکس به ویدئوئه (image-to-video).</li>
                <li><strong>کدنویسی انیمیشن:</strong> اگه پروژه‌ات مربوط به وب هست و می‌خوای مثلاً یک ویدئوی تبلیغاتی یا موشن گرافیک بسازی، می‌تونم کمکت کنم اسکریپت، ایده، یا حتی کد براش (مثلاً یک انیمیشن با HTML/CSS/JS) بنویسم.</li>
              </ul>
              <p>می‌خوای دقیق‌تر بگی برای چه هدفی این ویدئو رو می‌خوای بسازی؟</p>
            </div>
          </div>
          
          {/* User Message 3 */}
          <div className="self-end max-w-[80%] bg-[#F3F2EF] px-5 py-3.5 rounded-2xl text-[15.5px] leading-relaxed text-[#2C2C2C] mt-4" dir="rtl">
            در باره pika بیشتر توضیح بده
          </div>
          
          {/* Claude Message 3 (Thinking/Triangulating) */}
          <div className="self-start max-w-[85%] flex gap-4 w-full mb-8" dir="rtl">
            <div className="w-7 h-7 shrink-0 flex items-center justify-center mt-0.5">
              <span className="text-[#D97757] text-[28px] leading-none animate-spin" style={{ animationDuration: "3s" }}>✺</span>
            </div>
            <div className="flex-1 text-[15px] text-gray-500 pt-1 flex flex-col gap-1.5 font-sans" dir="ltr">
              <div className="flex items-center gap-2">
                <span className="text-[#D97757] animate-pulse">✺</span> Triangulating
              </div>
              <div className="flex items-center gap-2">
                <Globe size={14} /> Searching the web
              </div>
            </div>
          </div>

        </div>
      </div>
      
      <div className="w-full flex justify-center px-4 pb-6 pt-2 bg-gradient-to-t from-white via-white to-transparent">
        <div className="w-full max-w-[800px] bg-white border border-[#E5E5E5] rounded-3xl p-3 shadow-[0_2px_12px_rgba(0,0,0,0.04)] focus-within:ring-[3px] focus-within:ring-[#EFECE5] focus-within:border-transparent transition-all relative">
          <textarea 
            placeholder="Write a message"
            className="w-full bg-transparent outline-none resize-none min-h-[50px] text-[17px] text-gray-800 placeholder-gray-400 px-1 pt-1"
            rows={1}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); if (inputValue.trim().length > 0) { setInputValue(""); } } }}
          ></textarea>
          
          <div className="flex items-center justify-between mt-2">
            <div className="relative">
              <button 
                onClick={() => setIsAttachMenuOpen(!isAttachMenuOpen)}
                className="p-2 text-gray-600 hover:bg-[#FAF9F7] rounded-xl transition-colors border border-transparent hover:border-gray-200"
              >
                <Plus size={20} strokeWidth={2.5} />
              </button>
              
              {isAttachMenuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setIsAttachMenuOpen(false)}></div>
                  <div className="absolute bottom-full left-0 mb-2 w-[280px] bg-white border border-[#E5E5E5] rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] py-1.5 z-50 text-[14px] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-100">
                    <button className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <div className="flex items-center gap-3"><Paperclip size={16} className="text-gray-500" /> Add files or photos</div>
                      <span className="text-[11px] text-gray-400">Ctrl+U</span>
                    </button>
                    <button className="w-full flex items-center gap-3 px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <Camera size={16} className="text-gray-500" /> Take a screenshot
                    </button>
                    <button className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <div className="flex items-center gap-3"><FolderPlus size={16} className="text-gray-500" /> Add to project</div>
                      <span className="text-gray-400 text-lg leading-none">&gt;</span>
                    </button>
                    
                    <div className="h-px bg-gray-100 my-1 mx-3"></div>
                    
                    <button className="w-full flex items-center gap-3 px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <FileCode size={16} className="text-gray-500" /> Skills
                    </button>
                    <button className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <div className="flex items-center gap-3"><Blocks size={16} className="text-gray-500" /> Add connector</div>
                      <span className="text-gray-400 text-lg leading-none">&gt;</span>
                    </button>
                    <button className="w-full flex items-center gap-3 px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <Puzzle size={16} className="text-gray-500" /> Add plugins...
                    </button>
                    
                    <div className="h-px bg-gray-100 my-1 mx-3"></div>
                    
                    <button className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <div className="flex items-center gap-3"><Globe size={16} className="text-gray-500" /> Web search</div>
                      <span className="text-blue-600 font-bold">✓</span>
                    </button>
                  </div>
                </>
              )}
            </div>
            
            <div className="flex items-center gap-1.5">
              <button className="flex items-center gap-1.5 text-[14px] font-medium text-gray-600 hover:bg-[#FAF9F7] px-3 py-1.5 rounded-xl transition-colors border border-transparent hover:border-gray-200">
                Sonnet 5 Medium <span className="text-[10px] text-gray-400">▼</span>
              </button>
              
              <div className="relative flex items-center">
                <button 
                  onMouseEnter={() => setIsMicHovered(true)}
                  onMouseLeave={() => setIsMicHovered(false)}
                  onClick={() => setIsMicActive(!isMicActive)}
                  className={`p-2 rounded-xl transition-all duration-200 flex items-center justify-center ${isMicActive ? "bg-[#DB4437] text-white" : "text-gray-600 hover:bg-[#EFECE5] bg-[#FAF9F7]"}`}
                >
                  <Mic size={18} strokeWidth={2.5} />
                </button>
                
                {isMicHovered && !isMicActive && (
                  <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-black text-white text-[12px] py-1.5 px-3 rounded-md whitespace-nowrap z-50 animate-in fade-in zoom-in-95">
                    Press and hold to record
                  </div>
                )}
              </div>
              
              {inputValue.trim().length > 0 ? (
                <button onClick={() => setInputValue("")} className="p-1 text-white bg-[#D97757] hover:bg-[#C96B4C] rounded-lg transition-colors ml-1 w-8 h-8 flex items-center justify-center shadow-sm">
                  <ArrowUp size={18} strokeWidth={2.5} />
                </button>
              ) : (
                <button className="p-2 text-gray-600 hover:bg-[#FAF9F7] rounded-xl transition-colors border border-transparent hover:border-gray-200">
                  <AudioLines size={18} strokeWidth={2.5} />
                </button>
              )}
            </div>
          </div>
        </div>
        <div className="absolute bottom-2 text-center text-[11px] text-gray-400 w-full">
          Claude is AI and can make mistakes. Please double-check responses.
        </div>
      </div>
    </div>
  );
}
