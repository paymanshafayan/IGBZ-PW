import { Search } from "lucide-react";

export default function Projects() {
  const projects = [
    { title: "cyberpunk", date: "Jul 21" },
    { title: "IGBZ", date: "Jul 20" },
    { title: "free", date: "Jul 19" },
    { title: "GameNetPlatform", date: "Jul 19" },
    { title: "bazino", desc: "طراحی سایت و اپلیکیشن گیم نت", date: "Jul 14" },
  ];

  return (
    <div className="flex-1 bg-white overflow-y-auto px-8 md:px-24 py-16">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-12">
          <h1 className="font-serif text-[32px] font-medium text-[#2C2C2C]">Projects</h1>
          <div className="flex items-center gap-2">
            <button className="p-2 border border-[#E5E5E5] rounded-xl hover:bg-[#FAF9F7] transition-colors shadow-sm">
              <Search size={18} className="text-gray-600" />
            </button>
            <button className="px-4 py-2 text-[14px] font-medium border border-[#E5E5E5] rounded-xl hover:bg-[#FAF9F7] flex items-center gap-2 transition-colors shadow-sm">
              Sort by <span className="font-semibold text-black">Last updated</span> <span className="text-[10px] text-gray-400">▼</span>
            </button>
            <button className="px-4 py-2 text-[14px] font-medium bg-black text-white rounded-xl hover:bg-gray-800 transition-colors shadow-sm">
              New project
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {projects.map((proj, i) => (
            <div key={i} className="border border-[#E5E5E5] rounded-2xl p-6 hover:shadow-[0_4px_12px_rgba(0,0,0,0.05)] hover:border-gray-300 cursor-pointer transition-all duration-200 h-36 flex flex-col justify-between group bg-white">
              <div>
                <h3 className="font-medium text-[16px] text-[#2C2C2C] mb-1">{proj.title}</h3>
                {proj.desc && <p className="text-[13px] text-gray-500 line-clamp-2 mt-1" dir="rtl">{proj.desc}</p>}
              </div>
              <div className="text-[13px] text-gray-500 flex justify-between items-center">
                <span>{proj.date}</span>
                <span className="opacity-0 group-hover:opacity-100 transition-opacity bg-gray-100 p-1.5 rounded-lg text-black">
                   <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
