import { Search, MoreVertical } from "lucide-react";

export default function Chats() {
  const chatList = [
    { title: "سلام و احوالپرسی", date: "4 hours ago" },
    { title: "سلام", date: "yesterday" },
    { title: "نصب Skill از GitHub", date: "Aug 10" },
    { title: "استخراج فایل و بررسی اسناد پروژه", date: "Aug 6", selected: true },
    { title: "بررسی اطلاعات پروژه و راهنما", date: "Aug 6", author: "bazino" },
    { title: "بررسی پروژه وب سایت و نرم افزار گیم نت", date: "Jul 29", author: "bazino" },
    { title: "Greeting", date: "Jul 28" },
    { title: "پیشنهادهای فاز دوم پروژه", date: "Jul 25", author: "IGBZ" },
    { title: "حرفه‌ای برای nopcommerce Web API پلاگین", date: "Jul 24", author: "IGBZ" },
    { title: "پنل سمت راست نمایش داده نمیشود", date: "Jul 24", author: "IGBZ", shared: true },
  ];

  return (
    <div className="flex-1 bg-white overflow-y-auto px-8 md:px-24 py-16">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-12">
          <h1 className="font-serif text-[32px] font-medium text-[#2C2C2C]">Chats</h1>
          <div className="flex items-center gap-2">
            <button className="p-2 border border-[#E5E5E5] rounded-xl hover:bg-[#FAF9F7] transition-colors shadow-sm">
              <Search size={18} className="text-gray-600" />
            </button>
            <button className="px-4 py-2 text-[14px] font-medium border border-[#E5E5E5] rounded-xl hover:bg-[#FAF9F7] flex items-center gap-2 transition-colors shadow-sm">
              Filter by <span className="font-semibold text-black">All</span> <span className="text-[10px] text-gray-400">▼</span>
            </button>
            <button className="px-4 py-2 text-[14px] font-medium border border-[#E5E5E5] rounded-xl hover:bg-[#FAF9F7] transition-colors shadow-sm text-gray-800">
              Select chats
            </button>
            <button className="px-4 py-2 text-[14px] font-medium bg-black text-white rounded-xl hover:bg-gray-800 transition-colors shadow-sm">
              New chat
            </button>
          </div>
        </div>

        <div className="flex flex-col gap-1">
          {chatList.map((chat, i) => (
            <div key={i} className={`group flex items-center justify-between py-3.5 border-b border-gray-100 last:border-0 ${chat.selected ? 'bg-[#FAF9F7] -mx-4 px-4 rounded-xl border-transparent' : 'hover:bg-[#FAF9F7] -mx-4 px-4 rounded-xl transition-colors'}`}>
              <div className="font-medium text-[#2C2C2C] text-[15px] truncate max-w-lg">
                {chat.title}
              </div>
              <div className="flex items-center gap-6 text-[13px] text-gray-500">
                {chat.author && <span>{chat.author}</span>}
                {chat.shared && <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-md font-medium text-[11px] uppercase tracking-wider">Shared</span>}
                <span className="w-24 text-right">{chat.date}</span>
                <button className="opacity-0 group-hover:opacity-100 p-1 hover:bg-[#E5E5E5] rounded-md text-gray-600 transition-opacity">
                  <MoreVertical size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
