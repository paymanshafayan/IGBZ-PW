import { Search } from "lucide-react";

export default function Artifacts() {
  return (
    <div className="flex-1 bg-white overflow-y-auto px-8 md:px-24 py-16 flex flex-col">
      <div className="max-w-5xl mx-auto w-full">
        <div className="flex items-center justify-between mb-16">
          <h1 className="font-serif text-[32px] font-medium text-[#2C2C2C]">Artifacts</h1>
          <div className="flex items-center gap-2">
            <button className="p-2 border border-[#E5E5E5] rounded-xl hover:bg-[#FAF9F7] transition-colors shadow-sm">
              <Search size={18} className="text-gray-600" />
            </button>
            <button className="px-4 py-2 text-[14px] font-medium bg-black text-white rounded-xl hover:bg-gray-800 transition-colors shadow-sm">
              New artifact
            </button>
          </div>
        </div>
        
        <div className="flex flex-col items-center justify-center text-center mt-32">
          <div className="mb-8">
            <svg width="88" height="88" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="25" y="45" width="24" height="30" stroke="#2C2C2C" strokeWidth="2.5" rx="2"/>
              <path d="M55 25 L75 55 H35 Z" stroke="#2C2C2C" strokeWidth="2.5" strokeLinejoin="round"/>
              <circle cx="70" cy="55" r="16" stroke="#2C2C2C" strokeWidth="2.5" fill="white"/>
              <path d="M40 75 V82 C40 86 44 90 48 90 C52 90 56 86 56 82 V55" stroke="#2C2C2C" strokeWidth="2.5" strokeLinecap="round"/>
              <path d="M34 70 V85" stroke="#2C2C2C" strokeWidth="2.5" strokeLinecap="round"/>
              <path d="M25 55 H50" stroke="#2C2C2C" strokeWidth="2.5" strokeLinecap="round"/>
            </svg>
          </div>
          <h2 className="text-[20px] font-medium text-[#2C2C2C] mb-3">What will you build with artifacts?</h2>
          <p className="text-gray-500 max-w-[380px] mb-8 text-[15px] leading-relaxed">
            If you can dream it, you can build it. Take apps, games, templates, and tools from thought to reality.
          </p>
          <button className="px-5 py-2.5 text-[14px] font-medium border border-[#E5E5E5] rounded-xl hover:bg-[#FAF9F7] shadow-sm transition-colors text-[#2C2C2C]">
            New artifact
          </button>
        </div>
      </div>
    </div>
  );
}
