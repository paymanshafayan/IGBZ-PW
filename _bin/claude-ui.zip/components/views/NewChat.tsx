import { Plus, Mic, AudioLines, Paperclip, Camera, FolderPlus, Blocks, Puzzle, Globe, FileCode, ArrowUp } from "lucide-react";
import { useState } from "react";
export default function NewChat({ setCurrentView }: any) {
  const [inputValue, setInputValue] = useState("");
  const [isAttachMenuOpen, setIsAttachMenuOpen] = useState(false);
  const [isMicHovered, setIsMicHovered] = useState(false);
  const [isMicActive, setIsMicActive] = useState(false);

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-white h-full relative">
      <div className="w-full max-w-[700px] px-4 flex flex-col items-center">
        <h2 className="font-serif text-[2.5rem] md:text-[3.25rem] text-[#2C2C2C] mb-8 flex items-center gap-3 tracking-tight font-normal">
          <span className="text-[#D97757] text-4xl md:text-5xl mt-1">✺</span> Hello, night owl
        </h2>
        <div className="w-full bg-white border border-[#E5E5E5] rounded-3xl p-3 shadow-sm focus-within:ring-[3px] focus-within:ring-[#EFECE5] focus-within:border-transparent transition-all relative">
          <textarea 
            placeholder="How can I help you today?"
            className="w-full bg-transparent outline-none resize-none min-h-[70px] text-[17px] text-gray-800 placeholder-gray-400 px-1 pt-1"
            rows={2}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); if (inputValue.trim().length > 0 && setCurrentView) { setCurrentView("chat_view"); } } }}
          ></textarea>
          
          <div className="flex items-center justify-between mt-2">
            <div className="relative">
              <button 
                onClick={() => setIsAttachMenuOpen(!isAttachMenuOpen)}
                className="p-2 text-gray-600 hover:bg-[#FAF9F7] rounded-xl transition-colors border border-transparent hover:border-gray-200"
              >
                <Plus size={20} strokeWidth={2.5} />
              </button>
              
              {isAttachMenuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setIsAttachMenuOpen(false)}></div>
                  <div className="absolute bottom-full left-0 mb-2 w-[280px] bg-white border border-[#E5E5E5] rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] py-1.5 z-50 text-[14px] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-100">
                    <button className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <div className="flex items-center gap-3"><Paperclip size={16} className="text-gray-500" /> Add files or photos</div>
                      <span className="text-[11px] text-gray-400">Ctrl+U</span>
                    </button>
                    <button className="w-full flex items-center gap-3 px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <Camera size={16} className="text-gray-500" /> Take a screenshot
                    </button>
                    <button className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <div className="flex items-center gap-3"><FolderPlus size={16} className="text-gray-500" /> Add to project</div>
                      <span className="text-gray-400 text-lg leading-none">&gt;</span>
                    </button>
                    
                    <div className="h-px bg-gray-100 my-1 mx-3"></div>
                    
                    <button className="w-full flex items-center gap-3 px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <FileCode size={16} className="text-gray-500" /> Skills
                    </button>
                    <button className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <div className="flex items-center gap-3"><Blocks size={16} className="text-gray-500" /> Add connector</div>
                      <span className="text-gray-400 text-lg leading-none">&gt;</span>
                    </button>
                    <button className="w-full flex items-center gap-3 px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <Puzzle size={16} className="text-gray-500" /> Add plugins...
                    </button>
                    
                    <div className="h-px bg-gray-100 my-1 mx-3"></div>
                    
                    <button className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-[#F5F5F5] text-gray-700">
                      <div className="flex items-center gap-3"><Globe size={16} className="text-gray-500" /> Web search</div>
                      <span className="text-blue-600 font-bold">✓</span>
                    </button>
                  </div>
                </>
              )}
            </div>
            
            <div className="flex items-center gap-1.5">
              <button className="flex items-center gap-1.5 text-[14px] font-medium text-gray-600 hover:bg-[#FAF9F7] px-3 py-1.5 rounded-xl transition-colors border border-transparent hover:border-gray-200">
                Sonnet 5 Medium <span className="text-[10px] text-gray-400">▼</span>
              </button>
              
              <div className="relative flex items-center">
                <button 
                  onMouseEnter={() => setIsMicHovered(true)}
                  onMouseLeave={() => setIsMicHovered(false)}
                  onClick={() => setIsMicActive(!isMicActive)}
                  className={`p-2 rounded-xl transition-all duration-200 flex items-center justify-center ${isMicActive ? "bg-[#DB4437] text-white" : "text-gray-600 hover:bg-[#EFECE5] bg-[#FAF9F7]"}`}
                >
                  <Mic size={18} strokeWidth={2.5} />
                </button>
                
                {isMicHovered && !isMicActive && (
                  <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-black text-white text-[12px] py-1.5 px-3 rounded-md whitespace-nowrap z-50 animate-in fade-in zoom-in-95">
                    Press and hold to record
                  </div>
                )}
              </div>
              
              {inputValue.trim().length > 0 ? (
                <button onClick={() => setCurrentView && setCurrentView("chat_view")} className="p-1 text-white bg-[#D97757] hover:bg-[#C96B4C] rounded-lg transition-colors ml-1 w-8 h-8 flex items-center justify-center shadow-sm">
                  <ArrowUp size={18} strokeWidth={2.5} />
                </button>
              ) : (
                <button className="p-2 text-gray-600 hover:bg-[#FAF9F7] rounded-xl transition-colors border border-transparent hover:border-gray-200">
                  <AudioLines size={18} strokeWidth={2.5} />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute top-5 right-6 flex items-center gap-2">
         <span className="text-[13px] font-medium text-black px-3.5 py-1.5 border border-[#E5E5E5] rounded-xl hover:bg-gray-50 cursor-pointer shadow-sm">Open in app</span>
         <span className="text-[13px] font-medium text-black px-3.5 py-1.5 border border-[#E5E5E5] rounded-xl hover:bg-gray-50 cursor-pointer shadow-sm">Upgrade</span>
      </div>
    </div>
  );
}
